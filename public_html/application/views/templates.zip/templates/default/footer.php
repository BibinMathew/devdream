</div>
</div>



	<!-- script references -->
		
		<script src="<?php echo base_url(); ?>css/template/default/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>css/template/default/js/scripts.js"></script>
	</body>
</html>