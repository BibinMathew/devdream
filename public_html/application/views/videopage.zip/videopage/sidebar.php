<div class="videomain uk-grid uk-grid-collapse"> 
    <div class="uk-width-3-10 uk-panel-box-primary">
        <h3 class="uk-panel-title"><i class="uk-icon-film"></i>  Topics</h3>
        
        <div id="treecontainer" class="demo"></div>
         <div id="event_result" > </div>
    </div>