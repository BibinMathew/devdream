   <div class="uk-grid" data-uk-grid-margin style="padding-top: 5%;">
                                <div class="uk-width-medium-1-3">
                                    <div class="uk-panel uk-panel-box">
                                        <h3 class="uk-panel-title"><i class="uk-icon-user"></i> Panel</h3>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </div>
                                </div>
                                <div class="uk-width-medium-1-3">
                                    <div class="uk-panel uk-panel-box">
                                        <h3 class="uk-panel-title"><i class="uk-icon-home"></i> Panel</h3>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </div>
                                </div>
                                <div class="uk-width-medium-1-3">
                                    <div class="uk-panel uk-panel-box">
                                        <h3 class="uk-panel-title"><i class="uk-icon-bookmark"></i> Panel</h3>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </div>
                                </div>
                            </div>
           </div>
	</div>
</body>
</html>