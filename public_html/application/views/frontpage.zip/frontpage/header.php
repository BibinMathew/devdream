<html>
<head>
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/uikit.min.css" />
	<script src="<?php echo base_url(); ?>js/jquery-3.1.1.min.js"></script>
	<script src="<?php echo base_url(); ?>js/uikit.min.js"></script>
	<script src="<?php echo base_url(); ?>js/components/autocomplete.js"></script>
	<script src="<?php echo base_url(); ?>js/dreamjs.js"></script>
</head>
<body>
	<div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
		<nav class="uk-navbar uk-margin-large-bottom">
			<a class="uk-navbar-brand uk-hidden-small" href="layouts_frontpage.html">IDreamIAS</a>
			<ul class="uk-navbar-nav uk-hidden-small">
				<li class="uk-active">
					<a href="layouts_frontpage.html">Home</a>
				</li>
				<li>
					<a href="layouts_portfolio.html">Videos</a>
				</li>
				<li>
					<a href="layouts_blog.html">News</a>
				</li>
				<li>
					<a href="layouts_documentation.html">Articles</a>
				</li>
				<li>
					<a href="layouts_contact.html">Contact</a>
				</li>
				<li>
					<a href="layouts_login.html">Login</a>
				</li>
			</ul>
			<a href="#offcanvas" class="uk-navbar-toggle uk-visible-small" data-uk-offcanvas></a>
			<div class="uk-navbar-brand uk-navbar-center uk-visible-small">Home</div>
			
			<div class="uk-navbar-flip">

			<div class="uk-navbar-content">

			    <div class="uk-autocomplete uk-form uk-margin-remove uk-display-inline-block" data-uk-autocomplete="{source:'json/_results.json'}">
                   <input class="uk-search-field" type="search" placeholder="search">
            </div>
			</div>
		</div>
		</nav>
