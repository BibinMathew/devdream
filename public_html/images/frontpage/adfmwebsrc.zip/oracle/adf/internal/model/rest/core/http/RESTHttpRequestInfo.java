/*    */ package oracle.adf.internal.model.rest.core.http;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod.Type;
/*    */ 
/*    */ 
/*    */ public class RESTHttpRequestInfo
/*    */ {
/*    */   private final String resourcePath;
/*    */   private final HttpMethod.Type httpMethod;
/*    */   private final Map<String, List<String>> headers;
/*    */   
/*    */   public RESTHttpRequestInfo(String resourcePath, HttpMethod.Type httpMethod, Map<String, List<String>> headers)
/*    */   {
/* 16 */     this.resourcePath = resourcePath;
/* 17 */     this.httpMethod = httpMethod;
/* 18 */     this.headers = headers;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 25 */     return "resourcePath = " + this.resourcePath + (this.httpMethod != null ? "; httpMethod = " + this.httpMethod.toString() : "");
/*    */   }
/*    */   
/*    */   public HttpMethod.Type getHttpMethod() {
/* 29 */     return this.httpMethod;
/*    */   }
/*    */   
/*    */   public List<String> getHeader(String headerName) {
/* 33 */     return (List)this.headers.get(headerName);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\RESTHttpRequestInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */