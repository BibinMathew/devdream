/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ 
/*    */ public class TotalResultsParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private Boolean count;
/*    */   
/*    */   public TotalResultsParam(String[] parameterValues)
/*    */   {
/* 11 */     if ((parameterValues != null) && (parameterValues.length > 0) && (parameterValues[0] != null)) {
/* 12 */       this.count = Boolean.valueOf(Boolean.parseBoolean(parameterValues[0]));
/*    */     }
/*    */   }
/*    */   
/*    */   public Boolean getCount() {
/* 17 */     return this.count;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\TotalResultsParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */