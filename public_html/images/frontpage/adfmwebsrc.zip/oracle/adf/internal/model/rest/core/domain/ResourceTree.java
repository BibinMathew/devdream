/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceType;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.DependencyParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.FinderParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.LimitParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ListParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.OrderByParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.QueryParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameter.Type;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap;
/*     */ import oracle.adf.internal.model.rest.core.exception.NonQueriableAttributeException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*     */ import oracle.adf.model.binding.DCBindingContainer;
/*     */ import oracle.adf.model.binding.DCControlBindingDef;
/*     */ import oracle.adf.model.binding.DCDataControl;
/*     */ import oracle.adf.model.binding.DCIteratorBinding;
/*     */ import oracle.adf.model.binding.DCUtil;
/*     */ import oracle.adf.model.rest.RestTypeConverter;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeList;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.Key;
/*     */ import oracle.jbo.NameValuePairs;
/*     */ import oracle.jbo.NavigatableRowIterator;
/*     */ import oracle.jbo.RowIterator;
/*     */ import oracle.jbo.RowSetIterator;
/*     */ import oracle.jbo.SortCriteria;
/*     */ import oracle.jbo.SortCriteriaImpl;
/*     */ import oracle.jbo.ViewCriteria;
/*     */ import oracle.jbo.ViewCriteriaItem;
/*     */ import oracle.jbo.ViewCriteriaItemValue;
/*     */ import oracle.jbo.ViewCriteriaManager;
/*     */ import oracle.jbo.ViewCriteriaRow;
/*     */ import oracle.jbo.ViewObject;
/*     */ import oracle.jbo.common.JboCompOper;
/*     */ import oracle.jbo.common.JboNameUtil;
/*     */ import oracle.jbo.common.JboTypeMap;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
/*     */ import oracle.jbo.uicli.binding.JUFormBinding;
/*     */ import oracle.jbo.uicli.binding.JUIteratorBinding;
/*     */ import oracle.jbo.uicli.binding.JUSearchBindingCustomizer;
/*     */ import oracle.jbo.version.VersionDef;
/*     */ import oracle.jbo.version.VersionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceTree
/*     */ {
/*     */   private final JUCtrlHierBinding tree;
/*     */   private final ResourceCollection rootResource;
/*     */   private List<Key> startingResourceKeyPath;
/*     */   private List<Key> currentResourceKeyPath;
/*     */   private String selectedAttribute;
/*     */   private String startingAttribute;
/*     */   private ResourceParameterMap parameterMap;
/*     */   
/*     */   private static enum Classification
/*     */   {
/*  77 */     CHILD, 
/*  78 */     LOV, 
/*  79 */     ENCLOSURE;
/*     */     
/*     */     private Classification() {}
/*     */     
/*  83 */     public String toString() { return name().toLowerCase(); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  88 */   private static final Map<String, Classification> CLASSIFICATION_MAP = new HashMap(Classification.values().length);
/*     */   
/*     */   static {
/*  91 */     for (Classification classification : Classification.values()) {
/*  92 */       CLASSIFICATION_MAP.put(classification.toString(), classification);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceTree(List<String> resourcePath, VersionDef versionDef)
/*     */   {
/* 103 */     this((String)resourcePath.get(1), versionDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceTree(String resName, VersionDef versionDef)
/*     */   {
/* 112 */     JUFormBinding resource = VersionResolver.resolveVersionedResource(versionDef, resName);
/* 113 */     if (resource == null) {
/* 114 */       StringBuilder msg = new StringBuilder("The resource definition could not be found. Resource: ");
/* 115 */       msg.append(resName);
/* 116 */       if (versionDef != null) {
/* 117 */         msg.append(" [Version: ");
/* 118 */         msg.append(versionDef.getDisplayName());
/* 119 */         msg.append("]");
/*     */       }
/* 121 */       throw new ResourceNotFoundException(msg.toString());
/*     */     }
/* 123 */     if (!resource.isRefreshed()) {
/* 124 */       resource.refresh(-1);
/*     */     }
/*     */     
/* 127 */     this.tree = findTree(resName, resource);
/* 128 */     if (this.tree == null) {
/* 129 */       StringBuilder msg = new StringBuilder("The resource could not be found, either because it has been removed, or its configuration is invalid. Resource: ");
/*     */       
/* 131 */       msg.append(resName);
/* 132 */       if (versionDef != null) {
/* 133 */         msg.append(" [Version: ");
/* 134 */         msg.append(versionDef.getDisplayName());
/* 135 */         msg.append("]");
/*     */       }
/* 137 */       throw new ResourceNotFoundException(msg.toString());
/*     */     }
/* 139 */     this.rootResource = new ResourceCollection(this, this.tree.getRootNodeBinding());
/*     */   }
/*     */   
/*     */   private ResourceTree(JUCtrlHierBinding tree) {
/* 143 */     this.tree = tree;
/* 144 */     this.rootResource = new ResourceCollection(this, this.tree.getRootNodeBinding());
/*     */   }
/*     */   
/*     */   private static JUCtrlHierBinding findTree(String resName, JUFormBinding resource) {
/* 148 */     JUCtrlHierBinding tree = (JUCtrlHierBinding)resource.findCtrlBinding(JboNameUtil.getLastPartOfName(resName));
/* 149 */     if (tree != null)
/*     */     {
/* 151 */       DCUtil.executeEmptyRowSet(tree.getIteratorBinding());
/*     */     }
/*     */     
/* 154 */     return tree;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ResourceTree createTree(String resName, VersionDef versionDef)
/*     */   {
/* 165 */     JUFormBinding resource = VersionResolver.resolveVersionedResource(versionDef, resName);
/* 166 */     if (resource == null) {
/* 167 */       throw new IllegalArgumentException("Resource definition not found. Resource name: " + resName + (versionDef != null ? ", Version: " + versionDef.getDisplayName() : ", Version: null"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 173 */     resource.refresh();
/* 174 */     JUCtrlHierBinding tree = findTree(resName, resource);
/* 175 */     if (tree == null) {
/* 176 */       throw new IllegalArgumentException("JUCtrlHierBinding not found. Resource name: " + resName + (versionDef != null ? ", Version: " + versionDef.getDisplayName() : ", Version: null"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 181 */     return new ResourceTree(tree);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ViewObject getViewObject(VersionDef versionDef, String topLevelResourceName)
/*     */   {
/* 193 */     ResourceTree tree = createTree(topLevelResourceName, versionDef);
/* 194 */     return tree.getRootResource().getVO();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   JUCtrlHierTypeBinding getTypeBinding(Resource parent, String accessor)
/*     */   {
/* 204 */     return this.tree.lookupTypeBinding(parent.getVO(), parent.getNode().getRow(), accessor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   JUCtrlHierTypeBinding getTypeBinding(ViewObject parentVO, String accessor)
/*     */   {
/* 214 */     return this.tree.lookupTypeBinding(parentVO, null, accessor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(List<String> resourcePath, ResourceParameterMap parameterMap, boolean processDependencies)
/*     */   {
/* 226 */     if (this.startingResourceKeyPath != null) {
/* 227 */       throw new JboException("The starting node was already configured.");
/*     */     }
/*     */     
/* 230 */     this.parameterMap = parameterMap;
/*     */     
/* 232 */     Resource resource = configureTreeNode(resourcePath);
/*     */     
/* 234 */     this.startingResourceKeyPath = resource.getKeyPath();
/* 235 */     this.currentResourceKeyPath = this.startingResourceKeyPath;
/*     */     
/* 237 */     if (processDependencies) {
/* 238 */       DependencyParam dependencyParam = (DependencyParam)ResourceParameter.Type.DEPENDENCY.castTo(parameterMap.get(ResourceParameter.Type.DEPENDENCY));
/* 239 */       configureDependencies(resource, dependencyParam.getParameters());
/*     */     }
/*     */     
/* 242 */     if (resource.isCollection()) {
/* 243 */       resource.getNode().getChildIteratorBinding().getRowSetIterator().setIterMode(0);
/* 244 */       filterCollection(ResourceCollection.asCollection(resource), parameterMap);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Resource configureTreeNode(List<String> resourcePath)
/*     */   {
/* 256 */     Queue<String> tokens = new LinkedList(resourcePath.subList(2, resourcePath.size()));
/* 257 */     Resource resource = processPathForCollection(this.rootResource, tokens);
/*     */     
/* 259 */     if (!resource.isRoot())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 264 */       resource.getNode().getBindings();
/*     */     }
/*     */     
/* 267 */     return resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Resource processPathClassification(Resource resource, Classification classification, Queue<String> tokens)
/*     */   {
/* 282 */     if (tokens.isEmpty()) {
/* 283 */       throw new ResourceNotFoundException("Cannot access the folder: " + classification.toString());
/*     */     }
/*     */     
/* 286 */     String token = (String)tokens.remove();
/* 287 */     Resource selectedResource = null;
/* 288 */     switch (classification)
/*     */     {
/*     */     case ENCLOSURE: 
/* 291 */       Attribute attr = resource.getAttribute(token);
/* 292 */       if (attr == null) {
/* 293 */         throw new ResourceNotFoundException("The attribute specified in the path could not be found.");
/*     */       }
/*     */       
/* 296 */       if (!tokens.isEmpty()) {
/* 297 */         throw new ResourceNotFoundException("The resource path indicates an enclosure, however, it contains additional tokens: " + tokens.toString());
/*     */       }
/* 299 */       this.startingAttribute = token;
/* 300 */       this.selectedAttribute = this.startingAttribute;
/* 301 */       selectedResource = resource;
/*     */       
/* 303 */       break;
/*     */     
/*     */     case LOV: 
/*     */     case CHILD: 
/* 307 */       if (classification == Classification.LOV) {
/* 308 */         if (resource.isLOV()) {
/* 309 */           throw new ResourceNotFoundException("LOV not found. LOV name: " + token);
/*     */         }
/*     */       } else {
/* 312 */         if (resource.isLOV()) {
/* 313 */           throw new ResourceNotFoundException("Nested Resource is not a child. Nested resource name: " + token);
/*     */         }
/* 315 */         if (!resource.isAccessorAttribute(token)) {
/* 316 */           throw new ResourceNotFoundException("The nested resource could not be found. Nested resource Name: " + token + " Current KeyPath: " + resource.getKeyPath().toString());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 321 */       ResourceCollection resourceCollection = ResourceItem.asItem(resource).getChild(token);
/* 322 */       selectedResource = processPathForCollection(resourceCollection, tokens);
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 327 */     return selectedResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Resource processPathForItem(Resource resource, Queue<String> tokens)
/*     */   {
/* 340 */     if (tokens.isEmpty()) {
/* 341 */       return resource;
/*     */     }
/*     */     
/* 344 */     String token = (String)tokens.remove();
/* 345 */     Classification classification = (Classification)CLASSIFICATION_MAP.get(token);
/*     */     
/* 347 */     if (classification != null) {
/* 348 */       return processPathClassification(resource, classification, tokens);
/*     */     }
/*     */     
/* 351 */     throw new ResourceNotFoundException("The folder specified in the path is not part of the available classifications. Classifications: " + CLASSIFICATION_MAP.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Resource processPathForCollection(ResourceCollection resourceCollection, Queue<String> tokens)
/*     */   {
/* 365 */     if (tokens.isEmpty()) {
/* 366 */       return resourceCollection;
/*     */     }
/*     */     
/* 369 */     String token = (String)tokens.remove();
/* 370 */     Classification classification = (Classification)CLASSIFICATION_MAP.get(token);
/*     */     
/* 372 */     if (classification != null) {
/* 373 */       return processPathClassification(resourceCollection, classification, tokens);
/*     */     }
/*     */     
/* 376 */     Key key = null;
/*     */     try {
/* 378 */       key = resourceCollection.createChildKey(token);
/*     */     } catch (Exception e) {
/* 380 */       throw new ResourceNotFoundException(e);
/*     */     }
/* 382 */     Resource nextResource = null;
/* 383 */     if (key != null) {
/* 384 */       nextResource = resourceCollection.getChild(key);
/*     */     }
/*     */     
/* 387 */     if (nextResource == null) {
/* 388 */       throw new ResourceNotFoundException("Could not find the element in the tree. KeyString: " + token + " KeyPath: " + resourceCollection.getKeyPath().toString());
/*     */     }
/*     */     
/*     */ 
/* 392 */     return processPathForItem(nextResource, tokens);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void filterCollection(ResourceCollection resource, ResourceParameterMap parameterMap)
/*     */   {
/* 403 */     JUCtrlHierNodeBinding treeNode = resource.getNode();
/* 404 */     DCIteratorBinding childIteratorBinding = treeNode.getChildIteratorBinding();
/*     */     
/*     */ 
/*     */ 
/* 408 */     int limit = childIteratorBinding.getRangeSize();
/* 409 */     LimitParam limitParam = (LimitParam)ResourceParameter.Type.LIMIT.castTo(parameterMap.get(ResourceParameter.Type.LIMIT));
/* 410 */     if (limitParam != null) {
/* 411 */       limit = limitParam.getLimit().intValue();
/*     */     }
/* 413 */     else if (limit == -1) {
/* 414 */       FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 415 */       limit = resource.getDefaultLimit();
/* 416 */       logger.warning("The range size is not configured and ?limit was not provided, using: " + limit);
/*     */     }
/*     */     
/*     */ 
/* 420 */     resource.setLimit(limit);
/*     */     
/* 422 */     QueryParam queryParam = (QueryParam)ResourceParameter.Type.QUERY.castTo(parameterMap.get(ResourceParameter.Type.QUERY));
/* 423 */     applyViewCriteria(queryParam, childIteratorBinding);
/*     */     
/* 425 */     OrderByParam orderByParam = (OrderByParam)ResourceParameter.Type.ORDER_BY.castTo(parameterMap.get(ResourceParameter.Type.ORDER_BY));
/*     */     
/* 427 */     applySortCriteria(orderByParam, childIteratorBinding);
/*     */     
/* 429 */     FinderParam finderParam = (FinderParam)ResourceParameter.Type.FINDER.castTo(parameterMap.get(ResourceParameter.Type.FINDER));
/* 430 */     if (finderParam != null) {
/* 431 */       Finder finder = resource.getFinder(finderParam.getName());
/*     */       
/* 433 */       if (finder == null) {
/* 434 */         throw new JboException("Could not obtain the finder. Check if it is enabled for this resource. Finder name: " + finderParam.getName());
/*     */       }
/*     */       
/*     */ 
/* 438 */       Map<String, String> finderParameters = finderParam.getParameters();
/* 439 */       Map<String, Attribute> finderAttributeMap = finder.getAttributeMap();
/* 440 */       NameValuePairs childKeyAttributes = new NameValuePairs(finderParameters.size());
/* 441 */       for (Map.Entry<String, String> entry : finderParameters.entrySet()) {
/* 442 */         String attributeName = (String)entry.getKey();
/* 443 */         Attribute attribute = (Attribute)finderAttributeMap.get(attributeName);
/*     */         
/*     */ 
/* 446 */         if (attribute == null)
/*     */         {
/* 448 */           throw new JboException("Could not find attribute: " + attributeName + " in Finder parameters map. Finder name: " + finderParam.getName());
/*     */         }
/*     */         
/*     */ 
/* 452 */         Object attributeValue = Attribute.convertValueToAttributeType(attribute, (String)entry.getValue());
/* 453 */         childKeyAttributes.setAttribute(attributeName, attributeValue);
/*     */       }
/* 455 */       resource.prepareVOForQuery();
/* 456 */       RowIterator iterator = resource.executeRowFinder(finder.getRowFinder(), childKeyAttributes);
/* 457 */       childIteratorBinding.bindRowSetIterator((NavigatableRowIterator)iterator, false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceCollection seekChildResourceCollection(String childName)
/*     */   {
/* 468 */     ResourceItem resourceItem = ResourceItem.asItem(getCurrentResource());
/* 469 */     if (resourceItem == null) {
/* 470 */       return null;
/*     */     }
/* 472 */     ResourceCollection collectionResource = resourceItem.getChild(childName);
/* 473 */     if (collectionResource != null) {
/* 474 */       setCurrentResource(collectionResource);
/*     */     }
/* 476 */     return collectionResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentResource(Resource resource)
/*     */   {
/* 485 */     setCurrentResource(resource.getNode().getKeyPath());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setCurrentResource(List<Key> resourceKeyPath)
/*     */   {
/* 493 */     if (resourceKeyPath == null) {
/* 494 */       this.currentResourceKeyPath = null;
/*     */     } else {
/* 496 */       this.currentResourceKeyPath = new ArrayList(resourceKeyPath);
/*     */     }
/*     */     
/* 499 */     this.selectedAttribute = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceItem seekChildResource(SearchAttributes searchAttributes)
/*     */   {
/* 511 */     ResourceItem resource = findChildResource(this.currentResourceKeyPath, searchAttributes);
/* 512 */     if (resource == null) {
/* 513 */       return null;
/*     */     }
/*     */     
/* 516 */     setCurrentResource(resource);
/* 517 */     return resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceItem createChildResource(Map<String, Object> attributes)
/*     */   {
/* 527 */     ResourceCollection resourceCollection = ResourceCollection.asCollection(getCurrentResource());
/*     */     
/* 529 */     if (resourceCollection == null) {
/* 530 */       return null;
/*     */     }
/*     */     
/* 533 */     ResourceItem resource = resourceCollection.createChild(attributes);
/* 534 */     if (resource != null) {
/* 535 */       setCurrentResource(resource);
/*     */     }
/* 537 */     return resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static DCBindingContainer getBindingContainer(ResourceTree resourceTree)
/*     */   {
/* 549 */     return resourceTree.tree.getBindingContainer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void commitTransaction()
/*     */   {
/* 556 */     this.tree.getIteratorBinding().getDataControl().callCommitTransaction();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void rollbackTransaction()
/*     */   {
/* 563 */     this.tree.getIteratorBinding().getDataControl().callRollbackTransaction();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource getRootResource()
/*     */   {
/* 571 */     return this.rootResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   ListParam getListParam()
/*     */   {
/* 579 */     if (this.parameterMap != null) {
/* 580 */       return (ListParam)ResourceParameter.Type.FIELDS.castTo(this.parameterMap.get(ResourceParameter.Type.FIELDS));
/*     */     }
/* 582 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource getStartingResource()
/*     */   {
/* 592 */     return findResourceByKeyPath(this.startingResourceKeyPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource getCurrentResource()
/*     */   {
/* 600 */     if (this.currentResourceKeyPath == null) {
/* 601 */       return null;
/*     */     }
/* 603 */     return findResourceByKeyPath(this.currentResourceKeyPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceType getResourceType()
/*     */   {
/* 611 */     if (this.selectedAttribute != null) {
/* 612 */       return ResourceType.ATTACHMENT;
/*     */     }
/*     */     
/* 615 */     if (getCurrentResource().isCollection()) {
/* 616 */       return ResourceType.RESOURCE_COLLECTION;
/*     */     }
/* 618 */     return ResourceType.RESOURCE_ITEM;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSelectedAttributeName()
/*     */   {
/* 626 */     return this.selectedAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attribute getSelectedAttribute()
/*     */   {
/* 634 */     Resource currentResource = getCurrentResource();
/*     */     
/* 636 */     Attribute attr = null;
/* 637 */     if ((this.selectedAttribute != null) && (currentResource != null)) {
/* 638 */       attr = currentResource.getAttribute(this.selectedAttribute);
/*     */     }
/* 640 */     return attr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource resetCurrentResource()
/*     */   {
/* 649 */     setCurrentResource(this.startingResourceKeyPath);
/* 650 */     this.selectedAttribute = this.startingAttribute;
/* 651 */     return findResourceByKeyPath(this.startingResourceKeyPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   JUCtrlHierBinding getTree()
/*     */   {
/* 663 */     return this.tree;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 671 */     return this.tree.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object getProperty(String propertyName)
/*     */   {
/* 680 */     return getProperty(this.tree, propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object getProperty(JUCtrlHierBinding tree, String propertyName)
/*     */   {
/* 691 */     return tree.getDef().getProperties().get(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static Object getTreeProperty(JUCtrlHierBinding tree, String propertyName)
/*     */   {
/* 699 */     return tree.getDef().getProperties().get(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource findResourceByKeyPath(List<Key> resourceKeyPath)
/*     */   {
/* 708 */     if (resourceKeyPath == null) {
/* 709 */       return null;
/*     */     }
/*     */     
/* 712 */     JUCtrlHierNodeBinding treeNode = null;
/* 713 */     int size = resourceKeyPath.size();
/*     */     
/* 715 */     treeNode = this.tree.findNodeByKeyPath(resourceKeyPath);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 724 */     if ((treeNode == null) && (size > 1)) {
/* 725 */       treeNode = findRecreateKeyPath(resourceKeyPath);
/*     */     }
/* 727 */     if (treeNode == null) {
/* 728 */       return null;
/*     */     }
/*     */     
/* 731 */     return Resource.isCollection(treeNode) ? new ResourceCollection(this, treeNode) : new ResourceItem(this, treeNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JUCtrlHierNodeBinding findRecreateKeyPath(List<Key> resourceKeyPath)
/*     */   {
/* 742 */     JUCtrlHierNodeBinding treeNode = null;
/*     */     
/* 744 */     List<Key> itemKeyPath = null;
/*     */     
/* 746 */     boolean isAccessor = resourceKeyPath.size() % 2 == 0;
/*     */     
/* 748 */     if (isAccessor) {
/* 749 */       itemKeyPath = resourceKeyPath.subList(0, resourceKeyPath.size() - 1);
/*     */     }
/*     */     else {
/* 752 */       itemKeyPath = resourceKeyPath;
/*     */     }
/*     */     
/* 755 */     int index = itemKeyPath.size() - 1;
/* 756 */     int lastIndex = index;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 761 */     for (int i = index; i >= 0; i -= 2)
/*     */     {
/* 763 */       Key childKey = (Key)itemKeyPath.get(i);
/*     */       
/* 765 */       if (i == 0)
/*     */       {
/* 767 */         treeNode = this.tree.findNodeByKeyPath(itemKeyPath.subList(0, 1));
/*     */       }
/*     */       else {
/* 770 */         List accessorKeyPath = itemKeyPath.subList(0, i);
/* 771 */         JUCtrlHierNodeBinding accessorNode = this.tree.findNodeByKeyPath(accessorKeyPath);
/*     */         
/* 773 */         if (accessorNode != null)
/*     */         {
/* 775 */           treeNode = ResourceCollection.findChildNode(accessorNode, childKey);
/* 776 */           if (i == lastIndex) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 782 */       if (treeNode != null) {
/* 783 */         return reconstructTree(itemKeyPath, i + 2);
/*     */       }
/*     */     }
/* 786 */     if ((isAccessor) && (treeNode != null)) {
/* 787 */       treeNode = this.tree.findNodeByKeyPath(resourceKeyPath);
/*     */     }
/*     */     
/* 790 */     return treeNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JUCtrlHierNodeBinding reconstructTree(List<Key> resourceKeyPath, int index)
/*     */   {
/* 801 */     int size = resourceKeyPath.size();
/* 802 */     JUCtrlHierNodeBinding treeNode = null;
/* 803 */     for (int i = index; i < size; i += 2) {
/* 804 */       Key childKey = (Key)resourceKeyPath.get(i);
/* 805 */       List accessorKeyPath = resourceKeyPath.subList(0, i);
/* 806 */       JUCtrlHierNodeBinding accessorNode = this.tree.findNodeByKeyPath(accessorKeyPath);
/* 807 */       if (accessorNode != null) {
/* 808 */         treeNode = ResourceCollection.findChildNode(accessorNode, childKey);
/* 809 */         if (treeNode == null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 814 */     return treeNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceItem findChildResource(List<Key> parentKeyPath, SearchAttributes childSearchAttributes)
/*     */   {
/* 825 */     ResourceCollection resourceCollection = ResourceCollection.asCollection(findResourceByKeyPath(parentKeyPath));
/*     */     
/* 827 */     if (resourceCollection == null) {
/* 828 */       throw new JboException("Cannot find a child resource for a resource that is not a resource collection. Parent key path: " + parentKeyPath);
/*     */     }
/*     */     
/* 831 */     Key childKey = null;
/*     */     try {
/* 833 */       childKey = resourceCollection.createChildKey(childSearchAttributes);
/*     */     } catch (Exception e) {
/* 835 */       throw new ResourceNotFoundException(e);
/*     */     }
/*     */     
/* 838 */     if (childKey == null) {
/* 839 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 841 */       AttributeList attrList = childSearchAttributes.getSearchAttributeList();
/* 842 */       String[] attrNames = attrList.getAttributeNames();
/* 843 */       Object[] attrValues = attrList.getAttributeValues();
/*     */       
/* 845 */       for (int i = 0; i < attrList.getAttributeCount(); i++) {
/* 846 */         sb.append(attrNames[i]).append("=").append(attrValues[i]).append(",");
/*     */       }
/*     */       
/* 849 */       throw new ResourceNotFoundException("Parent path: " + parentKeyPath + " AttributeList: " + sb);
/*     */     }
/*     */     
/* 852 */     return resourceCollection.getChild(childKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void configureDependencies(Resource resource, Map<String, String> dependencies)
/*     */   {
/* 867 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 868 */     logger.beginActivity(Level.FINE, "Configuring dependencies");
/*     */     try {
/* 870 */       if (resource.isRoot()) {
/* 871 */         logger.fine("The provided resource is root. Cannot set the dependencies.");
/*     */       }
/*     */       else
/*     */       {
/* 875 */         resourceItem = resource;
/* 876 */         if (resource.isCollection()) {
/* 877 */           resourceItem = resource.getParent();
/*     */         }
/* 879 */         for (Map.Entry<String, String> entry : dependencies.entrySet()) {
/* 880 */           String attributeName = (String)entry.getKey();
/* 881 */           Attribute attribute = resourceItem.getAttribute(attributeName);
/* 882 */           if (attribute != null) {
/* 883 */             String value = (String)entry.getValue();
/* 884 */             attribute.setValue(value);
/* 885 */             logger.finest("Dependency set: " + attributeName + " = " + value);
/*     */           } else {
/* 887 */             logger.fine("Attribute not found: " + attributeName);
/*     */           }
/*     */         }
/*     */       } } finally { Resource resourceItem;
/* 891 */       logger.endCurrentActivity();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean applyViewCriteria(QueryParam queryParam, DCIteratorBinding iteratorBinding)
/*     */   {
/* 905 */     if (queryParam == null) {
/* 906 */       return false;
/*     */     }
/* 908 */     ViewCriteria vc = JUSearchBindingCustomizer.findOrCreateFilterCriteria(iteratorBinding, null);
/* 909 */     vc.forceFiltering(true);
/*     */     
/* 911 */     AttributeDef[] attributeDefs = iteratorBinding.getAttributeDefs();
/*     */     
/* 913 */     Set<String> attributeNames = new HashSet(attributeDefs.length);
/* 914 */     for (AttributeDef attributeDef : attributeDefs) {
/* 915 */       attributeNames.add(attributeDef.getName());
/*     */     }
/*     */     
/*     */ 
/* 919 */     HashMap<String, String> createQueryMap = queryParam.createQueryMap(attributeNames);
/* 920 */     List<String> nonQueriableAttrs = null;
/* 921 */     if ((createQueryMap != null) && (createQueryMap.size() > 0))
/*     */     {
/* 923 */       ViewCriteriaRow row = (ViewCriteriaRow)vc.get(0);
/*     */       
/* 925 */       for (Map.Entry<String, String> entry : createQueryMap.entrySet()) {
/* 926 */         ViewCriteriaItem item = row.ensureCriteriaItem((String)entry.getKey());
/* 927 */         ViewCriteriaItemValue itemValue = (ViewCriteriaItemValue)item.getValues().get(0);
/* 928 */         if (ViewCriteriaRow.isItemSearchable(item, getTree().getLocaleContext())) {
/* 929 */           itemValue.setSearchValue(entry.getValue());
/*     */         } else {
/* 931 */           if (nonQueriableAttrs == null) {
/* 932 */             nonQueriableAttrs = new ArrayList();
/*     */           }
/* 934 */           nonQueriableAttrs.add(entry.getKey());
/*     */         }
/* 936 */         AttributeDef attrDef = item.getAttributeDef();
/* 937 */         if ((JboTypeMap.isDateType(attrDef.getSQLType())) && (item.getCompOper().isRelationalOperator())) {
/* 938 */           String strValue = (String)itemValue.getValue();
/* 939 */           Object dateTime = RestTypeConverter.toJavaType(strValue, attrDef.getJavaType());
/* 940 */           itemValue.setValue(dateTime);
/*     */         }
/*     */       }
/* 943 */       if ((nonQueriableAttrs != null) && (nonQueriableAttrs.size() > 0)) {
/* 944 */         throw new NonQueriableAttributeException(nonQueriableAttrs);
/*     */       }
/*     */     } else {
/* 947 */       throw new JboException("The query parameter was provided but it could not be processed. Query: " + queryParam.getQuery());
/*     */     }
/*     */     
/*     */ 
/* 951 */     vc.setCriteriaMode(ViewCriteria.CRITERIA_MODE_CACHE | ViewCriteria.CRITERIA_MODE_QUERY);
/*     */     
/* 953 */     iteratorBinding.getViewObject().getViewCriteriaManager().applyViewCriteria(vc, true);
/* 954 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean applySortCriteria(OrderByParam orderByParam, DCIteratorBinding iteratorBinding)
/*     */   {
/* 964 */     if (orderByParam == null) {
/* 965 */       return false;
/*     */     }
/*     */     
/* 968 */     Map<String, Boolean> map = orderByParam.getParameters();
/* 969 */     SortCriteria[] sortCriterias = new SortCriteria[map.size()];
/* 970 */     int i = 0;
/* 971 */     for (Map.Entry<String, Boolean> entry : map.entrySet()) {
/* 972 */       Boolean desc = (Boolean)entry.getValue();
/* 973 */       if (desc != null) {
/* 974 */         sortCriterias[i] = new SortCriteriaImpl((String)entry.getKey(), desc.booleanValue());
/*     */       } else {
/* 976 */         sortCriterias[i] = new SortCriteriaImpl((String)entry.getKey());
/*     */       }
/* 978 */       i++;
/*     */     }
/* 980 */     iteratorBinding.getViewObject().setOrderByOrSortBy(sortCriterias);
/* 981 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void deleteResource()
/*     */   {
/* 988 */     ResourceItem resource = ResourceItem.asItem(getCurrentResource());
/*     */     
/* 990 */     if (resource == null) {
/* 991 */       throw new IllegalStateException("Can only delete delete resource instance");
/*     */     }
/*     */     
/* 994 */     Resource nextCurrentResource = resource.getParent();
/* 995 */     resource.delete();
/* 996 */     setCurrentResource(nextCurrentResource);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */