/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ 
/*    */ public final class GetAction extends Action
/*    */ {
/*    */   GetAction(ResourceEntityType responseEntityType)
/*    */   {
/*  9 */     super(responseEntityType == ResourceEntityType.RESOURCEITEM ? ActionType.GET_ITEM : ActionType.GET_COLLECTION);
/*    */   }
/*    */   
/*    */ 
/*    */   void bindToResource(Resource resource) {}
/*    */   
/*    */ 
/*    */   public boolean isEnabled()
/*    */   {
/* 18 */     return true;
/*    */   }
/*    */   
/*    */   public boolean producesActionResult()
/*    */   {
/* 23 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\GetAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */