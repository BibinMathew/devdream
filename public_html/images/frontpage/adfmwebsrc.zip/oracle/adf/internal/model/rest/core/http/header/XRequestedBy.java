/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ 
/*    */ public class XRequestedBy
/*    */   implements Header
/*    */ {
/*    */   public static final String NAME = "X-Requested-By";
/*    */   
/*    */ 
/*    */   public String getName()
/*    */   {
/* 12 */     return "X-Requested-By";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\XRequestedBy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */