/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.http.operation.HTTPOperationFactory;
/*    */ import oracle.adf.internal.model.rest.core.operation.DefaultOperationFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperationFactory
/*    */ {
/*    */   public static Operation createOperation(ResourceType resourceType, OperationType operationType)
/*    */   {
/* 13 */     Operation operation = null;
/*    */     
/* 15 */     switch (operationType)
/*    */     {
/*    */     case DESCRIPTION: 
/* 18 */       operation = HTTPOperationFactory.createOperation(resourceType, operationType);
/* 19 */       break;
/*    */     
/*    */ 
/*    */     default: 
/* 23 */       operation = DefaultOperationFactory.createOperation(resourceType, operationType);
/*    */     }
/*    */     
/*    */     
/*    */ 
/* 28 */     return operation;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\OperationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */