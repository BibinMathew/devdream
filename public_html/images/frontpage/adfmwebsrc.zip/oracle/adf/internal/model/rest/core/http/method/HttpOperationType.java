/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HttpOperationType
/*    */ {
/* 15 */   BATCH, 
/*    */   
/*    */ 
/*    */ 
/* 19 */   RESOURCE;
/*    */   
/*    */   private OperationType operation;
/*    */   
/*    */   private HttpOperationType() {}
/*    */   
/*    */   public void setOperation(OperationType operation)
/*    */   {
/* 27 */     this.operation = operation;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OperationType getOperation()
/*    */   {
/* 35 */     return this.operation;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\HttpOperationType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */