/*    */ package oracle.adf.internal.model.rest.core.exception;
/*    */ 
/*    */ import oracle.jbo.CSMessageBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionNotFoundException
/*    */   extends BadRequestException
/*    */ {
/*    */   public ActionNotFoundException(String resourceName, String actionName)
/*    */   {
/* 17 */     super(CSMessageBundle.class, "27501", new Object[] { resourceName, actionName });
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\exception\ActionNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */