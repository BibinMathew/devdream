package oracle.adf.internal.model.rest.core.common;

import oracle.adf.internal.model.rest.core.domain.ActionType;
import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;

public abstract interface Operation
{
  public abstract boolean isDependentOnResource();
  
  public abstract void processPrecondition(ResourceProcessingContext paramResourceProcessingContext)
    throws Exception;
  
  public abstract void init(ResourceProcessingContext paramResourceProcessingContext)
    throws Exception;
  
  public abstract void applyInputValues(ResourceProcessingContext paramResourceProcessingContext)
    throws Exception;
  
  public abstract void execute(ResourceProcessingContext paramResourceProcessingContext)
    throws Exception;
  
  public abstract void validateInputValues(ResourceProcessingContext paramResourceProcessingContext)
    throws Exception;
  
  public abstract void generateResponse(ResourceProcessingContext paramResourceProcessingContext)
    throws Exception;
  
  public abstract void setResponseHandler(ResponseHandler paramResponseHandler);
  
  public abstract ResponseHandler getResponseHandler();
  
  public abstract boolean isCommitNeeded();
  
  public abstract boolean isAuthorized(ResourceProcessingContext paramResourceProcessingContext);
  
  public abstract String getSecurityName();
  
  public abstract void prepareResponse(ResourceProcessingContext paramResourceProcessingContext);
  
  public abstract ResourceEntityType getResponseEntityType();
  
  public abstract boolean isCreatingResource();
  
  public abstract OperationType getOperationType();
  
  public abstract ActionType getActionType();
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\Operation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */