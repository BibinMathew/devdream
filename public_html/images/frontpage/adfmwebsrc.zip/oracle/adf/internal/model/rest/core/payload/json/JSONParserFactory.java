/*    */ package oracle.adf.internal.model.rest.core.payload.json;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceTreeManager;
/*    */ import oracle.adf.internal.model.rest.core.payload.ActionParser;
/*    */ import oracle.adf.internal.model.rest.core.payload.BatchRequestParser;
/*    */ import oracle.adf.internal.model.rest.core.payload.ParserFactory;
/*    */ import oracle.adf.internal.model.rest.core.payload.ResourceParser;
/*    */ import org.codehaus.jackson.JsonFactory;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.map.ObjectMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JSONParserFactory
/*    */   extends ParserFactory
/*    */ {
/* 23 */   private static final JsonFactory JSON_FACTORY = new JsonFactory();
/* 24 */   private static final ObjectMapper MAPPER = new ObjectMapper(JSON_FACTORY);
/* 25 */   private JsonParser jp = null;
/*    */   
/*    */   public JSONParserFactory(Reader reader) throws IOException {
/* 28 */     this.jp = JSON_FACTORY.createJsonParser(reader);
/*    */   }
/*    */   
/*    */   public JSONParserFactory(InputStream inputStream) throws IOException {
/* 32 */     this.jp = JSON_FACTORY.createJsonParser(inputStream);
/*    */   }
/*    */   
/*    */   public ActionParser getActionParser()
/*    */   {
/* 37 */     return new JSONActionParser(this.jp);
/*    */   }
/*    */   
/*    */   public BatchRequestParser getBatchRequestParser()
/*    */   {
/* 42 */     return new JSONBatchRequestParser(MAPPER, this.jp);
/*    */   }
/*    */   
/*    */   public ResourceParser getResourceParser(ResourceTreeManager resourceTreeManager)
/*    */   {
/* 47 */     return new JSONResourceParser(MAPPER, this.jp, resourceTreeManager);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\json\JSONParserFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */