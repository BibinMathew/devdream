/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpandParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private static final String ALL_ACCESSORS = "all";
/*    */   private static final String ACCESSOR_SEPARATOR = ",";
/*    */   private final boolean expandAllFirstLevelAccessorsEnabled;
/*    */   private final Set<String> accessorsToExpand;
/*    */   
/*    */   public ExpandParam(String[] parameterValues)
/*    */   {
/* 19 */     boolean expandAll = false;
/* 20 */     Set<String> accessors = Collections.emptySet();
/* 21 */     if ((parameterValues != null) && (parameterValues.length > 0) && (parameterValues[0] != null)) {
/* 22 */       String expand = parameterValues[0];
/* 23 */       if (expand.equals("all")) {
/* 24 */         expandAll = true;
/*    */       } else {
/* 26 */         accessors = createAccessorsSet(expand.split(","));
/*    */       }
/*    */     }
/* 29 */     this.accessorsToExpand = Collections.unmodifiableSet(accessors);
/* 30 */     this.expandAllFirstLevelAccessorsEnabled = expandAll;
/*    */   }
/*    */   
/*    */   private Set<String> createAccessorsSet(String[] accessorsArray) {
/* 34 */     Set<String> accessors = new HashSet();
/* 35 */     for (String accessor : accessorsArray) {
/* 36 */       String[] accessorParts = accessor.split("\\.");
/*    */       
/* 38 */       String currentAccessor = "";
/* 39 */       for (String accessorPart : accessorParts) {
/* 40 */         if (currentAccessor.length() > 0) {
/* 41 */           currentAccessor = currentAccessor + ".";
/*    */         }
/* 43 */         currentAccessor = currentAccessor + accessorPart;
/* 44 */         accessors.add(currentAccessor);
/*    */       }
/*    */     }
/* 47 */     return accessors;
/*    */   }
/*    */   
/*    */   public boolean isExpandAllFirstLevelAccessorsEnabled() {
/* 51 */     return this.expandAllFirstLevelAccessorsEnabled;
/*    */   }
/*    */   
/*    */   public Set<String> getAccessorsToExpand() {
/* 55 */     return this.accessorsToExpand;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\ExpandParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */