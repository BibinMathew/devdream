/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import oracle.adf.model.binding.DCControlBindingDef;
/*    */ import oracle.adf.model.binding.DCIteratorBinding;
/*    */ import oracle.jbo.Key;
/*    */ import oracle.jbo.Row;
/*    */ import oracle.jbo.uicli.binding.JUCtrlActionBinding;
/*    */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*    */ 
/*    */ public final class CreateAction extends Action
/*    */ {
/*    */   public CreateAction(Resource resource)
/*    */   {
/* 14 */     super(ActionType.CREATE, resource);
/*    */   }
/*    */   
/*    */   CreateAction() {
/* 18 */     super(ActionType.CREATE);
/*    */   }
/*    */   
/*    */   public ActionResult<ResourceItem> execute()
/*    */   {
/* 23 */     Resource parentResource = getResource();
/* 24 */     if (parentResource.isItem()) {
/* 25 */       throw new oracle.adf.internal.model.rest.core.exception.InvalidResourceTypeException();
/*    */     }
/* 27 */     getActionBinding().getDef().setProperty("__IsValidationOnCreate__", Boolean.valueOf(true));
/* 28 */     super.execute();
/*    */     
/* 30 */     JUCtrlHierNodeBinding parentNode = parentResource.getNode();
/*    */     
/* 32 */     Row row = parentNode.getChildIteratorBinding().getCurrentRow();
/* 33 */     if (row == null) {
/* 34 */       return null;
/*    */     }
/* 36 */     Key childKey = row.getKey();
/* 37 */     if (childKey.isNull()) {
/* 38 */       return null;
/*    */     }
/*    */     
/*    */ 
/* 42 */     JUCtrlHierNodeBinding childNode = parentNode.findChildNodeByKey(childKey);
/*    */     
/* 44 */     if (childNode == null) {
/* 45 */       return null;
/*    */     }
/*    */     
/* 48 */     return new ActionResult(new ResourceItem(parentResource.getTree(), childNode));
/*    */   }
/*    */   
/*    */   public boolean producesActionResult()
/*    */   {
/* 53 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\CreateAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */