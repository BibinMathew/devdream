/*    */ package oracle.adf.internal.model.rest.core.http.payload;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.util.zip.GZIPInputStream;
/*    */ import java.util.zip.GZIPOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GZIPProcessor
/*    */   implements ContentCodingProcessor
/*    */ {
/*    */   public OutputStream wrapOutput(OutputStream out)
/*    */     throws IOException
/*    */   {
/* 18 */     return new LazyGZIPOutputStream(out, null);
/*    */   }
/*    */   
/*    */   public InputStream wrapInput(InputStream in) throws IOException
/*    */   {
/* 23 */     return new GZIPInputStream(in);
/*    */   }
/*    */   
/*    */ 
/*    */   private static class LazyGZIPOutputStream
/*    */     extends OutputStream
/*    */   {
/*    */     private final OutputStream originalOutputStream;
/*    */     
/*    */     private GZIPOutputStream gzipOutputStream;
/*    */     
/*    */     private LazyGZIPOutputStream(OutputStream out)
/*    */     {
/* 36 */       this.originalOutputStream = out;
/*    */     }
/*    */     
/*    */     public void write(byte[] b) throws IOException {
/* 40 */       ensureGZIPOutputStream();
/* 41 */       this.gzipOutputStream.write(b);
/*    */     }
/*    */     
/*    */     private void ensureGZIPOutputStream() throws IOException {
/* 45 */       if (this.gzipOutputStream == null) {
/* 46 */         this.gzipOutputStream = new GZIPOutputStream(this.originalOutputStream);
/*    */       }
/*    */     }
/*    */     
/*    */     public void write(int b) throws IOException {
/* 51 */       ensureGZIPOutputStream();
/* 52 */       this.gzipOutputStream.write(b);
/*    */     }
/*    */     
/*    */     public void close() throws IOException {
/* 56 */       ensureGZIPOutputStream();
/* 57 */       this.gzipOutputStream.close();
/*    */     }
/*    */     
/*    */     public void flush() throws IOException {
/* 61 */       ensureGZIPOutputStream();
/* 62 */       this.gzipOutputStream.flush();
/*    */     }
/*    */     
/*    */     public void write(byte[] buf, int off, int len) throws IOException {
/* 66 */       ensureGZIPOutputStream();
/* 67 */       this.gzipOutputStream.write(buf, off, len);
/*    */     }
/*    */     
/*    */     public void finish() throws IOException {
/* 71 */       ensureGZIPOutputStream();
/* 72 */       this.gzipOutputStream.finish();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\payload\GZIPProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */