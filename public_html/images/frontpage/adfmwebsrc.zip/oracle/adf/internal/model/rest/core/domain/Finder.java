/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeHints;
/*     */ import oracle.jbo.LocaleContext;
/*     */ import oracle.jbo.ViewObject;
/*     */ import oracle.jbo.common.JboTypeMap;
/*     */ import oracle.jbo.server.BoundParameter;
/*     */ import oracle.jbo.server.RowFinder;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Finder
/*     */ {
/*     */   private final String name;
/*     */   private final Map<String, Attribute> attributeMap;
/*     */   private final RowFinder rowFinder;
/*     */   
/*     */   Finder(RowFinder rowFinder, Resource resource)
/*     */   {
/*  39 */     this(resource.getVO(), rowFinder, resource.getNode().getHierTypeBinding(), resource.getNode().getLocaleContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Finder(ViewObject vo, RowFinder rowFinder, JUCtrlHierTypeBinding typeBinding, LocaleContext localeContext)
/*     */   {
/*  46 */     this.name = rowFinder.getName();
/*  47 */     this.rowFinder = rowFinder;
/*     */     
/*  49 */     Collection<AttributeDef> parameters = rowFinder.getParameters(false);
/*  50 */     if (parameters != null) {
/*  51 */       Map<String, Attribute> map = new HashMap(parameters.size());
/*  52 */       for (AttributeDef parameter : parameters)
/*     */       {
/*     */ 
/*  55 */         if ((!"Hide".equals(parameter.getUIHelper().getPayloadHint(localeContext))) && (
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  60 */           (!rowFinder.areAllVariablesMappedToAttributes()) || (!((BoundParameter)parameter).isUnmapped())))
/*     */         {
/*     */ 
/*     */ 
/*  64 */           String attributeName = parameter.getName();
/*  65 */           if ((parameter instanceof BoundParameter)) {
/*  66 */             attributeName = ((BoundParameter)parameter).getAttributeName();
/*     */           }
/*     */           
/*  69 */           map.put(attributeName, new Attribute(vo, parameter, typeBinding, localeContext));
/*     */         } }
/*  71 */       this.attributeMap = Collections.unmodifiableMap(map);
/*     */     } else {
/*  73 */       this.attributeMap = Collections.emptyMap();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Attribute> getAttributes()
/*     */   {
/*  83 */     return this.attributeMap.values();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  91 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/* 102 */     if (this.rowFinder.isPayloadHintHide()) {
/* 103 */       return false;
/*     */     }
/*     */     
/* 106 */     if ((this.attributeMap == null) || (this.attributeMap.isEmpty())) {
/* 107 */       return true;
/*     */     }
/*     */     
/* 110 */     for (Attribute attribute : this.attributeMap.values()) {
/* 111 */       AttributeDef attrDef = attribute.getAttrDef();
/* 112 */       int sqlType = attrDef.getSQLType();
/*     */       
/* 114 */       if ((!JboTypeMap.isCharType(sqlType)) && (!JboTypeMap.isNumericType(sqlType)) && (!JboTypeMap.isDateType(sqlType)) && (Serializable.class.isAssignableFrom(attrDef.getJavaType())))
/*     */       {
/* 116 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 120 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> getAttributeNames()
/*     */   {
/* 129 */     return this.attributeMap.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   RowFinder getRowFinder()
/*     */   {
/* 138 */     return this.rowFinder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Attribute> getAttributeMap()
/*     */   {
/* 146 */     return this.attributeMap;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Finder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */