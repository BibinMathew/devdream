/*    */ package oracle.adf.internal.model.rest.core.http.media;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Set;
/*    */ import oracle.adf.internal.model.rest.core.http.header.ContentCoding;
/*    */ import oracle.adf.internal.model.rest.core.http.payload.ContentCodingProcessor;
/*    */ import oracle.adf.internal.model.rest.core.http.payload.DeflateProcessor;
/*    */ import oracle.adf.internal.model.rest.core.http.payload.GZIPProcessor;
/*    */ import oracle.adf.internal.model.rest.core.http.payload.IdentityProcessor;
/*    */ import oracle.jbo.JboException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentCodingHandler
/*    */ {
/* 17 */   private static final ContentCoding GZIP = new ContentCoding("gzip");
/* 18 */   private static final ContentCoding X_GZIP = new ContentCoding("x-gzip");
/* 19 */   private static final ContentCoding IDENTITY = new ContentCoding("identity");
/* 20 */   private static final ContentCoding DEFLATE = new ContentCoding("deflate");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 25 */   private static final HashMap<ContentCoding, Class<? extends ContentCodingProcessor>> contentCodingMap = new HashMap(4);
/* 26 */   static { contentCodingMap.put(GZIP, GZIPProcessor.class);
/* 27 */     contentCodingMap.put(X_GZIP, GZIPProcessor.class);
/* 28 */     contentCodingMap.put(IDENTITY, IdentityProcessor.class);
/* 29 */     contentCodingMap.put(DEFLATE, DeflateProcessor.class);
/*    */   }
/*    */   
/*    */   public static Set<ContentCoding> generateSupportedContentEncodingList()
/*    */   {
/* 34 */     return contentCodingMap.keySet();
/*    */   }
/*    */   
/*    */   public static ContentCodingProcessor createContentCodingProcessor(ContentCoding contentCoding) {
/* 38 */     Class<? extends ContentCodingProcessor> cls = (Class)contentCodingMap.get(contentCoding);
/* 39 */     ContentCodingProcessor codingProcessor = null;
/*    */     try {
/* 41 */       if (cls != null) {
/* 42 */         codingProcessor = (ContentCodingProcessor)cls.newInstance();
/*    */       }
/*    */     } catch (Exception ex) {
/* 45 */       throw new JboException(ex);
/*    */     }
/*    */     
/* 48 */     return codingProcessor;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\media\ContentCodingHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */