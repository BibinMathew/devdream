/*    */ package oracle.adf.internal.model.rest.core.http.payload;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdentityProcessor
/*    */   implements ContentCodingProcessor
/*    */ {
/*    */   public OutputStream wrapOutput(OutputStream out)
/*    */   {
/* 14 */     return out;
/*    */   }
/*    */   
/*    */   public InputStream wrapInput(InputStream in)
/*    */   {
/* 19 */     return in;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\payload\IdentityProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */