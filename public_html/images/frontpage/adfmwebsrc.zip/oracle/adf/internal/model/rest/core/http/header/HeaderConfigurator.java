package oracle.adf.internal.model.rest.core.http.header;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

public abstract interface HeaderConfigurator
  extends Serializable
{
  public abstract Map<String, String> getHeaders();
  
  public abstract Set<String> getSuppressedHeaderNames();
  
  public abstract void setup(HeaderConfiguratorInfo paramHeaderConfiguratorInfo);
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\HeaderConfigurator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */