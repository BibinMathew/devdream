/*     */ package oracle.adf.internal.model.rest.core.payload;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionResult;
/*     */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*     */ import oracle.adf.internal.model.rest.core.domain.BatchPart;
/*     */ import oracle.adf.internal.model.rest.core.domain.Cardinality;
/*     */ import oracle.adf.internal.model.rest.core.domain.FinderDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.Link;
/*     */ import oracle.adf.internal.model.rest.core.domain.Path;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription.CollectionSection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription.ResourceAnnotationsSection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceProperty;
/*     */ import oracle.adf.internal.model.rest.core.domain.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLGenerator
/*     */   implements PayloadGenerator
/*     */ {
/*     */   public static final String NIL = "nil";
/*     */   public static final String PREFIX_XSI = "xsi";
/*     */   private final XMLStreamWriter xsw;
/*     */   private PayloadType payloadType;
/*     */   
/*     */   public XMLGenerator(OutputStream out)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  40 */       this.xsw = getXMLOutputFactory().createXMLStreamWriter(out);
/*  41 */       this.xsw.setPrefix("xsi", "http://www.w3.org/2001/XMLSchema-instance");
/*     */     } catch (XMLStreamException ex) {
/*  43 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public XMLGenerator(Writer writer) throws IOException {
/*     */     try {
/*  49 */       this.xsw = getXMLOutputFactory().createXMLStreamWriter(writer);
/*  50 */       this.xsw.setPrefix("xsi", "http://www.w3.org/2001/XMLSchema-instance");
/*     */     } catch (XMLStreamException ex) {
/*  52 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private XMLOutputFactory getXMLOutputFactory()
/*     */   {
/*  59 */     XMLOutputFactory xof = XMLOutputFactory.newFactory();
/*  60 */     xof.setProperty("javax.xml.stream.isRepairingNamespaces", Boolean.valueOf(true));
/*  61 */     return xof;
/*     */   }
/*     */   
/*     */   public PayloadType getPayloadType()
/*     */   {
/*  66 */     return this.payloadType;
/*     */   }
/*     */   
/*     */   public Object getTarget()
/*     */   {
/*  71 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startAttributeDescriptionItem() throws IOException
/*     */   {
/*  76 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endAttributeDescriptionItem() throws IOException
/*     */   {
/*  81 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void addAttributeDescriptionItem(Attribute attribute) throws IOException
/*     */   {
/*  86 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setPayloadType(PayloadType payloadType)
/*     */   {
/*  91 */     this.payloadType = payloadType;
/*     */   }
/*     */   
/*     */   public void startResource() throws IOException
/*     */   {
/*     */     try {
/*  97 */       this.xsw.writeStartElement("item");
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 100 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endResource() throws IOException
/*     */   {
/*     */     try {
/* 107 */       this.xsw.writeEndElement();
/*     */     } catch (XMLStreamException ex) {
/* 109 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void startLinks() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       this.xsw.writeStartElement("links");
/*     */     }
/*     */     catch (XMLStreamException ex)
/*     */     {
/* 121 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endLinks() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 129 */       this.xsw.writeEndElement();
/*     */     }
/*     */     catch (XMLStreamException ex)
/*     */     {
/* 133 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addLink(Link link) throws IOException
/*     */   {
/* 139 */     if (link == null)
/*     */     {
/* 141 */       throw new IllegalArgumentException("null argument");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 146 */       this.xsw.writeStartElement("link");
/* 147 */       this.xsw.writeAttribute("rel", link.getRel());
/* 148 */       this.xsw.writeAttribute("href", link.getHref().createHref());
/* 149 */       this.xsw.writeAttribute("name", link.getName());
/* 150 */       this.xsw.writeAttribute("kind", link.getKind());
/* 151 */       this.xsw.writeEndElement();
/*     */     }
/*     */     catch (XMLStreamException ex)
/*     */     {
/* 155 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addLink(List<Link> links) throws IOException
/*     */   {
/* 161 */     if ((links != null) && (links.size() > 0))
/*     */     {
/* 163 */       for (Link link : links)
/*     */       {
/* 165 */         addLink(link);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addAttributeLink(List<Attribute> attrs, Path resourceHref) throws IOException
/*     */   {
/* 172 */     if ((attrs != null) && (attrs.size() > 0))
/*     */     {
/* 174 */       for (Attribute attr : attrs)
/*     */       {
/* 176 */         addAttributeLink(attr, resourceHref);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addAttributeLink(Attribute attribute, Path resourceHref) throws IOException
/*     */   {
/* 183 */     if (attribute.canStreamContent())
/*     */     {
/* 185 */       addLink(attribute.createContentLink(resourceHref));
/*     */     }
/*     */     else
/*     */     {
/* 189 */       attribute.serializeLink(getPayloadType(), getTarget());
/*     */     }
/*     */   }
/*     */   
/*     */   public void createLinks(List<Link> links) throws IOException
/*     */   {
/* 195 */     if ((links == null) || (links.isEmpty()))
/*     */     {
/* 197 */       return;
/*     */     }
/*     */     
/* 200 */     startLinks();
/* 201 */     addLink(links);
/* 202 */     endLinks();
/*     */   }
/*     */   
/*     */   public void startPayload() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 209 */       this.xsw.writeStartElement("collection");
/*     */     }
/*     */     catch (XMLStreamException ex)
/*     */     {
/* 213 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endPayload() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 221 */       this.xsw.writeEndElement();
/*     */     }
/*     */     catch (XMLStreamException ex)
/*     */     {
/* 225 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void createActionResult(ActionResult actionResult) throws IOException
/*     */   {
/* 231 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createAttribute(Attribute attr) throws IOException
/*     */   {
/* 236 */     String name = attr.getName();
/* 237 */     Object value = attr.getValue();
/*     */     
/*     */     try
/*     */     {
/* 241 */       this.xsw.writeStartElement(name);
/*     */       
/*     */ 
/* 244 */       if (value == null)
/*     */       {
/* 246 */         this.xsw.writeAttribute("http://www.w3.org/2001/XMLSchema-instance", "nil", Boolean.TRUE.toString());
/*     */       }
/*     */       else
/*     */       {
/* 250 */         this.xsw.writeCharacters(value.toString());
/*     */       }
/* 252 */       this.xsw.writeEndElement();
/*     */     } catch (XMLStreamException ex) {
/* 254 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setup() {}
/*     */   
/*     */   public void startResourceCollectionDescriptionSection()
/*     */     throws IOException
/*     */   {
/* 264 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startActionDescription() throws IOException
/*     */   {
/* 269 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endActionDescription() throws IOException
/*     */   {
/* 274 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endResourceCollectionDescriptionSection() throws IOException
/*     */   {
/* 279 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startResourceDescriptionSection() throws IOException
/*     */   {
/* 284 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endResourceDescriptionSection() throws IOException
/*     */   {
/* 289 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startChildrenDescriptionSection() throws IOException
/*     */   {
/* 294 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endChildrenDescriptionSection() throws IOException
/*     */   {
/* 299 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startResourceDescription(ResourceDescription resourceDescription) throws IOException
/*     */   {
/* 304 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endResourceDescription(ResourceDescription resourceDescription) throws IOException
/*     */   {
/* 309 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createResourceAnnotationsSection(ResourceDescription.ResourceAnnotationsSection annSec) throws IOException
/*     */   {
/* 314 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startDescription() throws IOException
/*     */   {
/* 319 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endDescription() throws IOException
/*     */   {
/* 324 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startActionDescriptionItem() throws IOException
/*     */   {
/* 329 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endActionDescriptionItem() throws IOException
/*     */   {
/* 334 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createActionDescription(ActionDescription actionDescription) throws IOException
/*     */   {
/* 339 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createCardinality(Cardinality cardinality) throws IOException
/*     */   {
/* 344 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startAttributeDescription() throws IOException
/*     */   {
/* 349 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endAttributeDescription() throws IOException
/*     */   {
/* 354 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createPart(BatchPart part) throws IOException
/*     */   {
/* 359 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createEmptyResource() throws IOException
/*     */   {
/* 364 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void finalizePart() throws IOException
/*     */   {
/* 369 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*     */     try {
/* 375 */       this.xsw.close();
/*     */     } catch (XMLStreamException ex) {
/* 377 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void createFinders(List<FinderDescription> finder) throws IOException
/*     */   {
/* 383 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void addPartPreconditionSucceeded(boolean preconditionFailed) throws IOException
/*     */   {
/* 388 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startPartPayload() throws IOException
/*     */   {
/* 393 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startBatch() throws IOException
/*     */   {
/* 398 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endBatch() throws IOException
/*     */   {
/* 403 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startVersions() throws IOException
/*     */   {
/* 408 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endVersions(List<Link> currentLinks) throws IOException
/*     */   {
/* 413 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void startVersion(Version version) throws IOException
/*     */   {
/* 418 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void endVersion() throws IOException
/*     */   {
/* 423 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createCollectionSectionAttributes(ResourceDescription.CollectionSection collectionSection) throws IOException
/*     */   {
/* 428 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void createResourceProperty(ResourceProperty property) throws IOException
/*     */   {
/*     */     try {
/* 434 */       this.xsw.writeStartElement((String)property.getKey());
/* 435 */       this.xsw.writeCharacters(property.getValue().toString());
/* 436 */       this.xsw.writeEndElement();
/*     */     } catch (XMLStreamException ex) {
/* 438 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void createResourceProperties(List<ResourceProperty> properties) throws IOException
/*     */   {
/* 444 */     for (ResourceProperty property : properties)
/*     */     {
/* 446 */       createResourceProperty(property);
/*     */     }
/*     */   }
/*     */   
/*     */   public void startResourceCollectionItems() throws IOException
/*     */   {
/*     */     try {
/* 453 */       this.xsw.writeStartElement("items");
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 456 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endResourceCollectionItems() throws IOException
/*     */   {
/*     */     try {
/* 463 */       this.xsw.writeEndElement();
/*     */     } catch (XMLStreamException ex) {
/* 465 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void startNestedResource(String childName) throws IOException
/*     */   {
/*     */     try {
/* 472 */       this.xsw.writeStartElement(childName);
/*     */     } catch (XMLStreamException ex) {
/* 474 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endNestedResource() throws IOException
/*     */   {
/*     */     try {
/* 481 */       this.xsw.writeEndElement();
/*     */     } catch (XMLStreamException ex) {
/* 483 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\XMLGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */