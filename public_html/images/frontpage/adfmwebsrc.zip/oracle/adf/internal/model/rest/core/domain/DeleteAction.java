/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ 
/*    */ public final class DeleteAction
/*    */   extends Action
/*    */ {
/*    */   public DeleteAction(Resource resource)
/*    */   {
/*  9 */     super(ActionType.DELETE, resource);
/*    */   }
/*    */   
/* 12 */   DeleteAction() { super(ActionType.DELETE); }
/*    */   
/*    */ 
/*    */   public boolean producesActionResult()
/*    */   {
/* 17 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\DeleteAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */