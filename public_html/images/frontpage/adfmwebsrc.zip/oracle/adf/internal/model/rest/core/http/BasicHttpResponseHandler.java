/*    */ package oracle.adf.internal.model.rest.core.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.http.header.DefaultHeaderConfigurator;
/*    */ import oracle.adf.internal.model.rest.core.http.header.HeaderConfigurator;
/*    */ import oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public class BasicHttpResponseHandler
/*    */   extends HttpResponseHandler
/*    */ {
/*    */   protected ContentTypeHandler contentTypeHandler;
/*    */   protected int status;
/*    */   protected String contentEncoding;
/* 22 */   protected Map<String, String> headers = Collections.emptyMap();
/*    */   
/*    */   public BasicHttpResponseHandler(OutputStream out) throws IOException
/*    */   {
/* 26 */     super(new BasicHttpResponseWrapper(out, null));
/*    */   }
/*    */   
/*    */   public BasicHttpResponseHandler(OutputStream out, AcceptHeaderManager acceptHeaderManager) throws IOException {
/* 30 */     super(acceptHeaderManager, new BasicHttpResponseWrapper(out, null));
/*    */   }
/*    */   
/*    */   public void setup()
/*    */   {
/* 35 */     this.headers = getHeaders();
/* 36 */     super.setup();
/* 37 */     this.contentTypeHandler = getContentTypeHandler();
/* 38 */     this.status = getStatus();
/* 39 */     this.contentEncoding = getContentEncoding();
/*    */   }
/*    */   
/*    */   private static class BasicHttpResponseWrapper implements RESTHttpResponseWrapper
/*    */   {
/*    */     private final OutputStream out;
/* 45 */     private final HeaderConfigurator headerConfigurator = new DefaultHeaderConfigurator();
/*    */     
/*    */     private BasicHttpResponseWrapper(OutputStream out) {
/* 48 */       this.out = out;
/*    */     }
/*    */     
/*    */     public OutputStream getOutpuStream()
/*    */     {
/* 53 */       return this.out;
/*    */     }
/*    */     
/*    */     public HeaderConfigurator getHeaderConfigurator()
/*    */     {
/* 58 */       return this.headerConfigurator;
/*    */     }
/*    */     
/*    */     public void setupResponseHeaders(int statusCode, Map<String, String> headers) {}
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\BasicHttpResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */