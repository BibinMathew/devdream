package oracle.adf.internal.model.rest.core.common;

public enum OperationType
{
  CREATION,  EXECUTION,  DESCRIPTION,  REPRESENTATION,  UPDATE,  REPLACEMENT,  MERGE,  DELETION;
  
  private OperationType() {}
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\OperationType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */