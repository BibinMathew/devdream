/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class ETag implements Header
/*    */ {
/*    */   public static final String NAME = "ETag";
/*    */   private List<EntityTag> entityTags;
/*    */   
/*    */   public ETag(String value) {
/* 11 */     this.entityTags = EntityTag.parseEntityTags(value);
/*    */   }
/*    */   
/*    */   public List<EntityTag> getEntityTags() {
/* 15 */     return this.entityTags;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 20 */     return "ETag";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\ETag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */