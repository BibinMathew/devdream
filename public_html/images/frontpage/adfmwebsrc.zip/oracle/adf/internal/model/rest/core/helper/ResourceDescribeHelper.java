/*     */ package oracle.adf.internal.model.rest.core.helper;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import oracle.adf.internal.model.rest.core.common.EntityContentMapping;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.AnnotationsParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.IncludeChildrenParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameter.Type;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.Path;
/*     */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription.CollectionSection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription.ItemSection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription.ResourceAnnotationsSection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*     */ import oracle.adf.model.binding.PermissionHelper;
/*     */ import oracle.adf.share.security.authorization.RestServicePermission;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.version.VersionDef;
/*     */ import oracle.jbo.version.VersionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceDescribeHelper
/*     */ {
/*     */   private final String basePath;
/*     */   private final ResourceTree resourceTree;
/*     */   private final Resource currentResource;
/*     */   private final EntityContentMapping entityContentMap;
/*     */   private final Configuration config;
/*     */   private final boolean showAnnotations;
/*     */   private final boolean includeChildren;
/*     */   
/*     */   public ResourceDescribeHelper(ResourceProcessingContext context, Configuration config)
/*     */   {
/*  53 */     this.basePath = context.getBasePath();
/*  54 */     this.resourceTree = context.getResourceTree();
/*  55 */     this.currentResource = this.resourceTree.getCurrentResource();
/*  56 */     this.entityContentMap = context.getEntityContentMap();
/*  57 */     this.config = config;
/*  58 */     ResourceParameterMap parameterMap = context.getResourceParameterMap();
/*  59 */     this.showAnnotations = isAnnotationsShowable(parameterMap);
/*  60 */     this.includeChildren = isIncludeChildrenEnabled(parameterMap);
/*     */   }
/*     */   
/*     */   private ResourceDescribeHelper(String basePath, ResourceTree tree, EntityContentMapping entityContentMap, Configuration config, ResourceParameterMap parameterMap)
/*     */   {
/*  65 */     this.basePath = basePath;
/*  66 */     this.resourceTree = tree;
/*  67 */     this.currentResource = this.resourceTree.getRootResource();
/*  68 */     this.entityContentMap = entityContentMap;
/*  69 */     this.config = config;
/*  70 */     this.showAnnotations = isAnnotationsShowable(parameterMap);
/*  71 */     this.includeChildren = isIncludeChildrenEnabled(parameterMap);
/*     */   }
/*     */   
/*     */   private static void start(PayloadGenerator generator) throws IOException {
/*  75 */     ResourceLoggerManager.getDiagnosticLogger().beginActivity(Level.CONFIG, "Processing describe");
/*  76 */     generator.setup();
/*  77 */     generator.startDescription();
/*     */   }
/*     */   
/*     */   private static void finish(PayloadGenerator generator) throws IOException {
/*  81 */     generator.endDescription();
/*  82 */     ResourceLoggerManager.getDiagnosticLogger().endCurrentActivity();
/*  83 */     ResourceLoggerManager.removeCurrentLogger();
/*     */   }
/*     */   
/*     */   public void describeResource(PayloadGenerator generator) throws IOException {
/*  87 */     start(generator);
/*  88 */     describe(generator);
/*  89 */     finish(generator);
/*     */   }
/*     */   
/*     */   private void describe(PayloadGenerator generator) throws IOException {
/*  93 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*  94 */     ResourceDescription resourceDescription = new ResourceDescription(this.currentResource, this.basePath, this.entityContentMap, generator.getPayloadType());
/*     */     
/*     */ 
/*  97 */     resourceDescription.setAnnotationsShowable(this.showAnnotations);
/*  98 */     startResourceDescription(generator, logger, resourceDescription);
/*  99 */     if (this.currentResource.isCollection()) {
/* 100 */       describeResourceCollectionSection(generator, resourceDescription.createCollectionSection());
/*     */     }
/*     */     
/* 103 */     describeResourceSection(generator, resourceDescription.createItemSection(), resourceDescription.getPath());
/* 104 */     describeResourceAnnotationsSection(generator, resourceDescription.createResourceAnnotationsSection());
/* 105 */     if ((this.includeChildren) || (this.currentResource.isCollection())) {
/* 106 */       createChildren(resourceDescription, generator);
/*     */     }
/* 108 */     endResourceDescription(generator, logger, resourceDescription);
/*     */   }
/*     */   
/*     */   private void startResourceDescription(PayloadGenerator generator, FunctionalLogger logger, ResourceDescription resourceDescription) throws IOException
/*     */   {
/* 113 */     logger.beginActivity(Level.FINER, "Describing resource");
/* 114 */     logger.addContextData("name", resourceDescription.getName());
/* 115 */     generator.startResourceDescription(resourceDescription);
/*     */   }
/*     */   
/*     */   private void describeResourceSection(PayloadGenerator generator, ResourceDescription.ItemSection itemDescription, Path resourcePath) throws IOException
/*     */   {
/* 120 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 121 */     logger.beginActivity(Level.FINER, "Describing item section");
/* 122 */     generator.startResourceDescriptionSection();
/* 123 */     generator.startLinks();
/* 124 */     generator.addLink(itemDescription.getLinks());
/* 125 */     generator.addAttributeLink(itemDescription.getAttributesWithLink(), resourcePath);
/* 126 */     generator.endLinks();
/* 127 */     describeActionSection(generator, itemDescription.getActionDescriptions());
/* 128 */     generator.endResourceDescriptionSection();
/* 129 */     logger.endCurrentActivity();
/*     */   }
/*     */   
/*     */   private void describeResourceCollectionSection(PayloadGenerator generator, ResourceDescription.CollectionSection collectionSection) throws IOException
/*     */   {
/* 134 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 135 */     logger.beginActivity(Level.FINER, "Describing collection section");
/* 136 */     generator.startResourceCollectionDescriptionSection();
/* 137 */     generator.createCollectionSectionAttributes(collectionSection);
/* 138 */     generator.createFinders(collectionSection.getFinderDescriptions());
/* 139 */     generator.createLinks(collectionSection.getLinks());
/* 140 */     describeActionSection(generator, collectionSection.getActionDescriptions());
/* 141 */     generator.endResourceCollectionDescriptionSection();
/* 142 */     logger.endCurrentActivity();
/*     */   }
/*     */   
/*     */   private void describeActionSection(PayloadGenerator payloadGenerator, List<ActionDescription> actions) throws IOException
/*     */   {
/* 147 */     payloadGenerator.startActionDescription();
/* 148 */     for (ActionDescription actionDescription : actions) {
/* 149 */       payloadGenerator.startActionDescriptionItem();
/* 150 */       this.config.configureActionDescription(actionDescription);
/* 151 */       payloadGenerator.createActionDescription(actionDescription);
/* 152 */       payloadGenerator.endActionDescriptionItem();
/*     */     }
/* 154 */     payloadGenerator.endActionDescription();
/*     */   }
/*     */   
/*     */   private void describeResourceAnnotationsSection(PayloadGenerator payloadGenerator, ResourceDescription.ResourceAnnotationsSection annotationsSection) throws IOException
/*     */   {
/* 159 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 160 */     if ((this.showAnnotations) && (annotationsSection != null)) {
/* 161 */       logger.beginActivity(Level.FINER, "Describing annotations section");
/* 162 */       payloadGenerator.createResourceAnnotationsSection(annotationsSection);
/* 163 */       logger.endCurrentActivity();
/*     */     }
/*     */   }
/*     */   
/*     */   private void createChildren(ResourceDescription parentResourceDescription, PayloadGenerator generator) throws IOException
/*     */   {
/* 169 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 170 */     logger.beginActivity(Level.FINER, "Describing children section");
/* 171 */     Set<String> childrenNames = parentResourceDescription.getChildrenNames();
/* 172 */     if (childrenNames.isEmpty()) {
/* 173 */       return;
/*     */     }
/*     */     
/* 176 */     generator.startChildrenDescriptionSection();
/* 177 */     for (String childName : childrenNames) {
/* 178 */       ResourceDescription childDescription = parentResourceDescription.createChildDescription(childName);
/* 179 */       childDescription.setAnnotationsShowable(this.showAnnotations);
/* 180 */       startResourceDescription(generator, logger, childDescription);
/*     */       
/* 182 */       logger.beginActivity(Level.FINER, "Describing collection section");
/* 183 */       describeResourceCollectionSection(generator, childDescription.createCollectionSection());
/* 184 */       logger.endCurrentActivity();
/*     */       
/* 186 */       logger.beginActivity(Level.FINER, "Describing item section");
/* 187 */       describeResourceSection(generator, childDescription.createItemSection(), childDescription.getPath());
/* 188 */       logger.endCurrentActivity();
/*     */       
/* 190 */       if (this.showAnnotations) {
/* 191 */         ResourceDescription.ResourceAnnotationsSection annotationsSection = childDescription.createResourceAnnotationsSection();
/* 192 */         if (annotationsSection != null) {
/* 193 */           logger.beginActivity(Level.FINER, "Describing annotations section");
/* 194 */           describeResourceAnnotationsSection(generator, annotationsSection);
/* 195 */           logger.endCurrentActivity();
/*     */         }
/*     */       }
/*     */       
/* 199 */       logger.beginActivity(Level.FINER, "Describing children section");
/* 200 */       createChildren(childDescription, generator);
/* 201 */       logger.endCurrentActivity();
/*     */       
/* 203 */       endResourceDescription(generator, logger, childDescription);
/*     */     }
/* 205 */     generator.endChildrenDescriptionSection();
/* 206 */     logger.endCurrentActivity();
/*     */   }
/*     */   
/*     */   private void endResourceDescription(PayloadGenerator generator, FunctionalLogger logger, ResourceDescription childDescription) throws IOException
/*     */   {
/* 211 */     generator.endResourceDescription(childDescription);
/* 212 */     logger.endCurrentActivity();
/*     */   }
/*     */   
/*     */   public static void describeAllResources(ResourceProcessingContext context, PayloadGenerator generator, Configuration config, String securityAction)
/*     */     throws IOException
/*     */   {
/* 218 */     start(generator);
/* 219 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 220 */     VersionDef versionDef = context.getVersionDef();
/* 221 */     Collection<String> resColl = VersionResolver.getAvailableResources(versionDef);
/* 222 */     for (String resName : resColl)
/*     */     {
/*     */       ResourceTree resourceTree;
/*     */       try {
/* 226 */         resourceTree = new ResourceTree(resName, versionDef);
/*     */       } catch (ResourceNotFoundException ex) {
/* 228 */         logger.warning("Could not find a resource while describing all resources", ex); }
/* 229 */       continue;
/*     */       
/*     */ 
/* 232 */       if (!PermissionHelper.hasPermission(new RestServicePermission(resName, securityAction))) {
/* 233 */         logger.fine("No permission to describe. Skipping resource: " + resName);
/*     */       }
/*     */       else {
/* 236 */         ResourceDescribeHelper describeHelper = new ResourceDescribeHelper(context.getBasePath(), resourceTree, context.getEntityContentMap(), config, context.getResourceParameterMap());
/*     */         
/* 238 */         describeHelper.describe(generator);
/*     */       }
/*     */     }
/*     */     
/* 242 */     finish(generator);
/*     */   }
/*     */   
/*     */   private static boolean isAnnotationsShowable(ResourceParameterMap parameterMap) {
/* 246 */     AnnotationsParam annotParam = (AnnotationsParam)ResourceParameter.Type.SHOW_ANNOTATIONS.castTo(parameterMap.get(ResourceParameter.Type.SHOW_ANNOTATIONS));
/* 247 */     if (annotParam != null) {
/* 248 */       return annotParam.isAnnotationsShowable();
/*     */     }
/* 250 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isIncludeChildrenEnabled(ResourceParameterMap parameterMap)
/*     */   {
/* 255 */     IncludeChildrenParam param = (IncludeChildrenParam)ResourceParameter.Type.INCLUDE_CHILDREN.castTo(parameterMap.get(ResourceParameter.Type.INCLUDE_CHILDREN));
/* 256 */     if (param != null) {
/* 257 */       return param.isIncludeChildrenEnabled().booleanValue();
/*     */     }
/* 259 */     return false;
/*     */   }
/*     */   
/*     */   public static abstract interface Configuration
/*     */   {
/*     */     public abstract void configureActionDescription(ActionDescription paramActionDescription);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\helper\ResourceDescribeHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */