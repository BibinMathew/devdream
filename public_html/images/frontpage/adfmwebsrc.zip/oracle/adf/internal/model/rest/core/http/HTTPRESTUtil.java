/*     */ package oracle.adf.internal.model.rest.core.http;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.common.Condition;
/*     */ import oracle.adf.internal.model.rest.core.common.ConditionType;
/*     */ import oracle.adf.internal.model.rest.core.common.EntityContentMapping;
/*     */ import oracle.adf.internal.model.rest.core.common.EntityContentMappingValue;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.internal.model.rest.core.exception.BadRequestException;
/*     */ import oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException;
/*     */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*     */ import oracle.adf.internal.model.rest.core.exception.NotAuthorizedException;
/*     */ import oracle.adf.internal.model.rest.core.exception.PreconditionFailedException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*     */ import oracle.adf.internal.model.rest.core.http.exception.HTTPResourceException;
/*     */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*     */ import oracle.adf.internal.model.rest.core.http.media.EntityMediaTypeMapping;
/*     */ import oracle.adf.internal.model.rest.core.http.media.EntityMediaTypeMappingValue;
/*     */ import oracle.adf.internal.model.rest.core.http.media.MediaTypeHandler;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod.Type;
/*     */ import oracle.adf.model.config.AdfmConfig;
/*     */ import oracle.jbo.JboException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTTPRESTUtil
/*     */ {
/*  43 */   private static final Map<ResourceEntityType, EntityMediaTypeMappingValue> entityMediaMap = ;
/*  44 */   public static final EntityContentMapping ENTITY_CONTENT_MAPPING = createEntityContentMapping(entityMediaMap);
/*  45 */   public static final EntityMediaTypeMapping ENTITY_MEDIA_MAPPING = new EntityMediaTypeMapping(entityMediaMap);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isCompressionEnabled()
/*     */   {
/*  52 */     boolean compressionEnabled = true;
/*  53 */     String enableCompressionProperty = (String)AdfmConfig.getCustomProperty("adf.rest.enablecompression");
/*  54 */     if (enableCompressionProperty != null) {
/*  55 */       compressionEnabled = Boolean.valueOf(enableCompressionProperty).booleanValue();
/*     */     }
/*     */     
/*  58 */     return compressionEnabled;
/*     */   }
/*     */   
/*     */   private static Map<ResourceEntityType, EntityMediaTypeMappingValue> createEntityMediaTypeMap() {
/*  62 */     HashMap<ResourceEntityType, EntityMediaTypeMappingValue> map = new HashMap();
/*  63 */     for (ResourceEntityType entityType : ResourceEntityType.values()) {
/*  64 */       Set<MediaType> mediaTypes = Collections.unmodifiableSet(MediaTypeHandler.generateSupportedMediaTypeList(false, new ResourceEntityType[] { entityType }));
/*  65 */       Set<MediaType> allSupportedMediaTypes = Collections.unmodifiableSet(MediaTypeHandler.generateSupportedMediaTypeList(true, new ResourceEntityType[] { entityType }));
/*  66 */       EntityMediaTypeMappingValue value = new EntityMediaTypeMappingValue(mediaTypes, allSupportedMediaTypes);
/*  67 */       map.put(entityType, value);
/*     */     }
/*  69 */     return Collections.unmodifiableMap(map);
/*     */   }
/*     */   
/*     */   private static EntityContentMapping createEntityContentMapping(Map<ResourceEntityType, EntityMediaTypeMappingValue> mediaTypeMap) {
/*  73 */     HashMap<ResourceEntityType, EntityContentMappingValue> map = new HashMap();
/*     */     
/*  75 */     for (Map.Entry<ResourceEntityType, EntityMediaTypeMappingValue> entry : mediaTypeMap.entrySet()) {
/*  76 */       ResourceEntityType entityType = (ResourceEntityType)entry.getKey();
/*  77 */       EntityMediaTypeMappingValue entryValue = (EntityMediaTypeMappingValue)entry.getValue();
/*  78 */       String[] contentTypes = createContentTypes(entryValue.getMediaTypes());
/*  79 */       String[] allSupportedContentTypes = createContentTypes(entryValue.getAllSupportedMediaTypes());
/*  80 */       map.put(entityType, new EntityContentMappingValue(contentTypes, allSupportedContentTypes));
/*     */     }
/*     */     
/*  83 */     return new EntityContentMapping(map);
/*     */   }
/*     */   
/*     */   private static String[] createContentTypes(Set<MediaType> mediaTypes) {
/*  87 */     String[] contentTypes = new String[mediaTypes.size()];
/*  88 */     int i = 0;
/*  89 */     for (MediaType mediaType : mediaTypes) {
/*  90 */       contentTypes[i] = mediaType.toString();
/*  91 */       i++;
/*     */     }
/*  93 */     return contentTypes;
/*     */   }
/*     */   
/*     */   public static HTTPResourceException createHTTPResourceExceptionInstance(Exception e, RESTHttpRequestInfo requestInfo, String entityTag)
/*     */   {
/*  98 */     String info = requestInfo.toString();
/*  99 */     if ((e instanceof CannotParseContentException)) {
/* 100 */       HTTPResourceException ex = new HTTPResourceException(e, StatusCode.UNSUPPORTED_MEDIA_TYPE, info);
/* 101 */       ex.setEntityTag(entityTag);
/* 102 */       return ex;
/*     */     }
/* 104 */     if ((e instanceof NotAuthorizedException)) {
/* 105 */       HTTPResourceException ex = new HTTPResourceException(e, StatusCode.UNAUTHORIZED, info);
/* 106 */       ex.setEntityTag(entityTag);
/* 107 */       return ex;
/*     */     }
/* 109 */     if ((e instanceof BadRequestException)) {
/* 110 */       HTTPResourceException ex = new HTTPResourceException(((BadRequestException)e).getDetailMessage(), e, StatusCode.BAD_REQUEST, info);
/* 111 */       ex.setEntityTag(entityTag);
/* 112 */       return ex;
/*     */     }
/* 114 */     if ((e instanceof CannotGenerateContentException)) {
/* 115 */       HTTPResourceException ex = new HTTPResourceException(e, StatusCode.NOT_ACCEPTABLE, info);
/* 116 */       ex.setEntityTag(entityTag);
/* 117 */       return ex;
/*     */     }
/* 119 */     if ((e instanceof ResourceNotFoundException)) {
/* 120 */       HTTPResourceException ex = new HTTPResourceException(e, StatusCode.NOT_FOUND, info);
/* 121 */       ex.setEntityTag(entityTag);
/* 122 */       return ex;
/*     */     }
/*     */     
/* 125 */     if ((e instanceof PreconditionFailedException)) {
/* 126 */       StatusCode errorCode = StatusCode.PRECONDITION_FAILED;
/*     */       
/* 128 */       if (isNotModifiedPrecondition(requestInfo.getHttpMethod(), requestInfo.getHeader("If-None-Match"))) {
/* 129 */         errorCode = StatusCode.NOT_MODIFIED;
/*     */       }
/* 131 */       HTTPResourceException ex = new HTTPResourceException(e, errorCode, info);
/* 132 */       ex.setEntityTag(entityTag);
/* 133 */       return ex;
/*     */     }
/*     */     
/* 136 */     if ((e instanceof JboException)) {
/* 137 */       HTTPResourceException ex = new HTTPResourceException(((JboException)e).getDetailMessage(), e, StatusCode.INTERNAL_SERVER_ERROR, info);
/* 138 */       ex.setEntityTag(entityTag);
/* 139 */       return ex;
/*     */     }
/*     */     
/* 142 */     HTTPResourceException ex = new HTTPResourceException(e, StatusCode.INTERNAL_SERVER_ERROR, info);
/* 143 */     ex.setEntityTag(entityTag);
/* 144 */     return ex;
/*     */   }
/*     */   
/*     */   static boolean isNotModifiedPrecondition(HttpMethod.Type methodType, List<String> ifNoneMatchHeader) {
/* 148 */     return (methodType == HttpMethod.Type.GET) && (ifNoneMatchHeader != null);
/*     */   }
/*     */   
/*     */   static boolean isNotModifiedPrecondition(OperationType operationType, Condition condition) {
/* 152 */     return (operationType == OperationType.REPRESENTATION) && (condition.getConditionType() == ConditionType.NONE_MATCH);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\HTTPRESTUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */