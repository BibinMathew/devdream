/*     */ package oracle.adf.internal.model.rest.core.lifecycle;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import javax.el.ExpressionFactory;
/*     */ import oracle.adf.internal.model.rest.core.binding.inputhandler.ResourceInputHandlerImpl;
/*     */ import oracle.adf.internal.model.rest.core.common.Operation;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationFactory;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.common.RESTUtil;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*     */ import oracle.adf.internal.model.rest.core.common.ResponseHandler.ErrorType;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.DependencyParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameter.Type;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTransactionStateListener;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*     */ import oracle.adf.internal.model.rest.core.exception.NotAuthorizedException;
/*     */ import oracle.adf.internal.model.rest.core.exception.OperationNotFoundException;
/*     */ import oracle.adf.internal.model.rest.core.exception.PreconditionFailedException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*     */ import oracle.adf.model.BindingContext;
/*     */ import oracle.adf.model.DataControlFrame;
/*     */ import oracle.adf.model.MetadataContext;
/*     */ import oracle.adf.model.RegionBinding;
/*     */ import oracle.adf.model.binding.DCBindingContainer;
/*     */ import oracle.adf.model.binding.DCCachingErrorHandler;
/*     */ import oracle.adf.model.binding.DCDataControl;
/*     */ import oracle.adf.model.binding.DCErrorHandler;
/*     */ import oracle.adf.model.config.AdfmConfig;
/*     */ import oracle.adf.model.dcframe.TransactionProperties;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.Environment;
/*     */ import oracle.adf.share.common.ClassUtils;
/*     */ import oracle.adf.share.mds.ADFSessionOptions;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.ApplicationModule;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.JboWarning;
/*     */ import oracle.jbo.Transaction;
/*     */ import oracle.jbo.common.JBOClass;
/*     */ import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
/*     */ 
/*     */ class ResourceLifecycle
/*     */ {
/*  57 */   private static final ResourceInputHandlerImpl DEFAULT_INPUT_HANDLER = new ResourceInputHandlerImpl();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void initContext(ResourceLifecycleContext lifecycleContext)
/*     */   {
/*  71 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*  72 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/*     */     
/*  74 */     logger.beginActivity(Level.FINER, "Configuring ADFContext");
/*  75 */     ADFContext adfContext = ADFContext.findCurrent();
/*     */     
/*  77 */     if (adfContext.hasEnvironment()) {
/*  78 */       adfContext.getEnvironment().setFacesEnvironment(false);
/*     */     }
/*     */     try
/*     */     {
/*  82 */       Class elFactory = ClassUtils.forName("com.sun.el.ExpressionFactoryImpl");
/*  83 */       Object elFactoryInstance = elFactory.newInstance();
/*  84 */       adfContext.setExpressionFactory((ExpressionFactory)elFactoryInstance);
/*     */     } catch (Exception ex) {
/*  86 */       logger.warning("Unable to set the EL Factory (com.sun.el.ExpressionFactoryImpl missing).");
/*     */     }
/*     */     
/*  89 */     Locale locale = context.getLocale();
/*  90 */     if (locale == null) {
/*  91 */       locale = Locale.getDefault();
/*     */     }
/*  93 */     adfContext.setLocale(locale);
/*  94 */     adfContext.setIsInServiceRequest(true);
/*     */     
/*  96 */     if (isDependencyProcessingNeeded(context.getResourceParameterMap(), lifecycleContext.getOperationType())) {
/*  97 */       RESTUtil.setFailOnLOVMismatchEnabled(Boolean.FALSE);
/*     */     }
/*     */     
/* 100 */     logger.endCurrentActivity();
/*     */     
/* 102 */     logger.beginActivity(Level.FINER, "Configuring the binding layer", null);
/* 103 */     context.init();
/* 104 */     setErrorHandlerCachingMode(context, true);
/* 105 */     BindingContext bindingContext = BindingContext.getCurrent();
/* 106 */     if ((bindingContext != null) && (bindingContext.getDefaultInputHandlerInstance() == null)) {
/* 107 */       bindingContext.setDefaultInputHandlerInstance(getDefaultInputHandler());
/*     */     }
/* 109 */     logger.endCurrentActivity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void prepareModel(ResourceLifecycleContext lifecycleContext)
/*     */     throws Exception
/*     */   {
/* 118 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/*     */     
/* 120 */     locateResource(context, lifecycleContext.getOperationType());
/* 121 */     Operation operation = createOperation(context, lifecycleContext.getResponseHandler(), lifecycleContext.getOperationType());
/*     */     
/*     */ 
/* 124 */     ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.OPERATION_PROVIDER);
/* 125 */     operation.init(context);
/* 126 */     ResourceLoggerManager.removeCurrentLogger();
/*     */     
/* 128 */     processPrecondition(lifecycleContext, operation);
/*     */     
/* 130 */     lifecycleContext.setOperation(operation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processPrecondition(ResourceLifecycleContext lifecycleContext, Operation operation)
/*     */     throws Exception
/*     */   {
/* 145 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 146 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 147 */     ResponseHandler responseHandler = lifecycleContext.getResponseHandler();
/* 148 */     Map<String, String> preconditionContextData = null;
/* 149 */     if (logger.isConfig()) {
/* 150 */       logger.beginActivity(Level.CONFIG, "Processing operation precondition", null);
/* 151 */       preconditionContextData = new HashMap(1);
/*     */     }
/*     */     try
/*     */     {
/* 155 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.OPERATION_PROVIDER);
/* 156 */       operation.processPrecondition(context);
/* 157 */       ResourceLoggerManager.removeCurrentLogger();
/* 158 */       if (logger.isConfig()) {
/* 159 */         preconditionContextData.put("Precondition succeeded?", "true");
/* 160 */         logger.addContextData(preconditionContextData);
/*     */       }
/*     */     } catch (PreconditionFailedException ex) {
/* 163 */       ResourceLoggerManager.removeCurrentLogger();
/* 164 */       if (logger.isConfig()) {
/* 165 */         preconditionContextData.put("Precondition succeeded?", "false");
/* 166 */         logger.addContextData(preconditionContextData);
/*     */       }
/* 168 */       responseHandler.setError(ResponseHandler.ErrorType.PRECONDITION_FAILED);
/* 169 */       throw ex;
/*     */     } finally {
/* 171 */       if (logger.isConfig()) {
/* 172 */         logger.endCurrentActivity();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void locateResource(ResourceProcessingContext context, OperationType operationType)
/*     */   {
/* 183 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 184 */     logger.beginActivity(Level.CONFIG, "Locating the resource");
/*     */     
/* 186 */     if (logger.isConfig()) {
/* 187 */       logger.addContextData("ResourcePath", context.getOriginalPathAsString());
/*     */     }
/*     */     
/* 190 */     context.locateResource(isDependencyProcessingNeeded(context.getResourceParameterMap(), operationType));
/* 191 */     logger.endCurrentActivity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Operation createOperation(ResourceProcessingContext context, ResponseHandler responseHandler, OperationType operationType)
/*     */   {
/* 204 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 205 */     ResourceType resourceType = null;
/* 206 */     resourceType = context.getResourceType();
/*     */     
/* 208 */     logger.beginActivity(Level.FINER, "Creating operation", null);
/*     */     
/* 210 */     Operation operation = OperationFactory.createOperation(resourceType, operationType);
/* 211 */     if (operation == null) {
/* 212 */       throw new OperationNotFoundException(resourceType.toString(), operationType.toString());
/*     */     }
/*     */     
/* 215 */     if ((!context.isResourceTreeAvailable()) && (operation.isDependentOnResource())) {
/* 216 */       throw new ResourceNotFoundException("This operation requires a resource tree.");
/*     */     }
/*     */     
/* 219 */     ResourceEntityType responseEntityType = operation.getResponseEntityType();
/* 220 */     if (responseEntityType != null) {
/* 221 */       responseHandler.setContentType(responseEntityType);
/*     */     }
/* 223 */     operation.setResponseHandler(responseHandler);
/*     */     
/* 225 */     if (logger.isFiner()) {
/* 226 */       Map<String, String> contextData = new HashMap(1);
/* 227 */       contextData.put("Operation", operation.getSecurityName());
/* 228 */       logger.addContextData(contextData);
/*     */     }
/* 230 */     logger.endCurrentActivity();
/*     */     
/* 232 */     return operation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void applyInputValues(ResourceLifecycleContext lifecycleContext)
/*     */     throws Exception
/*     */   {
/* 241 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 242 */     Operation operation = lifecycleContext.getOperation();
/* 243 */     ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.OPERATION_PROVIDER);
/* 244 */     operation.applyInputValues(context);
/* 245 */     ResourceLoggerManager.removeCurrentLogger();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void validateInputValues(ResourceLifecycleContext lifecycleContext)
/*     */     throws Exception
/*     */   {
/* 254 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 255 */     Operation operation = lifecycleContext.getOperation();
/*     */     
/* 257 */     ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.OPERATION_PROVIDER);
/* 258 */     operation.validateInputValues(context);
/* 259 */     ResourceLoggerManager.removeCurrentLogger();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void checkSecurity(ResourceLifecycleContext lifecycleContext)
/*     */     throws Exception
/*     */   {
/* 268 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 269 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 270 */     Operation operation = lifecycleContext.getOperation();
/*     */     
/* 272 */     if (!canExecuteOperation(context, operation)) {
/* 273 */       throw new NotAuthorizedException("Not authorized. Operation: " + operation.getSecurityName());
/*     */     }
/* 275 */     logger.config("User authorized");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void processUpdateModel(ResourceLifecycleContext lifecycleContext)
/*     */     throws Exception
/*     */   {
/* 284 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 285 */     Operation operation = lifecycleContext.getOperation();
/*     */     
/* 287 */     if ((!context.isBatchMode()) && (operation.isCommitNeeded()))
/*     */     {
/* 289 */       if (MetadataContext.isUsingSandbox()) {
/* 290 */         lifecycleContext.prepareMetadata();
/*     */       }
/*     */       
/* 293 */       context.getBindingContext().dataControlFrame().beginTransaction(new TransactionProperties());
/*     */     }
/* 295 */     ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.OPERATION_PROVIDER);
/* 296 */     operation.execute(context);
/* 297 */     ResourceLoggerManager.removeCurrentLogger();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void validateModelUpdates(ResourceLifecycleContext lifecycleContext)
/*     */   {
/* 305 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 306 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 307 */     DCBindingContainer bindingContainer = context.getBindingContainer();
/*     */     
/* 309 */     if (bindingContainer != null) {
/* 310 */       bindingContainer.validate();
/* 311 */       bindingContainer.getDataControl().getApplicationModule().getTransaction().validate();
/*     */     } else {
/* 313 */       logger.finer("Binding container is null, skipping validation");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   List hasErrors(ResourceLifecycleContext context)
/*     */   {
/* 324 */     DCBindingContainer bindings = context.getResourceProcessingContext().getBindingContainer();
/*     */     
/*     */ 
/* 327 */     if (bindings == null) {
/* 328 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/* 331 */     List runtimeErrors = bindings.getExceptionsList();
/* 332 */     if ((runtimeErrors != null) && (!runtimeErrors.isEmpty())) {
/* 333 */       for (Iterator iterator = runtimeErrors.iterator(); iterator.hasNext();)
/*     */       {
/* 335 */         Object ex = iterator.next();
/* 336 */         if (((ex instanceof JboWarning)) && (((JboWarning)ex).isWarning())) {
/* 337 */           ContextualLogger logger = ResourceLoggerManager.getCurrentLogger();
/* 338 */           logger.warning((JboWarning)ex);
/* 339 */           iterator.remove();
/*     */         }
/*     */       }
/* 342 */       return runtimeErrors;
/*     */     }
/*     */     
/* 345 */     return Collections.EMPTY_LIST;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void dataCommit(ResourceLifecycleContext lifecycleContext)
/*     */   {
/* 353 */     Operation operation = lifecycleContext.getOperation();
/* 354 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 355 */     if (operation.isCommitNeeded()) {
/* 356 */       if (context.isEffectiveDateRangeOperation()) {
/* 357 */         context.getBindingContainer().getDataControl().getApplicationModule().getTransaction().addTransactionStateListener(new ResourceTransactionStateListener(context));
/*     */       }
/*     */       
/* 360 */       context.getResourceTree().commitTransaction();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static RegionBinding setBindingELVariable(RegionBinding bindings)
/*     */   {
/*     */     Map requestScope;
/*     */     try
/*     */     {
/* 370 */       requestScope = ADFContext.findCurrent().getRequestScope();
/*     */     } catch (UnsupportedOperationException ex) {
/* 372 */       ContextualLogger logger = ResourceLoggerManager.getCurrentLogger();
/* 373 */       logger.severe("Cannot set bindings");
/* 374 */       return null;
/*     */     }
/*     */     
/* 377 */     return setBindingELVariable(requestScope, bindings);
/*     */   }
/*     */   
/*     */   private void refreshBindingsIfNeeded(ResourceLifecycleContext lfContext) {
/* 381 */     BindingContext bctx = BindingContext.getCurrent();
/* 382 */     if (bctx != null) {
/* 383 */       DCBindingContainer bindings = lfContext.getResourceProcessingContext().getBindingContainer();
/* 384 */       if (bindings != null) {
/* 385 */         bctx.refreshAfterMetadataChanges(bindings);
/*     */         
/*     */ 
/* 388 */         bindings = lfContext.getResourceProcessingContext().getBindingContainer();
/*     */         
/*     */ 
/*     */ 
/* 392 */         setBindingELVariable(bindings);
/* 393 */         bindings.refresh(1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void metadataCommit(ResourceLifecycleContext lfContext)
/*     */   {
/*     */     try
/*     */     {
/* 404 */       lfContext.flushMetadata();
/* 405 */       refreshBindingsIfNeeded(lfContext);
/*     */     } catch (Exception ex) {
/* 407 */       BindingContext bctx = BindingContext.getCurrent();
/*     */       
/* 409 */       if (bctx != null) {
/* 410 */         DCBindingContainer bindingContainer = (DCBindingContainer)bctx.getCurrentBindingsEntry();
/*     */         
/*     */ 
/* 413 */         if (bindingContainer != null) {
/* 414 */           bindingContainer.reportException(ex);
/* 415 */           return;
/*     */         }
/*     */       }
/*     */       
/* 419 */       if ((ex instanceof RuntimeException)) {
/* 420 */         throw ((RuntimeException)ex);
/*     */       }
/* 422 */       throw new JboException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void prepareResponse(ResourceLifecycleContext lifecycleContext)
/*     */     throws Exception
/*     */   {
/* 434 */     Operation operation = lifecycleContext.getOperation();
/* 435 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/*     */     
/*     */ 
/*     */ 
/* 439 */     ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.OPERATION_PROVIDER);
/* 440 */     operation.prepareResponse(context);
/* 441 */     ResourceLoggerManager.removeCurrentLogger();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void generateResponse(ResourceLifecycleContext lifecycleContext)
/*     */     throws Exception
/*     */   {
/* 450 */     ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/* 451 */     Operation operation = lifecycleContext.getOperation();
/*     */     
/* 453 */     ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.OPERATION_PROVIDER);
/* 454 */     operation.generateResponse(context);
/* 455 */     if (!context.isBatchMode()) {
/* 456 */       ResponseHandler responseHandler = lifecycleContext.getResponseHandler();
/* 457 */       if ((responseHandler.isEntityGenerationAllowed()) && (responseHandler.getPayloadGenerator() != null)) {
/* 458 */         responseHandler.getPayloadGenerator().close();
/*     */       }
/*     */     }
/* 461 */     ResourceLoggerManager.removeCurrentLogger();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setErrorHandlerCachingMode(ResourceProcessingContext context, boolean mode)
/*     */   {
/* 471 */     BindingContext bctx = context.getBindingContext();
/* 472 */     if (bctx == null) {
/* 473 */       return;
/*     */     }
/*     */     
/* 476 */     DCErrorHandler handler = bctx.getErrorHandler();
/* 477 */     if ((handler instanceof DCCachingErrorHandler)) {
/* 478 */       ((DCCachingErrorHandler)handler).setThrowFlag(!mode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void reportErrors(ResourceLifecycleContext context, List exList)
/*     */   {
/* 487 */     if (exList.size() == 1) {
/* 488 */       Object ex = exList.get(0);
/* 489 */       if ((ex instanceof JboException)) {
/* 490 */         throw ((JboException)ex);
/*     */       }
/*     */     }
/* 493 */     ErrorMessageHandler errorMessageHandler = new ErrorMessageHandler(context.getResourceProcessingContext().getBindingContainer());
/*     */     
/*     */ 
/* 496 */     String consolidatedMessage = errorMessageHandler.getConsolidatedMessage();
/*     */     
/* 498 */     throw new JboException(consolidatedMessage == null ? "" : consolidatedMessage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void reportErrors(ResourceLifecycleContext context, JboException defaultException)
/*     */   {
/* 506 */     ErrorMessageHandler errorMessageHandler = new ErrorMessageHandler(context.getResourceProcessingContext().getBindingContainer());
/*     */     
/*     */ 
/* 509 */     String consolidatedMessage = errorMessageHandler.getConsolidatedMessage();
/* 510 */     if (consolidatedMessage == null) {
/* 511 */       throw defaultException;
/*     */     }
/* 513 */     JboException consolidateMessageException = new JboException(consolidatedMessage);
/* 514 */     consolidateMessageException.addToExceptions(defaultException);
/*     */     
/* 516 */     throw consolidateMessageException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void reportErrors(ResourceLifecycleContext context, ResourceException ex)
/*     */   {
/* 524 */     ErrorMessageHandler errorMessageHandler = new ErrorMessageHandler(context.getResourceProcessingContext().getBindingContainer());
/*     */     
/* 526 */     String consolidatedErrorMessage = errorMessageHandler.getConsolidatedMessage();
/* 527 */     if (consolidatedErrorMessage != null) {
/* 528 */       ex.addToExceptions(new JboException(consolidatedErrorMessage));
/*     */     }
/* 530 */     throw ex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canExecuteOperation(ResourceProcessingContext context, Operation operation)
/*     */   {
/* 540 */     return operation.isAuthorized(context);
/*     */   }
/*     */   
/*     */   private static JUCtrlInputValueHandler getDefaultInputHandler()
/*     */   {
/* 545 */     ContextualLogger logger = ResourceLoggerManager.getCurrentLogger();
/* 546 */     JUCtrlInputValueHandler defaultInputHandler = null;
/* 547 */     String defaultInputHandlerProperty = (String)AdfmConfig.getCustomProperty("adf.rest.defaultinputhandler");
/* 548 */     if (defaultInputHandlerProperty != null) {
/*     */       try
/*     */       {
/* 551 */         Class inputHandler = JBOClass.forName(defaultInputHandlerProperty);
/* 552 */         if (JUCtrlInputValueHandler.class.isAssignableFrom(inputHandler))
/*     */         {
/* 554 */           defaultInputHandler = (JUCtrlInputValueHandler)inputHandler.newInstance();
/*     */         }
/*     */         else
/*     */         {
/* 558 */           logger.log(Level.FINE, "Error while setting the default BindingContext input handler. The informed class does not implement " + JUCtrlInputValueHandler.class.getName() + ". Class name: " + defaultInputHandlerProperty);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 565 */         logger.log(Level.FINE, "Error while creating the default input handler. Provided class name: " + defaultInputHandlerProperty, e);
/*     */       }
/*     */     }
/*     */     
/* 569 */     if (defaultInputHandler == null) {
/* 570 */       defaultInputHandler = DEFAULT_INPUT_HANDLER;
/*     */     }
/*     */     
/* 573 */     return defaultInputHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isDependencyProcessingNeeded(ResourceParameterMap map, OperationType operationType)
/*     */   {
/* 584 */     if ((operationType == OperationType.REPRESENTATION) && (map != null)) {
/* 585 */       DependencyParam dependencyParam = (DependencyParam)ResourceParameter.Type.DEPENDENCY.castTo(map.get(ResourceParameter.Type.DEPENDENCY));
/* 586 */       if ((dependencyParam != null) && (dependencyParam.getParameters() != null)) {
/* 587 */         return true;
/*     */       }
/*     */     }
/* 590 */     return false;
/*     */   }
/*     */   
/*     */   void checkMetadataContext(ResourceLifecycleContext context) {
/* 594 */     if (RESTUtil.skipMetadataContextCheck()) {
/* 595 */       return;
/*     */     }
/* 597 */     String metadataProperties = context.getResourceProcessingContext().getMetadataProperties();
/* 598 */     ADFSessionOptions so = MetadataContext.createADFSessionOptions(metadataProperties);
/* 599 */     if (so != null) {
/* 600 */       so.verifyCurrentMDSSession();
/*     */     }
/*     */   }
/*     */   
/*     */   private static RegionBinding setBindingELVariable(Map requestMap, RegionBinding bindings) {
/* 605 */     return (RegionBinding)requestMap.put("bindings", bindings);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ResourceLifecycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */