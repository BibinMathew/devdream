/*    */ package oracle.adf.internal.model.rest.core.http;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ import oracle.adf.internal.model.rest.core.http.header.Accept;
/*    */ import oracle.adf.internal.model.rest.core.http.header.AcceptBestMatchResult;
/*    */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*    */ import oracle.adf.internal.model.rest.core.http.media.EntityMediaTypeMapping;
/*    */ import oracle.adf.internal.model.rest.core.http.media.MediaTypeHandler;
/*    */ 
/*    */ public class AcceptHeaderManager
/*    */ {
/*    */   private final Accept acceptHeader;
/*    */   private oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler contentTypeHandler;
/*    */   private AcceptBestMatchResult acceptResult;
/*    */   private EntityMediaTypeMapping entityMediaMapping;
/*    */   
/*    */   public oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler getContentTypeHandler()
/*    */   {
/* 21 */     return this.contentTypeHandler;
/*    */   }
/*    */   
/*    */   public boolean isAcceptable() {
/* 25 */     return this.contentTypeHandler != null;
/*    */   }
/*    */   
/*    */   public AcceptHeaderManager(EntityMediaTypeMapping entityMediaMapping)
/*    */   {
/* 30 */     this.acceptHeader = createAcceptHeader(null);
/* 31 */     this.entityMediaMapping = entityMediaMapping;
/*    */   }
/*    */   
/*    */   public AcceptHeaderManager(String acceptHeader, EntityMediaTypeMapping entityMediaMapping)
/*    */   {
/* 36 */     this.acceptHeader = createAcceptHeader(acceptHeader);
/* 37 */     this.entityMediaMapping = entityMediaMapping;
/*    */   }
/*    */   
/*    */   public AcceptHeaderManager()
/*    */   {
/* 42 */     this.acceptHeader = createAcceptHeader(null);
/* 43 */     this.entityMediaMapping = HTTPRESTUtil.ENTITY_MEDIA_MAPPING;
/*    */   }
/*    */   
/*    */   private Accept createAcceptHeader(String acceptHeader) {
/* 47 */     Accept accept = null;
/*    */     
/* 49 */     if (acceptHeader != null) {
/* 50 */       accept = Accept.parse(acceptHeader);
/*    */     } else {
/* 52 */       accept = Accept.createDefaultAccept();
/*    */     }
/* 54 */     return accept;
/*    */   }
/*    */   
/*    */   public void process(String mediaType) {
/* 58 */     process(MediaType.parseMediaType(mediaType));
/*    */   }
/*    */   
/*    */   public void process(MediaType mediaType) {
/* 62 */     process(mediaType, null);
/*    */   }
/*    */   
/*    */   public void process(ResourceEntityType entityType) {
/* 66 */     process(this.entityMediaMapping.getAllSupportedMediaTypes(entityType), entityType);
/*    */   }
/*    */   
/*    */   public void process(Set<MediaType> medias, ResourceEntityType defaultEntityType) {
/* 70 */     AcceptBestMatchResult acceptResult = this.acceptHeader.findBestMatch(medias);
/* 71 */     if ((acceptResult == null) || (!acceptResult.getBestMediaRange().getQualityFactor().isAcceptable())) {
/* 72 */       this.acceptResult = null;
/* 73 */       this.contentTypeHandler = null;
/* 74 */       return;
/*    */     }
/* 76 */     this.acceptResult = acceptResult;
/*    */     
/* 78 */     if (defaultEntityType != null) {
/* 79 */       this.contentTypeHandler = MediaTypeHandler.createContentTypeHandler(acceptResult.getBestSuppportedMediaType(), defaultEntityType);
/*    */     }
/*    */     else {
/* 82 */       this.contentTypeHandler = MediaTypeHandler.createContentTypeHandler(acceptResult.getBestSuppportedMediaType());
/*    */     }
/*    */   }
/*    */   
/*    */   public AcceptBestMatchResult getAcceptResult()
/*    */   {
/* 88 */     return this.acceptResult;
/*    */   }
/*    */   
/*    */   public void process(MediaType mediaType, ResourceEntityType defaultEntityType) {
/* 92 */     HashSet<MediaType> mediaTypes = new HashSet(1);
/* 93 */     mediaTypes.add(mediaType);
/* 94 */     process(mediaTypes, defaultEntityType);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\AcceptHeaderManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */