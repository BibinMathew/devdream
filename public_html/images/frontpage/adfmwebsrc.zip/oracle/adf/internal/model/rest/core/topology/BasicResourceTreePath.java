/*     */ package oracle.adf.internal.model.rest.core.topology;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceItem;
/*     */ 
/*     */ public class BasicResourceTreePath implements ResourceTreePath
/*     */ {
/*     */   private ResourceTreePath parent;
/*  11 */   private final Map<String, List<BasicResourceTreePath>> childResourceMap = new java.util.HashMap();
/*     */   private BasicTreePath treePath;
/*     */   private List<oracle.jbo.Key> resourceKeyPath;
/*  14 */   private String accessorPath = "";
/*     */   
/*     */   public BasicResourceTreePath(Resource resource)
/*     */   {
/*  18 */     configureResource(resource);
/*     */   }
/*     */   
/*     */   private void configureResource(Resource resource) {
/*  22 */     this.resourceKeyPath = resource.getKeyPath();
/*     */   }
/*     */   
/*     */ 
/*     */   public BasicResourceTreePath() {}
/*     */   
/*     */   public void addChildResourcePath(String childResource, BasicResourceTreePath info)
/*     */   {
/*  30 */     List<BasicResourceTreePath> infos = (List)this.childResourceMap.get(childResource);
/*  31 */     if (infos == null) {
/*  32 */       infos = new java.util.ArrayList();
/*  33 */       this.childResourceMap.put(childResource, infos);
/*     */     }
/*  35 */     info.parent = this;
/*  36 */     info.treePath = this.treePath;
/*  37 */     info.accessorPath = TreePathUtil.createAccessorPath(this.accessorPath, childResource);
/*  38 */     infos.add(info);
/*     */   }
/*     */   
/*     */   public java.util.Collection<String> getAllChildrenNames() {
/*  42 */     return getResource().getNestedResourceNames();
/*     */   }
/*     */   
/*     */   public java.util.Collection<String> getChildrenNames() {
/*  46 */     return new java.util.HashSet(this.childResourceMap.keySet());
/*     */   }
/*     */   
/*     */   public java.util.Collection<BasicResourceTreePath> getChildren(String childResourceName) {
/*  50 */     List<BasicResourceTreePath> children = (List)this.childResourceMap.get(childResourceName);
/*  51 */     if (children == null) {
/*  52 */       return java.util.Collections.emptyList();
/*     */     }
/*  54 */     java.util.Set childrenSet = new java.util.HashSet(children);
/*     */     
/*  56 */     List<BasicResourceTreePath> childrenList = new java.util.ArrayList(childrenSet.size());
/*     */     
/*     */ 
/*  59 */     for (BasicResourceTreePath child : children) {
/*  60 */       if (childrenSet.remove(child)) {
/*  61 */         childrenList.add(child);
/*     */       }
/*     */     }
/*     */     
/*  65 */     return childrenList;
/*     */   }
/*     */   
/*     */   public void setResource(ResourceItem resource) {
/*  69 */     configureResource(resource);
/*     */   }
/*     */   
/*     */   public ResourceItem getResource() {
/*  73 */     if (this.resourceKeyPath == null) {
/*  74 */       return null;
/*     */     }
/*  76 */     return ResourceItem.asItem(this.treePath.getResourceTree().findResourceByKeyPath(this.resourceKeyPath));
/*     */   }
/*     */   
/*     */   public ResourceTreePath getParent() {
/*  80 */     return this.parent;
/*     */   }
/*     */   
/*     */   void setTreePath(BasicTreePath treePath) {
/*  84 */     this.treePath = treePath;
/*     */   }
/*     */   
/*     */   public List<oracle.jbo.Key> getResourceKeyPath()
/*     */   {
/*  89 */     return this.resourceKeyPath;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/*  94 */     if (this == object) {
/*  95 */       return true;
/*     */     }
/*  97 */     if (!(object instanceof BasicResourceTreePath)) {
/*  98 */       return false;
/*     */     }
/* 100 */     BasicResourceTreePath other = (BasicResourceTreePath)object;
/* 101 */     if (this.resourceKeyPath == null ? other.resourceKeyPath != null : !this.resourceKeyPath.equals(other.resourceKeyPath))
/*     */     {
/* 103 */       return false;
/*     */     }
/* 105 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 110 */     int PRIME = 37;
/* 111 */     int result = 1;
/* 112 */     result = 37 * result + (this.resourceKeyPath == null ? 0 : this.resourceKeyPath.hashCode());
/* 113 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public Integer getLimit(String childResourceName)
/*     */   {
/* 119 */     List<BasicResourceTreePath> children = (List)this.childResourceMap.get(childResourceName);
/* 120 */     if (children == null) {
/* 121 */       return Integer.valueOf(0);
/*     */     }
/* 123 */     return Integer.valueOf(children.size());
/*     */   }
/*     */   
/*     */   public String getAccessorPath()
/*     */   {
/* 128 */     return this.accessorPath;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\topology\BasicResourceTreePath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */