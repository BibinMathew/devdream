/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.Action;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionResult;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceHelper;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ 
/*    */ class ActionExecution extends AbstractResourceOperation
/*    */ {
/*    */   private Action action;
/*    */   private ActionResult actionResult;
/*    */   
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 22 */     if (context.getParserFactory() == null) {
/* 23 */       throw new CannotParseContentException("The PayloadParser could not be found in the ResourceProcessingContext.");
/*    */     }
/*    */   }
/*    */   
/*    */   public void applyInputValues(ResourceProcessingContext context) throws IOException
/*    */   {
/* 29 */     this.action = ResourceHelper.createResourceAction(context);
/*    */   }
/*    */   
/*    */   public void validateInputValues(ResourceProcessingContext context)
/*    */   {
/* 34 */     if ((this.action.producesActionResult()) && (!this.responseHandler.isEntityGenerationAllowed())) {
/* 35 */       throw new CannotGenerateContentException("The action returns a result but the entity generation is not enabled in the ResponseHandler.");
/*    */     }
/*    */   }
/*    */   
/*    */   public void execute(ResourceProcessingContext context)
/*    */   {
/* 41 */     this.actionResult = context.getResourceTree().getCurrentResource().executeAction(this.action);
/* 42 */     if (this.actionResult == null) {
/* 43 */       this.responseHandler.resetContentType();
/*    */     }
/*    */   }
/*    */   
/*    */   public void generateResponse(ResourceProcessingContext context) throws IOException
/*    */   {
/* 49 */     if ((this.actionResult != null) && (this.responseHandler.isEntityGenerationAllowed())) {
/* 50 */       oracle.adf.internal.model.rest.core.payload.PayloadGenerator generator = this.responseHandler.getPayloadGenerator();
/* 51 */       ResourceHelper.generateActionResult(this.actionResult, generator);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 62 */     return OperationType.EXECUTION;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 67 */     return ActionType.INVOKE;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ActionExecution.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */