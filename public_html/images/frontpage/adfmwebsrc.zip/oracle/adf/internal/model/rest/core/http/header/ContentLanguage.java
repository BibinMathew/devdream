/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ public class ContentLanguage implements Header
/*    */ {
/*    */   private String[] languages;
/*    */   public static final String NAME = "Content-Language";
/*    */   private static final String EMPTY_LANGUAGE = "";
/*    */   private static final String SEPARATOR = " ";
/*    */   
/*    */   public ContentLanguage(String... languages)
/*    */   {
/* 12 */     this.languages = languages;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 16 */     if ((this.languages == null) || (this.languages.length == 0)) {
/* 17 */       return "";
/*    */     }
/*    */     
/* 20 */     String contentLanguage = null;
/*    */     
/* 22 */     for (int i = 0; i < this.languages.length; i++) {
/* 23 */       if (i > 0) {
/* 24 */         contentLanguage = contentLanguage + contentLanguage + " " + this.languages[i];
/*    */       } else {
/* 26 */         contentLanguage = this.languages[i];
/*    */       }
/*    */     }
/* 29 */     return contentLanguage;
/*    */   }
/*    */   
/*    */   public static ContentLanguage parseContentLanguage(String contentLanguage) {
/* 33 */     return new ContentLanguage(contentLanguage.split(" "));
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 38 */     return "Content-Language";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\ContentLanguage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */