/*    */ package oracle.adf.internal.model.rest.core.lifecycle;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import oracle.adf.internal.model.rest.core.common.listener.ResourceLifecycleEvent;
/*    */ import oracle.adf.internal.model.rest.core.common.listener.ResourceLifecycleListener;
/*    */ import oracle.adf.internal.model.rest.core.common.listener.annotation.ResourceLifecycleListenerConfig;
/*    */ 
/*    */ class ResourceLifecycleListenerWrapper implements ResourceLifecycleListener
/*    */ {
/*    */   private final ResourceLifecycleListener listener;
/*    */   private final ResourceLifecyclePhase[] listenTo;
/*    */   
/*    */   private ResourceLifecycleListenerWrapper(ResourceLifecycleListener listener)
/*    */   {
/* 15 */     this.listener = listener;
/* 16 */     ResourceLifecycleListenerConfig listenerConfig = (ResourceLifecycleListenerConfig)this.listener.getClass().getAnnotation(ResourceLifecycleListenerConfig.class);
/* 17 */     ResourceLifecyclePhase[] array = null;
/* 18 */     if (listenerConfig != null) {
/* 19 */       array = listenerConfig.listenTo();
/*    */     }
/*    */     
/* 22 */     this.listenTo = ((array == null) || (array.length == 0) ? ResourceLifecyclePhase.values() : array);
/*    */   }
/*    */   
/*    */   static ResourceLifecycleListenerWrapper wrap(ResourceLifecycleListener listener) {
/* 26 */     ResourceLifecycleListenerWrapper wrappedListener = new ResourceLifecycleListenerWrapper(listener);
/* 27 */     return wrappedListener;
/*    */   }
/*    */   
/*    */   static ResourceLifecycleListener unWrap(ResourceLifecycleListenerWrapper wrappedListener) {
/* 31 */     return wrappedListener.listener;
/*    */   }
/*    */   
/*    */   public void notify(ResourceLifecycleEvent event)
/*    */   {
/* 36 */     this.listener.notify(event);
/*    */   }
/*    */   
/*    */   ResourceLifecyclePhase[] getListenTo() {
/* 40 */     return (ResourceLifecyclePhase[])Arrays.copyOf(this.listenTo, this.listenTo.length);
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 45 */     if (this == object) {
/* 46 */       return true;
/*    */     }
/* 48 */     if (!(object instanceof ResourceLifecycleListenerWrapper)) {
/* 49 */       return false;
/*    */     }
/*    */     
/* 52 */     ResourceLifecycleListenerWrapper other = (ResourceLifecycleListenerWrapper)object;
/* 53 */     String className = this.listener.getClass().getName();
/* 54 */     String otherClassName = other.getClass().getName();
/* 55 */     if (className == null ? otherClassName != null : !className.equals(otherClassName)) {
/* 56 */       return false;
/*    */     }
/* 58 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 63 */     int PRIME = 37;
/* 64 */     int result = 1;
/* 65 */     String className = this.listener.getClass().getName();
/* 66 */     result = 37 * result + (className == null ? 0 : className.hashCode());
/* 67 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ResourceLifecycleListenerWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */