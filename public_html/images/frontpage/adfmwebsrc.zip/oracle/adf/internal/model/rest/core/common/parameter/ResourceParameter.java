/*     */ package oracle.adf.internal.model.rest.core.common.parameter;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceParameter
/*     */ {
/*     */   public static abstract enum Type
/*     */   {
/*  17 */     FINDER(FinderParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  23 */     ONLYDATA(OnlyDataParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  34 */     FIELDS(ListParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */     TOTAL_RESULTS(TotalResultsParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */     OFFSET(OffsetParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */     LIMIT(LimitParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */     EXPAND(ExpandParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */     ORDER_BY(OrderByParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */     QUERY(QueryParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     DEPENDENCY(DependencyParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */     EFFECTIVE_DATE(EffectiveDateParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */     INCLUDE_CHILDREN(IncludeChildrenParam.class), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */     SHOW_ANNOTATIONS(AnnotationsParam.class);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Class<? extends ResourceParameter> paramImpl;
/*     */     
/*     */ 
/*     */ 
/*     */     private static final Map<String, Type> MAP;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     static
/*     */     {
/* 146 */       Type[] values = values();
/* 147 */       Map<String, Type> map = new HashMap(values.length);
/* 148 */       for (Type resourceParameter : values) {
/* 149 */         map.put(resourceParameter.toString(), resourceParameter);
/*     */       }
/* 151 */       MAP = Collections.unmodifiableMap(map);
/*     */     }
/*     */     
/* 154 */     static Map<String, Type> getMap() { return MAP; }
/*     */     
/*     */     private Type(Class<? extends ResourceParameter> paramImpl)
/*     */     {
/* 158 */       this.paramImpl = paramImpl;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 162 */       return super.toString().toLowerCase();
/*     */     }
/*     */     
/*     */ 
/*     */     public Class<? extends ResourceParameter> getParamImpl()
/*     */     {
/* 168 */       return this.paramImpl;
/*     */     }
/*     */     
/*     */     public abstract <T extends ResourceParameter> T castTo(ResourceParameter paramResourceParameter);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\ResourceParameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */