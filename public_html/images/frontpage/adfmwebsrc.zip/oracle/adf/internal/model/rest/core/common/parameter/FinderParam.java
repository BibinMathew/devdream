/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FinderParam
/*    */   extends ResourceParameter
/*    */ {
/* 18 */   private static final Pattern FINDER_REGEX = Pattern.compile("([^,=]+)=([^,$]+)");
/*    */   
/*    */   private static final String FINDER_NAME_SEPARATOR = ";";
/*    */   private static final String FINDER_PARAMETER_SEPARATOR = ",";
/*    */   private static final String FINDER_PARAMETER_VALUE_SEPARATOR = "=";
/*    */   private final String name;
/* 24 */   private final Map<String, String> parameters = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public FinderParam(String[] parameterValues)
/*    */   {
/* 31 */     String finderString = parameterValues[0];
/* 32 */     String[] splitFinderString = finderString.split(";", 2);
/* 33 */     this.name = splitFinderString[0];
/* 34 */     if (splitFinderString.length == 2) {
/* 35 */       Matcher finderMatcher = FINDER_REGEX.matcher(splitFinderString[1]);
/* 36 */       while (finderMatcher.find()) {
/* 37 */         this.parameters.put(finderMatcher.group(1), finderMatcher.group(2));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 47 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, String> getParameters()
/*    */   {
/* 55 */     return this.parameters;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 63 */     StringBuilder sb = new StringBuilder();
/* 64 */     sb.append(this.name);
/* 65 */     sb.append(";");
/* 66 */     boolean first = true;
/* 67 */     for (Map.Entry<String, String> entry : this.parameters.entrySet()) {
/* 68 */       if (!first) {
/* 69 */         sb.append(",");
/*    */       }
/* 71 */       sb.append((String)entry.getKey());
/* 72 */       sb.append("=");
/* 73 */       sb.append((String)entry.getValue());
/* 74 */       first = false;
/*    */     }
/* 76 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\FinderParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */