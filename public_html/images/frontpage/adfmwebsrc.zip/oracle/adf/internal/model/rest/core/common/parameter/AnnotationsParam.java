/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationsParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private final boolean annotationsShowable;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AnnotationsParam(String[] parameterValues)
/*    */   {
/* 39 */     String boolAsString = null;
/* 40 */     if (parameterValues != null) {
/* 41 */       boolAsString = parameterValues[0];
/*    */     }
/* 43 */     this.annotationsShowable = Boolean.parseBoolean(boolAsString);
/*    */   }
/*    */   
/*    */   public boolean isAnnotationsShowable() {
/* 47 */     return this.annotationsShowable;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\AnnotationsParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */