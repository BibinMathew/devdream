package oracle.adf.internal.model.rest.core.domain;

import java.util.Map.Entry;

public abstract interface Property<V>
  extends Map.Entry<String, V>
{}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Property.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */