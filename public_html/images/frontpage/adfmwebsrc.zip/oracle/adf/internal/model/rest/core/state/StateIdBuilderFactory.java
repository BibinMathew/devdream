/*    */ package oracle.adf.internal.model.rest.core.state;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StateIdBuilderFactory
/*    */ {
/* 10 */   private static StateIdBuilder DEFAULT_BUILDER = new ResourceStateIdBuilder();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static StateIdBuilder getInstance()
/*    */   {
/* 24 */     return DEFAULT_BUILDER;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\state\StateIdBuilderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */