/*    */ package oracle.adf.internal.model.rest.core.http.operation;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.Operation;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPOperationFactory
/*    */ {
/*    */   public static Operation createOperation(ResourceType resourceType, OperationType operationType)
/*    */   {
/* 13 */     Operation operation = null;
/* 14 */     switch (operationType) {
/*    */     case DESCRIPTION: 
/* 16 */       operation = new HTTPResourceDescription();
/*    */     }
/*    */     
/*    */     
/*    */ 
/* 21 */     return operation;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\operation\HTTPOperationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */