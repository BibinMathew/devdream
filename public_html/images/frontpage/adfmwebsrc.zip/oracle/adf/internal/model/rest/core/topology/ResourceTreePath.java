package oracle.adf.internal.model.rest.core.topology;

import java.util.Collection;
import java.util.List;
import oracle.adf.internal.model.rest.core.domain.ResourceItem;
import oracle.jbo.Key;

public abstract interface ResourceTreePath
{
  public abstract void setResource(ResourceItem paramResourceItem);
  
  public abstract ResourceItem getResource();
  
  public abstract ResourceTreePath getParent();
  
  public abstract Collection<String> getChildrenNames();
  
  public abstract Collection<String> getAllChildrenNames();
  
  public abstract Collection<? extends ResourceTreePath> getChildren(String paramString);
  
  public abstract List<Key> getResourceKeyPath();
  
  public abstract Integer getLimit(String paramString);
  
  public abstract String getAccessorPath();
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\topology\ResourceTreePath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */