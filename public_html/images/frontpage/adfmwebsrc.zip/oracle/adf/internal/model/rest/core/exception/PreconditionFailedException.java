/*    */ package oracle.adf.internal.model.rest.core.exception;
/*    */ 
/*    */ 
/*    */ public class PreconditionFailedException
/*    */   extends ResourceException
/*    */ {
/*    */   public PreconditionFailedException(String msg)
/*    */   {
/*  9 */     super(msg);
/*    */   }
/*    */   
/*    */   public PreconditionFailedException(ResourceNotFoundException ex) {
/* 13 */     super(ex);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\exception\PreconditionFailedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */