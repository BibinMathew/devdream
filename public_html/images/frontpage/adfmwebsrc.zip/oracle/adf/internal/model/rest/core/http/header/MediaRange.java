/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ public class MediaRange
/*    */ {
/*    */   public static final String MEDIA_TYPE_GROUP_CHAR = "*";
/*    */   public static final String MEDIA_RANGE_SEPARATOR = ",";
/*    */   public static final String MEDIA_RANGE_PARAM_SEPARATOR = ";";
/*    */   public static final String MEDIA_RANGE_PARAM_VALUE_SEPARATOR = "=";
/*    */   private final MediaType mediaType;
/*    */   private final QualityFactor qualityFactor;
/*    */   
/*    */   public MediaRange(MediaType mediaType, HashMap<String, String> acceptParams)
/*    */   {
/* 17 */     this.mediaType = mediaType;
/*    */     
/* 19 */     String qvalue = "1";
/*    */     
/* 21 */     if (acceptParams != null) {
/* 22 */       String qvalueParameter = (String)acceptParams.get("q");
/* 23 */       if (qvalue != null) {
/* 24 */         qvalue = qvalueParameter;
/*    */       }
/*    */     }
/*    */     
/* 28 */     this.qualityFactor = new QualityFactor(qvalue);
/*    */   }
/*    */   
/*    */   public MediaRange(MediaType mediaType) {
/* 32 */     this(mediaType, null);
/*    */   }
/*    */   
/*    */   public MediaType getMediaType() {
/* 36 */     return this.mediaType;
/*    */   }
/*    */   
/*    */   public QualityFactor getQualityFactor() {
/* 40 */     return this.qualityFactor;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\MediaRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */