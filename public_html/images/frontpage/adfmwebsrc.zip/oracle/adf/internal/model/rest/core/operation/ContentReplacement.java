/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ import oracle.adf.model.rest.core.serializer.StreamSerializerInfo;
/*    */ 
/*    */ class ContentReplacement extends AbstractContentOperation
/*    */ {
/*    */   public void execute(ResourceProcessingContext context)
/*    */   {
/* 14 */     StreamSerializerInfo updateInfo = new StreamSerializerInfo();
/* 15 */     Map<String, String> properties = context.getProperties();
/* 16 */     if (properties != null) {
/* 17 */       updateInfo.putAll(properties);
/*    */     }
/* 19 */     this.attribute.updateContent(updateInfo, context.getInputStream());
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 30 */     return OperationType.REPLACEMENT;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 35 */     return ActionType.REPLACE;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ContentReplacement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */