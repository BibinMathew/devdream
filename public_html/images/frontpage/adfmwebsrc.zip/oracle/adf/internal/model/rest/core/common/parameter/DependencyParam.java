/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DependencyParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private static final String DEPENDENCY_PARAMETER_SEPARATOR = ",";
/*    */   private static final String DEPENDENCY_PARAMETER_VALUE_SEPARATOR = "=";
/*    */   private final Map<String, String> parameters;
/*    */   
/*    */   public DependencyParam(String[] parameterValues)
/*    */   {
/* 27 */     String dependencyString = parameterValues[0];
/* 28 */     String[] parametersArray = dependencyString.split(",");
/* 29 */     Map<String, String> params = new HashMap(parametersArray.length);
/* 30 */     for (String parameter : parametersArray) {
/* 31 */       String[] nameValuePair = parameter.split("=");
/* 32 */       params.put(nameValuePair[0], nameValuePair[1]);
/*    */     }
/* 34 */     this.parameters = Collections.unmodifiableMap(params);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, String> getParameters()
/*    */   {
/* 42 */     return this.parameters;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\DependencyParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */