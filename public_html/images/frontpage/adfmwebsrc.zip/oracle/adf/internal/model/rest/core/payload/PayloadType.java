/*    */ package oracle.adf.internal.model.rest.core.payload;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import oracle.adf.internal.model.rest.core.payload.json.JSONParserFactory;
/*    */ import oracle.adf.internal.model.rest.core.payload.xml.XMLParserFactory;
/*    */ 
/*    */ public enum PayloadType
/*    */ {
/* 10 */   JSON(JSONGenerator.class, JSONParserFactory.class), 
/* 11 */   XML(XMLGenerator.class, XMLParserFactory.class);
/*    */   
/*    */   private final Class<? extends PayloadGenerator> generatorClass;
/*    */   private final Class<? extends ParserFactory> parserClass;
/*    */   
/*    */   private PayloadType(Class<? extends PayloadGenerator> generatorClass, Class<? extends ParserFactory> parserClass) {
/* 17 */     this.generatorClass = generatorClass;
/* 18 */     this.parserClass = parserClass;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public <E> PayloadGenerator createGeneratorInstance(Class<? extends E> outclass, E output)
/*    */     throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException
/*    */   {
/* 27 */     return (PayloadGenerator)this.generatorClass.getConstructor(new Class[] { outclass }).newInstance(new Object[] { output });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public <E> ParserFactory createParserInstance(Class<? extends E> inclass, E output)
/*    */     throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException
/*    */   {
/* 35 */     return (ParserFactory)this.parserClass.getConstructor(new Class[] { inclass }).newInstance(new Object[] { output });
/*    */   }
/*    */   
/*    */   public String toString() {
/* 39 */     return name().toLowerCase();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\PayloadType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */