/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ResourceReference
/*    */ {
/*    */   public abstract Type getType();
/*    */   
/*    */ 
/*    */ 
/*    */   public abstract Path getResourceReferencePath();
/*    */   
/*    */ 
/*    */ 
/*    */   public static enum Type
/*    */   {
/* 17 */     INTERNAL, 
/*    */     
/*    */ 
/*    */ 
/* 21 */     EXTERNAL;
/*    */     
/*    */     private Type() {}
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */