package oracle.adf.internal.model.rest.core.common;

public enum ConditionType
{
  MATCH,  NONE_MATCH;
  
  private ConditionType() {}
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\ConditionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */