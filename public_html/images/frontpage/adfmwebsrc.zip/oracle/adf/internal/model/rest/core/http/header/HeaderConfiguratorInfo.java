/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HeaderConfiguratorInfo
/*    */ {
/* 12 */   private Map<String, String> setupMap = Collections.emptyMap();
/* 13 */   private Set<String> suppressedHeaders = Collections.emptySet();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSetupMap(Map<String, String> setupMap)
/*    */   {
/* 27 */     this.setupMap = Collections.unmodifiableMap(setupMap);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, String> getSetupMap()
/*    */   {
/* 35 */     return this.setupMap;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSuppressedHeaders(Set<String> suppressedHeaders)
/*    */   {
/* 43 */     this.suppressedHeaders = Collections.unmodifiableSet(suppressedHeaders);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Set<String> getSuppressedHeaderNames()
/*    */   {
/* 51 */     return this.suppressedHeaders;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\HeaderConfiguratorInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */