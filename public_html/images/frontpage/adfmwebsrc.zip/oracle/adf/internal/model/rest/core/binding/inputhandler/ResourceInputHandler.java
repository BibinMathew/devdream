package oracle.adf.internal.model.rest.core.binding.inputhandler;

import oracle.adf.model.rest.core.describer.ResourceDescriber;
import oracle.adf.model.rest.core.serializer.ResourceStreamSerializer;
import oracle.adf.model.rest.core.serializer.ResourceValueSerializer;
import oracle.jbo.AttributeDef;
import oracle.jbo.uicli.binding.JUCtrlValueHandler;

abstract interface ResourceInputHandler
  extends JUCtrlValueHandler
{
  public abstract ResourceValueSerializer getJSONSerializer(AttributeDef paramAttributeDef);
  
  public abstract ResourceDescriber getJSONDescriber(AttributeDef paramAttributeDef);
  
  public abstract ResourceStreamSerializer getStreamSerializer(AttributeDef paramAttributeDef);
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\binding\inputhandler\ResourceInputHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */