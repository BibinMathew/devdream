/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultHeaderConfigurator
/*    */   implements HeaderConfigurator
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   public static final String HEADER_CACHE_CONTROL_NAME = "Cache-Control";
/*    */   public static final String HEADER_CACHE_CONTROL_VALUE = "no-cache, no-store, must-revalidate";
/* 21 */   private Map<String, String> headers = Collections.emptyMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private Set<String> suppressedHeaderNames;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, String> getHeaders()
/*    */   {
/* 34 */     return this.headers;
/*    */   }
/*    */   
/*    */   public Set<String> getSuppressedHeaderNames()
/*    */   {
/* 39 */     return this.suppressedHeaderNames;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setup(HeaderConfiguratorInfo info)
/*    */   {
/* 49 */     Map<String, String> headerMap = new HashMap(info.getSetupMap());
/* 50 */     addHeader("Cache-Control", "no-cache, no-store, must-revalidate", headerMap);
/* 51 */     this.headers = Collections.unmodifiableMap(headerMap);
/* 52 */     this.suppressedHeaderNames = info.getSuppressedHeaderNames();
/*    */   }
/*    */   
/*    */ 
/*    */   private void addHeader(String headerName, String headerValue, Map<String, String> headerMap)
/*    */   {
/* 58 */     if (headerMap.containsKey(headerName)) {
/* 59 */       return;
/*    */     }
/* 61 */     headerMap.put(headerName, headerValue);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\DefaultHeaderConfigurator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */