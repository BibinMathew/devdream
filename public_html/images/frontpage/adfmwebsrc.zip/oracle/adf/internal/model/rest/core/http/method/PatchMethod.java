/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.Verb;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*    */ import oracle.adf.internal.model.rest.core.http.exception.OperationNotSupportedException;
/*    */ import oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ class PatchMethod
/*    */   implements HttpMethod
/*    */ {
/*    */   private final HttpOperationType operationType;
/*    */   
/*    */   PatchMethod(HttpMethodInfo info)
/*    */   {
/* 18 */     Verb verb = info.getVerb();
/*    */     
/* 20 */     if (verb != null) {
/* 21 */       throw new OperationNotSupportedException();
/*    */     }
/* 23 */     ContentTypeHandler requestContentTypeHandler = info.getRequestContentTypeHandler();
/*    */     
/*    */ 
/* 26 */     if ((requestContentTypeHandler == null) || (requestContentTypeHandler.getMediaType() == null)) {
/* 27 */       throw new CannotParseContentException("No content type was configured in this request.");
/*    */     }
/* 29 */     this.operationType = HttpOperationType.RESOURCE;
/* 30 */     this.operationType.setOperation(OperationType.UPDATE);
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 36 */     return HttpMethod.Type.PATCH.toString();
/*    */   }
/*    */   
/*    */   public HttpOperationType getOperationType()
/*    */   {
/* 41 */     return this.operationType;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\PatchMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */