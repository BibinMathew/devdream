/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Set;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import oracle.adf.internal.model.rest.core.binding.inputhandler.DescriberFactory;
/*     */ import oracle.adf.internal.model.rest.core.binding.inputhandler.SerializerFactory;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*     */ import oracle.adf.model.BindingContext;
/*     */ import oracle.adf.model.rest.LOVResource;
/*     */ import oracle.adf.model.rest.RestTypeConverter;
/*     */ import oracle.adf.model.rest.core.describer.DescriberInfo;
/*     */ import oracle.adf.model.rest.core.describer.DescriberInfo.LOVResourceInfo;
/*     */ import oracle.adf.model.rest.core.describer.ResourceDescriber;
/*     */ import oracle.adf.model.rest.core.describer.json.JSONDescriberInfo;
/*     */ import oracle.adf.model.rest.core.serializer.ResourceStreamSerializer;
/*     */ import oracle.adf.model.rest.core.serializer.ResourceValueSerializer;
/*     */ import oracle.adf.model.rest.core.serializer.StreamSerializerInfo;
/*     */ import oracle.adf.model.rest.core.serializer.ValueSerializerInfo;
/*     */ import oracle.adf.model.rest.core.serializer.ValueSerializerType;
/*     */ import oracle.adf.model.rest.core.serializer.json.JSONValueInfo;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeHints;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.LocaleContext;
/*     */ import oracle.jbo.Row;
/*     */ import oracle.jbo.ViewObject;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueDef;
/*     */ import oracle.jbo.version.VersionDef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Attribute
/*     */ {
/*     */   public static final String NAME_PLURAL = "attributes";
/*     */   public static final String ANNOT_ATTR = "annotations";
/*     */   public static final String DESC_ATTR = "description";
/*     */   private static final String INPUT_HANDLER_HINT = "inputHandler";
/*     */   private static final String BASE64_ENCODING_NAME = "base64";
/*     */   private final AttributeDef attrDef;
/*     */   private final LocaleContext localeContext;
/*     */   private final JUCtrlInputValueHandler inputHandler;
/*     */   private final JUCtrlValueBinding valb;
/*     */   private final Row row;
/*     */   private final String name;
/*     */   private final ViewObject vo;
/*     */   
/*     */   Attribute(ViewObject vo, AttributeDef attrDef, JUCtrlHierTypeBinding typeBinding, LocaleContext localeContext)
/*     */   {
/*  65 */     this.attrDef = attrDef;
/*  66 */     this.localeContext = localeContext;
/*  67 */     AttributeHints attrHints = getAttributeHints(attrDef);
/*     */     
/*  69 */     JUCtrlInputValueHandler handler = getInputHandlerFromHints(attrHints, attrDef, localeContext);
/*  70 */     if (handler == null) {
/*  71 */       handler = getJUCtrlInputHandler(BindingContext.getCurrent(), attrDef, typeBinding);
/*     */     }
/*  73 */     this.inputHandler = handler;
/*  74 */     this.name = attrDef.getName();
/*  75 */     this.row = null;
/*  76 */     this.valb = null;
/*  77 */     this.vo = vo;
/*     */   }
/*     */   
/*     */   Attribute(ViewObject vo, JUCtrlValueBinding valb) {
/*  81 */     this.attrDef = valb.getAttributeDef();
/*  82 */     this.localeContext = valb.getLocaleContext();
/*  83 */     AttributeHints attrHints = getAttributeHints(valb);
/*     */     
/*  85 */     JUCtrlInputValueHandler handler = getInputHandlerFromHints(attrHints, this.attrDef, this.localeContext);
/*  86 */     if (handler == null) {
/*  87 */       handler = valb.getInputValueHandler();
/*     */     }
/*     */     
/*  90 */     this.inputHandler = handler;
/*  91 */     this.name = valb.getName();
/*  92 */     this.row = valb.getCurrentRow();
/*  93 */     this.valb = valb;
/*  94 */     this.vo = vo;
/*     */   }
/*     */   
/*     */   public void serializeValue(PayloadType payloadType, Object target) {
/*  98 */     ValueSerializerInfo info = null;
/*     */     
/* 100 */     if (payloadType == PayloadType.JSON) {
/* 101 */       info = new JSONValueInfo();
/*     */     }
/*     */     
/* 104 */     serializeValue(payloadType, this.attrDef, this.inputHandler, this.valb, target, info);
/*     */   }
/*     */   
/*     */   public boolean canStreamContent() {
/* 108 */     ResourceStreamSerializer serializer = SerializerFactory.getStreamSerializer(this.inputHandler, this.attrDef);
/* 109 */     return serializer != null;
/*     */   }
/*     */   
/*     */   public boolean canSerializeValue(PayloadType payloadType) {
/* 113 */     return SerializerFactory.getValueSerializer(payloadType, this.attrDef, this.inputHandler) != null;
/*     */   }
/*     */   
/*     */   public boolean hasItemLevelLink(PayloadType payloadType) {
/* 117 */     if ((canStreamContent()) || (hasValueLink(payloadType))) {
/* 118 */       return true;
/*     */     }
/*     */     
/* 121 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasResourceLevelLink() {
/* 125 */     return hasLOVResource();
/*     */   }
/*     */   
/*     */   private boolean hasLOVResource() {
/* 129 */     return LOVResource.lookupLOVResource(this.attrDef) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Link> createResourceLevelLinks(String basePath)
/*     */   {
/* 137 */     LOVResource lovResourceConfiguration = null;
/*     */     try {
/* 139 */       lovResourceConfiguration = getLOVResourceConfiguration();
/*     */     } catch (Exception ex) {
/* 141 */       ResourceLoggerManager.getDiagnosticLogger().warning(ex);
/*     */     }
/*     */     
/* 144 */     Collection<Link> links = new LinkedList();
/* 145 */     if (lovResourceConfiguration != null) {
/* 146 */       Link lovResourceLink = createLOVResourceLink(basePath, lovResourceConfiguration);
/* 147 */       if (lovResourceLink != null) {
/* 148 */         links.add(lovResourceLink);
/*     */       }
/*     */     }
/*     */     
/* 152 */     return links;
/*     */   }
/*     */   
/*     */   public static Set<Link> createResourceLevelLinks(Collection<Attribute> attributes, String basePath) {
/* 156 */     Set<Link> attributesResourceLevelLinks = new HashSet();
/* 157 */     for (Attribute attribute : attributes) {
/* 158 */       attributesResourceLevelLinks.addAll(attribute.createResourceLevelLinks(basePath));
/*     */     }
/* 160 */     return attributesResourceLevelLinks;
/*     */   }
/*     */   
/*     */   private Link createLOVResourceLink(String basePath, LOVResource lovResourceConfiguration) {
/* 164 */     String rootResource = lovResourceConfiguration.getRootResourceName();
/* 165 */     Path path = new Path(Path.changeVersion(basePath, lovResourceConfiguration.findVersionDef().getDisplayName()), rootResource);
/*     */     
/* 167 */     return new Link(rootResource, "lov", path, Link.Kind.COLLECTION);
/*     */   }
/*     */   
/*     */   private boolean hasValueLink(PayloadType payloadType) {
/* 171 */     ValueSerializerInfo info = null;
/* 172 */     if (payloadType == PayloadType.JSON) {
/* 173 */       info = new JSONValueInfo();
/*     */     }
/*     */     
/* 176 */     ValueSerializerType valueSerializerType = getValueSerializerType(payloadType, this.attrDef, this.inputHandler, this.valb, info);
/*     */     
/*     */ 
/* 179 */     return (valueSerializerType != null) && (valueSerializerType == ValueSerializerType.LINK);
/*     */   }
/*     */   
/*     */   public Link createContentLink(Path resourceHref) {
/* 183 */     Link contentLink = null;
/*     */     
/* 185 */     ResourceStreamSerializer serializer = SerializerFactory.getStreamSerializer(this.inputHandler, this.attrDef);
/* 186 */     if (serializer != null) {
/* 187 */       contentLink = new Link(this.name, "enclosure", new Path(resourceHref, Arrays.asList(new String[] { "enclosure", this.name })), Link.Kind.OTHER);
/*     */     }
/*     */     
/* 190 */     return contentLink;
/*     */   }
/*     */   
/*     */   public void serializeLink(PayloadType payloadType, Object target) {
/* 194 */     ValueSerializerInfo info = null;
/* 195 */     if (payloadType == PayloadType.JSON) {
/* 196 */       info = new JSONValueInfo();
/*     */     }
/*     */     
/* 199 */     serializeLink(payloadType, this.attrDef, this.inputHandler, this.valb, target, info);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 203 */     return this.name;
/*     */   }
/*     */   
/*     */   JUCtrlValueBinding getValb() {
/* 207 */     return this.valb;
/*     */   }
/*     */   
/*     */   public void serializeDescription(PayloadType payloadType, Object target) {
/* 211 */     DescriberInfo info = null;
/* 212 */     if (payloadType == PayloadType.JSON) {
/* 213 */       info = new JSONDescriberInfo();
/*     */     }
/*     */     
/* 216 */     if (hasLov()) {
/* 217 */       LOVResource configuration = null;
/*     */       try {
/* 219 */         configuration = getLOVResourceConfiguration();
/*     */       } catch (Exception ex) {
/* 221 */         ResourceLoggerManager.getDiagnosticLogger().warning(ex);
/*     */       }
/*     */       
/* 224 */       if (configuration != null) {
/* 225 */         ViewObject resourceLOVVo = ResourceTree.getViewObject(configuration.findVersionDef(), configuration.getRootResourceName());
/*     */         
/* 227 */         DescriberInfo.LOVResourceInfo lovInfo = new DescriberInfo.LOVResourceInfo(this.attrDef, this.vo, resourceLOVVo);
/* 228 */         info.setLOVInfo(lovInfo);
/*     */       }
/*     */     }
/*     */     
/* 232 */     serializeDescription(payloadType, target, this.attrDef, this.inputHandler, this.valb, info, this.localeContext);
/*     */   }
/*     */   
/*     */   public boolean isDisplayable() {
/* 236 */     AttributeHints hints = getAttributeHints();
/* 237 */     return !"Hide".equals(hints.getPayloadHint(this.localeContext));
/*     */   }
/*     */   
/*     */   private AttributeHints getAttributeHints() {
/* 241 */     if (this.valb != null) {
/* 242 */       return getAttributeHints(this.valb);
/*     */     }
/*     */     
/* 245 */     return getAttributeHints(this.attrDef);
/*     */   }
/*     */   
/*     */   private static AttributeHints getAttributeHints(JUCtrlValueBinding valb) {
/* 249 */     return valb.getCurrentRow().getAttributeHints(valb.getAttributeDef().getName());
/*     */   }
/*     */   
/*     */   private static AttributeHints getAttributeHints(AttributeDef attrDef) {
/* 253 */     return attrDef.getUIHelper();
/*     */   }
/*     */   
/*     */   public StreamSerializerInfo getResourceStreamInfo() {
/* 257 */     return getResourceStreamInfo(this.inputHandler, this.attrDef, this.valb);
/*     */   }
/*     */   
/*     */   AttributeDef getAttrDef()
/*     */   {
/* 262 */     return this.attrDef;
/*     */   }
/*     */   
/*     */   public void setValue(Object value) {
/* 266 */     if (this.valb != null) {
/* 267 */       if (this.valb.processNewInputValue(value)) {
/* 268 */         this.valb.setInputValue(value);
/*     */       }
/* 270 */       return;
/*     */     }
/*     */     
/* 273 */     if (this.row == null) {
/* 274 */       throw new JboException("There is no tree node or row specified for this attribute, cannot set value.");
/*     */     }
/*     */     
/* 277 */     this.row.setAttribute(this.name, value);
/*     */   }
/*     */   
/*     */   public Object getValue() {
/* 281 */     if (this.valb != null) {
/* 282 */       return this.valb.getInputValue();
/*     */     }
/*     */     
/* 285 */     if (this.row == null) {
/* 286 */       return null;
/*     */     }
/*     */     
/* 289 */     return this.row.getAttribute(this.name);
/*     */   }
/*     */   
/*     */   public void serializeContent(StreamSerializerInfo info, OutputStream outputStream) {
/* 293 */     serializeContent(this.attrDef, this.inputHandler, this.valb, outputStream, info);
/*     */   }
/*     */   
/*     */   public void updateContent(StreamSerializerInfo info, InputStream in) {
/* 297 */     updateContent(this.attrDef, this.inputHandler, this.valb, in, info);
/*     */   }
/*     */   
/*     */   public Object deserializeValue(PayloadType payloadType, Object value) {
/* 301 */     ValueSerializerInfo info = null;
/* 302 */     if (payloadType == PayloadType.JSON) {
/* 303 */       info = new JSONValueInfo();
/* 304 */       info.put("attributeDef", this.attrDef);
/*     */     }
/* 306 */     return deserializeValue(payloadType, this.attrDef, this.inputHandler, this.valb, value, info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasLov()
/*     */   {
/* 314 */     return hasLov(this.attrDef);
/*     */   }
/*     */   
/*     */   public boolean isPrimaryKey() {
/* 318 */     return this.attrDef.isPrimaryKey();
/*     */   }
/*     */   
/*     */   public boolean isMandatory() {
/* 322 */     return this.attrDef.isMandatory();
/*     */   }
/*     */   
/* 325 */   public boolean isDiscrColumnType() { return this.attrDef.isDiscrColumn(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean belongToItem()
/*     */   {
/* 332 */     return this.row != null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/* 337 */     if (this == object) {
/* 338 */       return true;
/*     */     }
/* 340 */     if (!(object instanceof Attribute)) {
/* 341 */       return false;
/*     */     }
/* 343 */     Attribute other = (Attribute)object;
/* 344 */     if (this.name == null ? other.name != null : !this.name.equals(other.name)) {
/* 345 */       return false;
/*     */     }
/* 347 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 352 */     int prime = 37;
/* 353 */     int result = 1;
/* 354 */     return 37 * result + (this.name == null ? 0 : this.name.hashCode());
/*     */   }
/*     */   
/*     */   private static JUCtrlInputValueHandler getJUCtrlInputHandler(BindingContext bindingContext, AttributeDef attrDef, String handlerId) {
/* 358 */     return JUCtrlValueDef.getJUCtrlInputHandler(bindingContext, attrDef, handlerId);
/*     */   }
/*     */   
/*     */   private static JUCtrlInputValueHandler getJUCtrlInputHandler(BindingContext bindingContext, AttributeDef attrDef, JUCtrlHierTypeBinding typeBinding) {
/* 362 */     String handlerId = typeBinding.findAttrCustomInputHandler(attrDef.getName());
/* 363 */     return getJUCtrlInputHandler(bindingContext, attrDef, handlerId);
/*     */   }
/*     */   
/*     */   private static void serializeValue(PayloadType payloadType, AttributeDef attrDef, JUCtrlInputValueHandler inputHandler, JUCtrlValueBinding valb, Object target, ValueSerializerInfo info)
/*     */   {
/* 368 */     ResourceValueSerializer serializer = SerializerFactory.getValueSerializer(payloadType, attrDef, inputHandler);
/*     */     
/* 370 */     if (serializer != null) {
/* 371 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.SERIALIZER_PROVIDER);
/* 372 */       serializer.serialize(valb, target, info);
/* 373 */       ResourceLoggerManager.removeCurrentLogger();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void serializeLink(PayloadType payloadType, AttributeDef attrDef, JUCtrlInputValueHandler inputHandler, JUCtrlValueBinding valb, Object target, ValueSerializerInfo info)
/*     */   {
/* 379 */     ResourceValueSerializer serializer = SerializerFactory.getValueSerializer(payloadType, attrDef, inputHandler);
/* 380 */     if ((serializer != null) && (serializer.getType(valb, info) == ValueSerializerType.LINK)) {
/* 381 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.SERIALIZER_PROVIDER);
/* 382 */       serializer.serializeLink(valb, target, info);
/* 383 */       ResourceLoggerManager.removeCurrentLogger();
/*     */     }
/*     */   }
/*     */   
/*     */   private static Object deserializeValue(PayloadType payloadType, AttributeDef attrDef, JUCtrlInputValueHandler inputHandler, JUCtrlValueBinding valb, Object value, ValueSerializerInfo info)
/*     */   {
/* 389 */     Object deserializedValue = null;
/* 390 */     ResourceValueSerializer serializer = SerializerFactory.getValueSerializer(payloadType, attrDef, inputHandler);
/*     */     
/* 392 */     if (serializer != null) {
/* 393 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.SERIALIZER_PROVIDER);
/* 394 */       deserializedValue = serializer.deserialize(valb, value, info);
/* 395 */       ResourceLoggerManager.removeCurrentLogger();
/*     */     }
/*     */     
/* 398 */     return deserializedValue;
/*     */   }
/*     */   
/*     */   private static StreamSerializerInfo getResourceStreamInfo(JUCtrlInputValueHandler inputHandler, AttributeDef attrDef, JUCtrlValueBinding valb)
/*     */   {
/* 403 */     StreamSerializerInfo streamInfo = null;
/*     */     
/* 405 */     ResourceStreamSerializer serializer = SerializerFactory.getStreamSerializer(inputHandler, attrDef);
/* 406 */     if (serializer != null) {
/* 407 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.SERIALIZER_PROVIDER);
/* 408 */       streamInfo = serializer.getStreamInfo(valb);
/* 409 */       ResourceLoggerManager.removeCurrentLogger();
/*     */     }
/* 411 */     return streamInfo;
/*     */   }
/*     */   
/*     */   private static void serializeContent(AttributeDef attrDef, JUCtrlInputValueHandler inputHandler, JUCtrlValueBinding valb, OutputStream outputStream, StreamSerializerInfo info)
/*     */   {
/* 416 */     ResourceStreamSerializer serializer = SerializerFactory.getStreamSerializer(inputHandler, attrDef);
/* 417 */     if (serializer != null) {
/* 418 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.SERIALIZER_PROVIDER);
/* 419 */       serializer.serializeStream(valb, outputStream, info);
/* 420 */       ResourceLoggerManager.removeCurrentLogger();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void updateContent(AttributeDef attrDef, JUCtrlInputValueHandler inputHandler, JUCtrlValueBinding valb, InputStream in, StreamSerializerInfo info)
/*     */   {
/* 426 */     ResourceStreamSerializer serializer = SerializerFactory.getStreamSerializer(inputHandler, attrDef);
/* 427 */     if (serializer != null) {
/* 428 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.SERIALIZER_PROVIDER);
/* 429 */       serializer.deserializeStream(valb, in, info);
/* 430 */       ResourceLoggerManager.removeCurrentLogger();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static ValueSerializerType getValueSerializerType(PayloadType payloadType, AttributeDef attrDef, JUCtrlInputValueHandler inputHandler, JUCtrlValueBinding valb, ValueSerializerInfo info)
/*     */   {
/* 437 */     ValueSerializerType valueSerializerType = null;
/* 438 */     ResourceValueSerializer valueSerializer = SerializerFactory.getValueSerializer(payloadType, attrDef, inputHandler);
/* 439 */     if (valueSerializer != null) {
/* 440 */       ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.SERIALIZER_PROVIDER);
/* 441 */       valueSerializerType = valueSerializer.getType(valb, info);
/* 442 */       ResourceLoggerManager.removeCurrentLogger();
/*     */     }
/* 444 */     return valueSerializerType;
/*     */   }
/*     */   
/*     */ 
/*     */   private static void serializeDescription(PayloadType payloadType, Object target, AttributeDef attrDef, JUCtrlInputValueHandler inputHandler, JUCtrlValueBinding valb, DescriberInfo info, LocaleContext localeContext)
/*     */   {
/* 450 */     ResourceDescriber describer = DescriberFactory.getDescriber(payloadType, attrDef, inputHandler);
/*     */     
/* 452 */     ResourceLoggerManager.setCurrentLogger(ResourceLoggerManager.DESCRIBER_PROVIDER);
/* 453 */     if (valb != null) {
/* 454 */       describer.describe(valb, target, info);
/*     */     } else {
/* 456 */       describer.catalogDescribe(attrDef, localeContext, target, info);
/*     */     }
/* 458 */     ResourceLoggerManager.removeCurrentLogger();
/*     */   }
/*     */   
/*     */   static Object convertValueToAttributeType(Attribute attribute, String value) {
/* 462 */     return RestTypeConverter.toJavaType(value, attribute.getAttrDef().getJavaType());
/*     */   }
/*     */   
/*     */   public Class getJavaType() {
/* 466 */     return this.attrDef.getJavaType();
/*     */   }
/*     */   
/*     */   private static JUCtrlInputValueHandler getInputHandlerFromHints(AttributeHints attrHints, AttributeDef attrDef, LocaleContext localeContext) {
/* 470 */     JUCtrlInputValueHandler inputHandler = null;
/* 471 */     String inputHandlerHint = attrHints.getHint(localeContext, "inputHandler");
/* 472 */     BindingContext bindingContext = BindingContext.getCurrent();
/* 473 */     if (inputHandlerHint != null) {
/* 474 */       inputHandler = getJUCtrlInputHandler(bindingContext, attrDef, inputHandlerHint);
/*     */     }
/* 476 */     return inputHandler;
/*     */   }
/*     */   
/*     */   public boolean isUpdatable() {
/* 480 */     if (this.valb != null) {
/* 481 */       return this.valb.isUpdateable();
/*     */     }
/* 483 */     return this.attrDef.getUpdateableFlag() == 2;
/*     */   }
/*     */   
/*     */   public static byte[] decodeBase64Value(String encodedBase64)
/*     */   {
/* 488 */     byte[] decodedBase64Value = null;
/* 489 */     InputStream encodedBase64Input = null;
/* 490 */     InputStream decodedBase64Input = null;
/* 491 */     ByteArrayOutputStream buffer = null;
/*     */     try {
/*     */       try {
/* 494 */         encodedBase64Input = new ByteArrayInputStream(encodedBase64.getBytes());
/* 495 */         decodedBase64Input = MimeUtility.decode(encodedBase64Input, "base64");
/*     */         
/* 497 */         buffer = new ByteArrayOutputStream();
/*     */         
/*     */ 
/* 500 */         byte[] data = new byte['䀀'];
/*     */         int nRead;
/* 502 */         while ((nRead = decodedBase64Input.read(data, 0, data.length)) != -1) {
/* 503 */           buffer.write(data, 0, nRead);
/*     */         }
/* 505 */         decodedBase64Value = buffer.toByteArray();
/*     */       } finally {
/* 507 */         if (buffer != null) {
/* 508 */           buffer.close();
/*     */         }
/* 510 */         if (decodedBase64Input != null) {
/* 511 */           decodedBase64Input.close();
/*     */         }
/* 513 */         if (encodedBase64Input != null) {
/* 514 */           encodedBase64Input.close();
/*     */         }
/*     */       }
/*     */     } catch (Exception ex) {
/* 518 */       throw new JboException(ex);
/*     */     }
/*     */     
/* 521 */     return decodedBase64Value;
/*     */   }
/*     */   
/*     */   static boolean hasLov(AttributeDef attributeDef) {
/* 525 */     return attributeDef.getLOVName() != null;
/*     */   }
/*     */   
/*     */   private LOVResource getLOVResourceConfiguration() {
/* 529 */     return LOVResource.lookupLOVResource(this.attrDef);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Attribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */