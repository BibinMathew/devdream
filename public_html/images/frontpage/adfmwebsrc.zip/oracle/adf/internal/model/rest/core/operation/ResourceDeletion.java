/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ import oracle.adf.internal.model.rest.core.exception.InvalidResourceTypeException;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceHelper;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ 
/*    */ class ResourceDeletion extends AbstractResourceOperation
/*    */ {
/*    */   public void applyInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */   public void execute(ResourceProcessingContext context)
/*    */   {
/* 17 */     ResourceHelper.deleteResource(context);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void generateResponse(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public void validateInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   public void init(ResourceProcessingContext context) throws Exception
/*    */   {
/* 35 */     if (context.getResourceTree().getCurrentResource().isCollection()) {
/* 36 */       throw new InvalidResourceTypeException();
/*    */     }
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 42 */     return OperationType.DELETION;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 47 */     return ActionType.DELETE;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ResourceDeletion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */