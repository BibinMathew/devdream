/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ public class AcceptEncoding implements Header
/*    */ {
/*    */   public static final String NAME = "Accept-Encoding";
/*    */   private static final String CODING_SEPARATOR = ",";
/*    */   private static final String CONTENT_QFACTOR_SEPARATOR = ";";
/*    */   private static final String QFACTOR_VALUE_SEPARATOR = "=";
/*    */   private final TreeSet<Coding> codings;
/*    */   private final String originalValue;
/*    */   
/*    */   private AcceptEncoding(TreeSet<Coding> codings, String originalValue)
/*    */   {
/* 18 */     this.codings = codings;
/* 19 */     this.originalValue = originalValue;
/*    */   }
/*    */   
/*    */   public Coding findBestMatch(Set<ContentCoding> supportedContentCodings) {
/* 23 */     Coding bestMatch = null;
/* 24 */     for (Coding coding : this.codings.descendingSet()) {
/* 25 */       if (supportedContentCodings.contains(coding.getContentCoding())) {
/* 26 */         bestMatch = coding;
/* 27 */         break;
/*    */       }
/*    */     }
/*    */     
/* 31 */     return bestMatch;
/*    */   }
/*    */   
/*    */   public static AcceptEncoding parse(String acceptEncodingHeaderValue) {
/* 35 */     if ((acceptEncodingHeaderValue == null) || (acceptEncodingHeaderValue.length() == 0)) {
/* 36 */       return null;
/*    */     }
/*    */     
/* 39 */     TreeSet<Coding> codings = new TreeSet();
/* 40 */     HashSet<ContentCoding> contentCodings = new HashSet();
/*    */     
/* 42 */     String[] codingsSplit = acceptEncodingHeaderValue.split(",");
/* 43 */     for (String coding : codingsSplit) {
/* 44 */       String[] splitCoding = coding.split(";");
/* 45 */       ContentCoding contentCoding = new ContentCoding(splitCoding[0].trim());
/* 46 */       QualityFactor qualityFactor = null;
/* 47 */       if ((splitCoding.length > 1) && (splitCoding[1] != null) && (splitCoding[1].length() > 0)) {
/* 48 */         String[] splitQvalue = splitCoding[1].split("=");
/* 49 */         qualityFactor = new QualityFactor(splitQvalue[1].trim());
/*    */       } else {
/* 51 */         qualityFactor = new QualityFactor();
/*    */       }
/* 53 */       contentCodings.add(contentCoding);
/* 54 */       codings.add(new Coding(contentCoding, qualityFactor));
/*    */     }
/*    */     
/* 57 */     return new AcceptEncoding(codings, acceptEncodingHeaderValue);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 62 */     return this.originalValue;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 67 */     return "Accept-Encoding";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\AcceptEncoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */