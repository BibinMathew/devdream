/*     */ package oracle.adf.internal.model.rest.core.lifecycle;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.model.AttributeBinding;
/*     */ import oracle.adf.model.BindingContext;
/*     */ import oracle.adf.model.binding.DCBindingContainer;
/*     */ import oracle.adf.model.binding.DCErrorHandler;
/*     */ import oracle.adf.model.binding.DCErrorMessage;
/*     */ import oracle.adf.model.binding.DCErrorMessageHandler;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ErrorMessageHandler
/*     */ {
/*  24 */   private Set<Throwable> addedErrors = new HashSet();
/*  25 */   private Set<ErrorMessage> messages = new HashSet();
/*  26 */   private static final String LINE_SEPARATOR = System.getProperty("line.separator");
/*     */   private final DCBindingContainer bindingContainer;
/*     */   
/*     */   public ErrorMessageHandler(DCBindingContainer bindingContainer) {
/*  30 */     this.bindingContainer = bindingContainer;
/*     */     try {
/*  32 */       ArrayList exceptionList = this.bindingContainer.getExceptionsList();
/*  33 */       if (exceptionList != null) {
/*  34 */         processExceptions(exceptionList.toArray());
/*     */       }
/*     */     } catch (Exception ex) {
/*  37 */       ContextualLogger logger = ResourceLoggerManager.getCurrentLogger();
/*  38 */       logger.warning("Could not generate the error message", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processExceptions(Object[] exceptions)
/*     */   {
/*  44 */     if (exceptions == null) {
/*  45 */       return;
/*     */     }
/*     */     
/*  48 */     for (Object ex : exceptions) {
/*  49 */       if ((ex instanceof Throwable)) {
/*  50 */         addError((Throwable)ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addError(Throwable ex)
/*     */   {
/*  63 */     if ((ex instanceof JboException)) {
/*  64 */       JboException jex = (JboException)ex;
/*     */       
/*  66 */       Boolean hint = (Boolean)jex.getProperty("_%HIDEDETAILEXCEPTIONSHINT%_");
/*  67 */       Object[] nextLevDetails = jex.getDetails();
/*     */       
/*  69 */       if ((jex.hasPeerExceptions()) && (hint != Boolean.TRUE))
/*     */       {
/*     */ 
/*     */ 
/*  73 */         if ((nextLevDetails != null) && (nextLevDetails.length == 1)) {
/*  74 */           Object nextLevEx = nextLevDetails[0];
/*  75 */           if ((nextLevEx instanceof Throwable)) {
/*  76 */             addError((Throwable)nextLevEx);
/*  77 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  84 */       if (this.addedErrors.add(ex)) {
/*  85 */         addMessages(jex, ex);
/*     */         
/*  87 */         if (hint != Boolean.TRUE) {
/*  88 */           processExceptions(nextLevDetails);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/*  93 */       addMessages(getParentException(ex), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMessages(JboException jex, Throwable ex) {
/*  98 */     boolean handled = false;
/*  99 */     List exBindings = null;
/*     */     
/* 101 */     if (jex != null) {
/* 102 */       exBindings = (List)jex.getProperty("_%DCBindingError%_");
/*     */     }
/*     */     
/* 105 */     if (exBindings != null) {
/* 106 */       for (Object bindingErr : exBindings) {
/* 107 */         if ((bindingErr instanceof AttributeBinding)) {
/* 108 */           addMessage((AttributeBinding)bindingErr, ex);
/* 109 */           handled = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 114 */     if (!handled)
/*     */     {
/* 116 */       addMessage(null, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addMessage(AttributeBinding binding, Throwable error)
/*     */   {
/* 128 */     if (error == null) {
/* 129 */       return;
/*     */     }
/*     */     
/* 132 */     ErrorMessage message = buildMessage(binding, error);
/* 133 */     if (message == null) {
/* 134 */       return;
/*     */     }
/*     */     
/* 137 */     this.messages.add(message);
/*     */     
/*     */ 
/* 140 */     if ((error instanceof JboException))
/*     */     {
/* 142 */       Boolean hint = (Boolean)((JboException)error).getProperty("_%HIDEDETAILEXCEPTIONSHINT%_");
/* 143 */       if (hint != Boolean.TRUE) {
/* 144 */         addMessage(binding, error.getCause());
/*     */       }
/*     */     } else {
/* 147 */       addMessage(binding, error.getCause());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ErrorMessage buildMessage(AttributeBinding binding, Throwable error)
/*     */   {
/* 160 */     ContextualLogger logger = ResourceLoggerManager.getCurrentLogger();
/* 161 */     String errorMsg = null;
/* 162 */     String summaryMsg = null;
/* 163 */     String detailMsg = null;
/* 164 */     Integer severity = null;
/* 165 */     DCBindingContainer bindingContainer = null;
/* 166 */     ErrorMessage message = null;
/*     */     
/* 168 */     if ((error instanceof Exception))
/*     */     {
/* 170 */       if ((error instanceof JboException)) {
/* 171 */         JboException jboEx = (JboException)error;
/*     */         
/*     */ 
/* 174 */         if (jboEx.getProperty("_%DCIgnoreError%_") != null) {
/* 175 */           return null;
/*     */         }
/*     */         
/* 178 */         severity = Integer.valueOf(jboEx.getSeverity());
/*     */         
/* 180 */         bindingContainer = (DCBindingContainer)jboEx.getProperty("_%DCBindingContainerError%_");
/*     */       }
/*     */       
/* 183 */       BindingContext bindingContext = this.bindingContainer.getBindingContext();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 188 */       DCErrorHandler errorHandler = bindingContext.getErrorHandler();
/*     */       
/* 190 */       if ((errorHandler != null) && ((errorHandler instanceof DCErrorMessageHandler))) {
/* 191 */         DCErrorMessageHandler errorMessageHandler = (DCErrorMessageHandler)errorHandler;
/* 192 */         errorMsg = errorMessageHandler.getDisplayMessage(bindingContext, (Exception)error);
/*     */         
/*     */ 
/* 195 */         if (errorMsg == null) {
/* 196 */           return null;
/*     */         }
/*     */         
/*     */ 
/* 200 */         DCErrorMessage dcError = errorMessageHandler.getDetailedDisplayMessage(bindingContext, bindingContainer, (Exception)error);
/*     */         
/* 202 */         if (dcError != null) {
/* 203 */           detailMsg = dcError.getText();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 208 */     if (errorMsg == null) {
/* 209 */       errorMsg = error.getLocalizedMessage();
/*     */       
/*     */ 
/*     */ 
/* 213 */       if ((errorMsg == null) || (errorMsg.length() == 0)) {
/* 214 */         errorMsg = error.getClass().getName();
/*     */       }
/*     */     }
/*     */     
/* 218 */     if (detailMsg == null) {
/* 219 */       detailMsg = errorMsg;
/*     */     } else {
/* 221 */       summaryMsg = errorMsg;
/*     */     }
/*     */     
/* 224 */     if (binding != null) {
/* 225 */       String label = null;
/* 226 */       if (((binding instanceof JUCtrlValueBinding)) && (((JUCtrlValueBinding)binding).getAttribute() == null)) {
/* 227 */         if ((((JUCtrlValueBinding)binding).getAttributeNames() != null) && (((JUCtrlValueBinding)binding).getAttributeNames().length > 0)) {
/* 228 */           label = ((JUCtrlValueBinding)binding).getAttributeNames()[0];
/*     */         }
/*     */       } else {
/* 231 */         label = binding.getLabel();
/*     */       }
/* 233 */       message = new ErrorMessage(severity, summaryMsg, detailMsg, label);
/* 234 */       if (logger.isFiner())
/*     */       {
/*     */ 
/* 237 */         logger.finer("ADF: Adding the following error message for binding '" + label + "': " + errorMsg, error);
/*     */       }
/*     */     } else {
/* 240 */       message = new ErrorMessage(severity, summaryMsg, detailMsg);
/* 241 */       if (logger.isWarning())
/*     */       {
/*     */ 
/* 244 */         logger.warning("ADF: Adding the following error message: " + errorMsg, error);
/*     */       }
/*     */     }
/*     */     
/* 248 */     return message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JboException getParentException(Throwable ex)
/*     */   {
/* 256 */     JboException parentEx = null;
/*     */     
/* 258 */     for (Throwable error : this.addedErrors) {
/* 259 */       if ((error instanceof JboException)) {
/* 260 */         Object[] nextLevDetails = ((JboException)error).getDetails();
/* 261 */         for (Object nextLev : nextLevDetails) {
/* 262 */           if (nextLev == ex) {
/* 263 */             parentEx = (JboException)error;
/* 264 */             break;
/*     */           }
/*     */         }
/*     */         
/* 268 */         if (parentEx != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 274 */     return parentEx;
/*     */   }
/*     */   
/*     */   public Set<Throwable> getAddedErrors()
/*     */   {
/* 279 */     return this.addedErrors;
/*     */   }
/*     */   
/*     */   public Set<ErrorMessage> getMessages() {
/* 283 */     return this.messages;
/*     */   }
/*     */   
/*     */   public String getConsolidatedMessage() {
/* 287 */     if (this.messages.isEmpty()) {
/* 288 */       return null;
/*     */     }
/*     */     
/* 291 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 293 */     for (ErrorMessage message : this.messages) {
/* 294 */       if (message != null)
/*     */       {
/*     */ 
/* 297 */         sb.append(message.toString() + LINE_SEPARATOR); }
/*     */     }
/* 299 */     if (sb.length() > 0) {
/* 300 */       sb.delete(sb.length() - LINE_SEPARATOR.length(), sb.length());
/*     */     }
/* 302 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ErrorMessageHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */