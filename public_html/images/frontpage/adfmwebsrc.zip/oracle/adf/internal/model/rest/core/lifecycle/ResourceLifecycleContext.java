/*    */ package oracle.adf.internal.model.rest.core.lifecycle;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.Operation;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.model.MetadataContext;
/*    */ import oracle.adf.share.mds.MDSLockedSessionOperations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResourceLifecycleContext
/*    */ {
/*    */   private final ResourceProcessingContext resourceBindingContext;
/*    */   private final OperationType operationType;
/*    */   private final ResponseHandler responseHandler;
/* 17 */   private Operation operation = null;
/*    */   private MDSLockedSessionOperations mdsOperations;
/*    */   
/*    */   protected ResourceLifecycleContext(ResourceProcessingContext resourceBindingContext, OperationType operationType, ResponseHandler responseHandler)
/*    */   {
/* 22 */     this.resourceBindingContext = resourceBindingContext;
/* 23 */     this.operationType = operationType;
/* 24 */     this.responseHandler = responseHandler;
/*    */   }
/*    */   
/*    */   protected ResourceProcessingContext getResourceProcessingContext()
/*    */   {
/* 29 */     return this.resourceBindingContext;
/*    */   }
/*    */   
/*    */   OperationType getOperationType() {
/* 33 */     return this.operationType;
/*    */   }
/*    */   
/*    */   protected ResponseHandler getResponseHandler() {
/* 37 */     return this.responseHandler;
/*    */   }
/*    */   
/*    */   void setOperation(Operation operation) {
/* 41 */     this.operation = operation;
/*    */   }
/*    */   
/*    */   Operation getOperation() {
/* 45 */     return this.operation;
/*    */   }
/*    */   
/*    */   void prepareMetadata() throws Exception {
/* 49 */     this.mdsOperations = MetadataContext.lockPrepareSession();
/*    */   }
/*    */   
/*    */   void flushMetadata() throws Exception {
/* 53 */     if (this.mdsOperations != null) {
/* 54 */       MetadataContext.releaseFlushSession(this.mdsOperations);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ResourceLifecycleContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */