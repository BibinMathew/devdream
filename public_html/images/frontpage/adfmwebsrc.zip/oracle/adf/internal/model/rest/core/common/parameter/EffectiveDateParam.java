/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ import java.sql.Date;
/*    */ import oracle.adf.model.rest.RestTypeConverter;
/*    */ 
/*    */ 
/*    */ public class EffectiveDateParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private Date effectiveDate;
/*    */   
/*    */   public EffectiveDateParam(String[] parameterValues)
/*    */   {
/* 14 */     if ((parameterValues != null) && (parameterValues.length > 0) && (parameterValues[0] != null)) {
/* 15 */       this.effectiveDate = ((Date)RestTypeConverter.toJavaType(parameterValues[0], Date.class));
/*    */     }
/*    */   }
/*    */   
/*    */   public Date getDate() {
/* 20 */     return this.effectiveDate;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\EffectiveDateParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */