/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ class InternalResourceRef implements ResourceReference
/*    */ {
/*    */   private Path resourceReferencePath;
/*    */   
/*    */   public InternalResourceRef(String resourceId, String basePath, String value)
/*    */   {
/*  9 */     if (resourceId != null) {
/* 10 */       this.resourceReferencePath = Resource.generateResourcePath(basePath, value, resourceId);
/*    */     } else {
/* 12 */       this.resourceReferencePath = Resource.generateResourceCollectionPath(basePath, value);
/*    */     }
/*    */   }
/*    */   
/*    */   public Path getResourceReferencePath()
/*    */   {
/* 18 */     return this.resourceReferencePath;
/*    */   }
/*    */   
/*    */   public ResourceReference.Type getType()
/*    */   {
/* 23 */     return ResourceReference.Type.INTERNAL;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\InternalResourceRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */