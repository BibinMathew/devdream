package oracle.adf.internal.model.rest.core.http.header;

public abstract interface Header
{
  public abstract String getName();
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\Header.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */