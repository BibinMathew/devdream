/*    */ package oracle.adf.internal.model.rest.core.lifecycle;
/*    */ 
/*    */ public class ErrorMessage
/*    */ {
/*    */   private final String summaryMsg;
/*    */   private final String detailMsg;
/*    */   private final Integer severity;
/*    */   private String label;
/*    */   
/*    */   public ErrorMessage(Integer severity, String summaryMsg, String detailMsg)
/*    */   {
/* 12 */     this.severity = severity;
/* 13 */     this.summaryMsg = summaryMsg;
/* 14 */     this.detailMsg = detailMsg;
/*    */   }
/*    */   
/*    */   public ErrorMessage(Integer severity, String summaryMsg, String detailMsg, String label)
/*    */   {
/* 19 */     this.severity = severity;
/* 20 */     this.summaryMsg = summaryMsg;
/* 21 */     this.detailMsg = detailMsg;
/* 22 */     this.label = label;
/*    */   }
/*    */   
/*    */   public String getSummaryMsg()
/*    */   {
/* 27 */     return this.summaryMsg;
/*    */   }
/*    */   
/*    */   public String getDetailMsg() {
/* 31 */     return this.detailMsg;
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 35 */     return this.label;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 41 */     String message = this.summaryMsg;
/* 42 */     if (message == null) {
/* 43 */       message = this.detailMsg;
/*    */     }
/* 45 */     if (message == null) {
/* 46 */       return "";
/*    */     }
/* 48 */     if (this.label != null) {
/* 49 */       message = this.label + ": " + message;
/*    */     }
/*    */     
/* 52 */     return message;
/*    */   }
/*    */   
/*    */   public Integer getSeverity()
/*    */   {
/* 57 */     return this.severity;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object object)
/*    */   {
/* 63 */     if (this == object) {
/* 64 */       return true;
/*    */     }
/* 66 */     if (!(object instanceof ErrorMessage)) {
/* 67 */       return false;
/*    */     }
/* 69 */     ErrorMessage other = (ErrorMessage)object;
/* 70 */     if (this.summaryMsg == null ? other.summaryMsg != null : !this.summaryMsg.equals(other.summaryMsg)) {
/* 71 */       return false;
/*    */     }
/* 73 */     if (this.detailMsg == null ? other.detailMsg != null : !this.detailMsg.equals(other.detailMsg)) {
/* 74 */       return false;
/*    */     }
/* 76 */     if (this.label == null ? other.label != null : !this.label.equals(other.label)) {
/* 77 */       return false;
/*    */     }
/* 79 */     if (this.severity == null ? other.severity != null : !this.severity.equals(other.severity)) {
/* 80 */       return false;
/*    */     }
/* 82 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 87 */     int PRIME = 37;
/* 88 */     int result = 1;
/* 89 */     result = 37 * result + (this.summaryMsg == null ? 0 : this.summaryMsg.hashCode());
/* 90 */     result = 37 * result + (this.detailMsg == null ? 0 : this.detailMsg.hashCode());
/* 91 */     result = 37 * result + (this.label == null ? 0 : this.label.hashCode());
/* 92 */     result = 37 * result + (this.severity == null ? 0 : this.severity.hashCode());
/* 93 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ErrorMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */