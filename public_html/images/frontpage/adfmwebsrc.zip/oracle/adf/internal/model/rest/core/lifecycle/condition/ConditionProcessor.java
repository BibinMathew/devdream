/*    */ package oracle.adf.internal.model.rest.core.lifecycle.condition;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.common.Condition;
/*    */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*    */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*    */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConditionProcessor
/*    */ {
/*    */   final Condition codition;
/*    */   
/*    */   ConditionProcessor(Condition condition)
/*    */   {
/* 25 */     this.codition = condition;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void process(String paramString);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   final boolean conditionSucceeded(String currentState, String conditionState)
/*    */   {
/* 43 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*    */     
/* 45 */     if (logger.isFinest()) {
/* 46 */       Map<String, String> contextData = new HashMap(2);
/* 47 */       contextData.put("Resource Current State", currentState);
/* 48 */       contextData.put("Condition State", conditionState);
/* 49 */       logger.finest("Comparing States", contextData);
/*    */     }
/*    */     
/* 52 */     return testCondition(!conditionState.equals(currentState));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   abstract boolean testCondition(boolean paramBoolean);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void process(ResourceNotFoundException paramResourceNotFoundException);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Condition getCondition()
/*    */   {
/* 76 */     return this.codition;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\condition\ConditionProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */