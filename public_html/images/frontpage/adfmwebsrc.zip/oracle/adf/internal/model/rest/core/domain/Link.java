/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.JboException;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Link
/*     */ {
/*     */   public static final String NAME = "link";
/*     */   public static final String NAME_PLURAL = "links";
/*     */   public static final String SELF_REL = "self";
/*     */   public static final String LOV_REL = "lov";
/*     */   public static final String PARENT_REL = "parent";
/*     */   public static final String CANONICAL_REL = "canonical";
/*     */   public static final String CHILD_REL = "child";
/*     */   public static final String ENCLOSURE_REL = "enclosure";
/*     */   public static final String ATTRIBUTE_REL = "rel";
/*     */   public static final String ATTRIBUTE_PROPERTIES = "properties";
/*     */   public static final String ATTRIBUTE_HREF = "href";
/*     */   public static final String ATTRIBUTE_NAME = "name";
/*     */   public static final String ATTRIBUTE_KIND = "kind";
/*     */   public static final String SEPARATOR = "/";
/*     */   public static final String PREDECESSOR_VERSION_REL = "predecessor-version";
/*     */   public static final String SUCCESSOR_VERSION_REL = "successor-version";
/*     */   public static final String CURRENT_VERSION_REL = "current";
/*     */   public static final String DESCRIBE_REL = "describe";
/*     */   private final String name;
/*     */   private final String rel;
/*     */   private final Path href;
/*     */   private final Kind kind;
/*     */   private final Cardinality cardinality;
/*  36 */   private List<ResourceProperty> properties = Collections.emptyList();
/*     */   
/*  38 */   public static enum Kind { COLLECTION,  ITEM,  DESCRIBE,  OTHER;
/*     */     
/*     */     private Kind() {}
/*  41 */     public String toString() { return super.toString().toLowerCase(); }
/*     */   }
/*     */   
/*     */   public Link(String name, String rel, Path href, Kind kind)
/*     */   {
/*  46 */     this.name = name;
/*  47 */     this.rel = rel;
/*  48 */     this.href = href;
/*  49 */     this.cardinality = null;
/*  50 */     this.kind = kind;
/*     */   }
/*     */   
/*     */   public Link(String name, String rel, Path href, Cardinality cardinality, Kind kind) {
/*  54 */     this.name = name;
/*  55 */     this.rel = rel;
/*  56 */     this.href = href;
/*  57 */     this.cardinality = cardinality;
/*  58 */     this.kind = kind;
/*     */   }
/*     */   
/*     */   public String getRel() {
/*  62 */     return this.rel;
/*     */   }
/*     */   
/*     */   public Path getHref() {
/*  66 */     return this.href;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  70 */     return this.name;
/*     */   }
/*     */   
/*     */   public Cardinality getCardinality() {
/*  74 */     return this.cardinality;
/*     */   }
/*     */   
/*     */   public void setProperties(List<ResourceProperty> properties) {
/*  78 */     this.properties = Collections.unmodifiableList(properties);
/*     */   }
/*     */   
/*     */   public List<ResourceProperty> getProperties() {
/*  82 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  88 */     StringBuilder sb = new StringBuilder();
/*  89 */     sb.append("<");
/*     */     try {
/*  91 */       sb.append(this.href.createHref());
/*     */     } catch (JboException ex) {
/*  93 */       ResourceLoggerManager.getDiagnosticLogger().warning("href creation failed", ex);
/*  94 */       sb.append(this.href.toString());
/*     */     }
/*  96 */     sb.append(">;rel=\"");
/*  97 */     sb.append(this.rel);
/*  98 */     sb.append("\";kind=\"");
/*  99 */     sb.append(this.kind.toString());
/* 100 */     sb.append("\"");
/*     */     
/* 102 */     if (this.name != null) {
/* 103 */       sb.append(";name=\"");
/* 104 */       sb.append(this.name);
/* 105 */       sb.append("\"");
/*     */     }
/*     */     
/* 108 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String getKind() {
/* 112 */     return this.kind.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/* 117 */     if (this == object) {
/* 118 */       return true;
/*     */     }
/* 120 */     if (!(object instanceof Link)) {
/* 121 */       return false;
/*     */     }
/* 123 */     Link other = (Link)object;
/* 124 */     if (this.name == null ? other.name != null : !this.name.equals(other.name)) {
/* 125 */       return false;
/*     */     }
/* 127 */     if (this.rel == null ? other.rel != null : !this.rel.equals(other.rel)) {
/* 128 */       return false;
/*     */     }
/* 130 */     if (this.href == null ? other.href != null : !this.href.equals(other.href)) {
/* 131 */       return false;
/*     */     }
/* 133 */     if (this.kind == null ? other.kind != null : !this.kind.equals(other.kind)) {
/* 134 */       return false;
/*     */     }
/* 136 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 141 */     int PRIME = 37;
/* 142 */     int result = 1;
/* 143 */     result = 37 * result + (this.name == null ? 0 : this.name.hashCode());
/* 144 */     result = 37 * result + (this.rel == null ? 0 : this.rel.hashCode());
/* 145 */     result = 37 * result + (this.href == null ? 0 : this.href.hashCode());
/* 146 */     result = 37 * result + (this.kind == null ? 0 : this.kind.hashCode());
/* 147 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Link.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */