/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*    */ import oracle.adf.internal.model.rest.core.exception.ActionNotEnabledException;
/*    */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*    */ 
/*    */ 
/*    */ public final class ReplaceAction
/*    */   extends Action
/*    */ {
/*    */   public ReplaceAction(Resource resource)
/*    */   {
/* 14 */     super(ActionType.REPLACE, resource);
/*    */   }
/*    */   
/*    */   ReplaceAction() {
/* 18 */     super(ActionType.REPLACE);
/*    */   }
/*    */   
/*    */   public ActionResult execute()
/*    */   {
/* 23 */     if (!isEnabled()) {
/* 24 */       throw new ActionNotEnabledException(getName());
/*    */     }
/*    */     
/* 27 */     ContextualLogger logger = ResourceLoggerManager.getCurrentLogger();
/* 28 */     Map<String, Object> parameters = getParameters();
/* 29 */     for (Attribute attribute : getResource().getAttributes()) {
/* 30 */       String attributeName = attribute.getName();
/* 31 */       if (parameters.containsKey(attributeName)) {
/* 32 */         attribute.setValue(parameters.get(attributeName));
/*    */       }
/* 34 */       else if ((attribute.isUpdatable()) && (!attribute.canStreamContent())) {
/* 35 */         logger.info("Executing replace: setting '" + attributeName + "' to null");
/* 36 */         attribute.setValue(null);
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   public boolean producesActionResult()
/*    */   {
/* 46 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ReplaceAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */