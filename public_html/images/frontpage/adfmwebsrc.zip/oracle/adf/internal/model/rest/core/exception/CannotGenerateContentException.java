/*    */ package oracle.adf.internal.model.rest.core.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CannotGenerateContentException
/*    */   extends ResourceException
/*    */ {
/*    */   public CannotGenerateContentException(String msg)
/*    */   {
/* 15 */     super(msg);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\exception\CannotGenerateContentException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */