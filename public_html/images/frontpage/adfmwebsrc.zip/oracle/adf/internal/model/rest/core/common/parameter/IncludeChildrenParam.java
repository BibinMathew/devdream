/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncludeChildrenParam
/*    */   extends ResourceParameter
/*    */ {
/* 10 */   private Boolean includeChildrenEnabled = Boolean.FALSE;
/*    */   
/*    */   public IncludeChildrenParam(String[] parameterValues) {
/* 13 */     if (parameterValues != null) {
/* 14 */       if ((parameterValues.length > 0) && (parameterValues[0].length() > 0)) {
/* 15 */         this.includeChildrenEnabled = Boolean.valueOf(parameterValues[0]);
/*    */       }
/*    */       else {
/* 18 */         this.includeChildrenEnabled = Boolean.TRUE;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Boolean isIncludeChildrenEnabled()
/*    */   {
/* 25 */     return this.includeChildrenEnabled;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\IncludeChildrenParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */