/*     */ package oracle.adf.internal.model.rest.core.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import oracle.adf.internal.model.rest.core.common.BasicResponseHandler;
/*     */ import oracle.adf.internal.model.rest.core.common.ConditionType;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceContext;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*     */ import oracle.adf.internal.model.rest.core.common.listener.ResourceLifecycleEvent;
/*     */ import oracle.adf.internal.model.rest.core.common.listener.ResourceLifecycleListener;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.domain.BatchPart;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*     */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*     */ import oracle.adf.internal.model.rest.core.exception.PreconditionFailedException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceException;
/*     */ import oracle.adf.internal.model.rest.core.http.exception.HTTPResourceException;
/*     */ import oracle.adf.internal.model.rest.core.http.header.HeaderConfiguratorInfo;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod.Type;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpOperationType;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceLifecyclePhase;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceLifecycleProcessor;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*     */ import oracle.adf.internal.model.rest.core.payload.BatchRequestParser;
/*     */ import oracle.adf.internal.model.rest.core.payload.ParserFactory;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*     */ import oracle.adf.model.BindingContext;
/*     */ import oracle.adf.model.MetadataContext;
/*     */ import oracle.adf.model.binding.DCBindingContainer;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.mds.ADFSessionOptions;
/*     */ import oracle.adf.share.mds.MDSLockedSessionOperations;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.JboException;
/*     */ 
/*     */ public class RESTHttpRequestExecutor
/*     */ {
/*  49 */   public static final Set<HttpMethod.Type> ANTI_CSRF_METHODS_TO_IGNORE = Collections.unmodifiableSet(EnumSet.of(HttpMethod.Type.GET, HttpMethod.Type.OPTIONS, HttpMethod.Type.HEAD));
/*  50 */   public static final Set<HttpMethod.Type> IMPLEMENTED_METHODS = Collections.unmodifiableSet(EnumSet.of(HttpMethod.Type.GET, HttpMethod.Type.DELETE, HttpMethod.Type.PATCH, HttpMethod.Type.POST, HttpMethod.Type.PUT));
/*     */   
/*     */ 
/*     */   private boolean antiCSRFEnabled;
/*     */   
/*     */   private HeaderConfiguratorInfo responseHeaderConfiguratorInfo;
/*     */   
/*     */ 
/*     */   public void setAntiCSRFEnabled(boolean antiCSRFEnabled)
/*     */   {
/*  60 */     this.antiCSRFEnabled = antiCSRFEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void execute(HttpRequestData requestData, RESTHttpResponseWrapper responseWrapper)
/*     */   {
/*  73 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*     */     
/*     */     try
/*     */     {
/*  77 */       RESTHttpRequestWrapper requestWrapper = new RESTHttpRequestWrapper(requestData);
/*  78 */       HttpMethod.Type httpMethodType = requestWrapper.getHttpMethod();
/*     */       
/*  80 */       if (!IMPLEMENTED_METHODS.contains(httpMethodType)) {
/*  81 */         logger.fine("This request will not execute because the HTTP method was not implemented. Method: " + httpMethodType.name());
/*     */         
/*     */ 
/*  84 */         int statusCode = httpMethodType == HttpMethod.Type.OPTIONS ? StatusCode.NO_CONTENT.getCode() : StatusCode.NOT_IMPLEMENTED.getCode();
/*     */         
/*  86 */         Map<String, String> emptyMap = Collections.emptyMap();
/*  87 */         responseWrapper.setupResponseHeaders(statusCode, emptyMap);
/*  88 */         return;
/*     */       }
/*     */       
/*  91 */       if ((this.antiCSRFEnabled) && (!ANTI_CSRF_METHODS_TO_IGNORE.contains(httpMethodType)) && (requestWrapper.getRequestHeader("X-Requested-By") == null))
/*     */       {
/*     */ 
/*  94 */         throw new HTTPResourceException("The anti-csrf header is missing. Header name: X-Requested-By", StatusCode.BAD_REQUEST, requestWrapper.getRequestInfo().toString());
/*     */       }
/*     */       
/*  97 */       HttpResponseHandler responseHandler = new HttpResponseHandler(responseWrapper);
/*     */       
/*  99 */       internalExecute(requestWrapper, responseHandler);
/*     */     } catch (HTTPResourceException e) {
/* 101 */       if (logger.isFine()) {
/* 102 */         Map<String, String> contextData = new HashMap(1);
/* 103 */         contextData.put("Request Info", e.getRequestInfo());
/* 104 */         logger.fine("Error while processing the request", e, contextData);
/*     */       }
/*     */       
/* 107 */       Map<String, String> responseHeaders = Collections.emptyMap();
/* 108 */       String entityTag = e.getEntityTag();
/* 109 */       if (entityTag != null) {
/* 110 */         int headersMapSize = 1;
/* 111 */         responseHeaders = new HashMap(1);
/*     */       }
/* 113 */       responseWrapper.setupResponseHeaders(e.getHttpErrorCode(), responseHeaders);
/*     */       try {
/* 115 */         responseWrapper.getOutpuStream().write(e.getMessage().getBytes());
/*     */       } catch (IOException f) {
/* 117 */         logger.severe("Unexpected error while writing the error message", f);
/*     */       }
/*     */     } catch (Exception e) {
/* 120 */       logger.severe("Unexpected error while processing the request", e);
/* 121 */       Map<String, String> emptyMap = Collections.emptyMap();
/* 122 */       responseWrapper.setupResponseHeaders(StatusCode.INTERNAL_SERVER_ERROR.getCode(), emptyMap);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void execute(RESTHttpRequestWrapper requestWrapper, BasicHttpResponseHandler responseHandler)
/*     */     throws HTTPResourceException
/*     */   {
/* 140 */     new RESTHttpRequestExecutor().internalExecute(requestWrapper, responseHandler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void internalExecute(RESTHttpRequestWrapper requestWrapper, HttpResponseHandler responseHandler)
/*     */     throws HTTPResourceException
/*     */   {
/* 154 */     oracle.adf.internal.model.rest.core.common.RESTUtil.setPathGenerationEncoded(Boolean.TRUE);
/* 155 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*     */     
/* 157 */     if (logger.isConfig()) {
/* 158 */       Map<String, String> contextData = new HashMap(1);
/* 159 */       contextData.put("HTTP method", requestWrapper.getHttpMethod().toString());
/* 160 */       logger.beginActivity(Level.CONFIG, "REST Request", contextData);
/*     */     }
/*     */     try {
/* 163 */       AcceptHeaderManager acceptHeaderManager = new AcceptHeaderManager(requestWrapper.getRequestHeader("Accept"), HTTPRESTUtil.ENTITY_MEDIA_MAPPING);
/*     */       
/*     */ 
/* 166 */       responseHandler.setAcceptEncoding(requestWrapper.getRequestHeader("Accept-Encoding"));
/* 167 */       responseHandler.setAcceptHeaderManager(acceptHeaderManager);
/* 168 */       responseHandler.setupHeaderConfigurator(this.responseHeaderConfiguratorInfo != null ? this.responseHeaderConfiguratorInfo : new HeaderConfiguratorInfo());
/*     */       
/* 170 */       HttpOperationType httpOperation = requestWrapper.getHttpOperationType();
/*     */       
/* 172 */       switch (httpOperation)
/*     */       {
/*     */       case BATCH: 
/* 175 */         BindingContext bindingContext = BindingContext.getCurrent();
/* 176 */         if (bindingContext == null) {
/* 177 */           throw new JboException("Unable to begin transaction for batch. Binding context is null");
/*     */         }
/* 179 */         boolean inSandbox = ((ADFSessionOptions)ADFContext.findCurrent().getCurrentADFSessionOptions()).getSandboxName() != null;
/* 180 */         MDSLockedSessionOperations mdsOperations = null;
/* 181 */         if (inSandbox) {
/* 182 */           mdsOperations = prepareMetadata();
/*     */         }
/*     */         
/* 185 */         List<Throwable> batchExceptions = new ArrayList();
/* 186 */         ParserFactory parser = requestWrapper.getResourceContext().getParserFactory();
/* 187 */         List<BatchPart> parts = new ArrayList();
/* 188 */         parser.getBatchRequestParser().parse(parts);
/* 189 */         if (parts.isEmpty()) {
/* 190 */           throw new CannotParseContentException("No parts were found in the Batch payload.");
/*     */         }
/* 192 */         responseHandler.setContentType(ResourceEntityType.BATCH);
/* 193 */         responseHandler.setup();
/* 194 */         PayloadGenerator generator = responseHandler.getPayloadGenerator();
/* 195 */         generator.startPayload();
/* 196 */         generator.startBatch();
/* 197 */         Iterator<BatchPart> partsIterator = parts.iterator();
/* 198 */         ResourceProcessingContext resourceBindingContext = null;
/* 199 */         while (partsIterator.hasNext()) {
/* 200 */           ResourceLifecycleProcessor processor = new ResourceLifecycleProcessor();
/* 201 */           BatchPart part = (BatchPart)partsIterator.next();
/* 202 */           BatchListener batchPreconditionListener = new BatchListener(part, null);
/* 203 */           processor.addListener(batchPreconditionListener);
/*     */           
/* 205 */           InputStream is = null;
/*     */           try
/*     */           {
/* 208 */             byte[] payloadByteArray = part.getPayloadByteArray();
/* 209 */             if (payloadByteArray != null) {
/* 210 */               is = new java.io.ByteArrayInputStream(payloadByteArray);
/*     */             }
/* 212 */             String basePath = requestWrapper.getResourceContext().getBasePath();
/* 213 */             String path = part.getPath();
/* 214 */             if ((path != null) && (basePath != null) && (path.startsWith(basePath))) {
/* 215 */               path = path.substring(basePath.length());
/*     */             }
/* 217 */             ResourceContext resourceContext = new ResourceContext(basePath, path, null, requestWrapper.getResourceContext().getLocale(), is);
/*     */             
/* 219 */             resourceContext.setEntityContentMap(HTTPRESTUtil.ENTITY_CONTENT_MAPPING);
/* 220 */             resourceContext.setBatchMode(true);
/* 221 */             resourceContext.setParserFactory(ParserFactory.getInstance(requestWrapper.getPayloadType(), is));
/*     */             
/* 223 */             resourceContext.setPrecondition(part.getCondition());
/* 224 */             generator.createPart(part);
/* 225 */             BasicResponseHandler handler = new BasicResponseHandler(responseHandler.getOutputStream(), generator);
/* 226 */             resourceBindingContext = processor.execute(resourceContext, part.getOperation(), handler);
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 230 */             if (((ex instanceof PreconditionFailedException)) && (HTTPRESTUtil.isNotModifiedPrecondition(part.getOperation(), part.getCondition())))
/*     */             {
/* 232 */               generator.addPartPreconditionSucceeded(false);
/* 233 */               if (part.containsPayload()) {
/* 234 */                 generator.startPartPayload();
/* 235 */                 generator.createEmptyResource();
/*     */               }
/*     */             } else {
/* 238 */               JboException jb = new JboException(System.getProperty("line.separator") + part.getId() + " failed: ");
/*     */               
/* 240 */               jb.addToExceptions(ex);
/* 241 */               batchExceptions.add(jb);
/*     */             }
/*     */           } finally {
/* 244 */             generator.finalizePart();
/* 245 */             partsIterator.remove();
/* 246 */             if (is != null) {
/* 247 */               is.close();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 252 */         if (!batchExceptions.isEmpty()) {
/* 253 */           JboException jboEx = new JboException("Request failed because of following error:" + System.getProperty("line.separator"));
/*     */           
/*     */ 
/* 256 */           for (Throwable ex : batchExceptions) {
/* 257 */             jboEx.addToExceptions(ex);
/*     */           }
/* 259 */           throw jboEx;
/*     */         }
/*     */         
/* 262 */         resourceBindingContext.getResourceTree().commitTransaction();
/* 263 */         if (inSandbox) {
/* 264 */           flushMetadata(mdsOperations);
/*     */         }
/* 266 */         generator.endBatch();
/* 267 */         generator.endPayload();
/* 268 */         generator.close();
/* 269 */         break;
/*     */       
/*     */ 
/*     */       case RESOURCE: 
/* 273 */         ResourceLifecycleProcessor processor = new ResourceLifecycleProcessor();
/* 274 */         ResourceContext context = requestWrapper.getResourceContext();
/*     */         try {
/* 276 */           processor.execute(context, httpOperation.getOperation(), responseHandler);
/*     */         } catch (PreconditionFailedException ex) {
/* 278 */           if (context.getPrecondition().getConditionType() != ConditionType.MATCH) {
/* 279 */             throw ex;
/*     */           }
/*     */           
/*     */ 
/* 283 */           context.setPrecondition(null);
/* 284 */           processor.execute(context, OperationType.REPRESENTATION, responseHandler);
/*     */         }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       default: 
/* 291 */         throw new JboException("Unknown HTTP operation type");
/*     */       }
/*     */     }
/*     */     catch (ResourceException e) {
/* 295 */       throw HTTPRESTUtil.createHTTPResourceExceptionInstance(e, requestWrapper.getRequestInfo(), responseHandler.getStateIdentifier());
/*     */     }
/*     */     catch (Exception e) {
/* 298 */       logger.severe("Unexpected error while processing the request", e);
/* 299 */       throw HTTPRESTUtil.createHTTPResourceExceptionInstance(e, requestWrapper.getRequestInfo(), responseHandler.getStateIdentifier());
/*     */     }
/*     */     finally {
/* 302 */       if (logger.isConfig()) {
/* 303 */         logger.endCurrentActivity();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setResponseHeaderConfiguratorInfo(HeaderConfiguratorInfo responseHeaderConfiguratorInfo) {
/* 309 */     this.responseHeaderConfiguratorInfo = responseHeaderConfiguratorInfo;
/*     */   }
/*     */   
/*     */   private MDSLockedSessionOperations prepareMetadata() throws Exception {
/* 313 */     MDSLockedSessionOperations dSLockedSessionOperations = MetadataContext.lockPrepareSession();
/* 314 */     return dSLockedSessionOperations;
/*     */   }
/*     */   
/*     */   private void flushMetadata(MDSLockedSessionOperations mdsOperations) throws Exception {
/*     */     try {
/* 319 */       MetadataContext.releaseFlushSession(mdsOperations);
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 324 */       BindingContext bctx = BindingContext.getCurrent();
/*     */       
/* 326 */       if (bctx != null) {
/* 327 */         DCBindingContainer bindingContainer = (DCBindingContainer)bctx.getCurrentBindingsEntry();
/*     */         
/*     */ 
/* 330 */         if (bindingContainer != null) {
/* 331 */           bindingContainer.reportException(ex);
/* 332 */           return;
/*     */         }
/*     */       }
/*     */       
/* 336 */       if ((ex instanceof RuntimeException)) {
/* 337 */         throw ex;
/*     */       }
/* 339 */       throw new JboException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class BatchListener implements ResourceLifecycleListener
/*     */   {
/*     */     private final BatchPart part;
/*     */     
/*     */     private BatchListener(BatchPart part)
/*     */     {
/* 349 */       this.part = part;
/*     */     }
/*     */     
/*     */ 
/*     */     public void notify(ResourceLifecycleEvent event)
/*     */     {
/* 355 */       ResourceLifecyclePhase lifecyclePhase = event.getPhase();
/*     */       
/* 357 */       if (lifecyclePhase == ResourceLifecyclePhase.CHECK_SECURITY) {
/* 358 */         ResponseHandler handler = event.getResponseHandler();
/* 359 */         PayloadGenerator generator = handler.getPayloadGenerator();
/*     */         try {
/* 361 */           if (this.part.getCondition() != null) {
/* 362 */             generator.addPartPreconditionSucceeded(handler.getError() != oracle.adf.internal.model.rest.core.common.ResponseHandler.ErrorType.PRECONDITION_FAILED);
/*     */           }
/*     */         } catch (IOException e) {
/* 365 */           throw new JboException(e);
/*     */         }
/* 367 */       } else if (lifecyclePhase == ResourceLifecyclePhase.GENERATE_RESPONSE) {
/* 368 */         ResponseHandler handler = event.getResponseHandler();
/* 369 */         PayloadGenerator generator = handler.getPayloadGenerator();
/*     */         try {
/* 371 */           generator.startPartPayload();
/*     */         } catch (IOException e) {
/* 373 */           throw new JboException(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\RESTHttpRequestExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */