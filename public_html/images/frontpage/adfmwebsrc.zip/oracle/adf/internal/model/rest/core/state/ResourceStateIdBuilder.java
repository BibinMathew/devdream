/*    */ package oracle.adf.internal.model.rest.core.state;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import oracle.jbo.ConsistentRow;
/*    */ import oracle.jbo.JboException;
/*    */ import oracle.jbo.Row;
/*    */ import oracle.jbo.common.RepConversion;
/*    */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*    */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ResourceStateIdBuilder
/*    */   extends StateIdBuilder
/*    */ {
/*    */   public String createStateId(JUCtrlValueBinding valueBinding)
/*    */   {
/* 31 */     return getChangeIndicator(valueBinding.getCurrentRow());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String createStateId(JUCtrlHierNodeBinding node)
/*    */   {
/* 41 */     return getChangeIndicator(node.getRow());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String getChangeIndicator(Row row)
/*    */   {
/* 50 */     if (!(row instanceof ConsistentRow)) {
/* 51 */       return null;
/*    */     }
/*    */     
/* 54 */     ConsistentRow consistentRow = (ConsistentRow)row;
/* 55 */     String changeIndicator = null;
/*    */     
/* 57 */     Serializable rowChangeIndicator = consistentRow.getClientChangeIndicator();
/* 58 */     if (rowChangeIndicator == null) {
/* 59 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 63 */       ByteArrayOutputStream baos = null;
/* 64 */       ObjectOutputStream oos = null;
/*    */       try {
/* 66 */         baos = new ByteArrayOutputStream();
/* 67 */         oos = new ObjectOutputStream(baos);
/* 68 */         oos.writeObject(rowChangeIndicator);
/* 69 */         byte[] ciBytes = baos.toByteArray();
/* 70 */         changeIndicator = RepConversion.bArray2String(ciBytes);
/*    */       } finally {
/* 72 */         if (oos != null) {
/* 73 */           oos.close();
/*    */         }
/*    */       }
/*    */     } catch (IOException ex) {
/* 77 */       throw new JboException(ex);
/*    */     }
/*    */     
/* 80 */     return changeIndicator;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\state\ResourceStateIdBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */