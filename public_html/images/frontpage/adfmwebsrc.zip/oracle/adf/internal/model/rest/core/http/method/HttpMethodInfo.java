/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.Verb;
/*    */ import oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpMethodInfo
/*    */ {
/*    */   private final Verb verb;
/*    */   private final ContentTypeHandler requestContentTypeHandler;
/*    */   
/*    */   public HttpMethodInfo(Verb verb, ContentTypeHandler requestContentTypeHandler)
/*    */   {
/* 22 */     this.verb = verb;
/* 23 */     this.requestContentTypeHandler = requestContentTypeHandler;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ContentTypeHandler getRequestContentTypeHandler()
/*    */   {
/* 31 */     return this.requestContentTypeHandler;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Verb getVerb()
/*    */   {
/* 39 */     return this.verb;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\HttpMethodInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */