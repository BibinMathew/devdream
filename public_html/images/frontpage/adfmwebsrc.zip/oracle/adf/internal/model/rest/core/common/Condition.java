/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Condition
/*    */ {
/*    */   private final Collection<String> states;
/*    */   private final ConditionType conditionType;
/*    */   
/*    */   public Condition(ConditionType conditionType)
/*    */   {
/* 22 */     this.conditionType = conditionType;
/* 23 */     this.states = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Condition(ConditionType conditionType, Collection<String> states)
/*    */   {
/* 33 */     this.conditionType = conditionType;
/* 34 */     this.states = states;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Collection<String> getStates()
/*    */   {
/* 42 */     return this.states;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConditionType getConditionType()
/*    */   {
/* 50 */     return this.conditionType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isAnyStateAllowed()
/*    */   {
/* 58 */     return (this.states == null) || (this.states.isEmpty());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Condition createCondition(Map<ConditionType, List<String>> conditions)
/*    */   {
/* 67 */     ConditionType conditionType = ConditionType.NONE_MATCH;
/* 68 */     if (conditions.containsKey(ConditionType.MATCH)) {
/* 69 */       conditionType = ConditionType.MATCH;
/*    */     }
/* 71 */     List<String> states = (List)conditions.get(conditionType);
/* 72 */     return new Condition(conditionType, states);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\Condition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */