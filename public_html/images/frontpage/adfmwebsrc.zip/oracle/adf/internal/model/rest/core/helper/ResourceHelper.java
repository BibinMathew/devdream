/*     */ package oracle.adf.internal.model.rest.core.helper;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.domain.Action;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionResult;
/*     */ import oracle.adf.internal.model.rest.core.domain.EffectiveDateUtil;
/*     */ import oracle.adf.internal.model.rest.core.domain.EffectiveDateUtil.EffectiveDateOperation;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceItem;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*     */ import oracle.adf.internal.model.rest.core.payload.ActionParser;
/*     */ import oracle.adf.internal.model.rest.core.payload.ParserFactory;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*     */ import oracle.adf.internal.model.rest.core.payload.ResourceParser;
/*     */ import oracle.adf.internal.model.rest.core.payload.ResourceParser.TokenType;
/*     */ import oracle.adf.internal.model.rest.core.topology.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceHelper
/*     */ {
/*     */   public static void generateResourceRepresentation(ResourceProcessingContext context, PayloadGenerator generator)
/*     */     throws IOException
/*     */   {
/*  26 */     ResourceTreeTraverser traverser = new ResourceTreeTraverser(context, generator);
/*  27 */     traverser.process();
/*     */   }
/*     */   
/*     */   public static void generateActionResult(ActionResult actionResult, PayloadGenerator generator) throws IOException {
/*  31 */     generator.setup();
/*  32 */     generator.createActionResult(actionResult);
/*     */   }
/*     */   
/*     */   public static Action createResourceAction(ResourceProcessingContext context) throws IOException {
/*  36 */     return context.getParserFactory().getActionParser().parse(context.getResourceTree().getCurrentResource());
/*     */   }
/*     */   
/*     */   public static void deleteResource(ResourceProcessingContext context) {
/*  40 */     ResourceTree tree = context.getResourceTree();
/*  41 */     if (context.isEffectiveDateRangeOperation()) {
/*  42 */       ResourceItem resource = ResourceItem.asItem(tree.getCurrentResource());
/*  43 */       EffectiveDateUtil.doEffectiveDateRangeDelete(resource, context.getEffectiveDateRangeProperties());
/*     */     }
/*     */     else {
/*  46 */       tree.deleteResource();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void replaceResource(ResourceProcessingContext context) throws IOException {
/*  51 */     ResourceTree tree = context.getResourceTree();
/*  52 */     ResourceTreeManager treeManager = new ResourceTreeManager(tree);
/*  53 */     manageResource(context, treeManager, OperationType.REPLACEMENT);
/*     */   }
/*     */   
/*     */   public static void updateResource(ResourceProcessingContext context) throws IOException {
/*  57 */     ResourceTree tree = context.getResourceTree();
/*  58 */     ResourceTreeManager treeManager = new ResourceTreeManager(tree);
/*  59 */     manageResource(context, treeManager, OperationType.UPDATE);
/*     */   }
/*     */   
/*     */   public static void mergeResource(ResourceProcessingContext context) throws IOException {
/*  63 */     ResourceTree tree = context.getResourceTree();
/*  64 */     ResourceTreeManager treeManager = new ResourceTreeManager(tree, context.getEffectiveDateRangeProperties());
/*     */     
/*  66 */     manageResource(context, treeManager, OperationType.MERGE);
/*     */   }
/*     */   
/*     */   public static void createResource(ResourceProcessingContext context) throws IOException {
/*  70 */     ResourceTree tree = context.getResourceTree();
/*  71 */     ResourceTreeManager treeManager = new ResourceTreeManager(tree);
/*  72 */     manageResource(context, treeManager, OperationType.CREATION);
/*     */   }
/*     */   
/*     */ 
/*     */   private static void manageResource(ResourceProcessingContext context, ResourceTreeManager treeManager, OperationType resourceOperation)
/*     */     throws IOException
/*     */   {
/*  79 */     ResourceParser parser = context.getParserFactory().getResourceParser(treeManager);
/*     */     ResourceParser.TokenType currentToken;
/*  81 */     while ((currentToken = parser.next()) != ResourceParser.TokenType.CLOSE) {
/*  82 */       switch (currentToken) {
/*     */       case START_ITEM: 
/*  84 */         treeManager.startResourceItem();
/*  85 */         break;
/*     */       case END_ITEM: 
/*  87 */         performResourceOperation(resourceOperation, treeManager);
/*  88 */         treeManager.endResourceItem();
/*  89 */         break;
/*     */       case START_COLLECTION: 
/*  91 */         performResourceOperation(resourceOperation, treeManager);
/*  92 */         treeManager.startResourceCollection(parser.getNestedResourceName());
/*  93 */         break;
/*     */       case END_COLLECTION: 
/*  95 */         treeManager.endResourceCollection();
/*  96 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case ATTR_VALUE: 
/* 101 */         if ((treeManager.isCurrentResourcePolymorphic()) && (treeManager.areDiscrValuesProvided()))
/*     */         {
/*     */ 
/*     */ 
/* 105 */           if ((resourceOperation == OperationType.CREATION) && (!treeManager.isCurrentResourceFlex())) {
/* 106 */             performResourceOperation(resourceOperation, treeManager);
/* 107 */             resourceOperation = OperationType.UPDATE;
/* 108 */           } else if (treeManager.areSearchValuesProvided()) {
/* 109 */             treeManager.findResource();
/*     */           }
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/* 115 */     TreePath treePath = treeManager.getTreePath();
/* 116 */     context.setTreePath(treePath);
/*     */     
/* 118 */     if (context.isEffectiveDateRangeOperation()) {
/* 119 */       EffectiveDateUtil.doEffectiveDateRangeOperation(context.getEffectiveDateRangeProperties(), treePath, getEffectiveDateOperationForResourceOperation(resourceOperation));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void performResourceOperation(OperationType op, ResourceTreeManager treeManager)
/*     */   {
/* 127 */     if ((op == OperationType.CREATION) && (treeManager.isCurrentResourceFlex())) {
/* 128 */       op = OperationType.UPDATE;
/*     */     }
/* 130 */     treeManager.operate(op);
/* 131 */     if ((op == OperationType.CREATION) && (treeManager.hasSavedAttributeValues())) {
/* 132 */       treeManager.prepareForSecondPhaseOperation();
/* 133 */       treeManager.operate(OperationType.UPDATE);
/*     */     }
/*     */   }
/*     */   
/*     */   private static EffectiveDateUtil.EffectiveDateOperation getEffectiveDateOperationForResourceOperation(OperationType resourceOperation)
/*     */   {
/* 139 */     switch (resourceOperation) {
/*     */     case CREATION: 
/* 141 */       return EffectiveDateUtil.EffectiveDateOperation.CREATE;
/*     */     case UPDATE: 
/*     */     case MERGE: 
/*     */     case REPLACEMENT: 
/* 145 */       return EffectiveDateUtil.EffectiveDateOperation.UPDATE;
/*     */     case DELETION: 
/* 147 */       return EffectiveDateUtil.EffectiveDateOperation.DELETE;
/*     */     }
/* 149 */     throw new UnsupportedOperationException("Invalid operation for effective dated objects");
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\helper\ResourceHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */