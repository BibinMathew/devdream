/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicResponseHandler
/*    */   implements ResponseHandler
/*    */ {
/*    */   private OutputStream out;
/*    */   private PayloadGenerator generator;
/*    */   private ResponseHandler.ErrorType errorType;
/*    */   
/*    */   public BasicResponseHandler(OutputStream out, PayloadGenerator generator)
/*    */   {
/* 18 */     this.out = out;
/* 19 */     this.generator = generator;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setup() {}
/*    */   
/*    */ 
/*    */   public OutputStream getOutputStream()
/*    */   {
/* 28 */     return this.out;
/*    */   }
/*    */   
/*    */   public PayloadGenerator getPayloadGenerator()
/*    */   {
/* 33 */     return this.generator;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setContentType(ResourceEntityType entityType) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void setContentType(String contentType) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void setStateIdentifier(String stateId) {}
/*    */   
/*    */ 
/*    */   public void setResourcePath(String resourcePath) {}
/*    */   
/*    */ 
/*    */   public boolean isContentGenerationAllowed()
/*    */   {
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isEntityGenerationAllowed()
/*    */   {
/* 59 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void resetContentType() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void finish() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void setProperties(Map<String, String> properties) {}
/*    */   
/*    */ 
/*    */   public void setCreatingResource(boolean creatingResource) {}
/*    */   
/*    */ 
/*    */   public String getStateIdentifier()
/*    */   {
/* 80 */     return null;
/*    */   }
/*    */   
/*    */   public void setError(ResponseHandler.ErrorType errorType)
/*    */   {
/* 85 */     this.errorType = errorType;
/*    */   }
/*    */   
/*    */   public ResponseHandler.ErrorType getError()
/*    */   {
/* 90 */     return this.errorType;
/*    */   }
/*    */   
/*    */   public void setLink(String link) {}
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\BasicResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */