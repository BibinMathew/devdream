/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Path;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceHelper;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*    */ 
/*    */ class ResourceCreation extends AbstractResourceOperation
/*    */ {
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 19 */     if (!context.getResourceTree().getCurrentResource().isCollection()) {
/* 20 */       throw new oracle.adf.internal.model.rest.core.exception.InvalidResourceTypeException();
/*    */     }
/* 22 */     if (context.getParserFactory() == null) {
/* 23 */       throw new CannotParseContentException("The PayloadParser could not be found in the ResourceProcessingContext.");
/*    */     }
/*    */   }
/*    */   
/*    */   public void execute(ResourceProcessingContext context) throws IOException
/*    */   {
/* 29 */     ResourceHelper.createResource(context);
/*    */   }
/*    */   
/*    */   public void generateResponse(ResourceProcessingContext context) throws IOException
/*    */   {
/* 34 */     if (this.responseHandler.isEntityGenerationAllowed()) {
/* 35 */       PayloadGenerator generator = this.responseHandler.getPayloadGenerator();
/* 36 */       ResourceHelper.generateResourceRepresentation(context, generator);
/*    */     }
/*    */   }
/*    */   
/*    */   public void prepareResponse(ResourceProcessingContext context)
/*    */   {
/* 42 */     this.responseHandler.setResourcePath(context.getResourcePath().createHref());
/* 43 */     super.prepareResponse(context);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void applyInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public void validateInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 56 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isCreatingResource()
/*    */   {
/* 61 */     return true;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 66 */     return OperationType.CREATION;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 71 */     return ActionType.CREATE;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ResourceCreation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */