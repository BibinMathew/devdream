/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ 
/*    */ public class ParameterDescription
/*    */ {
/*    */   private String name;
/*    */   
/*    */   private String typeName;
/*    */   private boolean mandatory;
/*    */   
/*    */   public void setName(String name)
/*    */   {
/* 13 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 17 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setTypeName(String typeName) {
/* 21 */     this.typeName = typeName;
/*    */   }
/*    */   
/*    */   public String getTypeName() {
/* 25 */     return this.typeName;
/*    */   }
/*    */   
/*    */   public void setMandatory(boolean mandatory) {
/* 29 */     this.mandatory = mandatory;
/*    */   }
/*    */   
/*    */   public boolean isMandatory() {
/* 33 */     return this.mandatory;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ParameterDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */