/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ public class ActionResult<T>
/*    */ {
/*    */   private T result;
/*    */   public static final String NAME = "ActionResult";
/*    */   public static final String RESULT_ATTR = "result";
/*    */   
/*    */   public ActionResult(T result)
/*    */   {
/* 11 */     this.result = result;
/*    */   }
/*    */   
/*    */   public T getResult() {
/* 15 */     return (T)this.result;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ActionResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */