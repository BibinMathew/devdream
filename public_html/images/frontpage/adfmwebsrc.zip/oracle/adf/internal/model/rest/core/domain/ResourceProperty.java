/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.AbstractMap.SimpleImmutableEntry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceProperty
/*    */   extends AbstractMap.SimpleImmutableEntry<String, Object>
/*    */   implements Property<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 8654810027747916884L;
/*    */   
/*    */   public ResourceProperty(String key, Object value)
/*    */   {
/* 19 */     super(key, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ResourceProperty(ResourceProperty resourceProperty)
/*    */   {
/* 27 */     super(resourceProperty);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceProperty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */