/*    */ package oracle.adf.internal.model.rest.core.http.media;
/*    */ 
/*    */ import java.util.Set;
/*    */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*    */ 
/*    */ public class EntityMediaTypeMappingValue
/*    */ {
/*    */   private final Set<MediaType> mediaTypes;
/*    */   private final Set<MediaType> allSupportedMediaTypes;
/*    */   
/*    */   public EntityMediaTypeMappingValue(Set<MediaType> mediaTypes, Set<MediaType> allSupportedMediaTypes)
/*    */   {
/* 13 */     this.mediaTypes = mediaTypes;
/* 14 */     this.allSupportedMediaTypes = allSupportedMediaTypes;
/*    */   }
/*    */   
/*    */   public Set<MediaType> getMediaTypes()
/*    */   {
/* 19 */     return this.mediaTypes;
/*    */   }
/*    */   
/*    */   public Set<MediaType> getAllSupportedMediaTypes() {
/* 23 */     return this.allSupportedMediaTypes;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\media\EntityMediaTypeMappingValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */