/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public final class EntityContentMapping
/*    */ {
/*    */   private final HashMap<ResourceEntityType, EntityContentMappingValue> map;
/*    */   
/*    */   public EntityContentMapping(HashMap<ResourceEntityType, EntityContentMappingValue> map)
/*    */   {
/* 12 */     this.map = map;
/*    */   }
/*    */   
/*    */   public String[] getSupportedContentTypes(ResourceEntityType entityType) {
/* 16 */     String[] supportedContentTypes = ((EntityContentMappingValue)this.map.get(entityType)).getSupportedContentTypes();
/* 17 */     return (String[])Arrays.copyOf(supportedContentTypes, supportedContentTypes.length);
/*    */   }
/*    */   
/*    */   public String[] getContentType(ResourceEntityType entityType) {
/* 21 */     String[] contentType = ((EntityContentMappingValue)this.map.get(entityType)).getContentType();
/* 22 */     return (String[])Arrays.copyOf(contentType, contentType.length);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\EntityContentMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */