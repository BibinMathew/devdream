package oracle.adf.internal.model.rest.core.domain;

public class Batch
{
  public static final String PAYLOAD_ATTR = "parts";
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Batch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */