package oracle.adf.internal.model.rest.core.state;

import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

public abstract class StateIdBuilder
{
  public abstract String createStateId(JUCtrlValueBinding paramJUCtrlValueBinding);
  
  public abstract String createStateId(JUCtrlHierNodeBinding paramJUCtrlHierNodeBinding);
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\state\StateIdBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */