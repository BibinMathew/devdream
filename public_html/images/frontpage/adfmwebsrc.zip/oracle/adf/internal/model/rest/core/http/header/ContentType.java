/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ public class ContentType implements Header
/*    */ {
/*    */   private final MediaType mediaType;
/*    */   public static final String NAME = "Content-Type";
/*    */   
/*    */   public ContentType(MediaType mediaType)
/*    */   {
/* 10 */     this.mediaType = mediaType;
/*    */   }
/*    */   
/*    */   public MediaType getMediaType() {
/* 14 */     return this.mediaType;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 19 */     return "Content-Type";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\ContentType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */