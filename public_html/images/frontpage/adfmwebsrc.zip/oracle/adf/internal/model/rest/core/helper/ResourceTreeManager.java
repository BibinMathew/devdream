/*     */ package oracle.adf.internal.model.rest.core.helper;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*     */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceCollection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceItem;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*     */ import oracle.adf.internal.model.rest.core.domain.SearchAttributes;
/*     */ import oracle.adf.internal.model.rest.core.topology.BasicResourceTreePath;
/*     */ import oracle.adf.internal.model.rest.core.topology.BasicTreePath;
/*     */ import oracle.adf.internal.model.rest.core.topology.TreePath;
/*     */ import oracle.jbo.Key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceTreeManager
/*     */ {
/*     */   private final ResourceTree tree;
/*  32 */   private final ArrayDeque<BasicResourceTreePath> resourcePathStack = new ArrayDeque();
/*     */   private BasicTreePath treePath;
/*     */   private Attribute currentAttribute;
/*     */   private ResourceItem currentResource;
/*     */   private ResourceCollection parentResource;
/*  37 */   private int nodeLevel = 0;
/*  38 */   private Set<String> searchAttributes = Collections.emptySet();
/*  39 */   private Map<String, Object> providedSearchAttributes = new HashMap();
/*  40 */   private Map<String, Object> allAttributesProvided = new LinkedHashMap();
/*  41 */   private Map<String, Object> savedAttributesProvided = new LinkedHashMap();
/*  42 */   private Set<List<Key>> modifiedResourceList = new HashSet();
/*     */   
/*  44 */   public static enum AttributeType { ATTRIBUTE,  ACCESSOR;
/*     */     
/*     */     private AttributeType() {} }
/*     */   
/*  48 */   public ResourceTreeManager(ResourceTree tree) { this(tree, Collections.emptyMap()); }
/*     */   
/*     */ 
/*     */   private final Map<String, String> effDateRangeProperties;
/*     */   public ResourceTreeManager(ResourceTree tree, Map<String, String> effDateRangeProperties)
/*     */   {
/*  54 */     this.tree = tree;
/*  55 */     this.effDateRangeProperties = effDateRangeProperties;
/*  56 */     if (this.tree.getCurrentResource().isCollection()) {
/*  57 */       this.parentResource = ResourceCollection.asCollection(this.tree.getCurrentResource());
/*     */     } else {
/*  59 */       this.currentResource = ResourceItem.asItem(this.tree.getCurrentResource());
/*  60 */       this.parentResource = this.currentResource.getParent();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isCurrentResourceNested()
/*     */   {
/*  67 */     return this.nodeLevel > 0;
/*     */   }
/*     */   
/*     */   public void startResourceCollection(String name)
/*     */   {
/*  72 */     if (this.currentResource == null) {
/*  73 */       throw new IllegalStateException("Unable to start a nested resource because there is no current resource. Nested resource name: " + name);
/*     */     }
/*  75 */     this.tree.setCurrentResource(this.currentResource);
/*  76 */     this.parentResource = this.tree.seekChildResourceCollection(name);
/*  77 */     if (this.parentResource == null) {
/*  78 */       throw new IllegalStateException("Could not create the parent resource for the following nested resource: " + name);
/*     */     }
/*  80 */     this.nodeLevel += 1;
/*  81 */     this.currentResource = null;
/*     */   }
/*     */   
/*     */   public void endResourceCollection()
/*     */   {
/*  86 */     this.currentResource = ResourceItem.asItem(this.tree.findResourceByKeyPath(((BasicResourceTreePath)this.resourcePathStack.peek()).getResourceKeyPath()));
/*     */     
/*  88 */     this.parentResource = this.currentResource.getParent();
/*  89 */     this.tree.setCurrentResource(this.currentResource);
/*  90 */     this.nodeLevel -= 1;
/*     */   }
/*     */   
/*     */   public void startResourceItem()
/*     */   {
/*  95 */     BasicResourceTreePath nextResourcePath = new BasicResourceTreePath();
/*  96 */     if (this.currentResource != null) {
/*  97 */       nextResourcePath.setResource(this.currentResource);
/*     */     }
/*  99 */     if (this.treePath == null) {
/* 100 */       this.treePath = new BasicTreePath(this.tree, this.parentResource);
/* 101 */       this.treePath.addResourcePath(nextResourcePath);
/*     */     }
/*     */     
/* 104 */     this.resourcePathStack.push(nextResourcePath);
/* 105 */     this.searchAttributes = new HashSet(this.parentResource.getSearchAttributeNames());
/* 106 */     this.savedAttributesProvided = new HashMap();
/*     */   }
/*     */   
/*     */   public void endResourceItem()
/*     */   {
/* 111 */     this.resourcePathStack.pop();
/* 112 */     if ((isCurrentResourceNested()) && (this.currentResource != null)) {
/* 113 */       this.tree.setCurrentResource(this.currentResource.getParent());
/*     */     }
/* 115 */     this.currentResource = null;
/* 116 */     this.savedAttributesProvided = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */   public Resource operate(OperationType operation)
/*     */   {
/* 122 */     if ((this.currentResource == null) && ((operation == OperationType.MERGE) || ((isCurrentResourceNested()) && ((operation == OperationType.REPLACEMENT) || (operation == OperationType.UPDATE)))))
/*     */     {
/* 124 */       findResource();
/*     */     }
/*     */     
/* 127 */     if (operation == OperationType.MERGE) {
/* 128 */       operation = this.currentResource != null ? OperationType.UPDATE : OperationType.CREATION;
/*     */     }
/*     */     
/* 131 */     BasicResourceTreePath currentResourceTreePath = (BasicResourceTreePath)this.resourcePathStack.peek();
/* 132 */     if (operation == OperationType.CREATION) {
/* 133 */       ResourceItem newResource = createChildResourceUsingBuffer();
/* 134 */       if ((newResource != null) && (!newResource.getKey().isNull())) {
/* 135 */         this.currentResource = newResource;
/* 136 */         currentResourceTreePath.setResource(this.currentResource);
/* 137 */         configureCurrentResourceTreePath(currentResourceTreePath);
/*     */       }
/* 139 */     } else if ((this.currentResource != null) && (!isOperationPerformedOnCurrentResource()) && ((operation == OperationType.UPDATE) || (operation == OperationType.REPLACEMENT)))
/*     */     {
/* 141 */       this.tree.setCurrentResource(this.currentResource);
/* 142 */       switch (operation) {
/*     */       case UPDATE: 
/* 144 */         this.currentResource.updateAttributes(this.allAttributesProvided);
/* 145 */         break;
/*     */       case REPLACEMENT: 
/* 147 */         this.currentResource.replaceAttributes(this.allAttributesProvided);
/*     */       }
/* 149 */       this.modifiedResourceList.add(this.currentResource.getKeyPath());
/* 150 */       configureCurrentResourceTreePath(currentResourceTreePath);
/*     */     }
/* 152 */     resetBuffers();
/* 153 */     return this.currentResource;
/*     */   }
/*     */   
/*     */   public AttributeType getAttributeType(String attribute) {
/* 157 */     if (this.currentResource != null) {
/* 158 */       if (this.currentResource.isAccessorAttribute(attribute)) {
/* 159 */         return AttributeType.ACCESSOR;
/*     */       }
/* 161 */       return AttributeType.ATTRIBUTE;
/*     */     }
/*     */     
/*     */ 
/* 165 */     if (this.parentResource.isAccessorAttribute(attribute)) {
/* 166 */       return AttributeType.ACCESSOR;
/*     */     }
/* 168 */     return AttributeType.ATTRIBUTE;
/*     */   }
/*     */   
/*     */   public Attribute setCurrentAttribute(String name)
/*     */   {
/* 173 */     if (this.currentResource != null) {
/* 174 */       this.currentAttribute = this.currentResource.getAttribute(name);
/*     */     } else {
/* 176 */       this.currentAttribute = this.parentResource.getAttribute(name);
/*     */     }
/* 178 */     return this.currentAttribute;
/*     */   }
/*     */   
/*     */   public void setAttributeValue(Object value) {
/* 182 */     String currentAttributeName = this.currentAttribute.getName();
/* 183 */     if (this.searchAttributes.contains(currentAttributeName)) {
/* 184 */       this.providedSearchAttributes.put(currentAttributeName, value);
/*     */     }
/*     */     
/* 187 */     this.allAttributesProvided.put(currentAttributeName, value);
/*     */   }
/*     */   
/*     */   boolean findResource() {
/* 191 */     if (this.providedSearchAttributes.size() > 0) {
/* 192 */       SearchAttributes searchAttributes = new SearchAttributes(this.providedSearchAttributes, this.effDateRangeProperties);
/*     */       
/* 194 */       this.currentResource = this.tree.seekChildResource(searchAttributes);
/* 195 */       if (this.currentResource != null) {
/* 196 */         ((BasicResourceTreePath)this.resourcePathStack.peek()).setResource(this.currentResource);
/*     */       }
/*     */       
/*     */ 
/* 200 */       this.providedSearchAttributes = new HashMap();
/*     */     }
/*     */     
/* 203 */     return this.currentResource != null;
/*     */   }
/*     */   
/*     */   private void configureCurrentResourceTreePath(BasicResourceTreePath currentResourcePath) {
/* 207 */     currentResourcePath.setResource(this.currentResource);
/* 208 */     if (isCurrentResourceNested()) {
/* 209 */       BasicResourceTreePath currentTop = (BasicResourceTreePath)this.resourcePathStack.pop();
/* 210 */       ((BasicResourceTreePath)this.resourcePathStack.peek()).addChildResourcePath(this.parentResource.getName(), currentResourcePath);
/* 211 */       this.resourcePathStack.push(currentTop);
/*     */     }
/*     */   }
/*     */   
/*     */   private ResourceItem createChildResourceUsingBuffer()
/*     */   {
/* 217 */     ResourceItem newResource = this.tree.createChildResource(this.allAttributesProvided);
/* 218 */     if (newResource == null) {
/* 219 */       return null;
/*     */     }
/* 221 */     this.modifiedResourceList.add(newResource.getKeyPath());
/* 222 */     return newResource;
/*     */   }
/*     */   
/*     */   private void resetBuffers() {
/* 226 */     this.providedSearchAttributes = new HashMap();
/* 227 */     this.allAttributesProvided = new HashMap();
/*     */   }
/*     */   
/*     */   TreePath getTreePath() {
/* 231 */     return this.treePath;
/*     */   }
/*     */   
/*     */   private boolean isOperationPerformedOnCurrentResource() {
/* 235 */     return this.modifiedResourceList.contains(this.tree.getCurrentResource().getKeyPath());
/*     */   }
/*     */   
/*     */   boolean isCurrentResourceFlex() {
/* 239 */     return this.parentResource.isFlexExtension();
/*     */   }
/*     */   
/* 242 */   boolean isCurrentResourcePolymorphic() { return this.parentResource.isPolymorphic(); }
/*     */   
/*     */   boolean areDiscrValuesProvided()
/*     */   {
/* 246 */     return this.allAttributesProvided.containsKey(this.parentResource.getDiscrAttribute());
/*     */   }
/*     */   
/*     */   boolean areSearchValuesProvided()
/*     */   {
/* 251 */     return this.allAttributesProvided.keySet().containsAll(this.searchAttributes);
/*     */   }
/*     */   
/*     */   boolean isValueForLOVAttribute()
/*     */   {
/* 256 */     return this.currentAttribute != null ? this.currentAttribute.hasLov() : false;
/*     */   }
/*     */   
/*     */   boolean hasSavedAttributeValues()
/*     */   {
/* 261 */     return this.savedAttributesProvided.size() > 0;
/*     */   }
/*     */   
/*     */   void prepareForSecondPhaseOperation()
/*     */   {
/* 266 */     this.modifiedResourceList.remove(this.currentResource.getKeyPath());
/* 267 */     this.allAttributesProvided = this.savedAttributesProvided;
/* 268 */     this.savedAttributesProvided = new HashMap();
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\helper\ResourceTreeManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */