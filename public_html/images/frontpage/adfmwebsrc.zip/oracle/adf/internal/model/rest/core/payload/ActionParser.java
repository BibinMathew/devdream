package oracle.adf.internal.model.rest.core.payload;

import java.io.IOException;
import oracle.adf.internal.model.rest.core.domain.Action;
import oracle.adf.internal.model.rest.core.domain.Resource;

public abstract interface ActionParser
{
  public abstract Action parse(Resource paramResource)
    throws IOException;
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\ActionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */