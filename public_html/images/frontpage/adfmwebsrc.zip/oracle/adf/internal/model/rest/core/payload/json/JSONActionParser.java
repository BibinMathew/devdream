/*    */ package oracle.adf.internal.model.rest.core.payload.json;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import oracle.adf.internal.model.rest.core.domain.Action;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.exception.NotAnActionException;
/*    */ import oracle.adf.internal.model.rest.core.payload.ActionParser;
/*    */ import oracle.adf.model.rest.RestTypeConverter;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JSONActionParser
/*    */   implements ActionParser
/*    */ {
/*    */   private JsonParser parser;
/*    */   
/*    */   JSONActionParser(JsonParser parser)
/*    */   {
/* 26 */     this.parser = parser;
/*    */   }
/*    */   
/*    */   public Action parse(Resource resource) throws IOException {
/* 30 */     this.parser.nextValue();
/*    */     
/* 32 */     Map<String, Object> parameters = null;
/* 33 */     String name; do { name = null;
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 44 */       while (this.parser.nextValue() != JsonToken.START_OBJECT)
/*    */       {
/*    */         String currentNodeName;
/*    */         for (;;)
/*    */         {
/* 34 */           if ((this.parser.nextValue() == JsonToken.END_OBJECT) || (this.parser.isClosed())) break label162;
/* 35 */           currentNodeName = this.parser.getCurrentName();
/*    */           
/* 37 */           if ((name != null) || (!"name".equals(currentNodeName))) break;
/* 38 */           name = this.parser.getText();
/*    */         }
/*    */         
/*    */ 
/* 42 */         if ((parameters != null) || (!"parameters".equals(currentNodeName))) break;
/* 43 */         parameters = new HashMap();
/*    */       }
/* 45 */       this.parser.nextValue();
/* 46 */       parameters.put(this.parser.getCurrentName(), this.parser.getText());
/* 47 */     } while (this.parser.nextValue() == JsonToken.END_OBJECT);
/* 48 */     throw new NotAnActionException();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 54 */     throw new NotAnActionException();
/*    */     
/*    */     label162:
/* 57 */     Action action = new Action(name, resource);
/* 58 */     if (parameters != null) {
/* 59 */       Map<String, Class> argTypes = action.getArgumentTypes();
/*    */       
/* 61 */       for (Map.Entry<String, Object> entry : parameters.entrySet()) {
/* 62 */         Object convertedValue = RestTypeConverter.toJavaType((String)entry.getValue(), (Class)argTypes.get(entry.getKey()));
/*    */         
/* 64 */         entry.setValue(convertedValue);
/*    */       }
/*    */       
/* 67 */       action.setParameters(parameters);
/*    */     }
/*    */     
/* 70 */     return action;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\json\JSONActionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */