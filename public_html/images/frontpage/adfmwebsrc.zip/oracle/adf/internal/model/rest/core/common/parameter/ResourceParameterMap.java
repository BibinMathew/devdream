/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import oracle.jbo.JboException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceParameterMap
/*    */ {
/* 15 */   private Map<ResourceParameter.Type, ResourceParameter> resourceParameters = new HashMap(ResourceParameter.Type.values().length);
/*    */   
/*    */   public ResourceParameterMap(Map<String, String[]> parameters) {
/* 18 */     if (parameters == null) {
/* 19 */       return;
/*    */     }
/*    */     
/* 22 */     Map<String, ResourceParameter.Type> resourceParameterMap = ResourceParameter.Type.getMap();
/* 23 */     for (Map.Entry<String, String[]> entry : parameters.entrySet()) {
/* 24 */       ResourceParameter.Type parameterType = (ResourceParameter.Type)resourceParameterMap.get(entry.getKey());
/* 25 */       if (parameterType != null) {
/*    */         try {
/* 27 */           this.resourceParameters.put(parameterType, parameterType.getParamImpl().getConstructor(new Class[] { String[].class }).newInstance(new Object[] { entry.getValue() }));
/*    */         } catch (Exception e) {
/* 29 */           throw new JboException(e);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public ResourceParameter get(ResourceParameter.Type parameter)
/*    */   {
/* 37 */     return (ResourceParameter)this.resourceParameters.get(parameter);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\ResourceParameterMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */