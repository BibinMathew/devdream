/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ListParam;
/*     */ import oracle.adf.internal.model.rest.core.exception.InvalidAttributeException;
/*     */ import oracle.adf.model.binding.DCIteratorBinding;
/*     */ import oracle.jbo.ApplicationModule;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeList;
/*     */ import oracle.jbo.Key;
/*     */ import oracle.jbo.LocaleContext;
/*     */ import oracle.jbo.RowSet;
/*     */ import oracle.jbo.RowSetIterator;
/*     */ import oracle.jbo.ViewObject;
/*     */ import oracle.jbo.server.RowFinder;
/*     */ import oracle.jbo.server.ServiceRuntimeUtil;
/*     */ import oracle.jbo.server.ViewObjectImpl;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceCollection
/*     */   extends Resource
/*     */ {
/*     */   private static final int INITIAL_RANGESTART = 0;
/*     */   private static final int LIMIT_RANGESIZE_DIFFERENCE = 1;
/*     */   private static final int MINIMUM_LIMIT = 0;
/*     */   private static final int DEFAULT_LIMIT = 25;
/*     */   public static final String NAME = "collection";
/*     */   public static final String ITEMS_ATTR = "items";
/*     */   public static final int UNSET_LIMIT = -1;
/*     */   
/*     */   public static abstract enum PropertyType
/*     */   {
/*  51 */     TOTAL_RESULTS("totalResults"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */     COUNT("count"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */     HAS_MORE("hasMore"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     LIMIT("limit"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     OFFSET("offset");
/*     */     
/*     */ 
/*     */ 
/*     */     private final String name;
/*     */     
/*     */ 
/*     */ 
/*     */     private PropertyType(String name)
/*     */     {
/*  84 */       this.name = name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     abstract ResourceProperty getValue(ResourceCollection paramResourceCollection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   ResourceCollection(ResourceTree tree, JUCtrlHierNodeBinding treeNode)
/*     */   {
/*  96 */     super(tree, treeNode);
/*  97 */     if (Resource.isItem(treeNode)) {
/*  98 */       throw new IllegalArgumentException("The provided node is a item node not a folder node");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ResourceItem> getChildren(int offset)
/*     */   {
/* 110 */     JUCtrlHierNodeBinding node = getNode();
/* 111 */     DCIteratorBinding iter = node.getChildIteratorBinding();
/*     */     
/* 113 */     prepareVOForQuery();
/*     */     
/* 115 */     if (iter.hasRSI()) {
/* 116 */       RowSet rs = iter.getRowSetIterator().getRowSet();
/* 117 */       if (rs.isExecutedEmpty()) {
/* 118 */         rs.executeQuery();
/* 119 */         node.myUpdateValuesFromRows(null, true);
/*     */       }
/*     */     }
/*     */     
/* 123 */     if (offset > 0) {
/* 124 */       setChildIteratorRangeStart(offset);
/*     */     }
/* 126 */     return wrap(node.getChildren());
/*     */   }
/*     */   
/*     */   void prepareVOForQuery() {
/* 130 */     ListParam listParam = getTree().getListParam();
/*     */     
/* 132 */     if (listParam != null) {
/* 133 */       Set<String> attrs = listParam.getAttributesForResource(this, getTree().getStartingResource());
/* 134 */       if ((attrs != null) && (attrs.size() > 0)) {
/* 135 */         Set<String> selectAttrs = new HashSet(attrs.size());
/* 136 */         JUCtrlHierNodeBinding node = getNode();
/* 137 */         DCIteratorBinding iterBinding = node.getChildIteratorBinding();
/* 138 */         ViewObject vo = iterBinding.getViewObject();
/*     */         
/* 140 */         AttributeDef attrDef = null;
/* 141 */         for (String attr : attrs) {
/* 142 */           if (((attrDef = vo.lookupAttributeDef(attr)) != null) && ((attrDef.getAttributeKind() == 0) || (attrDef.getAttributeKind() == 1)))
/*     */           {
/*     */ 
/* 145 */             selectAttrs.add(attr);
/*     */           }
/*     */         }
/*     */         
/* 149 */         if (selectAttrs.size() > 0) {
/* 150 */           String[] selectAttrNames = (String[])selectAttrs.toArray(new String[selectAttrs.size()]);
/* 151 */           ApplicationModule am = vo.getApplicationModule();
/* 152 */           am.resetSelectedAttributeDefs(vo);
/* 153 */           am.prepareViewObjects(new String[] { vo.getName() }, new String[][] { selectAttrNames }, node.getLocaleContext());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<ResourceItem> wrap(List listOfNodes)
/*     */   {
/* 165 */     if ((listOfNodes == null) || (listOfNodes.isEmpty())) {
/* 166 */       return Collections.emptyList();
/*     */     }
/* 168 */     List<ResourceItem> childrenResources = new ArrayList(listOfNodes.size());
/* 169 */     for (Object child : listOfNodes) {
/* 170 */       ResourceItem childResource = new ResourceItem(getTree(), (JUCtrlHierNodeBinding)child);
/* 171 */       childrenResources.add(childResource);
/*     */     }
/* 173 */     return childrenResources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ResourceItem> getChildren()
/*     */   {
/* 181 */     return getChildren(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOffset()
/*     */   {
/* 190 */     int rangeStart = getChildIteratorRangeStart().intValue();
/* 191 */     return rangeStart <= 0 ? 0 : rangeStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void setOffset(int offset)
/*     */   {
/* 200 */     setChildIteratorRangeStart(offset <= 0 ? 0 : offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLimit(int limit)
/*     */   {
/* 208 */     int rangeSize = limit;
/* 209 */     if (limit <= 0) {
/* 210 */       rangeSize = 0;
/*     */     }
/* 212 */     rangeSize++;
/* 213 */     setChildIteratorRangeSize(rangeSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getLimit()
/*     */   {
/* 221 */     int rangeSize = getChildIteratorRangeSize();
/* 222 */     return Integer.valueOf(getLimit(getVO(), rangeSize));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int getLimit(ViewObjectImpl vo, int rangeSize)
/*     */   {
/* 232 */     return rangeSize <= 0 ? getDefaultLimit(vo) : rangeSize - 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDefaultLimit()
/*     */   {
/* 240 */     return getDefaultLimit(getVO());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int getDefaultLimit(ViewObjectImpl vo)
/*     */   {
/* 251 */     int defaultLimit = Long.valueOf(ServiceRuntimeUtil.getRowLimit(vo)).intValue() - 1;
/*     */     
/* 253 */     return defaultLimit >= 0 ? defaultLimit : 25;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Key createChildKey(AttributeList searchAttributes)
/*     */   {
/* 262 */     Finder finder = getFinder();
/* 263 */     if (finder != null) {
/* 264 */       return createRowFinderChildKey(finder.getRowFinder(), new SearchAttributes(searchAttributes));
/*     */     }
/*     */     
/* 267 */     return createVOChildKey(searchAttributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Key createChildKey(AttributeList finderAttributes, Finder finder)
/*     */   {
/* 278 */     return createRowFinderChildKey(finder.getRowFinder(), new SearchAttributes(finderAttributes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Key createChildKey(String keyString)
/*     */   {
/* 289 */     Finder finder = getFinder();
/* 290 */     if (finder != null) {
/* 291 */       RowFinder rowFinder = finder.getRowFinder();
/* 292 */       AttributeList attributeList = createRowFinderAttributeList(rowFinder, keyString);
/* 293 */       return createRowFinderChildKey(rowFinder, new SearchAttributes(attributeList));
/*     */     }
/*     */     
/* 296 */     return createVOChildKey(keyString);
/*     */   }
/*     */   
/*     */   public Attribute getAttribute(String attributeName) {
/*     */     Attribute attribute;
/*     */     Attribute attribute;
/* 302 */     if (isRoot()) {
/* 303 */       attribute = getRootChildAttribute(attributeName);
/*     */     } else {
/* 305 */       attribute = getAccessorChildAttribute(attributeName);
/*     */     }
/* 307 */     if ((attribute == null) && (!"links".equals(attributeName)))
/*     */     {
/* 309 */       throw new InvalidAttributeException(attributeName);
/*     */     }
/* 311 */     return attribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Attribute getRootChildAttribute(String attributeName)
/*     */   {
/* 322 */     JUCtrlHierNodeBinding node = getNode();
/* 323 */     JUCtrlHierTypeBinding typeBinding = node.getHierTypeBinding();
/* 324 */     String[] bindingAttributeNames = typeBinding.getAttrNames();
/*     */     
/* 326 */     if (bindingAttributeNames == null) {
/* 327 */       return findAttribute(attributeName, node.getLocaleContext(), node.getViewObject(), typeBinding);
/*     */     }
/*     */     
/*     */ 
/* 331 */     for (String bindingAttributeName : bindingAttributeNames) {
/* 332 */       if (bindingAttributeName.equals(attributeName)) {
/* 333 */         AttributeDef attrDef = node.getChildIteratorBinding().getAttributeDefs(new String[] { attributeName })[0];
/*     */         
/* 335 */         return createAttribute(getVO(), attrDef, typeBinding, node.getLocaleContext());
/*     */       }
/*     */     }
/*     */     
/* 339 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Attribute getAccessorChildAttribute(String attributeName)
/*     */   {
/* 349 */     JUCtrlHierNodeBinding node = getNode();
/* 350 */     String accessorName = getName();
/*     */     
/* 352 */     JUCtrlHierTypeBinding childTypeBinding = getAccessorHierTypeBinding(accessorName);
/* 353 */     String[] bindingAttributeNames = childTypeBinding.getAttrNames();
/*     */     
/* 355 */     ViewObject vo = getVO();
/* 356 */     if (bindingAttributeNames == null) {
/* 357 */       return findAttribute(attributeName, node.getLocaleContext(), vo, childTypeBinding);
/*     */     }
/*     */     
/* 360 */     for (String bindingAttribute : bindingAttributeNames) {
/* 361 */       if (bindingAttribute.equals(attributeName)) {
/* 362 */         AttributeDef attrDef = vo.findAttributeDef(attributeName);
/* 363 */         return createAttribute(getVO(), attrDef, childTypeBinding, node.getLocaleContext());
/*     */       }
/*     */     }
/* 366 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<ResourceProperty> getProperties()
/*     */   {
/* 372 */     return getProperties(EnumSet.allOf(PropertyType.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ResourceProperty> getProperties(EnumSet<PropertyType> properties)
/*     */   {
/* 382 */     List<ResourceProperty> resourceProperties = new ArrayList(properties.size());
/* 383 */     for (PropertyType property : properties) {
/* 384 */       ResourceProperty resourceProperty = property.getValue(this);
/* 385 */       if (resourceProperty != null) {
/* 386 */         resourceProperties.add(resourceProperty);
/*     */       }
/*     */     }
/* 389 */     return resourceProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Long getTotalResults()
/*     */   {
/* 397 */     return getChildIteratorEstimatedRowCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getCount()
/*     */   {
/* 406 */     int children = getChildren().size();
/* 407 */     Integer limit = getLimit();
/* 408 */     return Integer.valueOf(children > limit.intValue() ? limit.intValue() : children);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResourceCollection asCollection(Resource resource)
/*     */   {
/* 417 */     return (resource instanceof ResourceCollection) ? (ResourceCollection)resource : null;
/*     */   }
/*     */   
/*     */   public List<Attribute> getAttributes()
/*     */   {
/* 422 */     if (isRoot()) {
/* 423 */       return getRootChildAttributes();
/*     */     }
/* 425 */     return getAccessorChildAttributes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Attribute> getRootChildAttributes()
/*     */   {
/* 436 */     JUCtrlHierNodeBinding node = getNode();
/* 437 */     JUCtrlHierTypeBinding typeBinding = node.getHierTypeBinding();
/* 438 */     String[] bindingAttributeNames = typeBinding.getAttrNames();
/*     */     
/* 440 */     AttributeDef[] attributeDefs = node.getChildIteratorBinding().getAttributeDefs(bindingAttributeNames);
/*     */     
/* 442 */     List<Attribute> attributes = new ArrayList(attributeDefs.length);
/* 443 */     for (AttributeDef attrDef : attributeDefs) {
/* 444 */       Attribute attribute = createAttribute(getVO(), attrDef, typeBinding, node.getLocaleContext());
/* 445 */       if (attribute != null) {
/* 446 */         attributes.add(attribute);
/*     */       }
/*     */     }
/* 449 */     return attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Attribute> getAccessorChildAttributes()
/*     */   {
/* 459 */     JUCtrlHierNodeBinding node = getNode();
/* 460 */     String accessor = getName();
/*     */     
/* 462 */     JUCtrlHierTypeBinding childTypeBinding = getAccessorHierTypeBinding(accessor);
/*     */     
/* 464 */     LocaleContext localeContext = node.getLocaleContext();
/*     */     
/* 466 */     return getAccessorChildAttributes(getVO(), childTypeBinding, localeContext);
/*     */   }
/*     */   
/*     */ 
/*     */   static List<Attribute> getAccessorChildAttributes(ViewObject vo, JUCtrlHierTypeBinding childTypeBinding, LocaleContext localeContext)
/*     */   {
/* 472 */     String[] attributeNames = childTypeBinding.getAttrNames();
/*     */     List<Attribute> attributes;
/* 474 */     if (attributeNames != null) {
/* 475 */       List<Attribute> attributes = new ArrayList(attributeNames.length);
/* 476 */       for (String bindingAttribute : attributeNames) {
/* 477 */         AttributeDef attrDef = vo.findAttributeDef(bindingAttribute);
/* 478 */         Attribute attribute = createAttribute(vo, attrDef, childTypeBinding, localeContext);
/* 479 */         if (attribute != null) {
/* 480 */           attributes.add(attribute);
/*     */         }
/*     */       }
/*     */     } else {
/* 484 */       AttributeDef[] attrDefs = vo.getAttributeDefs();
/* 485 */       attributes = new ArrayList(attrDefs.length);
/* 486 */       for (AttributeDef attrDef : attrDefs) {
/* 487 */         Attribute attribute = createAttribute(vo, attrDef, childTypeBinding, localeContext);
/* 488 */         if (attribute != null) {
/* 489 */           attributes.add(attribute);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 494 */     return attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Attribute findAttribute(String attributeName, LocaleContext localeContext, ViewObject vo, JUCtrlHierTypeBinding typeBinding)
/*     */   {
/* 508 */     AttributeDef attrDef = vo.lookupAttributeDef(attributeName);
/*     */     
/* 510 */     return attrDef == null ? null : createAttribute(vo, attrDef, typeBinding, localeContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Attribute createAttribute(ViewObject vo, AttributeDef attrDef, JUCtrlHierTypeBinding typeBinding, LocaleContext localeContext)
/*     */   {
/* 522 */     byte attributeKind = attrDef.getAttributeKind();
/* 523 */     if ((attributeKind == 6) || (attributeKind == 7) || (attributeKind == 2))
/*     */     {
/*     */ 
/* 526 */       return null;
/*     */     }
/* 528 */     Attribute attribute = new Attribute(vo, attrDef, typeBinding, localeContext);
/* 529 */     return attribute.isDisplayable() ? attribute : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceItem createChild(Map<String, Object> parameters)
/*     */   {
/* 538 */     CreateAction createAction = new CreateAction(this);
/* 539 */     createAction.setParameters(parameters);
/*     */     
/* 541 */     ActionResult<ResourceItem> actionResult = createAction.execute();
/* 542 */     if (actionResult == null) {
/* 543 */       return null;
/*     */     }
/*     */     
/* 546 */     return (ResourceItem)actionResult.getResult();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceItem getChild(Key childKey)
/*     */   {
/* 556 */     prepareVOForQuery();
/* 557 */     JUCtrlHierNodeBinding childNode = findChildNode(getNode(), childKey);
/* 558 */     return childNode == null ? null : new ResourceItem(getTree(), childNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static JUCtrlHierNodeBinding findChildNode(JUCtrlHierNodeBinding treeNode, Key childKey)
/*     */   {
/* 567 */     DCIteratorBinding iterBinding = treeNode.getChildIteratorBinding();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 572 */     if (treeNode.isAccessorFolderNode())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 578 */       iterBinding.executeQuery();
/* 579 */       treeNode.myUpdateValuesFromRows(null, true);
/*     */     }
/*     */     
/*     */ 
/* 583 */     return treeNode.findChildNodeByKeyIgnoringRange(childKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean hasMore()
/*     */   {
/* 591 */     return Boolean.valueOf(getChildren().size() > getLimit().intValue());
/*     */   }
/*     */   
/*     */ 
/*     */   public ResourceItem getParent()
/*     */   {
/* 597 */     JUCtrlHierNodeBinding parent = getNode().getParent();
/* 598 */     if (parent == null) {
/* 599 */       return null;
/*     */     }
/* 601 */     return new ResourceItem(getTree(), parent);
/*     */   }
/*     */   
/*     */ 
/*     */   String createKeyString()
/*     */   {
/* 607 */     return null;
/*     */   }
/*     */   
/*     */   public List<Link> getLinks(String basePath)
/*     */   {
/* 612 */     return Arrays.asList(new Link[] { getSelfLink(basePath) });
/*     */   }
/*     */   
/*     */   public Link getSelfLink(String basePath)
/*     */   {
/* 617 */     return new Link(getName(), "self", getPath(basePath), Link.Kind.COLLECTION);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPolymorphic()
/*     */   {
/* 627 */     return Resource.isPolymorphic(getHierTypeBinding(), null, null, null);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */