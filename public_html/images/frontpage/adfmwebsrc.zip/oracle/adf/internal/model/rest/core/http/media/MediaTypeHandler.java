/*     */ package oracle.adf.internal.model.rest.core.http.media;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaTypeHandler
/*     */ {
/*     */   private static final String DEFAULT_MEDIA_TYPE = "application";
/*     */   private static final String SUB_TYPE_SEPARATOR = "+";
/*     */   private static final String MEDIA_TYPE_WILDCARD = "*";
/*     */   private static final String SUB_TYPE_PREFIX = "vnd.oracle.adf.";
/*     */   
/*     */   public static ContentTypeHandler createContentTypeHandler(String mt, ResourceEntityType defaultEntityType)
/*     */   {
/*  24 */     MediaType mediaType = MediaType.parseMediaType(mt);
/*  25 */     return createContentTypeHandler(mediaType, defaultEntityType);
/*     */   }
/*     */   
/*     */   public static ContentTypeHandler createContentTypeHandler(String mt) {
/*  29 */     MediaType mediaType = MediaType.parseMediaType(mt);
/*  30 */     return createContentTypeHandler(mediaType);
/*     */   }
/*     */   
/*     */   public static boolean acceptAllMedias(MediaType mediaType) {
/*  34 */     String type = mediaType.getType();
/*  35 */     String subType = mediaType.getSubType();
/*  36 */     return (type.equals("*")) && (subType.equals("*"));
/*     */   }
/*     */   
/*     */   public static boolean acceptDefaultMedias(MediaType mediaType) {
/*  40 */     String type = mediaType.getType();
/*  41 */     String subType = mediaType.getSubType();
/*  42 */     return (acceptAllMedias(mediaType)) || ((type.equals("application")) && (subType.equals("*")));
/*     */   }
/*     */   
/*     */   public static ContentTypeHandler createContentTypeHandler(MediaType mediaType, ResourceEntityType defaultEntityType) {
/*  46 */     String type = mediaType.getType();
/*  47 */     String subType = mediaType.getSubType();
/*     */     
/*  49 */     if ((!type.equals("application")) && (!type.equals("*"))) {
/*  50 */       return new ContentTypeHandler(mediaType);
/*     */     }
/*     */     
/*  53 */     PayloadType payloadType = null;
/*  54 */     if (subType.equals("*"))
/*     */     {
/*  56 */       payloadType = PayloadType.JSON;
/*  57 */       subType = createSubType(defaultEntityType, payloadType);
/*     */     } else {
/*     */       try {
/*  60 */         payloadType = getPayloadType(subType);
/*     */       } catch (IllegalArgumentException ex) {
/*  62 */         return new ContentTypeHandler(mediaType);
/*     */       }
/*     */     }
/*     */     
/*  66 */     MediaType defaultMediaType = new MediaType("application", subType);
/*  67 */     return new ContentTypeHandler(defaultEntityType, payloadType, defaultMediaType);
/*     */   }
/*     */   
/*     */   public static ContentTypeHandler createContentTypeHandler(MediaType mediaType)
/*     */   {
/*  72 */     String type = mediaType.getType();
/*  73 */     String subType = mediaType.getSubType();
/*     */     
/*  75 */     if (!type.equals("application")) {
/*  76 */       return new ContentTypeHandler(mediaType);
/*     */     }
/*     */     
/*  79 */     String entity = null;
/*  80 */     String payload = null;
/*     */     
/*  82 */     String[] splitSubType = splitSubtype(subType);
/*  83 */     if (splitSubType.length == 2) {
/*  84 */       entity = splitSubType[0];
/*  85 */       payload = splitSubType[1];
/*  86 */     } else if (splitSubType.length == 1) {
/*  87 */       payload = splitSubType[0];
/*     */     } else {
/*  89 */       return new ContentTypeHandler(mediaType);
/*     */     }
/*     */     
/*  92 */     PayloadType payloadType = null;
/*  93 */     ResourceEntityType entityType = null;
/*     */     try {
/*  95 */       payloadType = (PayloadType)Enum.valueOf(PayloadType.class, payload.toUpperCase());
/*     */       
/*  97 */       if (payloadType == PayloadType.XML)
/*     */       {
/*  99 */         return new ContentTypeHandler(mediaType);
/*     */       }
/*     */       
/* 102 */       if (entity != null) {
/* 103 */         entityType = (ResourceEntityType)Enum.valueOf(ResourceEntityType.class, entity.toUpperCase());
/*     */       }
/*     */     } catch (IllegalArgumentException ex) {
/* 106 */       return new ContentTypeHandler(mediaType);
/*     */     }
/*     */     
/*     */ 
/* 110 */     return new ContentTypeHandler(entityType, payloadType, mediaType);
/*     */   }
/*     */   
/*     */   private static PayloadType getPayloadType(String subType) {
/* 114 */     String payloadType = null;
/* 115 */     String[] splitSubType = splitSubtype(subType);
/* 116 */     if (splitSubType.length == 2) {
/* 117 */       payloadType = splitSubType[1];
/* 118 */     } else if (splitSubType.length == 1) {
/* 119 */       payloadType = splitSubType[0];
/*     */     } else {
/* 121 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 124 */     return PayloadType.valueOf(payloadType.toUpperCase());
/*     */   }
/*     */   
/*     */   private static String[] splitSubtype(String subType)
/*     */   {
/* 129 */     String separator = "\\+";
/* 130 */     String[] splitSubType = subType.split(separator);
/* 131 */     if (splitSubType.length > 1) {
/* 132 */       if (splitSubType[0].startsWith("vnd.oracle.adf.")) {
/* 133 */         splitSubType[0] = splitSubType[0].substring("vnd.oracle.adf.".length());
/*     */       } else {
/* 135 */         return new String[0];
/*     */       }
/*     */     }
/* 138 */     return splitSubType;
/*     */   }
/*     */   
/*     */   public static Set<MediaType> generateSupportedMediaTypeList(boolean includeDefaultMediaType, ResourceEntityType... entityTypes) {
/* 142 */     HashSet<MediaType> mediaTypes = new HashSet();
/*     */     
/* 144 */     for (ResourceEntityType entityType : entityTypes) {
/* 145 */       for (PayloadType payloadType : PayloadType.values())
/*     */       {
/* 147 */         if (payloadType != PayloadType.XML)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 152 */           mediaTypes.add(createMediaType(entityType, payloadType));
/* 153 */           if (includeDefaultMediaType) {
/* 154 */             mediaTypes.add(new MediaType("application", payloadType.toString()));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 159 */     return mediaTypes;
/*     */   }
/*     */   
/*     */   public static MediaType createMediaType(ResourceEntityType entityType, PayloadType payloadType) {
/* 163 */     return new MediaType("application", createSubType(entityType, payloadType));
/*     */   }
/*     */   
/*     */   public static List<String> generateSupportedMediaTypeStringList(boolean includeDefaultMediaType, ResourceEntityType entityType) {
/* 167 */     Set<MediaType> mediaTypes = generateSupportedMediaTypeList(includeDefaultMediaType, new ResourceEntityType[] { entityType });
/* 168 */     if ((mediaTypes == null) || (mediaTypes.isEmpty())) {
/* 169 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 172 */     List<String> supportedMediaTypes = new ArrayList(mediaTypes.size());
/*     */     
/* 174 */     for (MediaType mediaType : mediaTypes) {
/* 175 */       supportedMediaTypes.add(mediaType.toString());
/*     */     }
/*     */     
/* 178 */     return supportedMediaTypes;
/*     */   }
/*     */   
/*     */   private static String createSubType(ResourceEntityType entityType, PayloadType payloadType) {
/* 182 */     return "vnd.oracle.adf." + entityType.toString() + "+" + payloadType.toString();
/*     */   }
/*     */   
/*     */   public static ResourceEntityType getRESTEntityType(MediaType mediaType) {
/* 186 */     String subtype = mediaType.getSubType();
/*     */     
/* 188 */     if (subtype.length() < "vnd.oracle.adf.".length() + "+".length() + 2)
/*     */     {
/* 190 */       return null;
/*     */     }
/* 192 */     int endSeparator = subtype.lastIndexOf("+");
/*     */     
/* 194 */     if (endSeparator == -1)
/*     */     {
/* 196 */       return null;
/*     */     }
/*     */     
/* 199 */     String entity = subtype.substring("vnd.oracle.adf.".length(), endSeparator);
/* 200 */     return ResourceEntityType.valueOf(entity.toUpperCase());
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\media\MediaTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */