/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceHelper;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ 
/*    */ class ResourceRepresentation extends AbstractResourceOperation
/*    */ {
/*    */   private final ResourceType resourceType;
/*    */   
/*    */   ResourceRepresentation(ResourceType resourceType)
/*    */   {
/* 17 */     this.resourceType = resourceType;
/*    */   }
/*    */   
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 22 */     if (!this.responseHandler.isEntityGenerationAllowed()) {
/* 23 */       throw new oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException("The entity generation is not enabled in the ResponseHandler.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void applyInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public void execute(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public void generateResponse(ResourceProcessingContext context)
/*    */     throws IOException
/*    */   {
/* 37 */     ResourceHelper.generateResourceRepresentation(context, this.responseHandler.getPayloadGenerator());
/*    */   }
/*    */   
/*    */ 
/*    */   public void validateInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 46 */     return false;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 51 */     return OperationType.REPRESENTATION;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 56 */     if (this.resourceType == ResourceType.RESOURCE_ITEM) {
/* 57 */       return ActionType.GET_ITEM;
/*    */     }
/*    */     
/* 60 */     return ActionType.GET_COLLECTION;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ResourceRepresentation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */