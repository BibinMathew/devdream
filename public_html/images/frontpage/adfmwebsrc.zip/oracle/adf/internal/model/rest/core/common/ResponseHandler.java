/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract interface ResponseHandler {
/*    */   public abstract void setup();
/*    */   
/*    */   public abstract java.io.OutputStream getOutputStream();
/*    */   
/* 10 */   public static enum ErrorType { PRECONDITION_FAILED;
/*    */     
/*    */     private ErrorType() {}
/*    */   }
/*    */   
/*    */   public abstract oracle.adf.internal.model.rest.core.payload.PayloadGenerator getPayloadGenerator();
/*    */   
/*    */   public abstract void setContentType(ResourceEntityType paramResourceEntityType);
/*    */   
/*    */   public abstract void setContentType(String paramString);
/*    */   
/*    */   public abstract String getStateIdentifier();
/*    */   
/*    */   public abstract void setStateIdentifier(String paramString);
/*    */   
/*    */   public abstract void setResourcePath(String paramString);
/*    */   
/*    */   public abstract void setProperties(Map<String, String> paramMap);
/*    */   
/*    */   public abstract boolean isContentGenerationAllowed();
/*    */   
/*    */   public abstract boolean isEntityGenerationAllowed();
/*    */   
/*    */   public abstract void resetContentType();
/*    */   
/*    */   public abstract void finish();
/*    */   
/*    */   public abstract void setCreatingResource(boolean paramBoolean);
/*    */   
/*    */   public abstract void setError(ErrorType paramErrorType);
/*    */   
/*    */   public abstract ErrorType getError();
/*    */   
/*    */   public abstract void setLink(String paramString);
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\ResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */