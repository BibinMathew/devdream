/*    */ package oracle.adf.internal.model.rest.core.topology;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ 
/*    */ public class BasicTreePath implements TreePath
/*    */ {
/* 10 */   private final List<BasicResourceTreePath> resourcePaths = new ArrayList();
/* 11 */   private boolean collectionTreePath = false;
/*    */   private final List topLevelResourceKeyPath;
/*    */   private final ResourceTree tree;
/*    */   
/*    */   public BasicTreePath(ResourceTree tree, Resource topLevelResource)
/*    */   {
/* 17 */     this.topLevelResourceKeyPath = topLevelResource.getKeyPath();
/* 18 */     this.tree = tree;
/*    */   }
/*    */   
/*    */   public Resource getTopLevelResource() {
/* 22 */     return this.tree.findResourceByKeyPath(this.topLevelResourceKeyPath);
/*    */   }
/*    */   
/*    */   public void addResourcePath(BasicResourceTreePath resourceTraversingInfo) {
/* 26 */     resourceTraversingInfo.setTreePath(this);
/* 27 */     this.resourcePaths.add(resourceTraversingInfo);
/*    */   }
/*    */   
/*    */   public List<BasicResourceTreePath> getResourcePaths() {
/* 31 */     return new ArrayList(this.resourcePaths);
/*    */   }
/*    */   
/*    */   public boolean isExpandableResourcePath(ResourceTreePath resourcePath, String childResourceName) {
/* 35 */     return !resourcePath.getChildren(childResourceName).isEmpty();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isCollectionTreePath()
/*    */   {
/* 41 */     return this.collectionTreePath;
/*    */   }
/*    */   
/*    */   public void setCollectionTreePath(boolean collectionTreePath) {
/* 45 */     this.collectionTreePath = collectionTreePath;
/*    */   }
/*    */   
/*    */   ResourceTree getResourceTree() {
/* 49 */     return this.tree;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\topology\BasicTreePath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */