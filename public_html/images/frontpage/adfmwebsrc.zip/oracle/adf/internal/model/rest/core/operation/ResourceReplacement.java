/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*    */ import oracle.adf.internal.model.rest.core.exception.InvalidResourceTypeException;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceHelper;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ 
/*    */ 
/*    */ public class ResourceReplacement
/*    */   extends AbstractResourceOperation
/*    */ {
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 20 */     if (context.getResourceTree().getCurrentResource().isCollection()) {
/* 21 */       throw new InvalidResourceTypeException();
/*    */     }
/* 23 */     if (context.getParserFactory() == null) {
/* 24 */       throw new CannotParseContentException("The PayloadParser could not be found in the ResourceProcessingContext.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void applyInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */   public void execute(ResourceProcessingContext context)
/*    */     throws IOException
/*    */   {
/* 34 */     ResourceHelper.replaceResource(context);
/*    */   }
/*    */   
/*    */   public void generateResponse(ResourceProcessingContext context) throws IOException
/*    */   {
/* 39 */     if (this.responseHandler.isEntityGenerationAllowed()) {
/* 40 */       ResourceHelper.generateResourceRepresentation(context, this.responseHandler.getPayloadGenerator());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void validateInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 50 */     return true;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 55 */     return OperationType.REPLACEMENT;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 60 */     return ActionType.REPLACE;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ResourceReplacement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */