/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ public class ContentEncoding implements Header
/*    */ {
/*    */   public static final String NAME = "Content-Encoding";
/*    */   private final ContentCoding contentCoding;
/*    */   
/*    */   public ContentEncoding(ContentCoding contentCoding) {
/*  9 */     this.contentCoding = contentCoding;
/*    */   }
/*    */   
/*    */   public ContentEncoding(String contentCoding) {
/* 13 */     this(new ContentCoding(contentCoding));
/*    */   }
/*    */   
/*    */   public ContentCoding getContentCoding() {
/* 17 */     return this.contentCoding;
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 22 */     if (this == object) {
/* 23 */       return true;
/*    */     }
/* 25 */     if (!(object instanceof ContentEncoding)) {
/* 26 */       return false;
/*    */     }
/* 28 */     ContentEncoding other = (ContentEncoding)object;
/* 29 */     if (this.contentCoding == null ? other.contentCoding != null : !this.contentCoding.equals(other.contentCoding)) {
/* 30 */       return false;
/*    */     }
/* 32 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 37 */     int PRIME = 37;
/* 38 */     int result = 1;
/* 39 */     result = 37 * result + (this.contentCoding == null ? 0 : this.contentCoding.hashCode());
/* 40 */     return result;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 45 */     return "Content-Encoding";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\ContentEncoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */