/*    */ package oracle.adf.internal.model.rest.core.binding.inputhandler;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*    */ import oracle.adf.model.rest.core.serializer.ResourceStreamSerializer;
/*    */ import oracle.adf.model.rest.core.serializer.ResourceValueSerializer;
/*    */ import oracle.jbo.AttributeDef;
/*    */ import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SerializerFactory
/*    */ {
/*    */   public static ResourceValueSerializer getValueSerializer(PayloadType payloadType, AttributeDef attrDef, JUCtrlInputValueHandler inputHandler)
/*    */   {
/* 20 */     ResourceValueSerializer serializer = null;
/* 21 */     if ((inputHandler instanceof ResourceInputHandler)) {
/* 22 */       switch (payloadType) {
/*    */       case JSON: 
/* 24 */         serializer = ((ResourceInputHandler)inputHandler).getJSONSerializer(attrDef);
/*    */       }
/*    */       
/*    */     }
/*    */     
/*    */ 
/* 30 */     return serializer;
/*    */   }
/*    */   
/*    */   public static ResourceStreamSerializer getStreamSerializer(JUCtrlInputValueHandler inputHandler, AttributeDef attrDef)
/*    */   {
/* 35 */     ResourceStreamSerializer serializer = null;
/* 36 */     if ((inputHandler instanceof ResourceInputHandler)) {
/* 37 */       serializer = ((ResourceInputHandler)inputHandler).getStreamSerializer(attrDef);
/*    */     }
/* 39 */     return serializer;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\binding\inputhandler\SerializerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */