/*    */ package oracle.adf.internal.model.rest.core.topology;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceCollection;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceItem;
/*    */ import oracle.jbo.Key;
/*    */ 
/*    */ public final class DefaultResourcePath implements ResourceTreePath
/*    */ {
/*    */   private ResourceItem resource;
/*    */   private DefaultResourcePath parent;
/*    */   private List<Key> resourceKeyPath;
/* 15 */   private String accessorPath = "";
/*    */   
/*    */   public DefaultResourcePath(ResourceItem resource) {
/* 18 */     this.resource = resource;
/* 19 */     this.resourceKeyPath = resource.getKeyPath();
/*    */   }
/*    */   
/*    */   public Collection<String> getChildrenNames()
/*    */   {
/* 24 */     return getResource().getNestedResourceNames();
/*    */   }
/*    */   
/*    */   public Collection<String> getAllChildrenNames() {
/* 28 */     return getResource().getNestedResourceNames();
/*    */   }
/*    */   
/*    */   public Collection<DefaultResourcePath> getChildren(String childResourceName)
/*    */   {
/* 33 */     List<ResourceItem> children = getResource().getChild(childResourceName).getChildren();
/* 34 */     return wrap(children, this);
/*    */   }
/*    */   
/*    */   static List<DefaultResourcePath> wrap(List<ResourceItem> children)
/*    */   {
/* 39 */     return wrap(children, null);
/*    */   }
/*    */   
/*    */   static List<DefaultResourcePath> wrap(List<ResourceItem> children, DefaultResourcePath parentPath) {
/* 43 */     List<DefaultResourcePath> resourcePaths = new ArrayList(children.size());
/* 44 */     for (ResourceItem child : children) {
/* 45 */       DefaultResourcePath defaultResourcePath = new DefaultResourcePath(child);
/* 46 */       if (parentPath != null) {
/* 47 */         defaultResourcePath.parent = parentPath;
/* 48 */         defaultResourcePath.accessorPath = TreePathUtil.createAccessorPath(parentPath.accessorPath, child.getName());
/*    */       }
/* 50 */       resourcePaths.add(defaultResourcePath);
/*    */     }
/* 52 */     return resourcePaths;
/*    */   }
/*    */   
/*    */   public void setResource(ResourceItem resource)
/*    */   {
/* 57 */     this.resource = resource;
/*    */   }
/*    */   
/*    */   public ResourceItem getResource()
/*    */   {
/* 62 */     return this.resource;
/*    */   }
/*    */   
/*    */   public ResourceTreePath getParent()
/*    */   {
/* 67 */     return this.parent;
/*    */   }
/*    */   
/*    */   public List<Key> getResourceKeyPath()
/*    */   {
/* 72 */     return this.resourceKeyPath;
/*    */   }
/*    */   
/*    */ 
/*    */   public Integer getLimit(String childResourceName)
/*    */   {
/* 78 */     return getResource().getParent().getLimit();
/*    */   }
/*    */   
/*    */   public String getAccessorPath()
/*    */   {
/* 83 */     return this.accessorPath;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\topology\DefaultResourcePath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */