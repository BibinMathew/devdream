/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceHelper;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ 
/*    */ class ResourceUpdate extends AbstractResourceOperation
/*    */ {
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 17 */     if (context.getParserFactory() == null) {
/* 18 */       throw new CannotParseContentException("The PayloadParser could not be found in the ResourceProcessingContext.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void applyInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */   public void execute(ResourceProcessingContext context)
/*    */     throws IOException
/*    */   {
/* 28 */     if (context.getResourceTree().getCurrentResource().isCollection()) {
/* 29 */       ResourceHelper.mergeResource(context);
/*    */     } else {
/* 31 */       ResourceHelper.updateResource(context);
/*    */     }
/*    */   }
/*    */   
/*    */   public void generateResponse(ResourceProcessingContext context) throws IOException
/*    */   {
/* 37 */     if (this.responseHandler.isEntityGenerationAllowed()) {
/* 38 */       ResourceHelper.generateResourceRepresentation(context, this.responseHandler.getPayloadGenerator());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void validateInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 48 */     return true;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 53 */     return OperationType.UPDATE;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 58 */     return ActionType.UPDATE;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ResourceUpdate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */