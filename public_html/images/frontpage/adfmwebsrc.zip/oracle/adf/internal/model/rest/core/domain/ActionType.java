/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ActionType
/*    */ {
/* 14 */   GET_ITEM("get", null, null, ResourceEntityType.RESOURCEITEM), 
/* 15 */   GET_COLLECTION("get", null, null, ResourceEntityType.RESOURCECOLLECTION), 
/* 16 */   CREATE("create", "create", ResourceEntityType.RESOURCEITEM, ResourceEntityType.RESOURCEITEM), 
/* 17 */   UPDATE("update", "update", ResourceEntityType.RESOURCEITEM, ResourceEntityType.RESOURCEITEM), 
/* 18 */   REPLACE("replace", "update", ResourceEntityType.RESOURCEITEM, ResourceEntityType.RESOURCEITEM), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 24 */   DESCRIBE("describe", null, null, ResourceEntityType.DESCRIPTION), 
/* 25 */   DELETE("delete", "delete", null, null), 
/* 26 */   INVOKE("invoke", null, ResourceEntityType.ACTION, ResourceEntityType.ACTIONRESULT);
/*    */   
/*    */   private String actionName;
/*    */   private String actionBindingName;
/*    */   private ResourceEntityType requestEntityType;
/*    */   private ResourceEntityType responseEntityType;
/* 32 */   static final Set<String> DEFAULT_ACTION_BINDING_NAMES = Collections.unmodifiableSet(new HashSet(Arrays.asList(new String[] { CREATE.actionName, UPDATE.actionName, DELETE.actionName })));
/*    */   
/*    */   private ActionType(String actionName, String actionBindingName, ResourceEntityType requestEntityType, ResourceEntityType responseEntityType)
/*    */   {
/* 36 */     this.actionName = actionName;
/* 37 */     this.actionBindingName = actionBindingName;
/* 38 */     this.requestEntityType = requestEntityType;
/* 39 */     this.responseEntityType = responseEntityType;
/*    */   }
/*    */   
/*    */   String getActionName() {
/* 43 */     return this.actionName;
/*    */   }
/*    */   
/*    */   public String getSecurityName() {
/* 47 */     return getActionName();
/*    */   }
/*    */   
/*    */   String getActionBindingName() {
/* 51 */     return this.actionBindingName;
/*    */   }
/*    */   
/*    */   ResourceEntityType getRequestEntityType() {
/* 55 */     return this.requestEntityType;
/*    */   }
/*    */   
/*    */   public ResourceEntityType getResponseEntityType() {
/* 59 */     return this.responseEntityType;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ActionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */