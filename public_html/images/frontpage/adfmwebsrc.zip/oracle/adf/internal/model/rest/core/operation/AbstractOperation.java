/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.Operation;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.Action;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Link;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ import oracle.jbo.JboException;
/*    */ 
/*    */ abstract class AbstractOperation
/*    */   implements Operation
/*    */ {
/* 16 */   protected boolean dependentOnResource = true;
/*    */   protected ResponseHandler responseHandler;
/*    */   
/*    */   public abstract ActionType getActionType();
/*    */   
/*    */   public void setResponseHandler(ResponseHandler responseHandler)
/*    */   {
/* 23 */     this.responseHandler = responseHandler;
/*    */   }
/*    */   
/*    */   public boolean isCreatingResource()
/*    */   {
/* 28 */     return false;
/*    */   }
/*    */   
/*    */   public ResponseHandler getResponseHandler()
/*    */   {
/* 33 */     return this.responseHandler;
/*    */   }
/*    */   
/*    */   public boolean isDependentOnResource()
/*    */   {
/* 38 */     return this.dependentOnResource;
/*    */   }
/*    */   
/*    */   public void prepareResponse(ResourceProcessingContext context)
/*    */   {
/* 43 */     Link currentResourceLink = context.getCurrentResourceLink(getOperationType());
/* 44 */     if (currentResourceLink != null) {
/* 45 */       this.responseHandler.setLink(currentResourceLink.toString());
/*    */     }
/*    */     
/* 48 */     this.responseHandler.setCreatingResource(isCreatingResource());
/* 49 */     this.responseHandler.setup();
/*    */   }
/*    */   
/*    */   public ResourceEntityType getResponseEntityType()
/*    */   {
/* 54 */     return getActionType().getResponseEntityType();
/*    */   }
/*    */   
/*    */   public boolean isAuthorized(ResourceProcessingContext context)
/*    */   {
/* 59 */     if (context.isResourceTreeAvailable()) {
/* 60 */       return Action.isAuthorized(context.getResourceTree().getName(), getActionType());
/*    */     }
/* 62 */     throw new JboException("Cannot obtain permissions without a resource tree");
/*    */   }
/*    */   
/*    */   public String getSecurityName()
/*    */   {
/* 67 */     return getActionType().getSecurityName();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\AbstractOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */