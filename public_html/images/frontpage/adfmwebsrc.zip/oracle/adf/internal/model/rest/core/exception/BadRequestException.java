/*    */ package oracle.adf.internal.model.rest.core.exception;
/*    */ 
/*    */ import oracle.jbo.CSMessageBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BadRequestException
/*    */   extends ResourceException
/*    */ {
/*    */   public BadRequestException(Class<CSMessageBundle> csMessageBundle, String errorCode, Object[] params)
/*    */   {
/* 14 */     super(csMessageBundle, errorCode, params);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\exception\BadRequestException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */