/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ 
/*    */ public class Link
/*    */   implements Header
/*    */ {
/*    */   public static final String NAME = "Link";
/*    */   
/*    */ 
/*    */   public String getName()
/*    */   {
/* 12 */     return "Link";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\Link.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */