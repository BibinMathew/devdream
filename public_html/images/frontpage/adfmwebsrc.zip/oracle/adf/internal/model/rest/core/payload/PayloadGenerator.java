package oracle.adf.internal.model.rest.core.payload;

import java.io.IOException;
import java.util.List;
import oracle.adf.internal.model.rest.core.domain.ActionDescription;
import oracle.adf.internal.model.rest.core.domain.ActionResult;
import oracle.adf.internal.model.rest.core.domain.Attribute;
import oracle.adf.internal.model.rest.core.domain.BatchPart;
import oracle.adf.internal.model.rest.core.domain.Cardinality;
import oracle.adf.internal.model.rest.core.domain.FinderDescription;
import oracle.adf.internal.model.rest.core.domain.Link;
import oracle.adf.internal.model.rest.core.domain.Path;
import oracle.adf.internal.model.rest.core.domain.ResourceDescription;
import oracle.adf.internal.model.rest.core.domain.ResourceDescription.CollectionSection;
import oracle.adf.internal.model.rest.core.domain.ResourceDescription.ResourceAnnotationsSection;
import oracle.adf.internal.model.rest.core.domain.ResourceProperty;
import oracle.adf.internal.model.rest.core.domain.Version;

public abstract interface PayloadGenerator
{
  public abstract PayloadType getPayloadType();
  
  public abstract Object getTarget();
  
  public abstract void startAttributeDescriptionItem()
    throws IOException;
  
  public abstract void endAttributeDescriptionItem()
    throws IOException;
  
  public abstract void addAttributeDescriptionItem(Attribute paramAttribute)
    throws IOException;
  
  public abstract void setPayloadType(PayloadType paramPayloadType);
  
  public abstract void startResource()
    throws IOException;
  
  public abstract void endResource()
    throws IOException;
  
  public abstract void startLinks()
    throws IOException;
  
  public abstract void endLinks()
    throws IOException;
  
  public abstract void addLink(Link paramLink)
    throws IOException;
  
  public abstract void addLink(List<Link> paramList)
    throws IOException;
  
  public abstract void addAttributeLink(List<Attribute> paramList, Path paramPath)
    throws IOException;
  
  public abstract void createLinks(List<Link> paramList)
    throws IOException;
  
  public abstract void startPayload()
    throws IOException;
  
  public abstract void endPayload()
    throws IOException;
  
  public abstract void createActionResult(ActionResult paramActionResult)
    throws IOException;
  
  public abstract void createAttribute(Attribute paramAttribute)
    throws IOException;
  
  public abstract void setup();
  
  public abstract void startResourceCollectionDescriptionSection()
    throws IOException;
  
  public abstract void startActionDescription()
    throws IOException;
  
  public abstract void endActionDescription()
    throws IOException;
  
  public abstract void endResourceCollectionDescriptionSection()
    throws IOException;
  
  public abstract void startResourceDescriptionSection()
    throws IOException;
  
  public abstract void endResourceDescriptionSection()
    throws IOException;
  
  public abstract void createResourceAnnotationsSection(ResourceDescription.ResourceAnnotationsSection paramResourceAnnotationsSection)
    throws IOException;
  
  public abstract void startChildrenDescriptionSection()
    throws IOException;
  
  public abstract void endChildrenDescriptionSection()
    throws IOException;
  
  public abstract void startResourceDescription(ResourceDescription paramResourceDescription)
    throws IOException;
  
  public abstract void endResourceDescription(ResourceDescription paramResourceDescription)
    throws IOException;
  
  public abstract void startDescription()
    throws IOException;
  
  public abstract void endDescription()
    throws IOException;
  
  public abstract void startActionDescriptionItem()
    throws IOException;
  
  public abstract void endActionDescriptionItem()
    throws IOException;
  
  public abstract void createActionDescription(ActionDescription paramActionDescription)
    throws IOException;
  
  public abstract void createCardinality(Cardinality paramCardinality)
    throws IOException;
  
  public abstract void startAttributeDescription()
    throws IOException;
  
  public abstract void endAttributeDescription()
    throws IOException;
  
  public abstract void createPart(BatchPart paramBatchPart)
    throws IOException;
  
  public abstract void createEmptyResource()
    throws IOException;
  
  public abstract void finalizePart()
    throws IOException;
  
  public abstract void close()
    throws IOException;
  
  public abstract void createFinders(List<FinderDescription> paramList)
    throws IOException;
  
  public abstract void addPartPreconditionSucceeded(boolean paramBoolean)
    throws IOException;
  
  public abstract void startPartPayload()
    throws IOException;
  
  public abstract void startBatch()
    throws IOException;
  
  public abstract void endBatch()
    throws IOException;
  
  public abstract void startVersions()
    throws IOException;
  
  public abstract void endVersions(List<Link> paramList)
    throws IOException;
  
  public abstract void startVersion(Version paramVersion)
    throws IOException;
  
  public abstract void endVersion()
    throws IOException;
  
  public abstract void createCollectionSectionAttributes(ResourceDescription.CollectionSection paramCollectionSection)
    throws IOException;
  
  public abstract void createResourceProperty(ResourceProperty paramResourceProperty)
    throws IOException;
  
  public abstract void createResourceProperties(List<ResourceProperty> paramList)
    throws IOException;
  
  public abstract void startResourceCollectionItems()
    throws IOException;
  
  public abstract void endResourceCollectionItems()
    throws IOException;
  
  public abstract void startNestedResource(String paramString)
    throws IOException;
  
  public abstract void endNestedResource()
    throws IOException;
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\PayloadGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */