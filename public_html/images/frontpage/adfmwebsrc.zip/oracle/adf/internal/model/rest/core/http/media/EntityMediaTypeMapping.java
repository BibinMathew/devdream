/*    */ package oracle.adf.internal.model.rest.core.http.media;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*    */ 
/*    */ public class EntityMediaTypeMapping
/*    */ {
/*    */   private final Map<ResourceEntityType, EntityMediaTypeMappingValue> map;
/*    */   
/*    */   public EntityMediaTypeMapping(Map<ResourceEntityType, EntityMediaTypeMappingValue> map)
/*    */   {
/* 14 */     this.map = map;
/*    */   }
/*    */   
/*    */   public Set<MediaType> getMediaTypes(ResourceEntityType entityType) {
/* 18 */     return ((EntityMediaTypeMappingValue)this.map.get(entityType)).getMediaTypes();
/*    */   }
/*    */   
/*    */   public Set<MediaType> getAllSupportedMediaTypes(ResourceEntityType entityType) {
/* 22 */     return ((EntityMediaTypeMappingValue)this.map.get(entityType)).getAllSupportedMediaTypes();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\media\EntityMediaTypeMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */