/*    */ package oracle.adf.internal.model.rest.core.http.exception;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.exception.BadRequestException;
/*    */ import oracle.jbo.CSMessageBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperationNotSupportedException
/*    */   extends BadRequestException
/*    */ {
/*    */   public OperationNotSupportedException()
/*    */   {
/* 16 */     super(CSMessageBundle.class, "27505", null);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\exception\OperationNotSupportedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */