/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.net.URL;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.NamingException;
/*    */ import oracle.adf.model.binding.DCBindingContainer;
/*    */ import oracle.adf.model.connection.url.URLConnectionProxy;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*    */ import oracle.jbo.JboException;
/*    */ 
/*    */ class ExternalResourceRef implements ResourceReference
/*    */ {
/*    */   private Path resourceReferencePath;
/*    */   
/*    */   public ExternalResourceRef(DCBindingContainer bindingContainer, String connectionId, String value)
/*    */   {
/* 18 */     ContextualLogger logger = oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager.getCurrentLogger();
/* 19 */     URLConnectionProxy urlConnectionProxy = null;
/*    */     try {
/* 21 */       urlConnectionProxy = (URLConnectionProxy)ADFContext.getCurrent().getConnectionsContext().lookup(connectionId);
/*    */     } catch (NamingException e) {
/* 23 */       logger.severe("Unable to find the connection. connectionId: " + connectionId);
/* 24 */       throw new JboException(e);
/*    */     }
/* 26 */     String externalURLBasePath = urlConnectionProxy.getURL().toString();
/* 27 */     this.resourceReferencePath = createResourceReferencePath(bindingContainer, externalURLBasePath, value);
/*    */   }
/*    */   
/*    */   public ResourceReference.Type getType()
/*    */   {
/* 32 */     return ResourceReference.Type.EXTERNAL;
/*    */   }
/*    */   
/*    */   private Path createResourceReferencePath(DCBindingContainer bindingContainer, String externalURLBasePath, String value) {
/* 36 */     Path resourcePath = null;
/*    */     
/* 38 */     if (bindingContainer != null) {
/* 39 */       Object el = bindingContainer.evaluateParameter(value, true);
/* 40 */       if (el != null) {
/* 41 */         resourcePath = new Path(externalURLBasePath, el.toString());
/*    */       }
/*    */     }
/*    */     
/* 45 */     if (resourcePath == null) {
/* 46 */       resourcePath = new Path(externalURLBasePath, "{expression}");
/*    */     }
/* 48 */     return resourcePath;
/*    */   }
/*    */   
/*    */   public Path getResourceReferencePath()
/*    */   {
/* 53 */     return this.resourceReferencePath;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ExternalResourceRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */