/*    */ package oracle.adf.internal.model.rest.core.payload;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import oracle.jbo.JboException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PayloadFactory
/*    */ {
/*    */   public static <T extends Writer> PayloadGenerator createPayloadGenerator(PayloadType type, T writer)
/*    */   {
/*    */     try
/*    */     {
/* 19 */       PayloadGenerator generator = type.createGeneratorInstance(Writer.class, writer);
/* 20 */       generator.setPayloadType(type);
/* 21 */       return generator;
/*    */     } catch (Exception e) {
/* 23 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public static <T extends OutputStream> PayloadGenerator createPayloadGenerator(PayloadType type, T out) {
/*    */     try {
/* 29 */       PayloadGenerator generator = type.createGeneratorInstance(OutputStream.class, out);
/* 30 */       generator.setPayloadType(type);
/* 31 */       return generator;
/*    */     } catch (Exception e) {
/* 33 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public static <T extends Reader> ParserFactory createParserFactory(PayloadType type, T reader) {
/*    */     try {
/* 39 */       return type.createParserInstance(Reader.class, reader);
/*    */     }
/*    */     catch (Exception e) {
/* 42 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public static <T extends InputStream> ParserFactory createParserFactory(PayloadType type, T in) {
/*    */     try {
/* 48 */       return type.createParserInstance(InputStream.class, in);
/*    */     }
/*    */     catch (Exception e) {
/* 51 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\PayloadFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */