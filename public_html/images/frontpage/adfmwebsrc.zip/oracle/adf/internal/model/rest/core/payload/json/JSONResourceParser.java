/*    */ package oracle.adf.internal.model.rest.core.payload.json;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceTreeManager;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceTreeManager.AttributeType;
/*    */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*    */ import oracle.adf.internal.model.rest.core.payload.ResourceParser;
/*    */ import oracle.adf.internal.model.rest.core.payload.ResourceParser.TokenType;
/*    */ import oracle.jbo.JboException;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.ObjectMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JSONResourceParser
/*    */   implements ResourceParser
/*    */ {
/*    */   private ObjectMapper mapper;
/*    */   private JsonParser parser;
/*    */   private ResourceTreeManager treeManager;
/*    */   private String nestedResourceName;
/*    */   
/*    */   JSONResourceParser(ObjectMapper mapper, JsonParser parser, ResourceTreeManager treeManager)
/*    */   {
/* 28 */     this.mapper = mapper;
/* 29 */     this.parser = parser;
/* 30 */     this.treeManager = treeManager;
/*    */   }
/*    */   
/*    */   public String getNestedResourceName()
/*    */   {
/* 35 */     return this.nestedResourceName;
/*    */   }
/*    */   
/*    */   public ResourceParser.TokenType next() throws IOException
/*    */   {
/*    */     JsonToken currentToken;
/* 41 */     while ((!this.parser.isClosed()) && ((currentToken = this.parser.nextValue()) != null))
/*    */     {
/* 43 */       String name = this.parser.getCurrentName();
/* 44 */       if (currentToken == JsonToken.START_OBJECT)
/*    */       {
/* 46 */         if (name != null)
/*    */         {
/* 48 */           this.parser.skipChildren();
/*    */         }
/*    */         else {
/* 51 */           this.nestedResourceName = null;
/* 52 */           return ResourceParser.TokenType.START_ITEM;
/*    */         }
/* 54 */       } else { if (currentToken == JsonToken.END_OBJECT) {
/* 55 */           return ResourceParser.TokenType.END_ITEM;
/*    */         }
/* 57 */         if (currentToken == JsonToken.END_ARRAY) {
/* 58 */           return ResourceParser.TokenType.END_COLLECTION;
/*    */         }
/*    */         
/*    */ 
/* 62 */         if (this.treeManager.getAttributeType(name) == ResourceTreeManager.AttributeType.ACCESSOR) {
/* 63 */           this.nestedResourceName = name;
/* 64 */           return ResourceParser.TokenType.START_COLLECTION;
/*    */         }
/*    */         
/* 67 */         Attribute attribute = this.treeManager.setCurrentAttribute(name);
/* 68 */         if (attribute != null)
/*    */         {
/* 70 */           JsonNode node = this.mapper.readTree(this.parser);
/*    */           
/* 72 */           Object value = null;
/* 73 */           if (attribute.canSerializeValue(PayloadType.JSON)) {
/* 74 */             value = attribute.deserializeValue(PayloadType.JSON, node);
/* 75 */           } else if (attribute.canStreamContent()) {
/* 76 */             value = node.isNull() ? null : Attribute.decodeBase64Value(node.getTextValue());
/*    */           } else {
/* 78 */             throw new JboException("Could not deserialize to json");
/*    */           }
/* 80 */           this.treeManager.setAttributeValue(value);
/* 81 */           return ResourceParser.TokenType.ATTR_VALUE;
/*    */         }
/*    */         
/*    */ 
/*    */ 
/* 86 */         this.parser.skipChildren();
/*    */       }
/*    */     }
/* 89 */     return ResourceParser.TokenType.CLOSE;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\json\JSONResourceParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */