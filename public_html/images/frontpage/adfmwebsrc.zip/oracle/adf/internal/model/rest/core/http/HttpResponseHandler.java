/*     */ package oracle.adf.internal.model.rest.core.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*     */ import oracle.adf.internal.model.rest.core.common.ResponseHandler.ErrorType;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException;
/*     */ import oracle.adf.internal.model.rest.core.http.header.AcceptEncoding;
/*     */ import oracle.adf.internal.model.rest.core.http.header.Coding;
/*     */ import oracle.adf.internal.model.rest.core.http.header.ContentCoding;
/*     */ import oracle.adf.internal.model.rest.core.http.header.EntityTag;
/*     */ import oracle.adf.internal.model.rest.core.http.header.HeaderConfigurator;
/*     */ import oracle.adf.internal.model.rest.core.http.header.HeaderConfiguratorInfo;
/*     */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*     */ import oracle.adf.internal.model.rest.core.http.header.QualityFactor;
/*     */ import oracle.adf.internal.model.rest.core.http.media.ContentCodingHandler;
/*     */ import oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler;
/*     */ import oracle.adf.internal.model.rest.core.http.payload.ContentCodingProcessor;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadFactory;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.JboException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpResponseHandler
/*     */   implements ResponseHandler
/*     */ {
/*     */   private OutputStream out;
/*     */   private ContentTypeHandler contentTypeHandler;
/*     */   private AcceptEncoding acceptEncoding;
/*  45 */   private AcceptHeaderManager acceptHeaderManager = new AcceptHeaderManager();
/*     */   private PayloadGenerator payloadGenerator;
/*     */   private String location;
/*     */   private EntityTag etag;
/*  49 */   private int status = StatusCode.OK.getCode();
/*     */   private String contentEncoding;
/*  51 */   private Map<String, String> headers = new HashMap();
/*  52 */   private boolean creatingResource = false;
/*     */   private ResponseHandler.ErrorType errorType;
/*     */   private ResourceEntityType entityType;
/*     */   private final RESTHttpResponseWrapper wrapper;
/*     */   private ContentCodingProcessor codingProcessor;
/*     */   
/*     */   HttpResponseHandler(RESTHttpResponseWrapper responseWrapper) throws IOException {
/*  59 */     this(new AcceptHeaderManager(), responseWrapper);
/*     */   }
/*     */   
/*     */   HttpResponseHandler(AcceptHeaderManager acceptHeaderManager, RESTHttpResponseWrapper responseWrapper) throws IOException {
/*  63 */     this.out = responseWrapper.getOutpuStream();
/*  64 */     this.acceptHeaderManager = acceptHeaderManager;
/*  65 */     this.wrapper = responseWrapper;
/*     */   }
/*     */   
/*     */   void setupHeaderConfigurator(HeaderConfiguratorInfo info) {
/*  69 */     this.wrapper.getHeaderConfigurator().setup(info);
/*     */   }
/*     */   
/*     */   public void setPayloadGenerator(PayloadGenerator payloadGenerator) {
/*  73 */     this.payloadGenerator = payloadGenerator;
/*     */   }
/*     */   
/*     */   public void setContentType(String contentType) {
/*  77 */     if (contentType == null) {
/*  78 */       this.contentTypeHandler = null;
/*  79 */       return;
/*     */     }
/*     */     
/*  82 */     MediaType mediaType = MediaType.parseMediaType(contentType);
/*  83 */     ContentTypeHandler contentTypeHandler = this.acceptHeaderManager.getContentTypeHandler();
/*     */     
/*     */ 
/*  86 */     if ((contentTypeHandler == null) || (!contentTypeHandler.getMediaType().equals(mediaType))) {
/*  87 */       this.acceptHeaderManager.process(mediaType);
/*     */     }
/*     */     
/*  90 */     configureContentTypeHandler();
/*     */   }
/*     */   
/*     */   public EntityTag getEtag() {
/*  94 */     return this.etag;
/*     */   }
/*     */   
/*     */   public Map<String, String> getHeaders() {
/*  98 */     return new HashMap(this.headers);
/*     */   }
/*     */   
/*     */   public ContentTypeHandler getContentTypeHandler()
/*     */   {
/* 103 */     return this.contentTypeHandler;
/*     */   }
/*     */   
/*     */   public String getLocation() {
/* 107 */     return this.location;
/*     */   }
/*     */   
/*     */   public String getContentEncoding() {
/* 111 */     return this.contentEncoding;
/*     */   }
/*     */   
/*     */   private void configureContentTypeHandler() {
/* 115 */     if (this.acceptHeaderManager.isAcceptable()) {
/* 116 */       this.contentTypeHandler = this.acceptHeaderManager.getContentTypeHandler();
/*     */     } else {
/* 118 */       this.contentTypeHandler = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setContentType(ResourceEntityType entityType) {
/* 123 */     if (entityType == null) {
/* 124 */       this.contentTypeHandler = null;
/* 125 */       return;
/*     */     }
/* 127 */     this.entityType = entityType;
/*     */     
/*     */ 
/* 130 */     if ((this.acceptHeaderManager.getContentTypeHandler() == null) || (!entityType.equals(this.acceptHeaderManager.getContentTypeHandler().getEntityType()))) {
/* 131 */       this.acceptHeaderManager.process(entityType);
/*     */     }
/*     */     
/* 134 */     configureContentTypeHandler();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setResourcePath(String resourcePath)
/*     */   {
/* 141 */     this.location = resourcePath;
/*     */   }
/*     */   
/*     */   public void setup()
/*     */   {
/* 146 */     configureHeaders(this.wrapper.getHeaderConfigurator().getHeaders());
/* 147 */     if (this.codingProcessor != null) {
/*     */       try {
/* 149 */         this.out = this.codingProcessor.wrapOutput(this.out);
/*     */       } catch (IOException e) {
/* 151 */         throw new JboException(e);
/*     */       }
/*     */     }
/* 154 */     if (this.errorType == ResponseHandler.ErrorType.PRECONDITION_FAILED) {
/* 155 */       this.status = StatusCode.PRECONDITION_FAILED.getCode();
/* 156 */       configurePayloadGenerator();
/* 157 */       return;
/*     */     }
/* 159 */     if (isContentGenerationAllowed()) {
/* 160 */       if (isCreatingContent()) {
/* 161 */         this.status = StatusCode.CREATED.getCode();
/*     */       }
/* 163 */       configurePayloadGenerator();
/*     */     } else {
/* 165 */       this.status = StatusCode.NO_CONTENT.getCode();
/*     */     }
/*     */     
/* 168 */     this.headers.put("Content-Encoding", getContentEncoding());
/* 169 */     this.headers.put("Location", getLocation());
/*     */     
/* 171 */     if (this.contentTypeHandler != null) {
/* 172 */       this.headers.put("Content-Type", this.contentTypeHandler.getMediaType().toString());
/*     */     }
/*     */     
/* 175 */     if (this.etag != null) {
/* 176 */       this.headers.put("ETag", this.etag.getFormattedValue());
/*     */     }
/*     */     
/* 179 */     for (String suppressedHeader : this.wrapper.getHeaderConfigurator().getSuppressedHeaderNames()) {
/* 180 */       this.headers.remove(suppressedHeader);
/*     */     }
/*     */     
/*     */ 
/* 184 */     this.wrapper.setupResponseHeaders(getStatus(), getHeaders());
/*     */   }
/*     */   
/*     */   protected String configureResponseContentCoding() {
/* 188 */     if (!HTTPRESTUtil.isCompressionEnabled()) {
/* 189 */       return null;
/*     */     }
/*     */     
/* 192 */     String contentEncoding = null;
/* 193 */     if (this.acceptEncoding != null) {
/* 194 */       Coding bestMatch = this.acceptEncoding.findBestMatch(ContentCodingHandler.generateSupportedContentEncodingList());
/* 195 */       if (bestMatch != null) {
/* 196 */         if (!bestMatch.getQualityFactor().isAcceptable()) {
/* 197 */           throw new CannotGenerateContentException("The quality factory for this coding is not acceptable. Quality factor: " + bestMatch.getQualityFactor());
/*     */         }
/* 199 */         ContentCoding coding = bestMatch.getContentCoding();
/* 200 */         this.codingProcessor = ContentCodingHandler.createContentCodingProcessor(coding);
/* 201 */         contentEncoding = coding.getValue();
/*     */       } else {
/* 203 */         throw new CannotGenerateContentException("The Accept-Encoding was not provided.");
/*     */       }
/*     */     }
/*     */     
/* 207 */     return contentEncoding;
/*     */   }
/*     */   
/*     */   public void setAcceptEncoding(String acceptEncodingHeaderValue) {
/* 211 */     this.acceptEncoding = AcceptEncoding.parse(acceptEncodingHeaderValue);
/* 212 */     this.contentEncoding = configureResponseContentCoding();
/*     */   }
/*     */   
/*     */   public AcceptEncoding getAcceptEncoding() {
/* 216 */     return this.acceptEncoding;
/*     */   }
/*     */   
/*     */   public AcceptHeaderManager getAcceptHeaderManager() {
/* 220 */     return this.acceptHeaderManager;
/*     */   }
/*     */   
/* 223 */   public void setAcceptHeaderManager(AcceptHeaderManager acceptHeaderManager) { this.acceptHeaderManager = acceptHeaderManager; }
/*     */   
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */   {
/* 228 */     return this.out;
/*     */   }
/*     */   
/*     */   public PayloadGenerator getPayloadGenerator()
/*     */   {
/* 233 */     return this.payloadGenerator;
/*     */   }
/*     */   
/*     */   public void setStateIdentifier(String stateId)
/*     */   {
/* 238 */     if (stateId != null) {
/* 239 */       FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 240 */       logger.config("Response State ID: " + stateId);
/* 241 */       this.etag = EntityTag.createStrongEntityTag(stateId);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isContentGenerationAllowed()
/*     */   {
/* 248 */     return this.contentTypeHandler != null;
/*     */   }
/*     */   
/*     */   protected void configurePayloadGenerator() {
/* 252 */     if (this.contentTypeHandler == null) {
/* 253 */       return;
/*     */     }
/* 255 */     PayloadType payloadType = this.contentTypeHandler.getPayloadType();
/* 256 */     if (payloadType != null) {
/* 257 */       this.payloadGenerator = PayloadFactory.createPayloadGenerator(payloadType, this.out);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEntityGenerationAllowed()
/*     */   {
/* 263 */     return (isContentGenerationAllowed()) && (this.contentTypeHandler.getEntityType() != null);
/*     */   }
/*     */   
/*     */   public void resetContentType()
/*     */   {
/* 268 */     this.contentTypeHandler = null;
/*     */   }
/*     */   
/*     */   public void finish()
/*     */   {
/* 273 */     if ((this.out instanceof DeflaterOutputStream)) {
/*     */       try {
/* 275 */         ((DeflaterOutputStream)this.out).finish();
/*     */       } catch (IOException e) {
/* 277 */         throw new JboException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCreatingContent() {
/* 283 */     return (this.creatingResource) && (isContentGenerationAllowed());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperties(Map<String, String> properties)
/*     */   {
/* 292 */     configureHeaders(properties);
/*     */   }
/*     */   
/*     */   private void configureHeaders(Map<String, String> properties) {
/* 296 */     for (Map.Entry<String, String> entry : properties.entrySet()) {
/* 297 */       String propertyKey = (String)entry.getKey();
/* 298 */       String headerValue = (String)entry.getValue();
/*     */       
/* 300 */       if ("Content-Type".equals(propertyKey)) {
/* 301 */         setContentType(headerValue);
/*     */       }
/*     */       
/* 304 */       if ("ETag".equals(propertyKey)) {
/* 305 */         setStateIdentifier(headerValue);
/*     */       }
/*     */       
/* 308 */       if ("Location".equals(propertyKey)) {
/* 309 */         setResourcePath(headerValue);
/*     */       }
/*     */       
/* 312 */       this.headers.put(propertyKey, headerValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCreatingResource(boolean creatingResource)
/*     */   {
/* 318 */     this.creatingResource = creatingResource;
/*     */   }
/*     */   
/*     */   public String getStateIdentifier()
/*     */   {
/* 323 */     String stateId = null;
/* 324 */     if (this.etag != null) {
/* 325 */       stateId = this.etag.toString();
/*     */     }
/* 327 */     return stateId;
/*     */   }
/*     */   
/*     */   public int getStatus() {
/* 331 */     return this.status;
/*     */   }
/*     */   
/*     */   public void setError(ResponseHandler.ErrorType errorType)
/*     */   {
/* 336 */     this.errorType = errorType;
/*     */   }
/*     */   
/*     */   public ResponseHandler.ErrorType getError()
/*     */   {
/* 341 */     return this.errorType;
/*     */   }
/*     */   
/*     */   ResourceEntityType getEntityType() {
/* 345 */     return this.entityType;
/*     */   }
/*     */   
/*     */   public void setLink(String link)
/*     */   {
/* 350 */     this.headers.put("Link", link);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\HttpResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */