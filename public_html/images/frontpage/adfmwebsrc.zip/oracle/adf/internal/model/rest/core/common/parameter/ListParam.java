/*     */ package oracle.adf.internal.model.rest.core.common.parameter;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ 
/*     */ public class ListParam
/*     */   extends ResourceParameter
/*     */ {
/*     */   private final Set<String> attributeFilterList;
/*     */   private static final String ATTRIBUTE_SEPARATOR = ",";
/*     */   private static final String RESOURCE_SEPARATOR = ";";
/*     */   private static final String ACCESSOR_FIELDS_SEPARATOR = ":";
/*  19 */   private static final Set<String> EMPTY_FILTER_LIST = ;
/*     */   private final Map<String, Set<String>> accessorFilterMap;
/*     */   
/*     */   public ListParam(String[] parameterValues) {
/*  23 */     Set<String> filterList = EMPTY_FILTER_LIST;
/*  24 */     Map<String, Set<String>> accessorFieldsMap = Collections.emptyMap();
/*  25 */     if ((parameterValues != null) && (parameterValues.length > 0) && (parameterValues[0] != null)) {
/*  26 */       String[] paramsPerResource = parameterValues[0].split(";");
/*  27 */       accessorFieldsMap = new HashMap(paramsPerResource.length);
/*     */       
/*  29 */       for (String param : paramsPerResource) {
/*  30 */         String[] resourceFieldsParam = param.split(":");
/*  31 */         if (resourceFieldsParam.length > 1)
/*     */         {
/*  33 */           accessorFieldsMap.put(resourceFieldsParam[0], createFieldsSet(resourceFieldsParam[1]));
/*  34 */           addImplicitAccessorPathParts(accessorFieldsMap, resourceFieldsParam[0]);
/*     */         }
/*  36 */         else if (param.endsWith(":")) {
/*  37 */           if (resourceFieldsParam.length > 0) {
/*  38 */             accessorFieldsMap.put(resourceFieldsParam[0], EMPTY_FILTER_LIST);
/*  39 */             addImplicitAccessorPathParts(accessorFieldsMap, resourceFieldsParam[0]);
/*     */           }
/*     */         } else {
/*  42 */           filterList = createFieldsSet(resourceFieldsParam[0]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  48 */     this.attributeFilterList = filterList;
/*  49 */     this.accessorFilterMap = Collections.unmodifiableMap(accessorFieldsMap);
/*     */   }
/*     */   
/*     */   private void addImplicitAccessorPathParts(Map<String, Set<String>> accessorFieldsMap, String s) {
/*  53 */     String[] accessorParts = s.split("\\.");
/*  54 */     if (accessorParts.length > 1) {
/*  55 */       int implicitAccessorPartsSize = accessorParts.length - 1;
/*  56 */       String currentAccessor = "";
/*     */       
/*  58 */       for (int i = 0; i < implicitAccessorPartsSize; i++) {
/*  59 */         if (currentAccessor.length() > 0) {
/*  60 */           currentAccessor = currentAccessor + ".";
/*     */         }
/*  62 */         currentAccessor = currentAccessor + accessorParts[i];
/*  63 */         if (!accessorFieldsMap.containsKey(currentAccessor)) {
/*  64 */           accessorFieldsMap.put(currentAccessor, EMPTY_FILTER_LIST);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Set<String> createFieldsSet(String fields) {
/*  71 */     return Collections.unmodifiableSet(new HashSet(Arrays.asList(fields.split(","))));
/*     */   }
/*     */   
/*     */   public Set<String> getAttributeFilterList() {
/*  75 */     return this.attributeFilterList;
/*     */   }
/*     */   
/*     */   public Map<String, Set<String>> getAccessorFilterMap() {
/*  79 */     return this.accessorFilterMap;
/*     */   }
/*     */   
/*     */   public Set<String> getAttributesForResource(Resource resource, Resource startingResource) {
/*  83 */     Set<String> attrs = null;
/*     */     
/*  85 */     boolean computeAccessorName = true;
/*  86 */     if ((startingResource == null) || (resource.getKeyPath().equals(startingResource.getKeyPath()))) {
/*  87 */       computeAccessorName = false;
/*     */     }
/*  89 */     String accessorName = computeAccessorName ? computeAccessorName(resource, startingResource) : null;
/*  90 */     if (accessorName != null) {
/*  91 */       attrs = (Set)this.accessorFilterMap.get(accessorName);
/*     */     } else {
/*  93 */       attrs = getAttributeFilterList();
/*     */     }
/*  95 */     return attrs;
/*     */   }
/*     */   
/*     */   private String computeAccessorName(Resource resource, Resource startingResource) {
/*  99 */     JUCtrlHierNodeBinding node = resource.getNode();
/* 100 */     String accName = node.getAccessorName();
/* 101 */     if (accName != null) {
/* 102 */       JUCtrlHierNodeBinding startingNode = startingResource.getNode();
/* 103 */       StringBuilder accNameBuilder = new StringBuilder(accName);
/* 104 */       while ((node = node.getParent()) != startingNode) {
/* 105 */         String parentAccName = node.getAccessorName();
/* 106 */         if (parentAccName != null) {
/* 107 */           accNameBuilder.insert(0, parentAccName);
/* 108 */           accNameBuilder.insert(parentAccName.length(), ".");
/*     */         }
/*     */       }
/* 111 */       return accNameBuilder.toString();
/*     */     }
/* 113 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\ListParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */