/*      */ package oracle.adf.internal.model.rest.core.domain;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import oracle.adf.internal.model.rest.core.common.RESTUtil;
/*      */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*      */ import oracle.adf.internal.model.rest.core.state.StateIdBuilder;
/*      */ import oracle.adf.internal.model.rest.core.state.StateIdBuilderFactory;
/*      */ import oracle.adf.model.binding.DCBindingContainer;
/*      */ import oracle.adf.model.binding.DCControlBinding;
/*      */ import oracle.adf.model.binding.DCIteratorBinding;
/*      */ import oracle.adf.model.binding.DCUtil;
/*      */ import oracle.jbo.ApplicationModule;
/*      */ import oracle.jbo.AttributeDef;
/*      */ import oracle.jbo.AttributeList;
/*      */ import oracle.jbo.JboException;
/*      */ import oracle.jbo.Key;
/*      */ import oracle.jbo.NameValuePairs;
/*      */ import oracle.jbo.Row;
/*      */ import oracle.jbo.RowIterator;
/*      */ import oracle.jbo.RowSetIterator;
/*      */ import oracle.jbo.VariableValueManager;
/*      */ import oracle.jbo.ViewObject;
/*      */ import oracle.jbo.common.JboTypeMap;
/*      */ import oracle.jbo.common.ListBindingDef;
/*      */ import oracle.jbo.domain.TypeFactory;
/*      */ import oracle.jbo.server.AssociationEnd;
/*      */ import oracle.jbo.server.AttributeDefImpl;
/*      */ import oracle.jbo.server.EffectiveDateHelper;
/*      */ import oracle.jbo.server.EffectiveDateRangeOperation;
/*      */ import oracle.jbo.server.RowDef;
/*      */ import oracle.jbo.server.RowFinder;
/*      */ import oracle.jbo.server.RowImpl;
/*      */ import oracle.jbo.server.ViewAttributeDefImpl;
/*      */ import oracle.jbo.server.ViewLinkDefImpl;
/*      */ import oracle.jbo.server.ViewObjectImpl;
/*      */ import oracle.jbo.uicli.binding.JUCtrlActionBinding;
/*      */ import oracle.jbo.uicli.binding.JUCtrlHierBinding;
/*      */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*      */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
/*      */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding.Type;
/*      */ import oracle.jbo.uicli.binding.JUIteratorBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Resource
/*      */ {
/*      */   private static final String EXPAND_ACCESSOR_PROPERTY = "expand";
/*      */   private static final String RESOURCE_REFERENCE_PROPERTY = "ResourceRef";
/*      */   private static final String RESOURCE_KEY_PROPERTY = "Key";
/*      */   private static final String RESOURCE_KEY_VALUE_ATTRIBUTE = "value";
/*      */   private final JUCtrlHierNodeBinding treeNode;
/*      */   private final ResourceTree tree;
/*      */   private final List<String> searchAttributeNames;
/*      */   
/*      */   Resource(ResourceTree tree, JUCtrlHierNodeBinding treeNode)
/*      */   {
/*   72 */     this.treeNode = treeNode;
/*   73 */     this.tree = tree;
/*   74 */     this.searchAttributeNames = createSearchAttributeNames();
/*      */     
/*      */ 
/*   77 */     ViewObject vo = this.treeNode.getViewObject();
/*   78 */     if (vo != null) {
/*   79 */       ((ViewObjectImpl)vo).setThrowOnListBindingMismatch(RESTUtil.isFailOnLOVMismatchEnabled().booleanValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JUCtrlHierNodeBinding getNode()
/*      */   {
/*   91 */     return this.treeNode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final String getChangeIndicator()
/*      */   {
/*   99 */     if (isItem()) {
/*  100 */       return StateIdBuilderFactory.getInstance().createStateId(this.treeNode);
/*      */     }
/*  102 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract String createKeyString();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static List<String> generateRelativePathSegments(Resource resource)
/*      */   {
/*  118 */     Resource currentResource = resource;
/*      */     
/*  120 */     LinkedList<String> pathSegments = new LinkedList();
/*      */     
/*      */ 
/*  123 */     if (!currentResource.isRoot()) {
/*      */       String keyString;
/*  125 */       for (;;) { String folderName = currentResource.isLOV() ? "lov" : "child";
/*  126 */         if (currentResource.isCollection()) {
/*  127 */           pathSegments.push(currentResource.getName());
/*  128 */           pathSegments.push(folderName);
/*  129 */           currentResource = currentResource.getParent();
/*      */         }
/*      */         else {
/*  132 */           keyString = currentResource.createKeyString();
/*  133 */           currentResource = currentResource.getParent();
/*  134 */           if (currentResource.isRoot()) {
/*      */             break;
/*      */           }
/*      */           
/*  138 */           pathSegments.push(keyString);
/*      */         } }
/*  140 */       pathSegments.push(keyString);
/*      */     }
/*  142 */     pathSegments.push(currentResource.getName());
/*      */     
/*  144 */     return pathSegments;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Path getPath(String basePath)
/*      */   {
/*  154 */     return new Path(basePath, generateRelativePathSegments(this));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isAccessorAttribute(String attributeName)
/*      */   {
/*  163 */     return getNestedResourceNames().contains(attributeName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract Resource getParent();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract Attribute getAttribute(String paramString);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract List<Attribute> getAttributes();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isCollection()
/*      */   {
/*  199 */     return isCollection(this.treeNode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isItem()
/*      */   {
/*  208 */     return !isCollection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isRoot()
/*      */   {
/*  216 */     return isRootNode(this.treeNode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isCollection(JUCtrlHierNodeBinding treeNode)
/*      */   {
/*  226 */     return (isRootNode(treeNode)) || (treeNode.isAccessorFolderNode());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isItem(JUCtrlHierNodeBinding treeNode)
/*      */   {
/*  236 */     return !isCollection(treeNode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isRootNode(JUCtrlHierNodeBinding treeNode)
/*      */   {
/*  245 */     JUCtrlHierNodeBinding rootNode = treeNode.getHierBinding().getRootNodeBinding();
/*  246 */     return rootNode == treeNode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final String getName()
/*      */   {
/*  255 */     JUCtrlHierBinding hierBinding = this.treeNode.getHierBinding();
/*      */     String nodeName;
/*  257 */     String nodeName; if (isTopLevel()) {
/*  258 */       nodeName = hierBinding.getName();
/*      */     } else { String nodeName;
/*  260 */       if (this.treeNode.isAccessorFolderNode()) {
/*  261 */         nodeName = this.treeNode.getHierTypeBinding().getAccessorName();
/*      */       } else {
/*  263 */         nodeName = this.treeNode.getParent().getHierTypeBinding().getAccessorName();
/*      */       }
/*      */     }
/*  266 */     return nodeName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isTopLevel()
/*      */   {
/*  274 */     return isTopLevel(this.treeNode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isTopLevel(JUCtrlHierNodeBinding node)
/*      */   {
/*  284 */     JUCtrlHierNodeBinding rootNode = node.getHierBinding().getRootNodeBinding();
/*  285 */     return (node == rootNode) || (node.getParent() == rootNode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isAccessorExpandable(String accessorName)
/*      */   {
/*  294 */     String accessorConfiguredToExpand = (String)getAccessorPropertyFromParent(this.treeNode, accessorName, "expand");
/*  295 */     return Boolean.parseBoolean(accessorConfiguredToExpand);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getNestedResourceNames()
/*      */   {
/*  303 */     JUCtrlHierTypeBinding typeBinding = getHierTypeBinding();
/*      */     
/*  305 */     String[] accessorNames = typeBinding.getAccessorNames();
/*  306 */     if ((accessorNames == null) || (accessorNames.length == 0)) {
/*  307 */       return Collections.emptySet();
/*      */     }
/*  309 */     return new HashSet(Arrays.asList(accessorNames));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   JUCtrlHierTypeBinding getHierTypeBinding()
/*      */   {
/*      */     JUCtrlHierTypeBinding typeBinding;
/*      */     
/*      */     JUCtrlHierTypeBinding typeBinding;
/*      */     
/*  320 */     if (this.treeNode.isAccessorFolderNode()) {
/*  321 */       typeBinding = getAccessorHierTypeBinding();
/*      */     } else {
/*  323 */       typeBinding = this.treeNode.getHierTypeBinding();
/*      */     }
/*  325 */     return typeBinding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private JUCtrlHierTypeBinding getAccessorHierTypeBinding()
/*      */   {
/*  333 */     return getAccessorHierTypeBinding(this.treeNode.getAccessorName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   JUCtrlHierTypeBinding getAccessorHierTypeBinding(String accessorName)
/*      */   {
/*  342 */     return this.tree.getTypeBinding(getParent(), accessorName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Integer getChildRangeOffset()
/*      */   {
/*  350 */     if (isCollection()) {
/*  351 */       return Integer.valueOf(this.treeNode.getChildIteratorBinding().getRangeStart());
/*      */     }
/*  353 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Integer getChildIteratorRangeStart()
/*      */   {
/*  362 */     return Integer.valueOf(this.treeNode.getChildIteratorBinding().getRangeStart());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final void setChildIteratorRangeStart(int rangeStart)
/*      */   {
/*  370 */     this.treeNode.getChildIteratorBinding().setRangeStart(rangeStart);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final void setChildIteratorRangeSize(int rangeSize)
/*      */   {
/*  378 */     this.treeNode.getChildIteratorBinding().setRangeSize(rangeSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getChildIteratorRangeSize()
/*      */   {
/*  387 */     return this.treeNode.getChildIteratorBinding().getRangeSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final Long getChildIteratorEstimatedRowCount()
/*      */   {
/*  395 */     return Long.valueOf(this.treeNode.getChildIteratorBinding().getEstimatedRowCount());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Path generateResourceCollectionPath(String basePath, String resourceName)
/*      */   {
/*  405 */     return new Path(basePath, resourceName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Path generateResourcePath(String basePath, String resourceName, String resourceId)
/*      */   {
/*  416 */     List<String> pathSegments = new ArrayList(2);
/*  417 */     pathSegments.add(resourceName);
/*  418 */     pathSegments.add(resourceId);
/*  419 */     return new Path(basePath, pathSegments);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResourceReference getResourceReference(String basePath)
/*      */   {
/*  428 */     Map resourceReferenceMap = (Map)getHierTypeBinding().getRawPropertyValue("ResourceRef");
/*      */     
/*  430 */     if (isCollection()) {
/*  431 */       return ResourceReferenceFactory.createResourceReference(null, basePath, "{id}", resourceReferenceMap);
/*      */     }
/*      */     
/*  434 */     return ResourceReferenceFactory.createResourceReference((DCBindingContainer)this.treeNode.getRegionBinding(), basePath, createKeyString(), resourceReferenceMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Object getAccessorPropertyFromParent(JUCtrlHierNodeBinding parentNode, String accessorName, String propertyName)
/*      */   {
/*  446 */     JUCtrlHierTypeBinding binding = parentNode.getHierTypeBinding();
/*  447 */     Object customAttribute = null;
/*  448 */     Map accessorHints = binding.getAccessorHints();
/*  449 */     if (accessorHints != null) {
/*  450 */       Map accessorCustomAttributes = (Map)accessorHints.get(accessorName);
/*  451 */       if (accessorCustomAttributes != null) {
/*  452 */         customAttribute = accessorCustomAttributes.get(propertyName);
/*      */       }
/*      */     }
/*  455 */     return customAttribute;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Key getKey()
/*      */   {
/*  465 */     return this.treeNode.getRowKey();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final List<Key> getKeyPath()
/*      */   {
/*  483 */     return this.treeNode.getKeyPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Key createChildKey(String keyString)
/*      */   {
/*  495 */     if (isItem()) {
/*  496 */       return null;
/*      */     }
/*      */     
/*  499 */     Finder finder = getFinder();
/*  500 */     if (finder != null) {
/*  501 */       RowFinder rowFinder = finder.getRowFinder();
/*  502 */       AttributeList attributeList = createRowFinderAttributeList(rowFinder, keyString);
/*  503 */       return createRowFinderChildKey(rowFinder, new SearchAttributes(attributeList));
/*      */     }
/*      */     
/*  506 */     return createVOChildKey(keyString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Key createChildKey(SearchAttributes searchAttributes)
/*      */   {
/*  517 */     if (isItem()) {
/*  518 */       return null;
/*      */     }
/*      */     
/*  521 */     Finder finder = getFinder();
/*  522 */     if (finder != null) {
/*  523 */       return createRowFinderChildKey(finder.getRowFinder(), searchAttributes);
/*      */     }
/*      */     
/*  526 */     return createVOChildKey(searchAttributes.getSearchAttributeList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<Attribute> getRowFinderAttributes(RowFinder rowFinder)
/*      */   {
/*  536 */     Collection<String> rowFinderAttributes = getSortedRowFinderAttributes(rowFinder);
/*  537 */     List<Attribute> attributes = new ArrayList(rowFinderAttributes.size());
/*  538 */     for (String rowFinderAttr : rowFinderAttributes) {
/*  539 */       Attribute attribute = getAttribute(rowFinderAttr);
/*  540 */       if (attribute == null) {
/*  541 */         throw new JboException("The following attribute is part of the RowFinder but wasn't exposed in the Resource: " + rowFinderAttr);
/*      */       }
/*  543 */       attributes.add(attribute);
/*      */     }
/*  545 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final AttributeList createRowFinderAttributeList(RowFinder rowFinder, String keyString)
/*      */   {
/*  557 */     List<Attribute> rowFinderAttributes = getRowFinderAttributes(rowFinder);
/*  558 */     AttributeDef[] attrDefs = new AttributeDef[rowFinderAttributes.size()];
/*  559 */     String[] attributeNames = new String[attrDefs.length];
/*      */     
/*  561 */     int i = 0;
/*  562 */     for (Attribute rowFinderAttribute : rowFinderAttributes) {
/*  563 */       attrDefs[i] = rowFinderAttribute.getAttrDef();
/*  564 */       attributeNames[i] = rowFinderAttribute.getName();
/*  565 */       i++;
/*      */     }
/*      */     Key key;
/*      */     Key key;
/*  569 */     if (verifyPrettyKeyString(attrDefs)) {
/*  570 */       key = new Key(new Object[] { ((AttributeDefImpl)attrDefs[0]).convertToJava(keyString) });
/*      */     } else {
/*      */       try {
/*  573 */         key = new Key(keyString, attrDefs);
/*      */       } catch (Exception e) {
/*  575 */         throw new JboException(e);
/*      */       }
/*      */     }
/*      */     
/*  579 */     return new NameValuePairs(attributeNames, key.getAttributeValues());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Key createRowFinderChildKey(RowFinder rowFinder, SearchAttributes searchAttributes)
/*      */   {
/*  590 */     Row r = findRow(rowFinder, searchAttributes);
/*      */     
/*  592 */     if (r == null) {
/*  593 */       return null;
/*      */     }
/*      */     
/*  596 */     ViewObjectImpl vo = getVO();
/*  597 */     if (vo.isEffectiveDated())
/*      */     {
/*  599 */       Object date1 = vo.getApplicationModule().getProperty("SysEffectiveDate");
/*  600 */       Object date2 = ((RowImpl)r).getEffectiveDate();
/*  601 */       Object effectiveDate = EffectiveDateHelper.compareDate(date1, date2) > 0 ? date1 : date2;
/*  602 */       vo.ensureVariableManager().setVariableValue("SysEffectiveDateBindVar", effectiveDate);
/*      */     }
/*      */     
/*  605 */     return r.getKey();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Row findRow(RowFinder rowFinder, SearchAttributes searchAttributes)
/*      */   {
/*  617 */     if (!searchAttributes.getEffDateRangeProperties().isEmpty()) {
/*  618 */       return EffectiveDateRangeOperation.findRangeStartRow(getVO(), searchAttributes.getSearchAttributeList(), rowFinder.getName(), searchAttributes.getEffDateRangeProperties());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  625 */     return executeRowFinder(rowFinder, searchAttributes.getSearchAttributeList()).first();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   RowIterator executeRowFinder(RowFinder rowFinder, AttributeList attributeList)
/*      */   {
/*  636 */     DCIteratorBinding iterBinding = this.treeNode.getChildIteratorBinding();
/*  637 */     getVO().setProperty("__Finder__RangePagingMode__internal__", Boolean.TRUE);
/*  638 */     return rowFinder.execute(attributeList, iterBinding.getRowSetIterator().getRowSet());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean verifyPrettyKeyString(AttributeDef[] keyDefs)
/*      */   {
/*  648 */     if (keyDefs == null) {
/*  649 */       throw new IllegalArgumentException("argument is null");
/*      */     }
/*  651 */     boolean hasPrettyKeyString = false;
/*  652 */     if (keyDefs.length == 1) {
/*  653 */       AttributeDef keyDef = keyDefs[0];
/*  654 */       if ((JboTypeMap.isCharType(keyDef.getSQLType())) || ((JboTypeMap.isNumericType(keyDef.getSQLType())) && (keyDef.getScale() <= 0)))
/*      */       {
/*  656 */         hasPrettyKeyString = true;
/*      */       }
/*      */     }
/*  659 */     return hasPrettyKeyString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getRowFinderName()
/*      */   {
/*  668 */     String rowFinderName = null;
/*  669 */     Map keyPropertyMap = (Map)getHierTypeBinding().getRawPropertyValue("Key");
/*  670 */     if (keyPropertyMap != null) {
/*  671 */       rowFinderName = (String)keyPropertyMap.get("value");
/*      */     }
/*  673 */     return rowFinderName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Finder getFinder(String finderName)
/*      */   {
/*  683 */     if (finderName == null) {
/*  684 */       return null;
/*      */     }
/*  686 */     ViewObjectImpl vo = getVO();
/*  687 */     RowFinder rowFinder = vo.lookupRowFinder(finderName);
/*      */     
/*  689 */     if (rowFinder == null) {
/*  690 */       return null;
/*      */     }
/*      */     
/*  693 */     Finder finder = new Finder(rowFinder, this);
/*      */     
/*  695 */     if (finder.isEnabled()) {
/*  696 */       return finder;
/*      */     }
/*      */     
/*  699 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   Finder getFinder()
/*      */   {
/*  707 */     String finderName = getRowFinderName();
/*  708 */     return getFinder(finderName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<String> createSearchAttributeNames()
/*      */   {
/*  720 */     Finder finder = getFinder();
/*  721 */     List<String> attributeNames; List<String> attributeNames; if (finder != null) {
/*  722 */       attributeNames = new ArrayList(finder.getAttributeNames());
/*      */     } else {
/*  724 */       AttributeDef[] keyAttributeDefs = getVO().getKeyAttributeDefs();
/*  725 */       attributeNames = new ArrayList(keyAttributeDefs.length);
/*      */       
/*  727 */       for (AttributeDef attrDef : keyAttributeDefs) {
/*  728 */         attributeNames.add(attrDef.getName());
/*      */       }
/*      */     }
/*      */     
/*  732 */     return attributeNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ViewObjectImpl getVO()
/*      */   {
/*  741 */     return getVO(this.treeNode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static ViewObjectImpl getVO(JUCtrlHierNodeBinding node)
/*      */   {
/*      */     ViewObjectImpl vo;
/*      */     
/*      */ 
/*  752 */     if (isCollection(node)) {
/*  753 */       ViewObjectImpl vo = (ViewObjectImpl)node.getChildIteratorBinding().getViewObject();
/*      */       
/*      */ 
/*      */ 
/*  757 */       if (vo == null)
/*      */       {
/*  759 */         JUCtrlHierNodeBinding parent = node.getParent();
/*  760 */         String accName = node.getAccessorName();
/*  761 */         if ((parent != null) && (accName != null))
/*      */         {
/*  763 */           Row parentRow = parent.getRow();
/*  764 */           vo = (ViewObjectImpl)DCUtil.lookupAccessorVO(parentRow, accName);
/*      */         }
/*      */       }
/*      */     } else {
/*  768 */       vo = (ViewObjectImpl)node.getViewObject();
/*      */     }
/*  770 */     return vo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ResourceTree getTree()
/*      */   {
/*  779 */     return this.tree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Key createVOChildKey(AttributeList searchAttributes)
/*      */   {
/*  788 */     return this.treeNode.getChildIteratorBinding().getRowSetIterator().createKey(searchAttributes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Key createVOChildKey(String keyString)
/*      */   {
/*  798 */     DCIteratorBinding iterBinding = this.treeNode.getChildIteratorBinding();
/*  799 */     AttributeDef[] keyDefs = getVO().getKeyAttributeDefs();
/*  800 */     Key key; Key key; if (verifyPrettyKeyString(keyDefs)) {
/*  801 */       key = new Key(new Object[] { ((AttributeDefImpl)keyDefs[0]).convertToJava(keyString) });
/*      */     } else {
/*  803 */       key = iterBinding.createKey(keyString);
/*      */     }
/*  805 */     return key;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String createVOKeyString(JUCtrlHierNodeBinding node)
/*      */   {
/*  814 */     if (isCollection(node)) {
/*  815 */       return null;
/*      */     }
/*  817 */     Key key = node.getRowKey();
/*  818 */     AttributeDef[] keyDefs = node.getIteratorBinding().getViewObject().getKeyAttributeDefs();
/*  819 */     return generateKeyString(key, keyDefs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static String generateKeyString(Key key, AttributeDef[] keyDefs)
/*      */   {
/*      */     String keyString;
/*      */     
/*      */     String keyString;
/*      */     
/*  830 */     if (verifyPrettyKeyString(keyDefs)) {
/*  831 */       keyString = (String)TypeFactory.getInstance(String.class, key.getAttributeValues()[0]);
/*      */     } else {
/*  833 */       keyString = key.toStringFormat(false);
/*      */     }
/*  835 */     return keyString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Collection<String> getSortedRowFinderAttributes(RowFinder rowFinder)
/*      */   {
/*  844 */     return new TreeSet(rowFinder.getAttributeNames());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final String createRowFinderKeyString(RowFinder rowFinder)
/*      */   {
/*  853 */     List<Attribute> rowFinderAttributes = getRowFinderAttributes(rowFinder);
/*      */     
/*  855 */     Object[] attributeValues = new Object[rowFinderAttributes.size()];
/*  856 */     AttributeDef[] attributeDefs = new AttributeDef[rowFinderAttributes.size()];
/*      */     
/*  858 */     int i = 0;
/*  859 */     for (Attribute attribute : rowFinderAttributes) {
/*  860 */       attributeValues[i] = attribute.getValue();
/*  861 */       attributeDefs[i] = attribute.getAttrDef();
/*  862 */       i++;
/*      */     }
/*      */     
/*  865 */     return generateKeyString(new Key(attributeValues), attributeDefs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final List<Finder> getFinders()
/*      */   {
/*  873 */     ViewObjectImpl vo = getVO();
/*      */     
/*  875 */     Collection<RowFinder> rowFinders = vo.getRowFinders(true).values();
/*      */     
/*  877 */     if (rowFinders.isEmpty()) {
/*  878 */       return Collections.emptyList();
/*      */     }
/*      */     
/*  881 */     List<Finder> enabledRowFinders = new ArrayList(rowFinders.size());
/*  882 */     for (RowFinder rowFinder : rowFinders) {
/*  883 */       Finder finder = new Finder(rowFinder, this);
/*  884 */       if (finder.isEnabled()) {
/*  885 */         enabledRowFinders.add(finder);
/*      */       }
/*      */     }
/*  888 */     return enabledRowFinders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> getSearchAttributeNames()
/*      */   {
/*  897 */     return new ArrayList(this.searchAttributeNames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract List<ResourceProperty> getProperties();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   JUCtrlActionBinding getActionBinding(String bindingName)
/*      */   {
/*  913 */     JUCtrlActionBinding action = null;
/*  914 */     DCBindingContainer bindingContainer = (DCBindingContainer)this.treeNode.getBindings();
/*  915 */     DCControlBinding actionBinding = bindingContainer.findCtrlBinding(bindingName);
/*  916 */     if ((actionBinding instanceof JUCtrlActionBinding)) {
/*  917 */       action = (JUCtrlActionBinding)actionBinding;
/*      */     }
/*      */     
/*  920 */     return action;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   List<JUCtrlActionBinding> getActionBindings()
/*      */   {
/*  928 */     List<JUCtrlActionBinding> bindings = new ArrayList();
/*  929 */     DCBindingContainer bindingContainer = (DCBindingContainer)this.treeNode.getBindings();
/*  930 */     for (Object controlBinding : bindingContainer.getCtrlBindingList()) {
/*  931 */       if ((controlBinding instanceof JUCtrlActionBinding)) {
/*  932 */         bindings.add((JUCtrlActionBinding)controlBinding);
/*      */       }
/*      */     }
/*  935 */     return bindings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<Action> getActions()
/*      */   {
/*  944 */     List<Action> actions = null;
/*  945 */     if (isItem()) {
/*  946 */       actions = getItemActions();
/*  947 */     } else if (isCollection()) {
/*  948 */       actions = getCollectionActions();
/*      */     }
/*  950 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   List<Action> getItemActions()
/*      */   {
/*  959 */     List<Action> actions = getItemDefaultActions();
/*  960 */     actions.addAll(getItemCustomActions());
/*      */     
/*  962 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   List<Action> getItemDefaultActions()
/*      */   {
/*  971 */     List<Action> actions = getUnboundItemDefaultActions(isLOV());
/*  972 */     for (Action action : actions) {
/*  973 */       action.bindToResource(this);
/*      */     }
/*  975 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   List<Action> getCollectionActions()
/*      */   {
/*  984 */     List<Action> actions = getCollectionDefaultActions();
/*  985 */     actions.addAll(getCollectionCustomActions());
/*  986 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   List<Action> getCollectionDefaultActions()
/*      */   {
/*  996 */     List<Action> actions = getUnboundCollectionDefaultActions(isLOV());
/*  997 */     for (Action action : actions) {
/*  998 */       action.bindToResource(this);
/*      */     }
/* 1000 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   List<Action> getCollectionCustomActions()
/*      */   {
/* 1008 */     return getCustomActions(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   List<Action> getItemCustomActions()
/*      */   {
/* 1017 */     return getCustomActions(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<Action> getCustomActions(boolean isItem)
/*      */   {
/* 1027 */     Set<String> filter = ActionType.DEFAULT_ACTION_BINDING_NAMES;
/* 1028 */     List<Action> actions = new ArrayList();
/* 1029 */     for (JUCtrlActionBinding actionBinding : getActionBindings()) {
/* 1030 */       if (!filter.contains(actionBinding.getName())) {
/* 1031 */         Action action = new Action(this, actionBinding);
/* 1032 */         if (isItem) {
/* 1033 */           if (action.isResourceItemAction()) {
/* 1034 */             actions.add(action);
/*      */           }
/*      */         }
/* 1037 */         else if (action.isResourceCollectionAction()) {
/* 1038 */           actions.add(action);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1044 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static List<Action> getUnboundCollectionDefaultActions(JUCtrlHierTypeBinding parentTypeBinding, String accessor, JUCtrlHierTypeBinding typeBinding)
/*      */   {
/* 1055 */     return getUnboundCollectionDefaultActions(isLOV(parentTypeBinding, accessor, typeBinding));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static List<Action> getUnboundItemDefaultActions(JUCtrlHierTypeBinding parentTypeBinding, String accessor, JUCtrlHierTypeBinding typeBinding)
/*      */   {
/* 1066 */     return getUnboundItemDefaultActions(isLOV(parentTypeBinding, accessor, typeBinding));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static List<Action> getUnboundCollectionDefaultActions(boolean isLOV)
/*      */   {
/* 1076 */     List<Action> actions = new ArrayList();
/* 1077 */     actions.add(new GetAction(ResourceEntityType.RESOURCECOLLECTION));
/* 1078 */     if (!isLOV) {
/* 1079 */       actions.add(new CreateAction());
/*      */     }
/*      */     
/* 1082 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static List<Action> getUnboundItemDefaultActions(boolean isLOV)
/*      */   {
/* 1092 */     List<Action> actions = new ArrayList();
/* 1093 */     actions.add(new GetAction(ResourceEntityType.RESOURCEITEM));
/* 1094 */     if (!isLOV) {
/* 1095 */       actions.add(new UpdateAction());
/* 1096 */       actions.add(new ReplaceAction());
/* 1097 */       actions.add(new DeleteAction());
/*      */     }
/*      */     
/* 1100 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAttributes(Map<String, Object> attributes)
/*      */   {
/* 1110 */     UpdateAction updateAction = new UpdateAction(this);
/* 1111 */     updateAction.setParameters(attributes);
/* 1112 */     updateAction.execute();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void replaceAttributes(Map<String, Object> attributes)
/*      */   {
/* 1120 */     ReplaceAction replaceAction = new ReplaceAction(this);
/* 1121 */     replaceAction.setParameters(attributes);
/* 1122 */     replaceAction.execute();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, Cardinality> getCardinalityMap()
/*      */   {
/* 1130 */     return getCardinalityMap(getNestedResourceNames(), getVO());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Map<String, Cardinality> getCardinalityMap(Collection<String> accessorNames, ViewObject vo)
/*      */   {
/* 1140 */     if (accessorNames.isEmpty()) {
/* 1141 */       return Collections.emptyMap();
/*      */     }
/* 1143 */     Map<String, Cardinality> cardinalityMap = new HashMap(accessorNames.size());
/* 1144 */     for (String accessorName : accessorNames) {
/* 1145 */       cardinalityMap.put(accessorName, createCardinality(accessorName, vo));
/*      */     }
/* 1147 */     return cardinalityMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Cardinality createCardinality(String accessorName, ViewObject vo)
/*      */   {
/* 1157 */     ViewAttributeDefImpl attributeDef = (ViewAttributeDefImpl)vo.findAttributeDef(accessorName);
/* 1158 */     ViewLinkDefImpl viewLinkDefImpl = attributeDef.findViewLinkDefImpl();
/* 1159 */     if (viewLinkDefImpl == null) {
/* 1160 */       return null;
/*      */     }
/*      */     
/*      */     AssociationEnd destination;
/*      */     AssociationEnd source;
/*      */     AssociationEnd destination;
/* 1166 */     if ((viewLinkDefImpl.getSourceOwner().equals(((ViewObjectImpl)vo).getDef())) || (viewLinkDefImpl.getSourceOwner().isBaseDefFor(((ViewObjectImpl)vo).getDef())))
/*      */     {
/* 1168 */       AssociationEnd source = viewLinkDefImpl.getSourceEnd();
/* 1169 */       destination = viewLinkDefImpl.getDestinationEnd();
/*      */     }
/*      */     else
/*      */     {
/* 1173 */       source = viewLinkDefImpl.getDestinationEnd();
/* 1174 */       destination = viewLinkDefImpl.getSourceEnd();
/*      */     }
/* 1176 */     return new Cardinality(source.getCardinality(), destination.getCardinality(), source.getAttributeDefImpls(), destination.getAttributeDefImpls());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract List<Link> getLinks(String paramString);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract Link getSelfLink(String paramString);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getLovNames()
/*      */   {
/* 1200 */     Set<String> lovNames = new HashSet();
/*      */     
/* 1202 */     for (Attribute attribute : getAttributes()) {
/* 1203 */       if (attribute.hasLov()) {
/* 1204 */         String listVOName = attribute.getAttrDef().getListBindingDef().getListVOName();
/* 1205 */         lovNames.add(listVOName);
/*      */       }
/*      */     }
/* 1208 */     return lovNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLOV()
/*      */   {
/* 1217 */     Resource parentResource = getParent();
/* 1218 */     if (isItem()) {
/* 1219 */       parentResource = parentResource.getParent();
/*      */     }
/*      */     
/* 1222 */     return (parentResource != null) && (isLOV(parentResource.getHierTypeBinding(), getName(), getHierTypeBinding()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isLOV(JUCtrlHierTypeBinding parentTypeBinding, String accessor, JUCtrlHierTypeBinding typeBinding)
/*      */   {
/* 1234 */     return typeBinding.getType(parentTypeBinding, accessor, null) == JUCtrlHierTypeBinding.Type.LOV;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFlexExtension()
/*      */   {
/* 1243 */     ViewObject vo = getVO();
/* 1244 */     return (vo != null) && ("true".equals(vo.getProperty("_FND_FLEX_INTEGRATED_EXTENSION")));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDiscrAttribute()
/*      */   {
/* 1252 */     return getHierTypeBinding().getDiscrColumnName();
/*      */   }
/*      */   
/*      */   static boolean isPolymorphic(JUCtrlHierTypeBinding typeBinding, JUCtrlHierTypeBinding parentTypeBinding, String accessorName, Row row) {
/* 1256 */     return typeBinding.getType(parentTypeBinding, accessorName, row) == JUCtrlHierTypeBinding.Type.POLYMORPHIC;
/*      */   }
/*      */   
/*      */   public ActionResult executeAction(Action action) {
/* 1260 */     if (action.isBoundToResource()) {
/* 1261 */       if (!action.getResource().getName().equals(getName())) {
/* 1262 */         throw new JboException("Failed to execute action " + action.getName() + ". Reason: Action is not bound to resource " + getName() + ".");
/*      */       }
/*      */     }
/*      */     else {
/* 1266 */       action.bindToResource(this);
/*      */     }
/* 1268 */     return action.execute();
/*      */   }
/*      */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Resource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */