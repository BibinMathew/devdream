/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.Map;
/*    */ import oracle.adf.model.binding.DCBindingContainer;
/*    */ import oracle.jbo.uicli.binding.JUCtrlHierBinding;
/*    */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResourceReferenceFactory
/*    */ {
/*    */   private static final String INTERNAL_RESOURCE_REF_TYPE = "Internal";
/*    */   private static final String EXTERNAL_URL_REF_TYPE = "External";
/*    */   private static final String CONNECTION_ID_ATTR = "connectionId";
/*    */   private static final String VALUE_ATTR = "value";
/*    */   private static final String TYPE_ATTR = "PropertyType";
/*    */   private static final String RESOURCE_REF_ELEM = "ResourceRef";
/*    */   
/*    */   static ResourceReference createResourceReference(JUCtrlHierBinding tree, String basePath, JUCtrlHierTypeBinding nodeType, String resourceId)
/*    */   {
/* 33 */     Map resourceReferenceMap = null;
/* 34 */     resourceReferenceMap = (Map)nodeType.getRawPropertyValue("ResourceRef");
/*    */     
/* 36 */     return createResourceReference(tree.getBindingContainer(), basePath, resourceId, resourceReferenceMap);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static ResourceReference createResourceReference(DCBindingContainer bindingContainer, String basePath, String resourceId, Map resourceReferenceMap)
/*    */   {
/* 45 */     if (resourceReferenceMap == null) {
/* 46 */       return null;
/*    */     }
/* 48 */     ResourceReference resourceReference = null;
/*    */     
/* 50 */     String type = (String)resourceReferenceMap.get("PropertyType");
/* 51 */     String value = (String)resourceReferenceMap.get("value");
/*    */     
/* 53 */     if (type.equals("External")) {
/* 54 */       String connectionId = (String)resourceReferenceMap.get("connectionId");
/* 55 */       resourceReference = new ExternalResourceRef(bindingContainer, connectionId, value);
/* 56 */     } else if (type.equals("Internal")) {
/* 57 */       resourceReference = new InternalResourceRef(resourceId, basePath, value);
/*    */     }
/* 59 */     return resourceReference;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceReferenceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */