/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.exception.InvalidAttributeException;
/*     */ import oracle.adf.model.RegionBinding;
/*     */ import oracle.adf.model.binding.DCIteratorBinding;
/*     */ import oracle.binding.ControlBinding;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeList;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.Key;
/*     */ import oracle.jbo.RowSet;
/*     */ import oracle.jbo.ViewObject;
/*     */ import oracle.jbo.server.ViewRowImpl;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceItem
/*     */   extends Resource
/*     */ {
/*     */   public static final String ITEM_ATTR = "item";
/*     */   
/*     */   public static abstract enum PropertyType
/*     */   {
/*  37 */     CHANGE_INDICATOR("changeIndicator");
/*     */     
/*     */ 
/*     */ 
/*     */     private final String name;
/*     */     
/*     */ 
/*     */ 
/*     */     private PropertyType(String name)
/*     */     {
/*  47 */       this.name = name;
/*     */     }
/*     */     
/*     */ 
/*     */     abstract ResourceProperty getValue(ResourceItem paramResourceItem);
/*     */   }
/*     */   
/*     */   ResourceItem(ResourceTree tree, JUCtrlHierNodeBinding treeNode)
/*     */   {
/*  56 */     super(tree, treeNode);
/*  57 */     if (Resource.isCollection(treeNode)) {
/*  58 */       throw new IllegalArgumentException("The provided node is a folder node not an item node");
/*     */     }
/*     */   }
/*     */   
/*     */   public String createKeyString()
/*     */   {
/*  64 */     Finder finder = getFinder();
/*  65 */     if (finder != null) {
/*  66 */       return createRowFinderKeyString(finder.getRowFinder());
/*     */     }
/*  68 */     return createVOKeyString(getNode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceCollection getChild(String childCollectionName)
/*     */   {
/*  78 */     JUCtrlHierNodeBinding node = getNode();
/*  79 */     JUCtrlHierNodeBinding accessorNode = node.findChildNodeByKey(new Key(new Object[] { childCollectionName }));
/*  80 */     if (accessorNode == null) {
/*  81 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  85 */     if (accessorNode.getChildIteratorBinding().getRowSetIterator() == null) {
/*  86 */       RowSet rs = createAccessorRS(node, childCollectionName);
/*  87 */       if (rs != null) {
/*  88 */         accessorNode.getChildIteratorBinding().bindRowSetIterator(rs, false);
/*     */       }
/*     */     }
/*     */     
/*  92 */     return new ResourceCollection(getTree(), accessorNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RowSet createAccessorRS(JUCtrlHierNodeBinding parentNode, String accessorName)
/*     */   {
/* 102 */     byte attributeKind = parentNode.getViewObject().findAttributeDef(accessorName).getAttributeKind();
/*     */     
/* 104 */     switch (attributeKind)
/*     */     {
/*     */     case 2: 
/*     */     case 6: 
/* 108 */       return ((ViewRowImpl)parentNode.getRow()).findOrCreateViewLinkAccessorRS(accessorName);
/*     */     
/*     */ 
/*     */     case 7: 
/* 112 */       return ((ViewRowImpl)parentNode.getRow()).findOrCreateViewAccessorRS(accessorName);
/*     */     }
/*     */     
/*     */     
/* 116 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void delete()
/*     */   {
/* 125 */     new DeleteAction(this).execute();
/*     */   }
/*     */   
/*     */ 
/*     */   public Attribute getAttribute(String name)
/*     */   {
/* 131 */     ControlBinding controlBinding = getNode().getBindings().getControlBinding(name);
/* 132 */     if ((controlBinding == null) && (!"links".equals(name))) {
/* 133 */       throw new InvalidAttributeException(name);
/*     */     }
/* 135 */     return controlBinding == null ? null : createAttribute((JUCtrlValueBinding)controlBinding);
/*     */   }
/*     */   
/*     */   public List<ResourceProperty> getProperties()
/*     */   {
/* 140 */     return getProperties(EnumSet.allOf(PropertyType.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ResourceProperty> getProperties(EnumSet<PropertyType> properties)
/*     */   {
/* 149 */     List<ResourceProperty> resourceProperties = new ArrayList(properties.size());
/* 150 */     for (PropertyType property : properties) {
/* 151 */       ResourceProperty resourceProperty = property.getValue(this);
/* 152 */       if (resourceProperty != null) {
/* 153 */         resourceProperties.add(resourceProperty);
/*     */       }
/*     */     }
/* 156 */     return resourceProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributes(AttributeList nameValuePairs)
/*     */   {
/* 165 */     if (nameValuePairs.getAttributeCount() == 0) {
/* 166 */       return;
/*     */     }
/* 168 */     String[] names = nameValuePairs.getAttributeNames();
/* 169 */     Object[] values = nameValuePairs.getAttributeValues();
/*     */     
/* 171 */     for (int i = 0; i < nameValuePairs.getAttributeCount(); i++) {
/* 172 */       setAttribute(names[i], values[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(String attributeName, Object value)
/*     */   {
/* 182 */     Attribute attribute = getAttribute(attributeName);
/*     */     
/* 184 */     if (attribute == null) {
/* 185 */       throw new JboException("Could not find the attribute. Name: " + attributeName);
/*     */     }
/* 187 */     attribute.setValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResourceItem asItem(Resource resource)
/*     */   {
/* 196 */     return (resource instanceof ResourceItem) ? (ResourceItem)resource : null;
/*     */   }
/*     */   
/*     */   public List<Attribute> getAttributes()
/*     */   {
/* 201 */     List controlBindings = getNode().getBindings().getAttributeBindings();
/* 202 */     if ((controlBindings == null) || (controlBindings.isEmpty())) {
/* 203 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 206 */     List<Attribute> attributes = new ArrayList(controlBindings.size());
/* 207 */     for (Object controlBinding : controlBindings) {
/* 208 */       JUCtrlValueBinding valb = (JUCtrlValueBinding)controlBinding;
/* 209 */       Attribute attr = createAttribute(valb);
/* 210 */       if (attr != null) {
/* 211 */         attributes.add(attr);
/*     */       }
/*     */     }
/*     */     
/* 215 */     return attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Attribute createAttribute(JUCtrlValueBinding valueBinding)
/*     */   {
/* 224 */     Attribute attribute = new Attribute(getVO(), valueBinding);
/* 225 */     return attribute.isDisplayable() ? attribute : null;
/*     */   }
/*     */   
/*     */   public ResourceCollection getParent()
/*     */   {
/* 230 */     JUCtrlHierNodeBinding parent = getNode().getParent();
/* 231 */     if (parent == null) {
/* 232 */       return null;
/*     */     }
/* 234 */     return new ResourceCollection(getTree(), parent);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<Link> getLinks(String basePath)
/*     */   {
/* 240 */     Path resourcePath = getPath(basePath);
/* 241 */     List<ResourceProperty> properties = getProperties();
/*     */     
/* 243 */     List<Link> links = new LinkedList();
/* 244 */     links.add(createSelfLink(resourcePath, properties));
/* 245 */     links.add(createCanonicalLink(resourcePath, basePath, properties));
/*     */     
/* 247 */     Link parentLink = getParentLink(basePath);
/* 248 */     if (parentLink != null) {
/* 249 */       links.add(parentLink);
/*     */     }
/*     */     
/* 252 */     links.addAll(getNestedResourceLinks(resourcePath));
/*     */     
/* 254 */     return links;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Link> getNestedResourceLinks(String basePath)
/*     */   {
/* 264 */     return getNestedResourceLinks(getPath(basePath));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Link> getNestedResourceLinks(Path path)
/*     */   {
/* 273 */     Set<String> allNestedResources = getNestedResourceNames();
/* 274 */     List<Link> nestedResourceLinks = new ArrayList(allNestedResources.size());
/*     */     
/* 276 */     for (String lovName : getLovNames()) {
/* 277 */       allNestedResources.remove(lovName);
/* 278 */       nestedResourceLinks.add(new Link(lovName, "lov", new Path(path, Arrays.asList(new String[] { "lov", lovName })), Link.Kind.COLLECTION));
/*     */     }
/*     */     
/*     */ 
/* 282 */     for (String childResource : allNestedResources) {
/* 283 */       nestedResourceLinks.add(new Link(childResource, "child", new Path(path, Arrays.asList(new String[] { "child", childResource })), Link.Kind.COLLECTION));
/*     */     }
/*     */     
/*     */ 
/* 287 */     return nestedResourceLinks;
/*     */   }
/*     */   
/*     */   public Link getSelfLink(String basePath)
/*     */   {
/* 292 */     return createSelfLink(getPath(basePath), getProperties());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Link createSelfLink(Path resourcePath, List<ResourceProperty> properties)
/*     */   {
/* 302 */     return createLink("self", resourcePath, properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Link createLink(String rel, Path resourcePath, List<ResourceProperty> properties)
/*     */   {
/* 313 */     Link link = new Link(getName(), rel, resourcePath, Link.Kind.ITEM);
/* 314 */     if (!properties.isEmpty()) {
/* 315 */       link.setProperties(properties);
/*     */     }
/*     */     
/* 318 */     return link;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Link getCanonicalLink(String basePath)
/*     */   {
/* 327 */     return createCanonicalLink(getPath(basePath), basePath, getProperties());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Link createCanonicalLink(Path path, String basePath, List<ResourceProperty> resourceProperties)
/*     */   {
/* 337 */     List<ResourceProperty> properties = Collections.emptyList();
/* 338 */     Path resourcePath = null;
/* 339 */     ResourceReference reference = getResourceReference(basePath);
/* 340 */     if (reference != null) {
/* 341 */       resourcePath = reference.getResourceReferencePath();
/* 342 */       if (reference.getType() == ResourceReference.Type.INTERNAL) {
/* 343 */         properties = resourceProperties;
/*     */       }
/*     */     } else {
/* 346 */       resourcePath = path;
/*     */     }
/*     */     
/* 349 */     return createLink("canonical", resourcePath, properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Link getParentLink(String basePath)
/*     */   {
/* 359 */     if (!isTopLevel()) {
/* 360 */       Resource itemParent = getParent().getParent();
/* 361 */       return new Link(itemParent.getName(), "parent", itemParent.getPath(basePath), Link.Kind.ITEM);
/*     */     }
/*     */     
/* 364 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */