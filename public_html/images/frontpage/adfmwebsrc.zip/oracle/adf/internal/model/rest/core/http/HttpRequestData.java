/*     */ package oracle.adf.internal.model.rest.core.http;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpRequestData
/*     */ {
/*     */   private final String requestContentType;
/*     */   private final String contextPath;
/*     */   private final String handlerPath;
/*     */   private final String pathInfo;
/*     */   private final Map<String, String[]> parameterMap;
/*     */   private final Map<String, List<String>> requestHeaders;
/*     */   private final InputStream in;
/*     */   private final Locale locale;
/*     */   private final HttpMethod.Type httpMethodType;
/*     */   private static final String QUERY_PARAMETER_SEPARATOR = "&";
/*     */   private static final String QUERY_PARAMETER_VALUE_SEPARATOR = "=";
/*     */   
/*     */   public HttpRequestData(String requestContentType, String contextPath, String handlerPath, String pathInfo, Map<String, String[]> parameterMap, Map<String, List<String>> requestHeaders, InputStream in, Locale locale, HttpMethod.Type httpMethodType)
/*     */   {
/*  58 */     this.requestContentType = requestContentType;
/*  59 */     this.contextPath = contextPath;
/*  60 */     this.handlerPath = handlerPath;
/*  61 */     this.pathInfo = pathInfo;
/*  62 */     this.parameterMap = Collections.unmodifiableMap(parameterMap);
/*  63 */     this.requestHeaders = Collections.unmodifiableMap(requestHeaders);
/*  64 */     this.in = in;
/*  65 */     this.locale = locale;
/*  66 */     this.httpMethodType = httpMethodType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestContentType()
/*     */   {
/*  75 */     return this.requestContentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/*  84 */     return this.contextPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServletPath()
/*     */   {
/*  92 */     return this.handlerPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathInfo()
/*     */   {
/* 100 */     return this.pathInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 108 */     return this.parameterMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, List<String>> getRequestHeaders()
/*     */   {
/* 116 */     return this.requestHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getIn()
/*     */   {
/* 124 */     return this.in;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 132 */     return this.locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMethod.Type getHttpMethodType()
/*     */   {
/* 140 */     return this.httpMethodType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String[]> getQueryParameters(URI uri)
/*     */   {
/* 149 */     String query = uri.getQuery();
/* 150 */     Map<String, String[]> paramMap = new HashMap();
/* 151 */     if (query != null) {
/* 152 */       String[] split = query.split("&");
/* 153 */       for (String token : split) {
/* 154 */         int idx = token.indexOf("=");
/* 155 */         String key = token.substring(0, idx);
/* 156 */         String value = token.substring(idx + 1);
/* 157 */         if (paramMap.containsKey(key))
/*     */         {
/* 159 */           String[] values = (String[])paramMap.get(key);
/* 160 */           String[] newValues = (String[])Arrays.copyOf(values, values.length + 1);
/* 161 */           newValues[(newValues.length - 1)] = value;
/* 162 */           paramMap.put(key, newValues);
/*     */         }
/*     */         else
/*     */         {
/* 166 */           paramMap.put(key, new String[] { value });
/*     */         }
/*     */       }
/*     */     }
/* 170 */     return paramMap;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\HttpRequestData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */