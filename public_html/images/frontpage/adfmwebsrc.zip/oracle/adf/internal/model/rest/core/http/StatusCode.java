/*    */ package oracle.adf.internal.model.rest.core.http;
/*    */ 
/*    */ public enum StatusCode
/*    */ {
/*  5 */   OK(200), 
/*  6 */   CREATED(201), 
/*  7 */   NO_CONTENT(204), 
/*  8 */   NOT_MODIFIED(304), 
/*  9 */   BAD_REQUEST(400), 
/* 10 */   UNAUTHORIZED(401), 
/* 11 */   NOT_FOUND(404), 
/* 12 */   NOT_ACCEPTABLE(406), 
/* 13 */   PRECONDITION_FAILED(412), 
/* 14 */   UNSUPPORTED_MEDIA_TYPE(415), 
/* 15 */   INTERNAL_SERVER_ERROR(500), 
/* 16 */   NOT_IMPLEMENTED(501);
/*    */   
/*    */   final int code;
/*    */   
/* 20 */   private StatusCode(int code) { this.code = code; }
/*    */   
/*    */   public int getCode()
/*    */   {
/* 24 */     return this.code;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\StatusCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */