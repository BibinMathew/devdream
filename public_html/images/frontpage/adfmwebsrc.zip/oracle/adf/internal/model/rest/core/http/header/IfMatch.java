/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class IfMatch implements Header
/*    */ {
/*    */   public static final String NAME = "If-Match";
/*    */   public static final String ANY_ETAG = "*";
/*  9 */   private boolean anyETagMatcher = false;
/*    */   private List<EntityTag> entityTags;
/*    */   private String value;
/*    */   
/*    */   public IfMatch(String value) {
/* 14 */     this.value = value;
/* 15 */     if (value.equals("*")) {
/* 16 */       this.anyETagMatcher = true;
/*    */     } else {
/* 18 */       this.entityTags = EntityTag.parseEntityTags(value);
/*    */     }
/*    */   }
/*    */   
/*    */   public IfMatch(EntityTag entityTag) {
/* 23 */     this.entityTags = new java.util.ArrayList(1);
/* 24 */     this.entityTags.add(entityTag);
/* 25 */     this.value = EntityTag.format(this.entityTags);
/*    */   }
/*    */   
/*    */   public IfMatch(List<EntityTag> entityTags) {
/* 29 */     this.entityTags = entityTags;
/* 30 */     this.value = EntityTag.format(this.entityTags);
/*    */   }
/*    */   
/*    */   public boolean isAnyETagMatcher() {
/* 34 */     return this.anyETagMatcher;
/*    */   }
/*    */   
/*    */   public List<EntityTag> getEntityTags() {
/* 38 */     return this.entityTags;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 42 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 47 */     return this.value;
/*    */   }
/*    */   
/*    */   public boolean proccessMatch(EntityTag currentEntityTag, boolean strongValidation) {
/* 51 */     if (currentEntityTag == null) {
/* 52 */       return false;
/*    */     }
/* 54 */     if (this.anyETagMatcher) {
/* 55 */       return true;
/*    */     }
/* 57 */     boolean match = false;
/* 58 */     for (EntityTag entityTag : this.entityTags) {
/* 59 */       if (strongValidation) {
/* 60 */         match = entityTag.strongValidateWith(currentEntityTag);
/*    */       } else {
/* 62 */         match = entityTag.weakValidateWith(currentEntityTag);
/*    */       }
/* 64 */       if (match) {
/*    */         break;
/*    */       }
/*    */     }
/* 68 */     return match;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 73 */     return "If-Match";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\IfMatch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */