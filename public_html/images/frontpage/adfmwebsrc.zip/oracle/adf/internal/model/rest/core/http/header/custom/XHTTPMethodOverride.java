/*    */ package oracle.adf.internal.model.rest.core.http.header.custom;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.http.header.Header;
/*    */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XHTTPMethodOverride
/*    */   implements Header
/*    */ {
/*    */   public static final String NAME = "X-HTTP-Method-Override";
/*    */   private final String value;
/*    */   
/*    */   public XHTTPMethodOverride(String value)
/*    */   {
/* 27 */     this.value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public XHTTPMethodOverride(Map<String, List<String>> headers)
/*    */   {
/* 35 */     String value = null;
/* 36 */     List<String> header = (List)headers.get("X-HTTP-Method-Override");
/* 37 */     if ((header != null) && (!header.isEmpty())) {
/* 38 */       value = (String)header.get(0);
/*    */     }
/* 40 */     this.value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HttpMethod.Type getHttpType()
/*    */   {
/* 48 */     if (this.value == null) {
/* 49 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 53 */       return HttpMethod.Type.valueOf(this.value);
/*    */     } catch (IllegalArgumentException ex) {
/* 55 */       throw new IllegalArgumentException("The provided HTTP method is not supported. HTTP method: " + this.value, ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 61 */     return "X-HTTP-Method-Override";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\custom\XHTTPMethodOverride.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */