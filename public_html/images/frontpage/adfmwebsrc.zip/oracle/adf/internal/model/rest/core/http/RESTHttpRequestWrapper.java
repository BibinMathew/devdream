/*     */ package oracle.adf.internal.model.rest.core.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import oracle.adf.internal.model.rest.core.common.Condition;
/*     */ import oracle.adf.internal.model.rest.core.common.ConditionType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceContext;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.exception.InvalidHeaderValueException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceException;
/*     */ import oracle.adf.internal.model.rest.core.http.exception.HTTPResourceException;
/*     */ import oracle.adf.internal.model.rest.core.http.header.ContentEncoding;
/*     */ import oracle.adf.internal.model.rest.core.http.header.EffectiveOf;
/*     */ import oracle.adf.internal.model.rest.core.http.header.EntityTag;
/*     */ import oracle.adf.internal.model.rest.core.http.header.IfMatch;
/*     */ import oracle.adf.internal.model.rest.core.http.header.IfNoneMatch;
/*     */ import oracle.adf.internal.model.rest.core.http.header.custom.XHTTPMethodOverride;
/*     */ import oracle.adf.internal.model.rest.core.http.media.ContentCodingHandler;
/*     */ import oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler;
/*     */ import oracle.adf.internal.model.rest.core.http.media.MediaTypeHandler;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod.Type;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethodFactory;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethodInfo;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpOperationType;
/*     */ import oracle.adf.internal.model.rest.core.http.payload.ContentCodingProcessor;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadFactory;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.http.ServletADFContext;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*     */ 
/*     */ public final class RESTHttpRequestWrapper
/*     */ {
/*     */   private static final String HTTP_BASE_PATH_FORMAT = "%s%s";
/*     */   private static final String MULTIPLE_HEADER_VALUES_SEPARATOR = ", ";
/*     */   private final Map<String, List<String>> requestHeaders;
/*     */   private final ResourceContext resourceContext;
/*     */   private final HttpMethod.Type httpMethodType;
/*     */   private final HttpOperationType operationType;
/*     */   private final ContentTypeHandler requestContentTypeHandler;
/*     */   
/*     */   public RESTHttpRequestWrapper(HttpRequestData requestData)
/*     */     throws IOException, HTTPResourceException
/*     */   {
/*  55 */     this(requestData.getRequestContentType(), requestData.getContextPath(), requestData.getServletPath(), requestData.getPathInfo(), requestData.getParameterMap(), requestData.getRequestHeaders(), requestData.getIn(), requestData.getLocale(), requestData.getHttpMethodType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RESTHttpRequestWrapper(String requestContentType, String contextPath, String handlerPath, String pathInfo, Map<String, String[]> parameterMap, Map<String, List<String>> requestHeaders, InputStream in, Locale locale, HttpMethod.Type httpMethodType)
/*     */     throws IOException, HTTPResourceException
/*     */   {
/*  82 */     String httpBasePath = null;
/*     */     
/*  84 */     ADFContext adfContext = ADFContext.findCurrent();
/*  85 */     if ((adfContext instanceof ServletADFContext)) {
/*  86 */       String baseURL = ((ServletADFContext)adfContext).getBaseURL().toString();
/*  87 */       httpBasePath = String.format("%s%s", new Object[] { baseURL, handlerPath });
/*     */     } else {
/*  89 */       httpBasePath = String.format("%s%s", new Object[] { contextPath, handlerPath });
/*     */     }
/*     */     
/*  92 */     this.requestHeaders = requestHeaders;
/*  93 */     this.resourceContext = new ResourceContext(httpBasePath, pathInfo, parameterMap, locale, in);
/*  94 */     this.resourceContext.setProperties(createRequestProperties(this.requestHeaders));
/*  95 */     this.resourceContext.setEntityContentMap(HTTPRESTUtil.ENTITY_CONTENT_MAPPING);
/*  96 */     this.resourceContext.setPrecondition(createPrecondition());
/*  97 */     setEffectiveDateRangeProperties();
/*     */     
/*  99 */     this.httpMethodType = determineHttpMethodType(httpMethodType);
/*     */     
/* 101 */     InputStream configuredInput = in;
/* 102 */     this.requestContentTypeHandler = createRequestContentTypeHandler(requestContentType);
/* 103 */     if (this.requestContentTypeHandler != null) {
/* 104 */       configuredInput = configureRequestContentCoding(configuredInput);
/* 105 */       this.resourceContext.setInputStream(configuredInput);
/* 106 */       if (this.requestContentTypeHandler.getEntityType() != null) {
/* 107 */         this.resourceContext.setParserFactory(PayloadFactory.createParserFactory(this.requestContentTypeHandler.getPayloadType(), configuredInput));
/*     */       }
/*     */     }
/* 110 */     HttpMethodInfo httpMethodInfo = new HttpMethodInfo(this.resourceContext.getVerb(), this.requestContentTypeHandler);
/*     */     try
/*     */     {
/* 113 */       HttpMethod method = HttpMethodFactory.createHTTPMethod(this.httpMethodType, httpMethodInfo);
/* 114 */       this.operationType = (method == null ? null : method.getOperationType());
/*     */     } catch (ResourceException e) {
/* 116 */       throw HTTPRESTUtil.createHTTPResourceExceptionInstance(e, getRequestInfo(), null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceContext getResourceContext()
/*     */   {
/* 127 */     return this.resourceContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PayloadType getPayloadType()
/*     */   {
/* 135 */     PayloadType payloadType = null;
/* 136 */     if (this.requestContentTypeHandler != null) {
/* 137 */       payloadType = this.requestContentTypeHandler.getPayloadType();
/*     */     }
/* 139 */     return payloadType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private InputStream configureRequestContentCoding(InputStream originalInput)
/*     */     throws IOException, HTTPResourceException
/*     */   {
/* 150 */     InputStream in = originalInput;
/* 151 */     String contentEncodingValue = getRequestHeader("Content-Encoding");
/* 152 */     if (contentEncodingValue != null) {
/* 153 */       ContentEncoding contentEncoding = new ContentEncoding(contentEncodingValue);
/* 154 */       ContentCodingProcessor codingProcessor = ContentCodingHandler.createContentCodingProcessor(contentEncoding.getContentCoding());
/*     */       
/* 156 */       if (codingProcessor == null) {
/* 157 */         throw new HTTPResourceException(StatusCode.UNSUPPORTED_MEDIA_TYPE, getRequestInfo().toString());
/*     */       }
/* 159 */       in = codingProcessor.wrapInput(in);
/*     */     }
/* 161 */     return in;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getRequestHeader(String headerName)
/*     */   {
/* 170 */     String header = null;
/* 171 */     List<String> headerValues = (List)this.requestHeaders.get(headerName);
/* 172 */     if (headerValues != null) {
/* 173 */       header = (String)headerValues.get(0);
/*     */     }
/*     */     
/* 176 */     return header;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpOperationType getHttpOperationType()
/*     */   {
/* 184 */     return this.operationType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ContentTypeHandler createRequestContentTypeHandler(String requestContentType)
/*     */   {
/* 193 */     ContentTypeHandler requestContentTypeHandler = null;
/* 194 */     if (requestContentType != null) {
/* 195 */       requestContentTypeHandler = MediaTypeHandler.createContentTypeHandler(requestContentType);
/*     */     }
/* 197 */     return requestContentTypeHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMethod.Type getHttpMethod()
/*     */   {
/* 205 */     return this.httpMethodType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final RESTHttpRequestInfo getRequestInfo()
/*     */   {
/* 213 */     return new RESTHttpRequestInfo(this.resourceContext.getPathInfo(), this.httpMethodType, this.requestHeaders);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, String> createRequestProperties(Map<String, List<String>> requestHeaders)
/*     */   {
/* 222 */     HashMap<String, String> properties = new HashMap(requestHeaders.size());
/* 223 */     Set<Map.Entry<String, List<String>>> entries = requestHeaders.entrySet();
/*     */     
/* 225 */     for (Map.Entry<String, List<String>> entry : entries) {
/* 226 */       properties.put(entry.getKey(), convertMultipleHeaderValuesToSingle((List)entry.getValue()));
/*     */     }
/* 228 */     return properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String convertMultipleHeaderValuesToSingle(List<String> values)
/*     */   {
/* 238 */     String firstValue = (String)values.get(0);
/* 239 */     if (values.size() == 1) {
/* 240 */       return firstValue;
/*     */     }
/* 242 */     StringBuilder sb = new StringBuilder(firstValue);
/* 243 */     for (int i = 1; i < values.size(); i++) {
/* 244 */       sb.append(", ").append((String)values.get(i));
/*     */     }
/*     */     
/* 247 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Condition createPrecondition()
/*     */   {
/* 256 */     Map<ConditionType, List<String>> conditions = new HashMap();
/*     */     
/* 258 */     String ifMatchHeader = getRequestHeader("If-Match");
/* 259 */     if (ifMatchHeader != null) {
/*     */       try {
/* 261 */         IfMatch ifMatch = new IfMatch(ifMatchHeader);
/* 262 */         if (ifMatch.isAnyETagMatcher()) {
/* 263 */           conditions.put(ConditionType.MATCH, null);
/*     */         } else {
/* 265 */           List<String> states = createStates(ifMatch.getEntityTags());
/* 266 */           conditions.put(ConditionType.MATCH, states);
/*     */         }
/*     */       } catch (IllegalArgumentException ex) {
/* 269 */         InvalidHeaderValueException headerException = new InvalidHeaderValueException("If-Match", ifMatchHeader);
/*     */         
/* 271 */         headerException.setExceptions(new Exception[] { ex });
/* 272 */         throw headerException;
/*     */       }
/*     */     }
/*     */     
/* 276 */     String ifNoneMatchHeader = getRequestHeader("If-None-Match");
/* 277 */     if (ifNoneMatchHeader != null) {
/*     */       try {
/* 279 */         IfNoneMatch ifNoneMatch = new IfNoneMatch(ifNoneMatchHeader);
/* 280 */         if (ifNoneMatch.isAnyETagMatcher()) {
/* 281 */           conditions.put(ConditionType.NONE_MATCH, null);
/*     */         } else {
/* 283 */           List<String> states = createStates(ifNoneMatch.getEntityTags());
/* 284 */           conditions.put(ConditionType.NONE_MATCH, states);
/*     */         }
/*     */       } catch (IllegalArgumentException ex) {
/* 287 */         InvalidHeaderValueException headerException = new InvalidHeaderValueException("If-None-Match", ifNoneMatchHeader);
/*     */         
/* 289 */         headerException.setExceptions(new Exception[] { ex });
/* 290 */         throw headerException;
/*     */       }
/*     */     }
/*     */     
/* 294 */     if (conditions.isEmpty()) {
/* 295 */       return null;
/*     */     }
/*     */     
/* 298 */     return Condition.createCondition(conditions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<String> createStates(List<EntityTag> entityTags)
/*     */   {
/* 307 */     List<String> states = new ArrayList(entityTags.size());
/*     */     
/* 309 */     for (EntityTag entityTag : entityTags) {
/* 310 */       states.add(entityTag.getValue());
/*     */     }
/* 312 */     return states;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HttpMethod.Type determineHttpMethodType(HttpMethod.Type httpMethodType)
/*     */     throws HTTPResourceException
/*     */   {
/* 324 */     HttpMethod.Type definedMethod = httpMethodType;
/* 325 */     if (httpMethodType == HttpMethod.Type.POST) {
/*     */       try {
/* 327 */         HttpMethod.Type overridenMethod = new XHTTPMethodOverride(this.requestHeaders).getHttpType();
/* 328 */         if (overridenMethod != null) {
/* 329 */           definedMethod = overridenMethod;
/*     */         }
/*     */       } catch (IllegalArgumentException ex) {
/* 332 */         ResourceLoggerManager.getCurrentLogger().log(Level.FINE, "Could not override the http method", ex);
/* 333 */         throw new HTTPResourceException(StatusCode.NOT_IMPLEMENTED, getRequestInfo().toString());
/*     */       }
/*     */     }
/* 336 */     return definedMethod;
/*     */   }
/*     */   
/*     */   private void setEffectiveDateRangeProperties() {
/* 340 */     String effectiveOfHeaderStr = getRequestHeader("Effective-Of");
/*     */     
/* 342 */     if (effectiveOfHeaderStr != null) {
/* 343 */       EffectiveOf effectiveOf = new EffectiveOf(effectiveOfHeaderStr);
/* 344 */       Map<String, String> rangeProperties = effectiveOf.getEffectiveDateRangeProperties();
/* 345 */       this.resourceContext.setEffectiveDateRangeProperties(rangeProperties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\RESTHttpRequestWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */