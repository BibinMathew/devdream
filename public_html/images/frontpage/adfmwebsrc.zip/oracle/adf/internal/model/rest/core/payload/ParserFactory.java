/*    */ package oracle.adf.internal.model.rest.core.payload;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceTreeManager;
/*    */ import oracle.adf.internal.model.rest.core.payload.json.JSONParserFactory;
/*    */ import oracle.adf.internal.model.rest.core.payload.xml.XMLParserFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ParserFactory
/*    */ {
/*    */   public static ParserFactory getInstance(PayloadType payloadType, Reader reader)
/*    */     throws IOException
/*    */   {
/* 31 */     switch (payloadType) {
/*    */     case JSON: 
/* 33 */       return new JSONParserFactory(reader);
/*    */     case XML: 
/* 35 */       return new XMLParserFactory(reader);
/*    */     }
/* 37 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static ParserFactory getInstance(PayloadType payloadType, InputStream inputStream)
/*    */     throws IOException
/*    */   {
/* 48 */     switch (payloadType) {
/*    */     case JSON: 
/* 50 */       return new JSONParserFactory(inputStream);
/*    */     case XML: 
/* 52 */       return new XMLParserFactory(inputStream);
/*    */     }
/* 54 */     return null;
/*    */   }
/*    */   
/*    */   public abstract ActionParser getActionParser();
/*    */   
/*    */   public abstract BatchRequestParser getBatchRequestParser();
/*    */   
/*    */   public abstract ResourceParser getResourceParser(ResourceTreeManager paramResourceTreeManager);
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\ParserFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */