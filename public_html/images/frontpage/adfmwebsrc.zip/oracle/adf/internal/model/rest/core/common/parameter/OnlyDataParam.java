/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ 
/*    */ public class OnlyDataParam
/*    */   extends ResourceParameter
/*    */ {
/*  7 */   private Boolean onlyDataEnabled = Boolean.FALSE;
/*    */   
/*    */   public OnlyDataParam(String[] parameterValues) {
/* 10 */     if (parameterValues != null) {
/* 11 */       if ((parameterValues.length > 0) && (parameterValues[0].length() > 0)) {
/* 12 */         this.onlyDataEnabled = Boolean.valueOf(parameterValues[0]);
/*    */       }
/*    */       else {
/* 15 */         this.onlyDataEnabled = Boolean.TRUE;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Boolean getOnlyDataEnabled()
/*    */   {
/* 22 */     return this.onlyDataEnabled;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\OnlyDataParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */