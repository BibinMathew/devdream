/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import java.util.Map;
/*    */ import oracle.adf.model.config.AdfmConfig;
/*    */ import oracle.adf.share.ADFContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RESTUtil
/*    */ {
/*    */   private static final String FAIL_ON_LOV_MISMATCH = "failOnLOVMismatch";
/*    */   private static final String REQUEST_PATH_GENERATION_ENCODED = "pathGenerationEncoded";
/*    */   
/*    */   public static void setPathGenerationEncoded(Boolean pathGenerationEncoded)
/*    */   {
/* 20 */     ADFContext.getCurrent().getRequestScope().put("pathGenerationEncoded", pathGenerationEncoded);
/*    */   }
/*    */   
/*    */   public static Boolean isPathGenerationEncoded() {
/* 24 */     Boolean pathGenerationEncoded = (Boolean)ADFContext.getCurrent().getRequestScope().get("pathGenerationEncoded");
/* 25 */     if (pathGenerationEncoded == null) {
/* 26 */       return Boolean.FALSE;
/*    */     }
/* 28 */     return pathGenerationEncoded;
/*    */   }
/*    */   
/*    */   public static void setFailOnLOVMismatchEnabled(Boolean enabled)
/*    */   {
/* 33 */     ADFContext.getCurrent().getRequestScope().put("failOnLOVMismatch", enabled);
/*    */   }
/*    */   
/*    */   public static Boolean isFailOnLOVMismatchEnabled() {
/* 37 */     Object enabled = ADFContext.getCurrent().getRequestScope().get("failOnLOVMismatch");
/* 38 */     return (enabled instanceof Boolean) ? (Boolean)enabled : Boolean.TRUE;
/*    */   }
/*    */   
/*    */   public static boolean skipMetadataContextCheck() {
/* 42 */     return Boolean.valueOf((String)AdfmConfig.getCustomProperty("adf.rest.skipmetadatacontextcheck")).booleanValue();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\RESTUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */