/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpMethodFactory
/*    */ {
/*    */   public static HttpMethod createHTTPMethod(HttpMethod.Type httpMethodType, HttpMethodInfo info)
/*    */   {
/* 21 */     switch (httpMethodType)
/*    */     {
/*    */     case GET: 
/* 24 */       return new GetMethod(info);
/*    */     
/*    */ 
/*    */     case POST: 
/* 28 */       return new PostMethod(info);
/*    */     
/*    */ 
/*    */     case DELETE: 
/* 32 */       return new DeleteMethod(info);
/*    */     
/*    */ 
/*    */     case PUT: 
/* 36 */       return new PutMethod(info);
/*    */     
/*    */ 
/*    */     case PATCH: 
/* 40 */       return new PatchMethod(info);
/*    */     }
/*    */     
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\HttpMethodFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */