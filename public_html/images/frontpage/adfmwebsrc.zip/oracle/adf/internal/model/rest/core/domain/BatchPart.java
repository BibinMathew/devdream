/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.common.Condition;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ 
/*    */ public class BatchPart
/*    */ {
/*    */   public static final String ID = "id";
/*    */   public static final String OPERATION_ATTR = "operation";
/*    */   public static final String PATH_ATTR = "path";
/*    */   public static final String PAYLOAD_ATTR = "payload";
/*    */   public static final String IF_MATCH_ATTR = "ifMatch";
/*    */   public static final String IF_NONE_MATCH_ATTR = "ifNoneMatch";
/*    */   public static final String PRECONDITION_SUCCEEDED_ATTR = "preconditionSucceeded";
/*    */   private final String id;
/*    */   private final OperationType operation;
/*    */   private final String path;
/*    */   private byte[] payloadByteArray;
/*    */   private static final Map<String, OperationType> ALLOWED_OPERATIONS;
/*    */   private Condition condition;
/*    */   
/*    */   static
/*    */   {
/* 26 */     Map<String, OperationType> operations = new java.util.HashMap(5);
/* 27 */     operations.put(OperationType.CREATION.toString(), OperationType.CREATION);
/* 28 */     operations.put(OperationType.UPDATE.toString(), OperationType.UPDATE);
/* 29 */     operations.put(OperationType.DELETION.toString(), OperationType.DELETION);
/* 30 */     operations.put(OperationType.REPLACEMENT.toString(), OperationType.REPLACEMENT);
/* 31 */     operations.put(OperationType.REPRESENTATION.toString(), OperationType.REPRESENTATION);
/* 32 */     ALLOWED_OPERATIONS = Collections.unmodifiableMap(operations);
/*    */   }
/*    */   
/*    */   public BatchPart(String id, String operation, String path) {
/* 36 */     this.id = id;
/* 37 */     this.operation = ((OperationType)ALLOWED_OPERATIONS.get(operation));
/* 38 */     if (this.operation == null) {
/* 39 */       throw new IllegalArgumentException("The following operation is not allowed in a BatchPart: " + operation);
/*    */     }
/* 41 */     this.path = path;
/*    */   }
/*    */   
/*    */   public OperationType getOperation() {
/* 45 */     return this.operation;
/*    */   }
/*    */   
/*    */   public String getPath() {
/* 49 */     return this.path;
/*    */   }
/*    */   
/*    */   public void setPayloadByteArray(byte[] payloadByteArray) {
/* 53 */     this.payloadByteArray = payloadByteArray;
/*    */   }
/*    */   
/*    */   public byte[] getPayloadByteArray() {
/* 57 */     return this.payloadByteArray;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 61 */     return this.id;
/*    */   }
/*    */   
/*    */   public Condition getCondition() {
/* 65 */     return this.condition;
/*    */   }
/*    */   
/*    */   public boolean containsPayload() {
/* 69 */     return this.operation != OperationType.DELETION;
/*    */   }
/*    */   
/*    */   public void setCondition(Condition condition) {
/* 73 */     this.condition = condition;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\BatchPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */