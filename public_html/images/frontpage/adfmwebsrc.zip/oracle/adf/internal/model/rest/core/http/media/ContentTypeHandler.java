/*    */ package oracle.adf.internal.model.rest.core.http.media;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*    */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*    */ 
/*    */ public class ContentTypeHandler
/*    */ {
/*    */   private final oracle.adf.internal.model.rest.core.common.ResourceEntityType entityType;
/*    */   private final PayloadType payloadType;
/*    */   private final MediaType mediaType;
/*    */   
/*    */   public ContentTypeHandler(oracle.adf.internal.model.rest.core.common.ResourceEntityType entityType, PayloadType payloadType, MediaType mediaType)
/*    */   {
/* 14 */     this.entityType = entityType;
/* 15 */     this.payloadType = payloadType;
/* 16 */     this.mediaType = mediaType;
/*    */   }
/*    */   
/*    */   public ContentTypeHandler(MediaType mediaType)
/*    */   {
/* 21 */     this.entityType = null;
/* 22 */     this.payloadType = null;
/* 23 */     this.mediaType = mediaType;
/*    */   }
/*    */   
/*    */   public oracle.adf.internal.model.rest.core.common.ResourceEntityType getEntityType() {
/* 27 */     return this.entityType;
/*    */   }
/*    */   
/*    */   public PayloadType getPayloadType() {
/* 31 */     return this.payloadType;
/*    */   }
/*    */   
/*    */   public MediaType getMediaType() {
/* 35 */     return this.mediaType;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\media\ContentTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */