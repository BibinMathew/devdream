/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ import oracle.adf.model.rest.core.serializer.StreamSerializerInfo;
/*    */ 
/*    */ abstract class AbstractContentOperation extends AbstractOperation
/*    */ {
/*    */   protected Attribute attribute;
/* 12 */   protected StreamSerializerInfo currentContentInfo = null;
/*    */   
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 16 */     ResourceTree tree = context.getResourceTree();
/* 17 */     this.attribute = tree.getSelectedAttribute();
/* 18 */     if (!this.attribute.canStreamContent()) {
/* 19 */       throw new oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException("The attribute specified in the path cannot be streamed. Attribute: " + this.attribute.getName());
/*    */     }
/*    */     
/* 22 */     this.currentContentInfo = this.attribute.getResourceStreamInfo();
/*    */   }
/*    */   
/*    */   public void processPrecondition(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {
/* 28 */     context.processCondition(this.currentContentInfo.getStateId());
/*    */   }
/*    */   
/*    */   public void applyInputValues(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public void generateResponse(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public void execute(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public void validateInputValues(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public ResourceEntityType getResponseEntityType()
/*    */   {
/* 49 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\AbstractContentOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */