/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ public class Location implements Header
/*    */ {
/*    */   public static final String NAME = "Location";
/*    */   private final String value;
/*    */   
/*    */   public Location(String value)
/*    */   {
/* 10 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getLocation() {
/* 14 */     return this.value;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 19 */     return "Location";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\Location.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */