/*     */ package oracle.adf.internal.model.rest.core.http;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.http.header.HeaderConfiguratorInfo;
/*     */ import oracle.adf.model.BindingContext;
/*     */ import oracle.adf.model.MetadataContext;
/*     */ import oracle.adf.model.rest.core.common.ServiceConfiguration;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.ADFScope;
/*     */ import oracle.adf.share.config.ConfigUtils;
/*     */ import oracle.adf.share.logging.ADFLogger;
/*     */ import oracle.adf.share.mds.ADFSessionOptionsFactoryImpl;
/*     */ import oracle.adf.share.mds.MDSTransManager;
/*     */ import oracle.adf.share.security.AuthenticationService;
/*     */ import oracle.adf.share.security.SecurityContext;
/*     */ import oracle.adf.share.security.authentication.AuthenticationServiceUtil;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*     */ import oracle.javatools.util.Chronometer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandaloneHttpController
/*     */ {
/*     */   private final ServiceConfiguration serviceConfig;
/*     */   
/*     */   public StandaloneHttpController()
/*     */   {
/*  58 */     this(new ServiceConfiguration());
/*     */   }
/*     */   
/*     */   public StandaloneHttpController(ServiceConfiguration serviceConfig) {
/*  62 */     this.serviceConfig = serviceConfig;
/*  63 */     ADFContext adfContext = initEmptyADFContext();
/*     */     try {
/*  65 */       serviceConfig.setup();
/*     */     } finally {
/*  67 */       ADFContext.resetADFContext(adfContext);
/*     */     }
/*     */   }
/*     */   
/*     */   private static ADFContext initEmptyADFContext() {
/*  72 */     return ADFContext.initADFContext(null, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeSync(HttpRequestData request, RESTHttpResponseWrapper response)
/*     */   {
/*  82 */     ADFContext oldContext = ADFContext.hasCurrent() ? ADFContext.findCurrent() : initEmptyADFContext();
/*     */     try {
/*     */       try {
/*  85 */         HttpRequestData configuredRequest = prepareRequest(request);
/*     */         
/*  87 */         beginRequest(this.serviceConfig.getResourceRegistryName());
/*     */         
/*  89 */         RESTHttpRequestExecutor executor = new RESTHttpRequestExecutor();
/*  90 */         executor.setResponseHeaderConfiguratorInfo(createDefaultHeaderConfiguratorInfo(configuredRequest));
/*     */         
/*  92 */         executor.execute(configuredRequest, response);
/*     */       } finally {
/*  94 */         endRequest();
/*     */       }
/*     */     } finally {
/*  97 */       if (oldContext == null) {
/*  98 */         ADFContext.resetADFContext(null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static HttpRequestData prepareRequest(HttpRequestData request)
/*     */   {
/* 105 */     ConfigUtils.setSessionOptionsFactory(ADFContext.findCurrent(), new ADFSessionOptionsFactoryImpl());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 110 */     ADFContext.findCurrent().getMDSInstanceAsObject();
/*     */     
/* 112 */     Map<String, List<String>> requestHeaders = request.getRequestHeaders();
/* 113 */     String headerStr = initMetadataContext(requestHeaders);
/* 114 */     if (headerStr == null) {
/* 115 */       return request;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */     List<String> headerValues = new ArrayList(1);
/* 122 */     headerValues.add(headerStr);
/* 123 */     requestHeaders = new HashMap(requestHeaders);
/* 124 */     requestHeaders.put("Metadata-Context", headerValues);
/* 125 */     return new HttpRequestData(request.getRequestContentType(), request.getContextPath(), request.getServletPath(), request.getPathInfo(), request.getParameterMap(), requestHeaders, request.getIn(), request.getLocale(), request.getHttpMethodType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void beginRequest(String resourceRegistryName)
/*     */   {
/* 135 */     long startTime = getNanoTimeWhenLoggable(Level.FINE);
/* 136 */     MDSTransManager.beginFlushCurrentMDSSess();
/* 137 */     logElapsedTime(Level.FINE, "MDSTransManager begin: ", startTime);
/*     */     
/*     */ 
/* 140 */     startTime = getNanoTimeWhenLoggable(Level.FINE);
/* 141 */     BindingContext bctx = new BindingContext();
/* 142 */     BindingContext.setCurrent(bctx);
/* 143 */     bctx.initialize(resourceRegistryName);
/* 144 */     logElapsedTime(Level.FINE, "BindingContext init: ", startTime);
/*     */   }
/*     */   
/*     */   private static String initMetadataContext(Map<String, List<String>> requestHeaders)
/*     */   {
/* 149 */     List<String> headerValues = (List)requestHeaders.get("Metadata-Context");
/* 150 */     String metadataContextHeaderStr = headerValues != null ? (String)headerValues.get(0) : null;
/*     */     
/*     */ 
/* 153 */     Map<String, String> metadataProperties = MetadataContext.setupMetadataContext(metadataContextHeaderStr);
/* 154 */     return MetadataContext.buildHeaderValue(metadataProperties);
/*     */   }
/*     */   
/*     */   private static HeaderConfiguratorInfo createDefaultHeaderConfiguratorInfo(HttpRequestData requestData) {
/* 158 */     HeaderConfiguratorInfo info = new HeaderConfiguratorInfo();
/*     */     
/* 160 */     List<String> headerValues = (List)requestData.getRequestHeaders().get("Metadata-Context");
/* 161 */     String metadataContextHeaderStr = headerValues != null ? (String)headerValues.get(0) : null;
/* 162 */     if (metadataContextHeaderStr != null) {
/* 163 */       info.setSetupMap(Collections.singletonMap("Metadata-Context", metadataContextHeaderStr));
/*     */     }
/*     */     
/* 166 */     return info;
/*     */   }
/*     */   
/*     */   private static void endRequest() {
/*     */     try { 
/*     */     } finally { ADFContext adfContext;
/*     */       AuthenticationService authenticationService;
/*     */       long startTime;
/*     */       BindingContext bindingContext;
/*     */       long startTime;
/* 176 */       ADFContext adfContext = ADFContext.findCurrent();
/*     */       try {
/* 178 */         if (adfContext.getSecurityContext().isAuthenticated()) {
/* 179 */           AuthenticationService authenticationService = AuthenticationServiceUtil.getAuthenticationService();
/*     */           
/* 181 */           long startTime = getNanoTimeWhenLoggable(Level.FINE);
/* 182 */           authenticationService.logout();
/* 183 */           logElapsedTime(Level.FINE, "Logout: ", startTime);
/*     */         }
/* 185 */         BindingContext bindingContext = BindingContext.getCurrent();
/* 186 */         if (bindingContext != null) {
/* 187 */           long startTime = getNanoTimeWhenLoggable(Level.FINE);
/* 188 */           bindingContext.release();
/* 189 */           logElapsedTime(Level.FINE, "BindingContext release: ", startTime);
/*     */         }
/*     */       } finally {
/* 192 */         removeScope(adfContext, "requestScope");
/* 193 */         removeScope(adfContext, "sessionScope");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void removeScope(ADFContext adfContext, String scopeName)
/*     */   {
/* 201 */     if (adfContext == null) {
/* 202 */       return;
/*     */     }
/* 204 */     ADFScope scope = (ADFScope)adfContext.findScope(scopeName);
/* 205 */     if (scope != null) {
/*     */       try {
/* 207 */         scope.invalidate();
/* 208 */         adfContext.removeScope(scopeName);
/*     */       } catch (RuntimeException ex) {
/* 210 */         ResourceLoggerManager.getCurrentLogger().log(Level.WARNING, "Error while removing ADF scope. Scope name: " + scopeName, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static long getNanoTimeWhenLoggable(Level loggable)
/*     */   {
/* 217 */     ADFLogger logger = ResourceLoggerManager.getRESTLogger();
/* 218 */     return logger.isLoggable(loggable) ? System.nanoTime() : 0L;
/*     */   }
/*     */   
/*     */   private static String formatElapsedTime(long elapsedTime, TimeUnit precision) {
/* 222 */     return Chronometer.format(elapsedTime, precision);
/*     */   }
/*     */   
/*     */   private static void logElapsedTime(Level level, String title, long startTime) {
/* 226 */     ADFLogger logger = ResourceLoggerManager.getRESTLogger();
/* 227 */     if (logger.isLoggable(level)) {
/* 228 */       logger.log(level, title + formatElapsedTime(System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\StandaloneHttpController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */