/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ import oracle.adf.internal.model.rest.core.common.Verb;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotParseContentException;
/*    */ import oracle.adf.internal.model.rest.core.http.exception.OperationNotSupportedException;
/*    */ import oracle.adf.internal.model.rest.core.http.header.MediaType;
/*    */ import oracle.adf.internal.model.rest.core.http.media.ContentTypeHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PostMethod
/*    */   implements HttpMethod
/*    */ {
/*    */   private final HttpOperationType operationType;
/*    */   
/*    */   PostMethod(HttpMethodInfo info)
/*    */   {
/* 22 */     Verb verb = info.getVerb();
/* 23 */     ContentTypeHandler requestContentTypeHandler = info.getRequestContentTypeHandler();
/*    */     
/* 25 */     if (requestContentTypeHandler == null) {
/* 26 */       throw new CannotParseContentException("No content type was configured in this request.");
/*    */     }
/*    */     
/* 29 */     if (verb != null) {
/* 30 */       throw new OperationNotSupportedException();
/*    */     }
/* 32 */     ResourceEntityType entityType = requestContentTypeHandler.getEntityType();
/*    */     
/*    */ 
/* 35 */     if (entityType == null) {
/* 36 */       throw new CannotParseContentException("The content type is not a ADFm REST entity. Content-Type: " + requestContentTypeHandler.getMediaType().toString());
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 41 */     switch (entityType)
/*    */     {
/*    */     case RESOURCEITEM: 
/* 44 */       this.operationType = HttpOperationType.RESOURCE;
/* 45 */       this.operationType.setOperation(OperationType.CREATION);
/* 46 */       break;
/*    */     
/*    */ 
/*    */     case ACTION: 
/* 50 */       this.operationType = HttpOperationType.RESOURCE;
/* 51 */       this.operationType.setOperation(OperationType.EXECUTION);
/* 52 */       break;
/*    */     
/*    */ 
/*    */     case BATCH: 
/* 56 */       this.operationType = HttpOperationType.BATCH;
/* 57 */       break;
/*    */     
/*    */ 
/*    */     default: 
/* 61 */       throw new CannotParseContentException("");
/*    */     }
/*    */     
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 70 */     return HttpMethod.Type.POST.toString();
/*    */   }
/*    */   
/*    */   public HttpOperationType getOperationType()
/*    */   {
/* 75 */     return this.operationType;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\PostMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */