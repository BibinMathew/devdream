/*     */ package oracle.adf.internal.model.rest.core.http;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*     */ import oracle.adf.internal.model.rest.core.helper.ResourceDescribeHelper.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DescribeHelperConfig
/*     */   implements ResourceDescribeHelper.Configuration
/*     */ {
/*  29 */   private static final Map<String, String> GET_ITEM_PROPERTIES = createPropertyMap(ActionType.GET_ITEM);
/*  30 */   private static final Map<String, String> GET_COLLECTION_PROPERTIES = createPropertyMap(ActionType.GET_COLLECTION);
/*  31 */   private static final Map<String, String> REPLACE_PROPERTIES = createPropertyMap(ActionType.REPLACE);
/*  32 */   private static final Map<String, String> CREATE_PROPERTIES = createPropertyMap(ActionType.CREATE);
/*  33 */   private static final Map<String, String> INVOKE_PROPERTIES = createPropertyMap(ActionType.INVOKE);
/*  34 */   private static final Map<String, String> DELETE_PROPERTIES = createPropertyMap(ActionType.DELETE);
/*  35 */   private static final Map<String, String> UPDATE_PROPERTIES = createPropertyMap(ActionType.UPDATE);
/*     */   private static final String PUT_HTTP_METHOD = "PUT";
/*     */   
/*     */   private static Map<String, String> createPropertyMap(ActionType actionType) {
/*  39 */     int maxTotalProperties = 1;
/*  40 */     Map<String, String> properties = new HashMap(1);
/*  41 */     switch (actionType)
/*     */     {
/*     */     case GET_ITEM: 
/*  44 */       properties.put("method", "GET");
/*  45 */       break;
/*     */     
/*     */ 
/*     */     case GET_COLLECTION: 
/*  49 */       properties.put("method", "GET");
/*  50 */       break;
/*     */     
/*     */ 
/*     */     case CREATE: 
/*  54 */       properties.put("method", "POST");
/*  55 */       break;
/*     */     
/*     */ 
/*     */     case UPDATE: 
/*  59 */       properties.put("method", "PATCH");
/*  60 */       break;
/*     */     
/*     */ 
/*     */     case REPLACE: 
/*  64 */       properties.put("method", "PUT");
/*  65 */       break;
/*     */     
/*     */ 
/*     */     case DELETE: 
/*  69 */       properties.put("method", "DELETE");
/*  70 */       break;
/*     */     
/*     */ 
/*     */     case INVOKE: 
/*  74 */       properties.put("method", "POST");
/*     */     }
/*     */     
/*     */     
/*  78 */     return Collections.unmodifiableMap(properties); }
/*     */   
/*     */   private static final String PATCH_HTTP_METHOD = "PATCH";
/*     */   
/*  82 */   public void configureActionDescription(ActionDescription actionDescription) { switch (actionDescription.getType())
/*     */     {
/*     */     case GET_ITEM: 
/*  85 */       actionDescription.setProperties(GET_ITEM_PROPERTIES);
/*  86 */       break;
/*     */     
/*     */ 
/*     */     case GET_COLLECTION: 
/*  90 */       actionDescription.setProperties(GET_COLLECTION_PROPERTIES);
/*  91 */       break;
/*     */     
/*     */ 
/*     */     case CREATE: 
/*  95 */       actionDescription.setProperties(CREATE_PROPERTIES);
/*  96 */       break;
/*     */     
/*     */ 
/*     */     case UPDATE: 
/* 100 */       actionDescription.setProperties(UPDATE_PROPERTIES);
/* 101 */       break;
/*     */     
/*     */ 
/*     */     case REPLACE: 
/* 105 */       actionDescription.setProperties(REPLACE_PROPERTIES);
/* 106 */       break;
/*     */     
/*     */ 
/*     */     case DELETE: 
/* 110 */       actionDescription.setProperties(DELETE_PROPERTIES);
/* 111 */       break;
/*     */     
/*     */ 
/*     */     case INVOKE: 
/* 115 */       actionDescription.setProperties(INVOKE_PROPERTIES);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final String GET_HTTP_METHOD = "GET";
/*     */   private static final String POST_HTTP_METHOD = "POST";
/*     */   private static final String DELETE_HTTP_METHOD = "DELETE";
/*     */   private static final String METHOD_ATTR = "method";
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\DescribeHelperConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */