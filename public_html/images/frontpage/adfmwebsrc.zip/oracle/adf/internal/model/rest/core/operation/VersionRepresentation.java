/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException;
/*    */ import oracle.adf.internal.model.rest.core.helper.VersionHelper;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VersionRepresentation
/*    */   extends AbstractResourceOperation
/*    */ {
/*    */   public static final String SECURITY_ACTION = "get";
/*    */   
/*    */   public VersionRepresentation()
/*    */   {
/* 45 */     this.dependentOnResource = false;
/*    */   }
/*    */   
/*    */   public void init(ResourceProcessingContext context) throws Exception
/*    */   {
/* 50 */     if (!this.responseHandler.isEntityGenerationAllowed()) {
/* 51 */       throw new CannotGenerateContentException("The entity generation is not enabled in the ResponseHandler.");
/*    */     }
/*    */   }
/*    */   
/*    */   public void applyInputValues(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public void execute(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public void validateInputValues(ResourceProcessingContext context)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public void generateResponse(ResourceProcessingContext context) throws Exception
/*    */   {
/* 69 */     VersionHelper.generateVersionRepresentation(context, this.responseHandler.getPayloadGenerator());
/*    */   }
/*    */   
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 74 */     return false;
/*    */   }
/*    */   
/*    */   public String getSecurityName()
/*    */   {
/* 79 */     return "get";
/*    */   }
/*    */   
/*    */   public boolean isAuthorized(ResourceProcessingContext context)
/*    */   {
/* 84 */     return true;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 89 */     return OperationType.REPRESENTATION;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 94 */     return null;
/*    */   }
/*    */   
/*    */   public ResourceEntityType getResponseEntityType()
/*    */   {
/* 99 */     return ResourceEntityType.VERSION;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\VersionRepresentation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */