/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import oracle.jbo.AttributeDef;
/*     */ 
/*     */ public class Cardinality
/*     */ {
/*     */   private static final String CARDINALITY_FORMAT = "%s to %s";
/*     */   private static final String VALUE_ONE = "1";
/*     */   private static final String VALUE_MANY = "*";
/*     */   public static final String NAME = "cardinality";
/*     */   public static final String ATTRIBUTE_VALUE = "value";
/*     */   public static final String ATTRIBUTE_SOURCE_ATTR = "sourceAttributes";
/*     */   public static final String ATTRIBUTE_DESTINATION_ATTR = "destinationAttributes";
/*     */   private static final String ATTR_NAME_SEPARATOR = ", ";
/*     */   private final Value sourceValue;
/*     */   private final Value destinationValue;
/*     */   private final String[] sourceAttribute;
/*     */   private final String[] destinationAttribute;
/*     */   
/*     */   public static enum Value
/*     */   {
/*  22 */     ONE("1"), 
/*  23 */     MANY("*");
/*     */     
/*     */     private final String value;
/*     */     
/*  27 */     private Value(String value) { this.value = value; }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  32 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Value valueOf(int cardinalityValue) {
/*  36 */       if (cardinalityValue == -1) {
/*  37 */         return MANY;
/*     */       }
/*     */       
/*  40 */       if (cardinalityValue == 1) {
/*  41 */         return ONE;
/*     */       }
/*  43 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cardinality(Value sourceValue, Value destinationValue, String[] sourceAttributes, String[] destinationAttributes)
/*     */   {
/*  52 */     this.sourceValue = sourceValue;
/*  53 */     this.destinationValue = destinationValue;
/*  54 */     this.sourceAttribute = ((String[])java.util.Arrays.copyOf(sourceAttributes, sourceAttributes.length));
/*  55 */     this.destinationAttribute = ((String[])java.util.Arrays.copyOf(destinationAttributes, destinationAttributes.length));
/*     */   }
/*     */   
/*     */ 
/*     */   Cardinality(int sourceCardinalityValue, int destinationCardinalityValue, AttributeDef[] sourceAttribute, AttributeDef[] destinationAttribute)
/*     */   {
/*  61 */     this.sourceValue = Value.valueOf(sourceCardinalityValue);
/*  62 */     this.destinationValue = Value.valueOf(destinationCardinalityValue);
/*  63 */     this.sourceAttribute = getAttributeNames(sourceAttribute);
/*  64 */     this.destinationAttribute = getAttributeNames(destinationAttribute);
/*     */   }
/*     */   
/*     */   public Value getSourceValue() {
/*  68 */     return this.sourceValue;
/*     */   }
/*     */   
/*     */   public Value getDestinationValue() {
/*  72 */     return this.destinationValue;
/*     */   }
/*     */   
/*     */   public String getFormattedValue() {
/*  76 */     return String.format("%s to %s", new Object[] { this.sourceValue, this.destinationValue });
/*     */   }
/*     */   
/*     */   public String[] getSourceAttributeNames() {
/*  80 */     return (String[])java.util.Arrays.copyOf(this.sourceAttribute, this.sourceAttribute.length);
/*     */   }
/*     */   
/*     */   public String[] getDestinationAttributeNames() {
/*  84 */     return (String[])java.util.Arrays.copyOf(this.destinationAttribute, this.destinationAttribute.length);
/*     */   }
/*     */   
/*     */   public String getFormattedSourceAttributeNames() {
/*  88 */     return getFormattedAttributeName(this.sourceAttribute);
/*     */   }
/*     */   
/*     */   public String getFormattedDestinationAttributeNames() {
/*  92 */     return getFormattedAttributeName(this.destinationAttribute);
/*     */   }
/*     */   
/*     */   private String[] getAttributeNames(AttributeDef[] attributeDefs) {
/*  96 */     String[] attributeNames = new String[attributeDefs.length];
/*  97 */     for (int i = 0; i < attributeDefs.length; i++) {
/*  98 */       attributeNames[i] = attributeDefs[i].getName();
/*     */     }
/* 100 */     return attributeNames;
/*     */   }
/*     */   
/*     */   private String getFormattedAttributeName(String[] attributeNames) {
/* 104 */     StringBuilder formattedName = new StringBuilder(attributeNames[0]);
/* 105 */     for (int i = 1; i < attributeNames.length; i++) {
/* 106 */       formattedName.append(", ").append(attributeNames[i]);
/*     */     }
/* 108 */     return formattedName.toString();
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Cardinality.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */