/*    */ package oracle.adf.internal.model.rest.core.common.listener;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.Path;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceLifecyclePhase;
/*    */ 
/*    */ public class ResourceLifecycleEvent
/*    */ {
/*    */   private final Path resourcePath;
/*    */   private final ResourceLifecyclePhase phase;
/*    */   private final ResponseHandler responseHandler;
/*    */   
/*    */   public ResourceLifecycleEvent(Path resourcePath, ResourceLifecyclePhase phase, ResponseHandler responseHandler)
/*    */   {
/* 15 */     this.resourcePath = resourcePath;
/* 16 */     this.phase = phase;
/* 17 */     this.responseHandler = responseHandler;
/*    */   }
/*    */   
/*    */   public String getResourcePath() {
/* 21 */     return this.resourcePath.createHref();
/*    */   }
/*    */   
/*    */   public ResourceLifecyclePhase getPhase() {
/* 25 */     return this.phase;
/*    */   }
/*    */   
/*    */   public ResponseHandler getResponseHandler() {
/* 29 */     return this.responseHandler;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\listener\ResourceLifecycleEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */