/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.exception.ActionNotEnabledException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ActionNotFoundException;
/*     */ import oracle.adf.model.OperationParameter;
/*     */ import oracle.adf.model.binding.DCInvokeMethodDef;
/*     */ import oracle.adf.model.binding.PermissionHelper;
/*     */ import oracle.adf.share.security.authorization.ADFPermission;
/*     */ import oracle.adf.share.security.authorization.RestServicePermission;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*     */ import oracle.jbo.CSMessageBundle;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.common.JBOClass;
/*     */ import oracle.jbo.uicli.binding.JUCtrlActionBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Action
/*     */ {
/*     */   public static final String NAME = "Action";
/*     */   public static final String NAME_ATTR = "name";
/*     */   public static final String PARAMETERS_ATTR = "parameters";
/*     */   private final String name;
/*     */   private final String bindingActionName;
/*     */   private final ActionType type;
/*  36 */   private Map<String, Object> parameters = Collections.emptyMap();
/*     */   private JUCtrlActionBinding actionBinding;
/*     */   private Resource resource;
/*     */   
/*     */   public Action(String name, Resource resource) {
/*  41 */     this.name = name;
/*  42 */     this.bindingActionName = name;
/*  43 */     this.type = ActionType.INVOKE;
/*  44 */     bind(resource);
/*     */   }
/*     */   
/*     */   Action(ActionType type, Resource resource) {
/*  48 */     this(type);
/*  49 */     bind(resource);
/*     */   }
/*     */   
/*     */   Action(Resource resource, JUCtrlActionBinding actionBinding) {
/*  53 */     this.name = actionBinding.getName();
/*  54 */     this.bindingActionName = this.name;
/*  55 */     this.actionBinding = actionBinding;
/*  56 */     this.type = ActionType.INVOKE;
/*  57 */     this.resource = resource;
/*     */   }
/*     */   
/*     */   Action(ActionType actionType) {
/*  61 */     this.type = actionType;
/*  62 */     this.name = actionType.getActionName();
/*  63 */     this.bindingActionName = actionType.getActionBindingName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void bind(Resource resource)
/*     */   {
/*  71 */     if ((this.actionBinding == null) && (this.bindingActionName != null)) {
/*  72 */       this.actionBinding = resource.getActionBinding(this.bindingActionName);
/*  73 */       if (this.actionBinding == null) {
/*  74 */         throw new ActionNotFoundException(resource.getName(), this.bindingActionName);
/*     */       }
/*     */     }
/*  77 */     this.resource = resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void bindToResource(Resource resource)
/*     */   {
/*  84 */     bind(resource);
/*     */   }
/*     */   
/*     */   public final ResourceEntityType getRequestEntityType() {
/*  88 */     return this.type.getRequestEntityType();
/*     */   }
/*     */   
/*     */   public final ResourceEntityType getResponseEntityType() {
/*  92 */     return this.type.getResponseEntityType();
/*     */   }
/*     */   
/*     */   final boolean isBoundToResource() {
/*  96 */     ContextualLogger contextualLogger = ResourceLoggerManager.getCurrentLogger();
/*  97 */     if (this.resource == null) {
/*  98 */       contextualLogger.finest("The action '" + this.name + "' is not bound to a resource.");
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     if (this.actionBinding == null) {
/* 103 */       contextualLogger.finest("The action '" + this.name + "' is associated to a resource but actionBinding is null.");
/*     */       
/* 105 */       return false;
/*     */     }
/*     */     
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   final Resource getResource() {
/* 112 */     return this.resource;
/*     */   }
/*     */   
/*     */   public final String getName() {
/* 116 */     return this.name;
/*     */   }
/*     */   
/*     */   public final Map<String, Object> getParameters() {
/* 120 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public final void setParameters(Map<String, Object> parameters) {
/* 124 */     this.parameters = Collections.unmodifiableMap(parameters);
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 128 */     ContextualLogger contextualLogger = ResourceLoggerManager.getCurrentLogger();
/* 129 */     if (this.actionBinding == null) {
/* 130 */       contextualLogger.finest("Action '" + this.name + "' not enabled. Action binding is null.");
/* 131 */       return false;
/*     */     }
/*     */     
/* 134 */     boolean actionBindingIsEnabled = this.actionBinding.isActionEnabled();
/*     */     
/* 136 */     if (!actionBindingIsEnabled) {
/* 137 */       contextualLogger.finest("Action '" + this.name + "' not enabled. actionBinding.isActionEnabled() is false.");
/*     */     }
/*     */     
/* 140 */     return actionBindingIsEnabled;
/*     */   }
/*     */   
/*     */   ActionResult execute()
/*     */   {
/* 145 */     ContextualLogger contextualLogger = ResourceLoggerManager.getCurrentLogger();
/* 146 */     contextualLogger.entering(getClass().getName(), "execute");
/* 147 */     contextualLogger.finer("Action Name: " + this.name);
/*     */     
/* 149 */     contextualLogger.finest("Checking if action is enabled.");
/* 150 */     if (!isEnabled()) {
/* 151 */       throw new ActionNotEnabledException(this.name);
/*     */     }
/* 153 */     contextualLogger.finest("Action is enabled.");
/*     */     
/*     */ 
/* 156 */     contextualLogger.finest("Checking if action is bound to a resource.");
/* 157 */     if (!isBoundToResource()) {
/* 158 */       throw new JboException(CSMessageBundle.class, "27508", new Object[] { this.name });
/*     */     }
/*     */     
/* 161 */     contextualLogger.finest("Action is bound to a resource.");
/*     */     
/*     */ 
/* 164 */     if (this.resource.isItem()) {
/* 165 */       getResource().getNode().synchronizeCurrentRow();
/*     */     }
/*     */     
/* 168 */     ActionResult actionResult = null;
/*     */     
/*     */ 
/* 171 */     if (!this.parameters.isEmpty()) {
/* 172 */       if (contextualLogger.isFinest()) {
/* 173 */         String newLine = System.getProperty("line.separator");
/* 174 */         StringBuilder sb = new StringBuilder();
/* 175 */         sb.append("Parameters provided:");
/*     */         
/* 177 */         for (Map.Entry<String, Object> param : this.parameters.entrySet()) {
/* 178 */           sb.append(newLine);
/* 179 */           sb.append("Name: ");
/* 180 */           sb.append((String)param.getKey());
/* 181 */           sb.append(" Value: ");
/* 182 */           sb.append(param.getValue());
/*     */         }
/* 184 */         contextualLogger.finest(sb.toString());
/*     */       }
/*     */       
/* 187 */       this.actionBinding.getParamsMap().putAll(this.parameters);
/*     */     } else {
/* 189 */       contextualLogger.finest("No parameters were provided.");
/*     */     }
/*     */     
/* 192 */     contextualLogger.finest("Executing action.");
/* 193 */     Object result = this.actionBinding.execute();
/* 194 */     contextualLogger.finest("Action executed.");
/*     */     
/* 196 */     if (result != null) {
/* 197 */       actionResult = new ActionResult(result);
/*     */     }
/*     */     
/* 200 */     contextualLogger.finest("Action result != null? " + (actionResult != null));
/*     */     
/* 202 */     contextualLogger.exiting(getClass().getName(), "execute");
/* 203 */     return actionResult;
/*     */   }
/*     */   
/*     */   public boolean producesActionResult() {
/* 207 */     if (this.actionBinding == null) {
/* 208 */       throw new JboException(CSMessageBundle.class, "27509", new Object[] { this.name });
/*     */     }
/*     */     
/* 211 */     DCInvokeMethodDef cInvokeMethodDef = this.actionBinding.getInvokeMethodDef();
/* 212 */     return cInvokeMethodDef != null;
/*     */   }
/*     */   
/*     */   public final boolean isResourceItemAction() {
/* 216 */     if (this.actionBinding == null) {
/* 217 */       throw new JboException(CSMessageBundle.class, "27509", new Object[] { this.name });
/*     */     }
/*     */     
/* 220 */     DCInvokeMethodDef invokeMethodDef = this.actionBinding.getInvokeMethodDef();
/* 221 */     if (invokeMethodDef == null) {
/* 222 */       return true;
/*     */     }
/* 224 */     return (invokeMethodDef.getInstanceName() != null) && (invokeMethodDef.getIsLocalObjectReference()) && (!invokeMethodDef.getIsViewObjectMethod());
/*     */   }
/*     */   
/*     */   public final boolean isResourceCollectionAction() {
/* 228 */     if (this.actionBinding == null) {
/* 229 */       throw new JboException(CSMessageBundle.class, "27509", new Object[] { this.name });
/*     */     }
/*     */     
/* 232 */     DCInvokeMethodDef invokeMethodDef = this.actionBinding.getInvokeMethodDef();
/* 233 */     if (invokeMethodDef == null) {
/* 234 */       return true;
/*     */     }
/* 236 */     return !isResourceItemAction();
/*     */   }
/*     */   
/*     */   final JUCtrlActionBinding getActionBinding() {
/* 240 */     return this.actionBinding;
/*     */   }
/*     */   
/*     */   public final ActionType getType() {
/* 244 */     return this.type;
/*     */   }
/*     */   
/*     */   public final Map<String, Class> getArgumentTypes() {
/* 248 */     OperationParameter[] params = this.actionBinding.getInvokeMethodDef().getParameters();
/* 249 */     if (params == null) { return Collections.emptyMap();
/*     */     }
/* 251 */     Map<String, Class> args = new HashMap(params.length);
/* 252 */     for (OperationParameter param : params) {
/*     */       try {
/* 254 */         args.put(param.getName(), JBOClass.forName(param.getTypeName()));
/*     */       } catch (ClassNotFoundException e) {
/* 256 */         throw new RuntimeException("Could not find class: " + param.getTypeName());
/*     */       }
/*     */     }
/* 259 */     return args;
/*     */   }
/*     */   
/*     */   public boolean isAuthorized() {
/* 263 */     return PermissionHelper.hasPermission(getPermission());
/*     */   }
/*     */   
/*     */   public static boolean isAuthorized(String resourceName, ActionType actionType) {
/* 267 */     return PermissionHelper.hasPermission(getPermission(resourceName, actionType));
/*     */   }
/*     */   
/*     */   private static ADFPermission getPermission(String resourceName, ActionType actionType) {
/* 271 */     return new RestServicePermission(resourceName, actionType.getSecurityName());
/*     */   }
/*     */   
/*     */   private ADFPermission getPermission() {
/* 275 */     if (this.resource == null) {
/* 276 */       throw new JboException("No resource has been bound to action " + getName() + ". Unable to fetch permissions");
/*     */     }
/*     */     
/*     */ 
/* 280 */     return getPermission(this.resource.getName(), this.type);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Action.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */