/*    */ package oracle.adf.internal.model.rest.core.lifecycle.condition;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.Condition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConditionProcessorFactory
/*    */ {
/*    */   public static ConditionProcessor createCondition(Condition condition)
/*    */   {
/* 24 */     ConditionProcessor conditionProcessor = null;
/* 25 */     if (condition == null) {
/* 26 */       return null;
/*    */     }
/* 28 */     switch (condition.getConditionType())
/*    */     {
/*    */     case MATCH: 
/* 31 */       conditionProcessor = new MatchProcessor(condition);
/* 32 */       break;
/*    */     
/*    */ 
/*    */ 
/*    */     case NONE_MATCH: 
/* 37 */       conditionProcessor = new NoneMatchProcessor(condition);
/*    */     }
/*    */     
/*    */     
/* 41 */     return conditionProcessor;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\condition\ConditionProcessorFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */