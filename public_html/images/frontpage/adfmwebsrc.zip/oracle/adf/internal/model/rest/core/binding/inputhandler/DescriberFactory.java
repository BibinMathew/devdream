/*    */ package oracle.adf.internal.model.rest.core.binding.inputhandler;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*    */ import oracle.adf.model.rest.core.describer.ResourceDescriber;
/*    */ import oracle.jbo.AttributeDef;
/*    */ import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DescriberFactory
/*    */ {
/*    */   public static ResourceDescriber getDescriber(PayloadType payloadType, AttributeDef attrDef, JUCtrlInputValueHandler inputHandler)
/*    */   {
/* 18 */     ResourceDescriber describer = null;
/* 19 */     if ((inputHandler instanceof ResourceInputHandler)) {
/* 20 */       switch (payloadType) {
/*    */       case JSON: 
/* 22 */         describer = ((ResourceInputHandler)inputHandler).getJSONDescriber(attrDef);
/*    */       }
/*    */       
/*    */     }
/*    */     
/* 27 */     return describer;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\binding\inputhandler\DescriberFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */