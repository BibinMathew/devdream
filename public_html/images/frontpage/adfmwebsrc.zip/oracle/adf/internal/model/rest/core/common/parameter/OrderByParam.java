/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderByParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private static final String ORDER_BY_PARAMETER_SEPARATOR = ",";
/*    */   private static final String ORDER_BY_PARAMETER_ASC_SEPARATOR = ":";
/*    */   private static final String DESC_VALUE = "desc";
/*    */   private static final String ASC_VALUE = "asc";
/*    */   private final Map<String, Boolean> parameters;
/*    */   
/*    */   public OrderByParam(String[] parameterValues)
/*    */   {
/* 29 */     String orderByString = parameterValues[0];
/* 30 */     String[] orderByParameters = orderByString.split(",");
/*    */     
/* 32 */     Map<String, Boolean> modifiableParameters = new LinkedHashMap();
/* 33 */     for (String param : orderByParameters) {
/* 34 */       String[] attributeAscPair = param.split(":");
/* 35 */       Boolean desc = null;
/* 36 */       if (attributeAscPair.length > 1) {
/* 37 */         String ascendency = attributeAscPair[1];
/* 38 */         if (ascendency.equals("desc")) {
/* 39 */           desc = Boolean.TRUE;
/* 40 */         } else if (ascendency.equals("asc")) {
/* 41 */           desc = Boolean.FALSE;
/*    */         }
/*    */       }
/* 44 */       modifiableParameters.put(attributeAscPair[0], desc);
/*    */     }
/* 46 */     this.parameters = Collections.unmodifiableMap(modifiableParameters);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, Boolean> getParameters()
/*    */   {
/* 54 */     return this.parameters;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\OrderByParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */