package oracle.adf.internal.model.rest.core.http;

import java.io.OutputStream;
import java.util.Map;
import oracle.adf.internal.model.rest.core.http.header.HeaderConfigurator;

public abstract interface RESTHttpResponseWrapper
{
  public abstract void setupResponseHeaders(int paramInt, Map<String, String> paramMap);
  
  public abstract OutputStream getOutpuStream();
  
  public abstract HeaderConfigurator getHeaderConfigurator();
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\RESTHttpResponseWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */