/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ public class AcceptBestMatchResult
/*    */ {
/*    */   private final MediaRange bestMediaRange;
/*    */   private final MediaType bestSuppportedMediaType;
/*    */   
/*    */   public AcceptBestMatchResult(MediaRange bestMediaRange, MediaType bestSuppportedMediaType)
/*    */   {
/* 10 */     this.bestMediaRange = bestMediaRange;
/* 11 */     this.bestSuppportedMediaType = bestSuppportedMediaType;
/*    */   }
/*    */   
/*    */   public MediaRange getBestMediaRange() {
/* 15 */     return this.bestMediaRange;
/*    */   }
/*    */   
/*    */   public MediaType getBestSuppportedMediaType() {
/* 19 */     return this.bestSuppportedMediaType;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\AcceptBestMatchResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */