package oracle.adf.internal.model.rest.core.payload;

import java.io.IOException;
import java.util.Collection;
import oracle.adf.internal.model.rest.core.domain.BatchPart;

public abstract interface BatchRequestParser
{
  public abstract void parse(Collection<BatchPart> paramCollection)
    throws IOException;
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\BatchRequestParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */