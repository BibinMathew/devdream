/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.HashMap;
/*    */ import java.util.Set;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import oracle.adf.internal.model.rest.core.exception.BadQueryException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private static final String QUERY_CONTENT_SEPARATOR = ";";
/*    */   private String[] expressions;
/*    */   private String query;
/* 18 */   private static final Pattern EXPRESSION_ATTRIBUTE_PATTERN = Pattern.compile("[^( +)^<^>^=^!]+");
/*    */   
/*    */   public QueryParam(String[] parameterValues) {
/* 21 */     String[] values = null;
/*    */     
/* 23 */     if (parameterValues != null) {
/* 24 */       values = (String[])Arrays.copyOf(parameterValues, parameterValues.length);
/*    */     }
/*    */     
/* 27 */     if ((values != null) && (values.length > 0) && (values[0] != null)) {
/* 28 */       this.query = values[0];
/* 29 */       if (this.query.length() == 0) {
/* 30 */         throw new BadQueryException();
/*    */       }
/* 32 */       this.expressions = this.query.split(";");
/*    */     }
/*    */   }
/*    */   
/*    */   public String getQuery()
/*    */   {
/* 38 */     return this.query;
/*    */   }
/*    */   
/*    */   public HashMap<String, String> createQueryMap(Set<String> attributeNames) {
/* 42 */     HashMap<String, String> queryMap = new HashMap(this.expressions.length);
/* 43 */     for (String expression : this.expressions) {
/* 44 */       String trimmedExpression = expression.trim();
/* 45 */       Matcher matcher = EXPRESSION_ATTRIBUTE_PATTERN.matcher(trimmedExpression);
/* 46 */       if (matcher.find()) {
/* 47 */         String expressionAttribute = matcher.group();
/* 48 */         if (attributeNames.contains(expressionAttribute)) {
/* 49 */           queryMap.put(expressionAttribute, trimmedExpression.substring(expressionAttribute.length()));
/*    */         }
/*    */       }
/*    */     }
/* 53 */     return queryMap;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\QueryParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */