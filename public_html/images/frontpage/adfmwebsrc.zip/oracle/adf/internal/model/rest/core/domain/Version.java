/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static final String NAME_PLURAL = "items";
/*    */   
/*    */ 
/*    */ 
/*    */   public static final String VERSION_ATTR = "version";
/*    */   
/*    */ 
/*    */ 
/*    */   public static final String LIFECYCLE_ATTR = "lifecycle";
/*    */   
/*    */ 
/*    */ 
/*    */   public static final String IS_LATEST_ATTR = "isLatest";
/*    */   
/*    */ 
/*    */   private final String _displayName;
/*    */   
/*    */ 
/*    */   private final String _lifecycle;
/*    */   
/*    */ 
/*    */   private final boolean _isLatest;
/*    */   
/*    */ 
/*    */ 
/*    */   public Version(String displayName, String lifecycle, boolean isLatest)
/*    */   {
/* 35 */     this._displayName = displayName;
/* 36 */     this._lifecycle = lifecycle;
/* 37 */     this._isLatest = isLatest;
/*    */   }
/*    */   
/*    */   public String getDisplayName() {
/* 41 */     return this._displayName;
/*    */   }
/*    */   
/*    */   public String getLifecycle() {
/* 45 */     return this._lifecycle;
/*    */   }
/*    */   
/*    */   public boolean isLatest() {
/* 49 */     return this._isLatest;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Version.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */