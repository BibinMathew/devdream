/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.common.EntityContentMapping;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadType;
/*     */ import oracle.adf.model.binding.DCBindingContainer;
/*     */ import oracle.adf.model.binding.DCDataControl;
/*     */ import oracle.binding.meta.DefinitionContainer;
/*     */ import oracle.binding.meta.OperationDefinition;
/*     */ import oracle.binding.meta.OperationReturnDefinition;
/*     */ import oracle.binding.meta.ParameterDefinition;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.LocaleContext;
/*     */ import oracle.jbo.ViewObject;
/*     */ import oracle.jbo.common.ListBindingDef;
/*     */ import oracle.jbo.server.NamedObjectAnnotations;
/*     */ import oracle.jbo.server.RowFinder;
/*     */ import oracle.jbo.server.RowFinderAnnotation;
/*     */ import oracle.jbo.server.ViewAnnotations;
/*     */ import oracle.jbo.server.ViewAnnotations.Category;
/*     */ import oracle.jbo.server.ViewDefImpl;
/*     */ import oracle.jbo.server.ViewObjectImpl;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
/*     */ 
/*     */ public final class ResourceDescription
/*     */ {
/*     */   public static final String NAME_PLURAL = "Resources";
/*     */   public static final String TITLE_ATTR = "title";
/*     */   public static final String TITLE_PLURAL_ATTR = "titlePlural";
/*     */   public static final String CHILDREN_ATTR = "children";
/*     */   public static final String DISCR_COLUMN_TYPE_ATTR = "discrColumnType";
/*     */   public static final String DOC_CATEGORIES_ATTR = "docCategories";
/*     */   public static final String DESCRIBE_SUFIX = "describe";
/*     */   private static final String VOID_RESULT_TYPE = "void";
/*     */   private static final String ACTION_DISABLED = "#{false}";
/*     */   private final String name;
/*     */   private final boolean discrColumnType;
/*     */   private final String basePath;
/*     */   private final Path collectionPath;
/*     */   private final Path itemPath;
/*     */   private final Path path;
/*     */   private final Collection<Attribute> attributes;
/*     */   private final EntityContentMapping entityContentMap;
/*     */   private final PayloadType payloadType;
/*     */   private final Set<String> childrenNames;
/*     */   private final ResourceTree resourceTree;
/*     */   private final Collection<Link> links;
/*     */   private final JUCtrlHierTypeBinding typeBinding;
/*     */   private final ViewObjectImpl vo;
/*     */   private final ViewAnnotations voAn;
/*     */   private final JUCtrlHierTypeBinding parentTypeBinding;
/*     */   private final Path parentResourcePath;
/*     */   private boolean annotationsShowable;
/*     */   private final Collection<Link> attributeResourceLevelLinks;
/*     */   private String label;
/*     */   private String pluralLabel;
/*     */   private Resource resource;
/*     */   
/*     */   public Path getPath()
/*     */   {
/*  74 */     return this.path;
/*     */   }
/*     */   
/*     */   public List<String> getDocCategories() {
/*  78 */     if (this.resource != null) {
/*  79 */       return this.resourceTree.getTree().getDocCategories();
/*     */     }
/*  81 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   public ResourceDescription(Resource resource, String basePath, EntityContentMapping entityContentMap, PayloadType payloadType) {
/*  85 */     this.typeBinding = resource.getHierTypeBinding();
/*  86 */     this.name = resource.getName();
/*  87 */     this.discrColumnType = this.typeBinding.isDiscrColumnType();
/*  88 */     this.basePath = basePath;
/*     */     Path itemPath;
/*     */     Path itemPath;
/*     */     Path path;
/*  92 */     if (resource.isCollection()) {
/*  93 */       this.collectionPath = resource.getPath(basePath);
/*  94 */       Path path = this.collectionPath;
/*  95 */       itemPath = new Path(this.collectionPath, "{id}");
/*     */     } else {
/*  97 */       this.collectionPath = resource.getParent().getPath(this.basePath);
/*  98 */       itemPath = resource.getPath(this.basePath);
/*  99 */       path = itemPath;
/*     */     }
/* 101 */     this.path = path;
/* 102 */     this.itemPath = itemPath;
/* 103 */     this.attributes = Collections.unmodifiableCollection(resource.getAttributes());
/* 104 */     this.attributeResourceLevelLinks = Collections.unmodifiableCollection(Attribute.createResourceLevelLinks(this.attributes, this.basePath));
/* 105 */     this.entityContentMap = entityContentMap;
/* 106 */     this.payloadType = payloadType;
/*     */     
/* 108 */     this.resourceTree = resource.getTree();
/*     */     
/* 110 */     JUCtrlHierTypeBinding parentTypeBinding = null;
/* 111 */     Path parentResourcePath = null;
/* 112 */     if (!resource.isTopLevel()) {
/* 113 */       Resource parent = resource.getParent();
/* 114 */       if (resource.isItem()) {
/* 115 */         Resource itemParent = parent.getParent();
/* 116 */         parentTypeBinding = itemParent.getHierTypeBinding();
/* 117 */         parentResourcePath = itemParent.getPath(basePath);
/*     */       } else {
/* 119 */         parentTypeBinding = parent.getHierTypeBinding();
/* 120 */         parentResourcePath = parent.getPath(basePath);
/*     */       }
/*     */     }
/*     */     
/* 124 */     this.parentTypeBinding = parentTypeBinding;
/* 125 */     this.links = Collections.unmodifiableCollection(createDescribeLinks(this.path));
/* 126 */     this.parentResourcePath = parentResourcePath;
/* 127 */     this.resource = resource;
/* 128 */     this.childrenNames = Collections.unmodifiableSet(this.resource.getNestedResourceNames());
/* 129 */     this.vo = resource.getVO();
/* 130 */     this.voAn = ViewAnnotations.getViewAnnotations((ViewDefImpl)this.vo.getDef());
/* 131 */     if (this.voAn != null) {
/* 132 */       this.voAn.setResourceBundleDef(this.vo.getResourceBundleDef());
/*     */     }
/*     */     
/* 135 */     this.label = getProperty("LABEL", this.vo, this.resourceTree.getTree().getLocaleContext());
/*     */     
/* 137 */     this.pluralLabel = getProperty("LABEL_PLURAL", this.vo, this.resourceTree.getTree().getLocaleContext());
/*     */   }
/*     */   
/*     */   public void setAnnotationsShowable(boolean annotationsShowable)
/*     */   {
/* 142 */     this.annotationsShowable = annotationsShowable;
/*     */   }
/*     */   
/*     */   public boolean isAnnotationsShowable() {
/* 146 */     return this.annotationsShowable;
/*     */   }
/*     */   
/*     */   private static String getProperty(String propertyName, ViewObject vo, LocaleContext localeContext) {
/* 150 */     return (String)vo.getProperty(propertyName, localeContext);
/*     */   }
/*     */   
/*     */   private ResourceDescription(ResourceDescription parent, ViewObjectImpl vo, String name, JUCtrlHierTypeBinding typeBinding)
/*     */   {
/* 155 */     this.parentTypeBinding = parent.typeBinding;
/* 156 */     this.resourceTree = parent.resourceTree;
/* 157 */     this.basePath = parent.basePath;
/* 158 */     this.parentResourcePath = parent.itemPath;
/* 159 */     this.entityContentMap = parent.entityContentMap;
/* 160 */     this.payloadType = parent.payloadType;
/*     */     
/*     */ 
/* 163 */     LocaleContext localeContext = this.resourceTree.getTree().getLocaleContext();
/* 164 */     this.vo = vo;
/* 165 */     this.voAn = ViewAnnotations.getViewAnnotations((ViewDefImpl)this.vo.getDef());
/* 166 */     if (this.voAn != null) {
/* 167 */       this.voAn.setResourceBundleDef(this.vo.getResourceBundleDef());
/*     */     }
/* 169 */     this.typeBinding = typeBinding;
/* 170 */     this.name = name;
/* 171 */     this.discrColumnType = Resource.isPolymorphic(typeBinding, this.parentTypeBinding, name, null);
/* 172 */     this.attributes = Collections.unmodifiableCollection(ResourceCollection.getAccessorChildAttributes(vo, typeBinding, localeContext));
/* 173 */     this.attributeResourceLevelLinks = Collections.unmodifiableCollection(Attribute.createResourceLevelLinks(this.attributes, this.basePath));
/* 174 */     this.collectionPath = new Path(this.parentResourcePath, Arrays.asList(new String[] { "child", this.name }));
/* 175 */     this.itemPath = new Path(this.collectionPath, "{id}");
/* 176 */     this.path = this.itemPath;
/*     */     
/* 178 */     Set<String> childAccessorNames = Collections.emptySet();
/*     */     
/* 180 */     if (this.parentTypeBinding != typeBinding) {
/* 181 */       String[] accessorNames = typeBinding.getAccessorNames();
/* 182 */       if ((accessorNames != null) && (accessorNames.length > 0)) {
/* 183 */         childAccessorNames = new HashSet(Arrays.asList(accessorNames));
/*     */       }
/*     */     }
/*     */     
/* 187 */     this.childrenNames = Collections.unmodifiableSet(childAccessorNames);
/* 188 */     this.links = Collections.unmodifiableCollection(createDescribeLinks(this.collectionPath));
/*     */     
/* 190 */     this.label = getProperty("LABEL", this.vo, localeContext);
/*     */     
/* 192 */     this.pluralLabel = getProperty("LABEL_PLURAL", this.vo, localeContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 199 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean isDiscrColumnType() {
/* 203 */     return this.discrColumnType;
/*     */   }
/*     */   
/*     */   public String getLabel() {
/* 207 */     return this.label;
/*     */   }
/*     */   
/*     */   public String getPluralLabel() {
/* 211 */     return this.pluralLabel;
/*     */   }
/*     */   
/*     */   public Collection<Attribute> getAttributes() {
/* 215 */     return this.attributes;
/*     */   }
/*     */   
/*     */   public CollectionSection createCollectionSection() {
/* 219 */     if (this.resource != null) {
/* 220 */       return new CollectionSection(this.resource, null);
/*     */     }
/* 222 */     return new CollectionSection(null);
/*     */   }
/*     */   
/*     */   public ItemSection createItemSection() {
/* 226 */     if (this.resource != null) {
/* 227 */       return new ItemSection(this.resource, null);
/*     */     }
/* 229 */     return new ItemSection(null);
/*     */   }
/*     */   
/*     */   public ResourceAnnotationsSection createResourceAnnotationsSection() {
/* 233 */     if ((this.voAn != null) && (this.annotationsShowable)) {
/* 234 */       return new ResourceAnnotationsSection(this.voAn, null);
/*     */     }
/* 236 */     return null;
/*     */   }
/*     */   
/*     */   public String getDescriptionText(Attribute attr) {
/* 240 */     if ((this.voAn != null) && (this.annotationsShowable))
/*     */     {
/* 242 */       NamedObjectAnnotations attrAn = this.voAn.findAttribute(attr.getName());
/* 243 */       if (attrAn != null) {
/* 244 */         return attrAn.getDescription(this.resourceTree.getTree().getLocaleContext());
/*     */       }
/*     */     }
/* 247 */     return null;
/*     */   }
/*     */   
/*     */   public Set<String> getChildrenNames() {
/* 251 */     return this.childrenNames;
/*     */   }
/*     */   
/*     */   public ResourceDescription createChildDescription(String childName) {
/* 255 */     JUCtrlHierTypeBinding childTypeBinding = this.resourceTree.getTypeBinding(this.vo, childName);
/* 256 */     ViewObjectImpl childVO = (ViewObjectImpl)this.vo.findAttributeDef(childName).getAccessorVO(this.vo);
/* 257 */     return new ResourceDescription(this, childVO, childName, childTypeBinding);
/*     */   }
/*     */   
/*     */   public List<Link> getLinks() {
/* 261 */     List<Link> allLinks = new LinkedList(this.links);
/* 262 */     allLinks.addAll(this.attributeResourceLevelLinks);
/* 263 */     return allLinks;
/*     */   }
/*     */   
/*     */   private List<Link> createDescribeLinks(Path path) {
/* 267 */     List<Link> describeLinks = new ArrayList();
/* 268 */     describeLinks.add(new Link("self", "self", new Path(path, "describe"), Link.Kind.DESCRIBE));
/*     */     
/* 270 */     Link canonicalLink = createCanonicalDescribeLink(path);
/* 271 */     describeLinks.add(canonicalLink);
/* 272 */     return describeLinks;
/*     */   }
/*     */   
/*     */   private Link createCanonicalDescribeLink(Path resourcePath) {
/* 276 */     Path canonicalPath = null;
/* 277 */     ResourceReference resourceReference = ResourceReferenceFactory.createResourceReference(this.resourceTree.getTree(), this.basePath, this.typeBinding, null);
/*     */     
/*     */ 
/* 280 */     if ((resourceReference != null) && (resourceReference.getType() != ResourceReference.Type.EXTERNAL)) {
/* 281 */       canonicalPath = resourceReference.getResourceReferencePath();
/*     */     }
/*     */     
/* 284 */     if (canonicalPath == null) {
/* 285 */       canonicalPath = resourcePath;
/*     */     }
/* 287 */     return new Link("canonical", "canonical", new Path(canonicalPath, "describe"), Link.Kind.DESCRIBE);
/*     */   }
/*     */   
/*     */   private List<ActionDescription> createActionDescriptions(List<Action> defaultActions, boolean acceptRowOperation)
/*     */   {
/* 292 */     List<ActionDescription> actionDescriptions = new LinkedList();
/*     */     
/* 294 */     for (Action action : defaultActions) {
/* 295 */       if (Action.isAuthorized(getName(), action.getType())) {
/* 296 */         actionDescriptions.add(new ActionDescription(action, this.entityContentMap));
/*     */       }
/*     */     }
/* 299 */     Map<String, String> nodeActions = this.typeBinding.getHierTypeActions();
/* 300 */     if (!nodeActions.isEmpty()) {
/* 301 */       Iterator<ActionDescription> iterator = actionDescriptions.iterator();
/* 302 */       while (iterator.hasNext()) {
/* 303 */         String actionValue = (String)nodeActions.get(((ActionDescription)iterator.next()).getType().getActionBindingName());
/* 304 */         if ("#{false}".equals(actionValue)) {
/* 305 */           iterator.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 310 */     if (("implied".equals(this.typeBinding.getActionType())) && (Action.isAuthorized(getName(), ActionType.INVOKE))) {
/* 311 */       DCDataControl dataControl = ResourceTree.getBindingContainer(this.resourceTree).getDataControl();
/* 312 */       for (OperationDefinition operDef : getOperations(dataControl, this.vo, acceptRowOperation)) {
/* 313 */         String resultType = operDef.getOperationReturnType().getJavaTypeString();
/* 314 */         if ("void".equals(resultType)) {
/* 315 */           resultType = null;
/*     */         }
/* 317 */         ActionDescription actionDescription = new ActionDescription(operDef.getName(), resultType, createParameterDescription(operDef), this.entityContentMap);
/*     */         
/*     */ 
/* 320 */         actionDescriptions.add(actionDescription);
/*     */       }
/*     */     }
/*     */     
/* 324 */     return actionDescriptions;
/*     */   }
/*     */   
/*     */   private Collection<OperationDefinition> getOperations(DCDataControl dataControl, ViewObject vo, boolean acceptRowOperation) {
/* 328 */     List<OperationDefinition> filteredOperations = new ArrayList();
/* 329 */     for (OperationDefinition operDef : JUCtrlHierNodeBinding.filterOperationsBasedOnPayLoadHintUsingVO(dataControl, vo)) {
/* 330 */       Boolean isRowOperation = (Boolean)operDef.getProperty("__IS_ROW_LEVEL_VIEW_OBJECT_METHOD__");
/* 331 */       if ((isRowOperation != null) && (isRowOperation.booleanValue())) {
/* 332 */         if (acceptRowOperation) {
/* 333 */           filteredOperations.add(operDef);
/*     */         }
/*     */       }
/* 336 */       else if (!acceptRowOperation) {
/* 337 */         filteredOperations.add(operDef);
/*     */       }
/*     */     }
/*     */     
/* 341 */     return filteredOperations;
/*     */   }
/*     */   
/*     */   private List<ParameterDescription> createParameterDescription(OperationDefinition operDef) {
/* 345 */     List<ParameterDescription> params = new ArrayList();
/* 346 */     DefinitionContainer parameters = operDef.getOperationParameters();
/* 347 */     Iterator parameterIter = parameters.iterator();
/*     */     
/* 349 */     while (parameterIter.hasNext()) {
/* 350 */       ParameterDefinition parameter = (ParameterDefinition)parameterIter.next();
/* 351 */       ParameterDescription paramDescription = new ParameterDescription();
/* 352 */       paramDescription.setName(parameter.getName());
/* 353 */       paramDescription.setTypeName(parameter.getJavaTypeString());
/* 354 */       params.add(paramDescription);
/*     */     }
/*     */     
/* 357 */     return params;
/*     */   }
/*     */   
/*     */   private List<ActionDescription> createActionDescriptions(List<Action> actions) {
/* 361 */     if (actions.isEmpty()) {
/* 362 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 365 */     List<ActionDescription> actionDescriptions = new ArrayList(actions.size());
/* 366 */     for (Action action : actions) {
/* 367 */       if ((action.isEnabled()) && (Action.isAuthorized(getName(), action.getType()))) {
/* 368 */         actionDescriptions.add(new ActionDescription(action, this.entityContentMap));
/*     */       }
/*     */     }
/*     */     
/* 372 */     return actionDescriptions;
/*     */   }
/*     */   
/*     */   private List<FinderDescription> createFinderDescriptions() {
/* 376 */     Collection<RowFinder> rowFinders = this.vo.getRowFinders(true).values();
/*     */     
/* 378 */     if (rowFinders.isEmpty()) {
/* 379 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 382 */     List<FinderDescription> finders = new ArrayList(rowFinders.size());
/*     */     
/* 384 */     boolean includeAnnotations = (this.annotationsShowable) && (this.voAn != null);
/*     */     
/*     */ 
/*     */ 
/* 388 */     for (RowFinder rowFinder : rowFinders) {
/* 389 */       Finder finder = new Finder(this.vo, rowFinder, this.typeBinding, this.resourceTree.getTree().getLocaleContext());
/* 390 */       if (finder.isEnabled()) { RowFinderAnnotation annotation;
/* 391 */         if ((includeAnnotations) && ((annotation = this.voAn.findRowFinder(finder.getName())) != null)) {
/* 392 */           FinderDescription finderDesc = new FinderDescription(finder, annotation, this.resourceTree.getTree().getLocaleContext());
/* 393 */           finders.add(finderDesc);
/*     */         } else {
/* 395 */           finders.add(new FinderDescription(finder));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 400 */     return finders;
/*     */   }
/*     */   
/*     */   private static List<FinderDescription> createFinderDescriptions(Resource resource, boolean annotationsShowable) {
/* 404 */     List<Finder> finders = resource.getFinders();
/*     */     
/* 406 */     List<FinderDescription> finderDescriptions = new ArrayList(finders.size());
/*     */     
/* 408 */     ViewAnnotations viewAnn = annotationsShowable ? ViewAnnotations.getViewAnnotations((ViewDefImpl)resource.getVO().getDef()) : null;
/*     */     
/*     */ 
/*     */ 
/* 412 */     for (Finder finder : finders) {
/*     */       RowFinderAnnotation annotation;
/* 414 */       if ((viewAnn != null) && ((annotation = viewAnn.findRowFinder(finder.getName())) != null)) {
/* 415 */         FinderDescription finderDesc = new FinderDescription(finder, annotation, resource.getTree().getTree().getLocaleContext());
/* 416 */         finderDescriptions.add(finderDesc);
/*     */       } else {
/* 418 */         finderDescriptions.add(new FinderDescription(finder));
/*     */       }
/*     */     }
/*     */     
/* 422 */     return finderDescriptions;
/*     */   }
/*     */   
/*     */   public final class ItemSection
/*     */   {
/*     */     private List<Link> links;
/*     */     private List<Attribute> attributesWithLink;
/*     */     private List<ActionDescription> actionDescriptions;
/*     */     private static final String RESOURCE_REF_ACCESSOR_ELEM = "ResourceRef";
/*     */     
/*     */     private ItemSection(Resource resource)
/*     */     {
/* 434 */       this.links = Collections.unmodifiableList(createResourceLinks(ResourceDescription.this.parentResourcePath, ResourceDescription.this.itemPath, resource.getCardinalityMap(), resource.getResourceReference(ResourceDescription.this.itemPath.getBasePath()), ResourceDescription.this.attributes));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 442 */       this.attributesWithLink = Collections.unmodifiableList(getAttributesWithLink(ResourceDescription.this.attributes, ResourceDescription.this.payloadType));
/*     */       
/*     */ 
/*     */ 
/* 446 */       if (resource.isItem()) {
/* 447 */         this.actionDescriptions = Collections.unmodifiableList(ResourceDescription.this.createActionDescriptions(resource.getItemActions()));
/*     */       }
/*     */       else {
/* 450 */         this.actionDescriptions = Collections.unmodifiableList(ResourceDescription.this.createActionDescriptions(resource.getItemDefaultActions(), true));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     private ItemSection()
/*     */     {
/* 457 */       JUCtrlHierBinding tree = ResourceDescription.this.resourceTree.getTree();
/* 458 */       Map resourceReferenceMap = (Map)ResourceDescription.this.typeBinding.getRawPropertyValue("ResourceRef");
/*     */       
/* 460 */       DCBindingContainer bindingContainer = tree.getBindingContainer();
/* 461 */       ResourceReference resourceReference = ResourceReferenceFactory.createResourceReference(bindingContainer, ResourceDescription.this.itemPath.getBasePath(), "{id}", resourceReferenceMap);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 467 */       this.links = Collections.unmodifiableList(createResourceLinks(ResourceDescription.this.parentResourcePath, ResourceDescription.this.itemPath, Resource.getCardinalityMap(ResourceDescription.this.childrenNames, ResourceDescription.this.vo), resourceReference, ResourceDescription.this.attributes));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 472 */       this.attributesWithLink = Collections.unmodifiableList(getAttributesWithLink(ResourceDescription.this.attributes, ResourceDescription.this.payloadType));
/*     */       
/* 474 */       this.actionDescriptions = Collections.unmodifiableList(ResourceDescription.this.createActionDescriptions(Resource.getUnboundItemDefaultActions(ResourceDescription.this.parentTypeBinding, ResourceDescription.this.name, ResourceDescription.this.typeBinding), true));
/*     */     }
/*     */     
/*     */ 
/*     */     private List<Link> createResourceLinks(Path parentPath, Path path, Map<String, Cardinality> cardinalityMap, ResourceReference resourceReference, Collection<Attribute> attributes)
/*     */     {
/* 480 */       List<Link> resourceLinks = new ArrayList();
/*     */       
/* 482 */       for (Attribute attribute : attributes) {
/* 483 */         if (attribute.hasLov()) {
/* 484 */           String listVOName = attribute.getAttrDef().getListBindingDef().getListVOName();
/* 485 */           if (cardinalityMap.containsKey(listVOName)) {
/* 486 */             cardinalityMap.remove(listVOName);
/* 487 */             resourceLinks.add(new Link(listVOName, "lov", new Path(path, Arrays.asList(new String[] { "lov", listVOName })), Link.Kind.COLLECTION));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 494 */       resourceLinks.addAll(createChildrenLinks(cardinalityMap, path));
/* 495 */       Link resourceSelfLink = new Link("self", "self", path, Link.Kind.ITEM);
/* 496 */       resourceLinks.add(resourceSelfLink);
/* 497 */       if (parentPath != null) {
/* 498 */         resourceLinks.add(new Link("parent", "parent", parentPath, Link.Kind.ITEM));
/*     */       }
/*     */       
/*     */ 
/* 502 */       Link canonicalLink = createCanonicalLink(path, resourceReference);
/* 503 */       resourceLinks.add(canonicalLink);
/*     */       
/* 505 */       return resourceLinks;
/*     */     }
/*     */     
/*     */     private List<Link> createChildrenLinks(Map<String, Cardinality> cardinalityMap, Path path) {
/* 509 */       if (cardinalityMap.isEmpty()) {
/* 510 */         return Collections.emptyList();
/*     */       }
/* 512 */       ArrayList<Link> childrenLinks = new ArrayList(cardinalityMap.size());
/*     */       
/* 514 */       for (Map.Entry<String, Cardinality> entry : cardinalityMap.entrySet()) {
/* 515 */         String childName = (String)entry.getKey();
/* 516 */         Link childLink = new Link(childName, "child", new Path(path, Arrays.asList(new String[] { "child", childName })), (Cardinality)entry.getValue(), Link.Kind.COLLECTION);
/*     */         
/* 518 */         childrenLinks.add(childLink);
/*     */       }
/*     */       
/* 521 */       return childrenLinks;
/*     */     }
/*     */     
/*     */     private Link createCanonicalLink(Path resourcePath, ResourceReference resourceReference) {
/* 525 */       Path canonicalPath = null;
/*     */       
/* 527 */       if (resourceReference != null) {
/* 528 */         canonicalPath = resourceReference.getResourceReferencePath();
/*     */       }
/*     */       
/* 531 */       if (canonicalPath == null) {
/* 532 */         canonicalPath = resourcePath;
/*     */       }
/* 534 */       return new Link("canonical", "canonical", canonicalPath, Link.Kind.ITEM);
/*     */     }
/*     */     
/*     */     private List<Attribute> getAttributesWithLink(Collection<Attribute> attributes, PayloadType payloadType)
/*     */     {
/* 539 */       List<Attribute> attributeLinks = new ArrayList();
/* 540 */       for (Attribute attribute : attributes) {
/* 541 */         if ((attribute.hasItemLevelLink(payloadType)) && ((attribute.canStreamContent()) || (attribute.getValue() != null))) {
/* 542 */           attributeLinks.add(attribute);
/*     */         }
/*     */       }
/*     */       
/* 546 */       return attributeLinks;
/*     */     }
/*     */     
/*     */     public List<Link> getLinks() {
/* 550 */       return this.links;
/*     */     }
/*     */     
/*     */     public List<Attribute> getAttributesWithLink() {
/* 554 */       return this.attributesWithLink;
/*     */     }
/*     */     
/*     */     public List<ActionDescription> getActionDescriptions() {
/* 558 */       return this.actionDescriptions;
/*     */     }
/*     */   }
/*     */   
/*     */   public final class CollectionSection
/*     */   {
/*     */     public static final String NAME = "collection";
/*     */     public static final String RANGE_SIZE_ATTR = "rangeSize";
/*     */     private final int rangeSize;
/*     */     private final List<FinderDescription> finders;
/*     */     private final List<ActionDescription> actionDescriptions;
/*     */     private final List<Link> links;
/*     */     
/*     */     private CollectionSection() {
/* 572 */       this.rangeSize = ResourceCollection.getLimit(ResourceDescription.this.vo, ResourceDescription.this.vo.getRangeSize());
/*     */       
/* 574 */       this.finders = Collections.unmodifiableList(ResourceDescription.this.createFinderDescriptions());
/* 575 */       this.actionDescriptions = Collections.unmodifiableList(ResourceDescription.this.createActionDescriptions(Resource.getUnboundCollectionDefaultActions(ResourceDescription.this.parentTypeBinding, ResourceDescription.this.name, ResourceDescription.this.typeBinding), false));
/* 576 */       this.links = Collections.unmodifiableList(createLinks(ResourceDescription.this.collectionPath));
/*     */     }
/*     */     
/*     */     private CollectionSection(Resource resource) {
/* 580 */       this.rangeSize = ResourceCollection.getLimit(ResourceDescription.this.vo, resource.getChildIteratorRangeSize());
/*     */       
/* 582 */       this.finders = Collections.unmodifiableList(ResourceDescription.createFinderDescriptions(resource, ResourceDescription.this.isAnnotationsShowable()));
/*     */       
/* 584 */       if (resource.isItem()) {
/* 585 */         this.actionDescriptions = Collections.unmodifiableList(ResourceDescription.this.createActionDescriptions(resource.getCollectionActions()));
/*     */       }
/*     */       else {
/* 588 */         this.actionDescriptions = Collections.unmodifiableList(ResourceDescription.this.createActionDescriptions(resource.getCollectionDefaultActions(), false));
/*     */       }
/*     */       
/*     */ 
/* 592 */       this.links = Collections.unmodifiableList(createLinks(ResourceDescription.this.collectionPath));
/*     */     }
/*     */     
/*     */     private List<Link> createLinks(Path path) {
/* 596 */       List<Link> collectionLinks = new ArrayList();
/* 597 */       Link collectionSelfLink = new Link("self", "self", path, Link.Kind.COLLECTION);
/*     */       
/* 599 */       collectionLinks.add(collectionSelfLink);
/* 600 */       return collectionLinks;
/*     */     }
/*     */     
/*     */     public int getRangeSize() {
/* 604 */       return this.rangeSize;
/*     */     }
/*     */     
/*     */     public List<FinderDescription> getFinderDescriptions() {
/* 608 */       return this.finders;
/*     */     }
/*     */     
/*     */     public List<Link> getLinks() {
/* 612 */       return this.links;
/*     */     }
/*     */     
/*     */     public List<ActionDescription> getActionDescriptions() {
/* 616 */       return this.actionDescriptions;
/*     */     }
/*     */   }
/*     */   
/*     */   public final class ResourceAnnotationsSection {
/*     */     public static final String NAME = "annotations";
/*     */     public static final String KEYWORDS = "keywords";
/*     */     public static final String CATEGORIES = "categories";
/*     */     public static final String CHILDREN = "children";
/*     */     public static final String NAME_ATTR = "name";
/*     */     public static final String DESC_ATTR = "description";
/* 627 */     private final int categoryMapSize = (int)Math.ceil(ViewAnnotations.Category.values().length / 0.74D);
/*     */     private final List<String> keywordList;
/*     */     private final Map<String, List<String>> categoryMap;
/*     */     private final String description;
/*     */     private final Map<String, String> childDescriptions;
/*     */     
/*     */     private ResourceAnnotationsSection(ViewAnnotations viewAnnotations)
/*     */     {
/* 635 */       LocaleContext localeContext = ResourceDescription.this.resourceTree.getTree().getLocaleContext();
/* 636 */       this.description = viewAnnotations.getDescription(localeContext);
/* 637 */       List<String> tempKeywordList = viewAnnotations.getKeywordList();
/* 638 */       Map<String, List<String>> tempCategoryMap = new HashMap(this.categoryMapSize);
/* 639 */       for (ViewAnnotations.Category category : ViewAnnotations.Category.values()) {
/* 640 */         List<String> categoryValues = viewAnnotations.getCategoryValues(category.getName().toUpperCase());
/* 641 */         if ((categoryValues != null) && (!categoryValues.isEmpty())) {
/* 642 */           tempCategoryMap.put(category.getName(), categoryValues);
/*     */         }
/*     */       }
/*     */       
/* 646 */       Map<String, String> tempLocaleSpecificDescriptions = new HashMap();
/* 647 */       for (String childName : ResourceDescription.this.childrenNames) {
/* 648 */         NamedObjectAnnotations childAnnotation = viewAnnotations.findAttribute(childName);
/* 649 */         String description = childAnnotation != null ? childAnnotation.getDescription(localeContext) : null;
/* 650 */         if (description != null) {
/* 651 */           tempLocaleSpecificDescriptions.put(childName, description);
/*     */         }
/*     */       }
/*     */       
/* 655 */       this.keywordList = Collections.unmodifiableList(tempKeywordList);
/* 656 */       this.categoryMap = Collections.unmodifiableMap(tempCategoryMap);
/* 657 */       this.childDescriptions = Collections.unmodifiableMap(tempLocaleSpecificDescriptions);
/*     */     }
/*     */     
/*     */     public List<String> getKeyWordList() {
/* 661 */       return this.keywordList;
/*     */     }
/*     */     
/*     */     public Map<String, List<String>> getCategoryMap() {
/* 665 */       return this.categoryMap;
/*     */     }
/*     */     
/*     */     public String getDescription() {
/* 669 */       return this.description;
/*     */     }
/*     */     
/*     */     public Map<String, String> getChildDescriptions() {
/* 673 */       return this.childDescriptions;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 677 */       return (this.categoryMap.isEmpty()) && (this.keywordList.isEmpty()) && (this.childDescriptions.isEmpty()) && (this.description == null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */