/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ 
/*    */ public class QualityFactor implements Comparable<QualityFactor>
/*    */ {
/*    */   public static final String NAME = "q";
/*    */   public static final String BEST_QUALITY_VALUE = "1";
/*    */   public static final String DEFAULT_VALUE = "1";
/*    */   public static final String WORST_QUALITY_VALUE = "0.001";
/*    */   public static final String NOT_ACCEPTABLE_QUALITY_VALUE = "0";
/*    */   private final Float qvalue;
/* 13 */   private static final Float NOT_ACCEPTABLE_VALUE = Float.valueOf(0.0F);
/*    */   
/*    */   public QualityFactor() {
/* 16 */     this.qvalue = createQvalue("1");
/*    */   }
/*    */   
/*    */   public QualityFactor(String qvalue) {
/* 20 */     this.qvalue = createQvalue(qvalue);
/*    */   }
/*    */   
/*    */   public static Float createQvalue(String qvalue) {
/* 24 */     Float createdQvalue = null;
/* 25 */     if ((qvalue != null) && (qvalue.length() < 6)) {
/* 26 */       createdQvalue = Float.valueOf(Float.parseFloat(qvalue));
/* 27 */       validateQvalue(createdQvalue);
/*    */     } else {
/* 29 */       throw new IllegalArgumentException("Invalid value for qvalue: " + qvalue);
/*    */     }
/* 31 */     return createdQvalue;
/*    */   }
/*    */   
/*    */   public static void validateQvalue(Float qvalue) {
/* 35 */     if ((qvalue.floatValue() > 1.0F) && (qvalue.floatValue() < 0.0F)) {
/* 36 */       throw new IllegalArgumentException("Invalid value for qvalue: " + qvalue);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString() {
/* 41 */     DecimalFormat decimalFormat = new DecimalFormat();
/* 42 */     decimalFormat.setMaximumFractionDigits(3);
/* 43 */     return decimalFormat.format(this.qvalue);
/*    */   }
/*    */   
/*    */   public Float getQvalue() {
/* 47 */     return this.qvalue;
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 52 */     if (this == object) {
/* 53 */       return true;
/*    */     }
/* 55 */     if (!(object instanceof QualityFactor)) {
/* 56 */       return false;
/*    */     }
/* 58 */     QualityFactor other = (QualityFactor)object;
/* 59 */     if (this.qvalue == null ? other.qvalue != null : !this.qvalue.equals(other.qvalue)) {
/* 60 */       return false;
/*    */     }
/* 62 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 67 */     int PRIME = 37;
/* 68 */     int result = 1;
/* 69 */     result = 37 * result + (this.qvalue == null ? 0 : this.qvalue.hashCode());
/* 70 */     return result;
/*    */   }
/*    */   
/*    */   public int compareTo(QualityFactor qFactor)
/*    */   {
/* 75 */     return this.qvalue.compareTo(qFactor.getQvalue());
/*    */   }
/*    */   
/*    */   public boolean isAcceptable() {
/* 79 */     return !this.qvalue.equals(NOT_ACCEPTABLE_VALUE);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\QualityFactor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */