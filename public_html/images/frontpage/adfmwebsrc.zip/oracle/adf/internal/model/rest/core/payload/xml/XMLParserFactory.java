/*    */ package oracle.adf.internal.model.rest.core.payload.xml;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import javax.xml.stream.XMLInputFactory;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamReader;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceTreeManager;
/*    */ import oracle.adf.internal.model.rest.core.payload.ActionParser;
/*    */ import oracle.adf.internal.model.rest.core.payload.BatchRequestParser;
/*    */ import oracle.adf.internal.model.rest.core.payload.ParserFactory;
/*    */ import oracle.adf.internal.model.rest.core.payload.ResourceParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XMLParserFactory
/*    */   extends ParserFactory
/*    */ {
/*    */   private final XMLStreamReader xsr;
/*    */   
/*    */   public XMLParserFactory(Reader reader)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 30 */       this.xsr = getXMLInputFactory().createXMLStreamReader(reader);
/*    */     }
/*    */     catch (XMLStreamException ex)
/*    */     {
/* 34 */       throw new IOException(ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public XMLParserFactory(InputStream inputStream) throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 42 */       this.xsr = getXMLInputFactory().createXMLStreamReader(inputStream);
/*    */     }
/*    */     catch (XMLStreamException ex)
/*    */     {
/* 46 */       throw new IOException(ex);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private XMLInputFactory getXMLInputFactory()
/*    */   {
/* 53 */     XMLInputFactory xif = XMLInputFactory.newFactory();
/* 54 */     xif.setProperty("javax.xml.stream.isSupportingExternalEntities", Boolean.valueOf(false));
/* 55 */     xif.setProperty("javax.xml.stream.isCoalescing", Boolean.valueOf(true));
/*    */     
/* 57 */     return xif;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ActionParser getActionParser()
/*    */   {
/* 64 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */ 
/*    */   public BatchRequestParser getBatchRequestParser()
/*    */   {
/* 70 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */ 
/*    */   public ResourceParser getResourceParser(ResourceTreeManager resourceTreeManager)
/*    */   {
/* 76 */     return new XMLResourceParser(this.xsr, resourceTreeManager);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\xml\XMLParserFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */