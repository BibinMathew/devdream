/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import oracle.adf.internal.model.rest.core.exception.ActionNotEnabledException;
/*    */ 
/*    */ public final class UpdateAction extends Action
/*    */ {
/*    */   public UpdateAction(Resource resource)
/*    */   {
/* 11 */     super(ActionType.UPDATE, resource);
/*    */   }
/*    */   
/*    */   UpdateAction() {
/* 15 */     super(ActionType.UPDATE);
/*    */   }
/*    */   
/*    */   public ActionResult execute()
/*    */   {
/* 20 */     if (!isEnabled()) {
/* 21 */       throw new ActionNotEnabledException(getName());
/*    */     }
/*    */     
/* 24 */     Resource resource = getResource();
/* 25 */     for (Map.Entry<String, Object> entry : getParameters().entrySet()) {
/* 26 */       Attribute currentAttribute = resource.getAttribute((String)entry.getKey());
/* 27 */       if (currentAttribute != null) {
/* 28 */         currentAttribute.setValue(entry.getValue());
/*    */       }
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\UpdateAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */