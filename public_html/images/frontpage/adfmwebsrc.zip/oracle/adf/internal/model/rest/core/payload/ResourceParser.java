/*    */ package oracle.adf.internal.model.rest.core.payload;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ResourceParser
/*    */ {
/*    */   public abstract TokenType next()
/*    */     throws IOException;
/*    */   
/*    */   public abstract String getNestedResourceName();
/*    */   
/*    */   public static enum TokenType
/*    */   {
/* 16 */     START_ITEM,  START_COLLECTION,  END_ITEM,  END_COLLECTION,  ATTR_VALUE,  CLOSE;
/*    */     
/*    */     private TokenType() {}
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\ResourceParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */