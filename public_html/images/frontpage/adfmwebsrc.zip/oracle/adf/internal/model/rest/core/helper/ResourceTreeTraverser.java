/*     */ package oracle.adf.internal.model.rest.core.helper;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameter.Type;
/*     */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*     */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceCollection;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*     */ import oracle.adf.internal.model.rest.core.topology.ResourceTreePath;
/*     */ import oracle.adf.internal.model.rest.core.topology.TreePath;
/*     */ 
/*     */ public final class ResourceTreeTraverser
/*     */ {
/*     */   private final String basePath;
/*     */   private final oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap parameterMap;
/*     */   private final PayloadGenerator generator;
/*     */   private final oracle.adf.internal.model.rest.core.domain.ResourceTree tree;
/*  22 */   private boolean count = false;
/*  23 */   private boolean onlyData = false;
/*     */   private Set<String> attributeFilterList;
/*     */   private TreePath treePath;
/*  26 */   private java.util.Map<String, Set<String>> accessorFilterMap = java.util.Collections.emptyMap();
/*     */   
/*     */   public ResourceTreeTraverser(ResourceProcessingContext context, PayloadGenerator generator) {
/*  29 */     this.generator = generator;
/*  30 */     this.basePath = context.getBasePath();
/*  31 */     this.parameterMap = context.getResourceParameterMap();
/*  32 */     this.tree = context.getResourceTree();
/*  33 */     this.treePath = context.getTreePath();
/*  34 */     if (this.parameterMap != null) {
/*  35 */       setupParameters();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setupParameters()
/*     */   {
/*  41 */     oracle.adf.internal.model.rest.core.common.parameter.OnlyDataParam onlyDataParam = (oracle.adf.internal.model.rest.core.common.parameter.OnlyDataParam)ResourceParameter.Type.ONLYDATA.castTo(this.parameterMap.get(ResourceParameter.Type.ONLYDATA));
/*  42 */     if (onlyDataParam != null) {
/*  43 */       this.onlyData = onlyDataParam.getOnlyDataEnabled().booleanValue();
/*     */     }
/*     */     
/*  46 */     oracle.adf.internal.model.rest.core.common.parameter.TotalResultsParam countParam = (oracle.adf.internal.model.rest.core.common.parameter.TotalResultsParam)ResourceParameter.Type.TOTAL_RESULTS.castTo(this.parameterMap.get(ResourceParameter.Type.TOTAL_RESULTS));
/*  47 */     if (countParam != null) {
/*  48 */       this.count = countParam.getCount().booleanValue();
/*     */     }
/*     */     
/*  51 */     oracle.adf.internal.model.rest.core.common.parameter.ListParam listParam = (oracle.adf.internal.model.rest.core.common.parameter.ListParam)ResourceParameter.Type.FIELDS.castTo(this.parameterMap.get(ResourceParameter.Type.FIELDS));
/*  52 */     if (listParam != null) {
/*  53 */       this.attributeFilterList = listParam.getAttributeFilterList();
/*  54 */       this.accessorFilterMap = listParam.getAccessorFilterMap();
/*     */     }
/*     */   }
/*     */   
/*     */   public void process() throws IOException
/*     */   {
/*  60 */     this.generator.setup();
/*     */     
/*  62 */     if (this.treePath == null) {
/*  63 */       this.treePath = new oracle.adf.internal.model.rest.core.topology.DefaultTreePath(this.tree, this.parameterMap);
/*     */     }
/*     */     
/*  66 */     if (this.treePath.isCollectionTreePath()) {
/*  67 */       processResourceCollection(this.generator);
/*     */     } else {
/*  69 */       processResource(this.generator);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processResourceCollection(PayloadGenerator payloadGenerator) throws IOException {
/*  74 */     ResourceCollection startingResource = ResourceCollection.asCollection(this.treePath.getTopLevelResource());
/*     */     
/*  76 */     payloadGenerator.startPayload();
/*  77 */     payloadGenerator.startResourceCollectionItems();
/*  78 */     processNestedResourcePath(this.generator, this.treePath.getResourcePaths(), startingResource.getLimit());
/*  79 */     payloadGenerator.endResourceCollectionItems();
/*     */     
/*     */     List<oracle.adf.internal.model.rest.core.domain.ResourceProperty> properties;
/*     */     List<oracle.adf.internal.model.rest.core.domain.ResourceProperty> properties;
/*  83 */     if (this.count) {
/*  84 */       properties = startingResource.getProperties();
/*     */     } else {
/*  86 */       properties = startingResource.getProperties(java.util.EnumSet.complementOf(java.util.EnumSet.of(oracle.adf.internal.model.rest.core.domain.ResourceCollection.PropertyType.TOTAL_RESULTS)));
/*     */     }
/*     */     
/*  89 */     payloadGenerator.createResourceProperties(properties);
/*  90 */     payloadGenerator.startLinks();
/*  91 */     payloadGenerator.addLink(startingResource.getLinks(this.basePath));
/*  92 */     payloadGenerator.endLinks();
/*     */     
/*  94 */     payloadGenerator.endPayload();
/*     */   }
/*     */   
/*     */   private void processResource(PayloadGenerator payloadGenerator) throws IOException
/*     */   {
/*  99 */     payloadGenerator.startResource();
/* 100 */     List<? extends ResourceTreePath> infos = this.treePath.getResourcePaths();
/* 101 */     if (!infos.isEmpty()) {
/* 102 */       processResourcePath((ResourceTreePath)infos.get(0), payloadGenerator);
/*     */     }
/* 104 */     payloadGenerator.endResource();
/*     */   }
/*     */   
/*     */   private boolean processNestedResourcePath(PayloadGenerator payloadGenerator, Collection<? extends ResourceTreePath> children, Integer limit) throws IOException
/*     */   {
/*     */     int counter;
/* 110 */     if (!children.isEmpty())
/*     */     {
/* 112 */       counter = 0;
/* 113 */       for (ResourceTreePath child : children)
/*     */       {
/* 115 */         if (counter == limit.intValue()) {
/* 116 */           return true;
/*     */         }
/*     */         
/* 119 */         payloadGenerator.startResource();
/* 120 */         processResourcePath(child, payloadGenerator);
/* 121 */         payloadGenerator.endResource();
/* 122 */         counter++;
/*     */       }
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   private void processResourcePath(ResourceTreePath resourceTreePath, PayloadGenerator payloadGenerator) throws IOException {
/* 129 */     Resource resource = resourceTreePath.getResource();
/*     */     List<Attribute> attributesContainingLink;
/*     */     List<Attribute> attributesContainingLink;
/* 132 */     if (resourceTreePath.getParent() == null) {
/* 133 */       attributesContainingLink = createAttributes(resource, this.attributeFilterList, payloadGenerator);
/*     */     } else {
/* 135 */       Set<String> filterList = null;
/* 136 */       if (!this.accessorFilterMap.isEmpty()) {
/* 137 */         filterList = (Set)this.accessorFilterMap.get(resourceTreePath.getAccessorPath());
/*     */       }
/* 139 */       attributesContainingLink = createAttributes(resource, filterList, payloadGenerator);
/*     */     }
/*     */     
/* 142 */     Set<String> linksToFilter = processChildren(resourceTreePath, payloadGenerator);
/*     */     
/* 144 */     if (!this.onlyData) {
/* 145 */       payloadGenerator.startLinks();
/*     */       
/* 147 */       List<oracle.adf.internal.model.rest.core.domain.Link> links = resource.getLinks(this.basePath);
/*     */       
/* 149 */       java.util.Iterator<oracle.adf.internal.model.rest.core.domain.Link> iterator = links.iterator();
/* 150 */       while (iterator.hasNext()) {
/* 151 */         oracle.adf.internal.model.rest.core.domain.Link link = (oracle.adf.internal.model.rest.core.domain.Link)iterator.next();
/* 152 */         if (linksToFilter.contains(link.getName())) {
/* 153 */           iterator.remove();
/*     */         }
/*     */       }
/*     */       
/* 157 */       payloadGenerator.addLink(links);
/* 158 */       payloadGenerator.addAttributeLink(attributesContainingLink, resource.getPath(this.basePath));
/* 159 */       payloadGenerator.endLinks();
/*     */     }
/*     */   }
/*     */   
/*     */   private Set<String> processChildren(ResourceTreePath item, PayloadGenerator payloadGenerator) throws IOException
/*     */   {
/* 165 */     Set<String> linksToFilter = new java.util.HashSet();
/* 166 */     Collection<String> nestedResource = item.getAllChildrenNames();
/* 167 */     if ((nestedResource != null) && (!nestedResource.isEmpty())) {
/* 168 */       for (String nestedResourceName : nestedResource) {
/* 169 */         if (this.treePath.isExpandableResourcePath(item, nestedResourceName)) {
/* 170 */           Collection<? extends ResourceTreePath> children = item.getChildren(nestedResourceName);
/* 171 */           payloadGenerator.startNestedResource(nestedResourceName);
/* 172 */           if (!children.isEmpty()) {
/* 173 */             processNestedResourcePath(payloadGenerator, children, item.getLimit(nestedResourceName));
/*     */           }
/* 175 */           payloadGenerator.endNestedResource();
/* 176 */           linksToFilter.add(nestedResourceName);
/*     */         }
/*     */       }
/*     */     }
/* 180 */     return linksToFilter;
/*     */   }
/*     */   
/*     */   private List<Attribute> createAttributes(Resource resource, Set<String> attributeFilterList, PayloadGenerator payloadGenerator) throws IOException {
/* 184 */     List<Attribute> attributesContainingLink = new java.util.ArrayList();
/* 185 */     for (Attribute attribute : resource.getAttributes())
/*     */     {
/* 187 */       if ((attributeFilterList == null) || (attributeFilterList.contains(attribute.getName())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 192 */         if (attribute.hasItemLevelLink(payloadGenerator.getPayloadType())) {
/* 193 */           if ((attribute.canStreamContent()) || (attribute.getValue() != null)) {
/* 194 */             attributesContainingLink.add(attribute);
/*     */           }
/*     */           
/* 197 */           if (attribute.canStreamContent()) {}
/*     */         }
/*     */         else
/*     */         {
/* 201 */           payloadGenerator.createAttribute(attribute);
/*     */         } }
/*     */     }
/* 204 */     return attributesContainingLink;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\helper\ResourceTreeTraverser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */