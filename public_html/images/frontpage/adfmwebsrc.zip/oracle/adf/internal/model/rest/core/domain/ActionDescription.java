/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import oracle.adf.internal.model.rest.core.common.EntityContentMapping;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.model.binding.DCInvokeMethodDef;
/*     */ import oracle.adf.model.binding.DCMethodParameterDef;
/*     */ import oracle.jbo.uicli.binding.JUCtrlActionBinding;
/*     */ 
/*     */ 
/*     */ public final class ActionDescription
/*     */ {
/*     */   public static final String NAME_PLURAL = "actions";
/*     */   public static final String NAME_ATTR = "name";
/*     */   public static final String DESCRIPTION_ATTR = "description";
/*     */   public static final String RESULT_TYPE_ATTR = "resultType";
/*     */   public static final String PARAMETERS_ATTR = "parameters";
/*     */   public static final String PARAMETER_NAME_ATTR = "name";
/*     */   public static final String PARAMETER_TYPE_ATTR = "type";
/*     */   public static final String PARAMETER_MANDATORY_ATTR = "mandatory";
/*     */   public static final String REQUEST_TYPE_ATTR = "requestType";
/*     */   public static final String RESPONSE_TYPE_ATTR = "responseType";
/*     */   private final String name;
/*     */   private final List<ParameterDescription> parameters;
/*     */   private final String resultType;
/*     */   private final ActionType type;
/*  31 */   private Map<String, String> properties = Collections.emptyMap();
/*     */   private String description;
/*  33 */   private List<String> requestType = Collections.emptyList();
/*  34 */   private List<String> responseType = Collections.emptyList();
/*     */   
/*     */   public ActionDescription(Action action) {
/*  37 */     JUCtrlActionBinding actionBinding = action.getActionBinding();
/*  38 */     this.name = action.getName();
/*  39 */     this.type = action.getType();
/*  40 */     List<ParameterDescription> parameters = Collections.emptyList();
/*  41 */     String resultType = null;
/*  42 */     if (actionBinding != null) {
/*  43 */       parameters = createParameterDescription(actionBinding);
/*  44 */       if (action.producesActionResult()) {
/*  45 */         resultType = actionBinding.getResultType();
/*     */       }
/*     */     }
/*  48 */     this.parameters = parameters;
/*  49 */     this.resultType = resultType;
/*     */   }
/*     */   
/*     */   public List<String> getRequestType() {
/*  53 */     return this.requestType;
/*     */   }
/*     */   
/*     */   public List<String> getResponseType() {
/*  57 */     return this.responseType;
/*     */   }
/*     */   
/*     */   public ActionDescription(Action action, EntityContentMapping entityContentMap) {
/*  61 */     this(action);
/*     */     
/*  63 */     if (action.getRequestEntityType() != null) {
/*  64 */       this.requestType = convertArrayToUnmodifiableList(entityContentMap.getContentType(action.getRequestEntityType()));
/*     */     }
/*     */     
/*  67 */     if (action.getResponseEntityType() != null) {
/*  68 */       this.responseType = convertArrayToUnmodifiableList(entityContentMap.getSupportedContentTypes(action.getResponseEntityType()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ActionDescription(String name, String resultType, List<ParameterDescription> parameters, EntityContentMapping entityContentMap)
/*     */   {
/*  75 */     this.name = name;
/*  76 */     this.resultType = resultType;
/*  77 */     this.parameters = new ArrayList(parameters);
/*  78 */     this.type = ActionType.INVOKE;
/*  79 */     this.requestType = convertArrayToUnmodifiableList(entityContentMap.getContentType(ResourceEntityType.ACTION));
/*     */     
/*  81 */     this.responseType = convertArrayToUnmodifiableList(entityContentMap.getSupportedContentTypes(ResourceEntityType.ACTIONRESULT));
/*     */   }
/*     */   
/*     */   private static final <T> List<T> convertArrayToUnmodifiableList(T[] array)
/*     */   {
/*  86 */     return Collections.unmodifiableList(Arrays.asList(array));
/*     */   }
/*     */   
/*     */   public String getName() {
/*  90 */     return this.name;
/*     */   }
/*     */   
/*     */   public List<ParameterDescription> getParameters() {
/*  94 */     if (this.parameters.isEmpty()) {
/*  95 */       return Collections.emptyList();
/*     */     }
/*  97 */     return new ArrayList(this.parameters);
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 101 */     return this.description;
/*     */   }
/*     */   
/*     */   public String getResultType() {
/* 105 */     return this.resultType;
/*     */   }
/*     */   
/* 108 */   public void setProperties(Map<String, String> properties) { this.properties = Collections.unmodifiableMap(properties); }
/*     */   
/*     */   public Map<String, String> getProperties()
/*     */   {
/* 112 */     return this.properties;
/*     */   }
/*     */   
/*     */   private List<ParameterDescription> createParameterDescription(JUCtrlActionBinding actionBinding) {
/* 116 */     List<ParameterDescription> params = Collections.emptyList();
/*     */     
/*     */ 
/* 119 */     DCInvokeMethodDef cInvokeMethodDef = actionBinding.getInvokeMethodDef();
/* 120 */     if (cInvokeMethodDef == null) {
/* 121 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 124 */     DCMethodParameterDef[] actionParameters = (DCMethodParameterDef[])cInvokeMethodDef.getParameters();
/*     */     
/* 126 */     if ((actionParameters != null) && (actionParameters.length > 0)) {
/* 127 */       params = new ArrayList(actionParameters.length);
/* 128 */       for (DCMethodParameterDef parameter : actionParameters) {
/* 129 */         ParameterDescription paramDescription = new ParameterDescription();
/* 130 */         paramDescription.setName(parameter.getName());
/* 131 */         paramDescription.setTypeName(parameter.getTypeName());
/* 132 */         paramDescription.setMandatory(parameter.isMandatory());
/* 133 */         params.add(paramDescription);
/*     */       }
/*     */     }
/* 136 */     return Collections.unmodifiableList(params);
/*     */   }
/*     */   
/*     */   public ActionType getType()
/*     */   {
/* 141 */     return this.type;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ActionDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */