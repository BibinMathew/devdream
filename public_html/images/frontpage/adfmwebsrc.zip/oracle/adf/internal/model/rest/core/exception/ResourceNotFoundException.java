/*    */ package oracle.adf.internal.model.rest.core.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceNotFoundException
/*    */   extends ResourceException
/*    */ {
/*    */   public ResourceNotFoundException(String msg)
/*    */   {
/* 15 */     super(msg);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ResourceNotFoundException(Throwable throwable)
/*    */   {
/* 23 */     super(throwable);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\exception\ResourceNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */