/*     */ package oracle.adf.internal.model.rest.core.lifecycle;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import oracle.adf.internal.model.rest.core.common.Condition;
/*     */ import oracle.adf.internal.model.rest.core.common.EntityContentMapping;
/*     */ import oracle.adf.internal.model.rest.core.common.EntityContentMappingValue;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceContext;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceEntityType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceType;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap;
/*     */ import oracle.adf.internal.model.rest.core.domain.EffectiveDateUtil;
/*     */ import oracle.adf.internal.model.rest.core.domain.Link;
/*     */ import oracle.adf.internal.model.rest.core.domain.Link.Kind;
/*     */ import oracle.adf.internal.model.rest.core.domain.Path;
/*     */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.condition.ConditionProcessor;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.condition.ConditionProcessorFactory;
/*     */ import oracle.adf.internal.model.rest.core.payload.ParserFactory;
/*     */ import oracle.adf.internal.model.rest.core.topology.TreePath;
/*     */ import oracle.adf.model.BindingContext;
/*     */ import oracle.adf.model.binding.DCBindingContainer;
/*     */ import oracle.adf.model.config.AdfmConfig;
/*     */ import oracle.jbo.version.VersionConfig;
/*     */ import oracle.jbo.version.VersionDef;
/*     */ 
/*     */ public class ResourceProcessingContext
/*     */ {
/*     */   private static final String PATH_SEPARATOR = "/";
/*     */   private final List<String> originalResourcePath;
/*     */   private final List<String> operationPath;
/*     */   private final String basePath;
/*     */   private final String originalBasePath;
/*     */   private final ParserFactory parserFactory;
/*     */   private final ResourceParameterMap parameterMap;
/*     */   private final Locale locale;
/*     */   private final InputStream in;
/*     */   private final Map<String, String> properties;
/*     */   private final EntityContentMapping entityContentMap;
/*     */   private final ConditionProcessor conditionProcessor;
/*     */   private final boolean batchMode;
/*     */   private final VersionDef versionDef;
/*     */   private final Map<String, String> effDateRangeProperties;
/*     */   private final String metadataContext;
/*     */   private ResourceTree tree;
/*     */   private TreePath treePath;
/*     */   
/*     */   public ResourceProcessingContext(ResourceContext resourceContext)
/*     */   {
/*  58 */     this.originalBasePath = resourceContext.getBasePath();
/*  59 */     this.originalResourcePath = Collections.unmodifiableList(resourceContext.getResourcePath());
/*  60 */     this.parserFactory = resourceContext.getParserFactory();
/*  61 */     this.parameterMap = resourceContext.getResourceParameterMap();
/*  62 */     this.locale = resourceContext.getLocale();
/*  63 */     this.operationPath = resourceContext.getVerbPath();
/*  64 */     this.in = resourceContext.getInputStream();
/*  65 */     this.properties = resourceContext.getProperties();
/*  66 */     this.entityContentMap = createEntityMediaTypeMap(resourceContext.getEntityContentMap());
/*  67 */     this.conditionProcessor = ConditionProcessorFactory.createCondition(resourceContext.getPrecondition());
/*  68 */     this.batchMode = resourceContext.isBatchMode();
/*  69 */     this.effDateRangeProperties = resourceContext.getEffectiveDateRangeProperties();
/*  70 */     this.metadataContext = resourceContext.getMetadataProperties();
/*     */     
/*  72 */     String version = resourceContext.getVersion();
/*  73 */     if (version != null) {
/*  74 */       this.versionDef = AdfmConfig.getVersionConfig().findVersionByDisplayName(version);
/*     */       
/*  76 */       this.basePath = (this.originalBasePath + "/" + this.versionDef.getDisplayName());
/*     */     } else {
/*  78 */       this.versionDef = null;
/*  79 */       this.basePath = this.originalBasePath;
/*     */     }
/*     */   }
/*     */   
/*     */   void init() {
/*  84 */     if (this.originalResourcePath.size() > 1) {
/*  85 */       this.tree = new ResourceTree(this.originalResourcePath, this.versionDef);
/*     */     }
/*     */   }
/*     */   
/*     */   void locateResource(boolean processDependencies) {
/*  90 */     if (!isResourceTreeAvailable()) {
/*  91 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  95 */       EffectiveDateUtil.prepareEffectiveDate(this.tree, this.parameterMap, this.effDateRangeProperties);
/*  96 */       this.tree.init(this.originalResourcePath, this.parameterMap, processDependencies);
/*     */     } catch (ResourceNotFoundException ex) {
/*  98 */       if (this.conditionProcessor == null) {
/*  99 */         throw ex;
/*     */       }
/* 101 */       this.conditionProcessor.process(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isResourceTreeAvailable() {
/* 106 */     return this.tree != null;
/*     */   }
/*     */   
/*     */   public Path getResourcePath() {
/* 110 */     Path resourcePath = null;
/* 111 */     if (this.tree != null) {
/* 112 */       Resource currentResource = this.tree.getCurrentResource();
/* 113 */       if (currentResource != null) {
/* 114 */         resourcePath = currentResource.getPath(this.basePath);
/*     */       }
/*     */     }
/* 117 */     return resourcePath;
/*     */   }
/*     */   
/*     */   public DCBindingContainer getBindingContainer() {
/* 121 */     DCBindingContainer bindingContainer = null;
/* 122 */     if (this.tree != null) {
/* 123 */       bindingContainer = ResourceTree.getBindingContainer(this.tree);
/*     */     }
/* 125 */     return bindingContainer;
/*     */   }
/*     */   
/*     */   public BindingContext getBindingContext()
/*     */   {
/* 130 */     BindingContext bindingContext = null;
/* 131 */     if (this.tree != null) {
/* 132 */       bindingContext = ResourceTree.getBindingContainer(this.tree).getBindingContext();
/*     */     }
/* 134 */     return bindingContext;
/*     */   }
/*     */   
/*     */   public ParserFactory getParserFactory() {
/* 138 */     return this.parserFactory;
/*     */   }
/*     */   
/*     */   public List<String> getOriginalResourcePath() {
/* 142 */     return this.originalResourcePath;
/*     */   }
/*     */   
/*     */   public ResourceParameterMap getResourceParameterMap() {
/* 146 */     return this.parameterMap;
/*     */   }
/*     */   
/*     */   public String getBasePath() {
/* 150 */     return this.basePath;
/*     */   }
/*     */   
/*     */   public String getOriginalBasePath() {
/* 154 */     return this.originalBasePath;
/*     */   }
/*     */   
/*     */   public ResourceTree getResourceTree() {
/* 158 */     return this.tree;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 162 */     return this.locale;
/*     */   }
/*     */   
/*     */   public boolean isBatchMode() {
/* 166 */     return this.batchMode;
/*     */   }
/*     */   
/*     */   public List<String> getOperationPath() {
/* 170 */     return this.operationPath;
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() {
/* 174 */     return this.in;
/*     */   }
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 178 */     return this.properties;
/*     */   }
/*     */   
/*     */   private EntityContentMapping createEntityMediaTypeMap(EntityContentMapping entityMediaTypeMapping) {
/* 182 */     if (entityMediaTypeMapping == null) {
/* 183 */       HashMap<ResourceEntityType, EntityContentMappingValue> map = new HashMap();
/* 184 */       for (ResourceEntityType entityType : ResourceEntityType.values()) {
/* 185 */         String[] contentTypes = { entityType.toString() };
/* 186 */         map.put(entityType, new EntityContentMappingValue(contentTypes, contentTypes));
/*     */       }
/* 188 */       return new EntityContentMapping(map);
/*     */     }
/* 190 */     return entityMediaTypeMapping;
/*     */   }
/*     */   
/*     */   public EntityContentMapping getEntityContentMap() {
/* 194 */     return this.entityContentMap;
/*     */   }
/*     */   
/*     */   public ConditionProcessor getConditionProcessor() {
/* 198 */     return this.conditionProcessor;
/*     */   }
/*     */   
/*     */   public Condition getCondition() {
/* 202 */     return this.conditionProcessor.getCondition();
/*     */   }
/*     */   
/*     */   public void processCondition(String state) {
/* 206 */     if ((this.conditionProcessor != null) && (state != null)) {
/* 207 */       this.conditionProcessor.process(state);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTreePath(TreePath treePath) {
/* 212 */     this.treePath = treePath;
/*     */   }
/*     */   
/*     */   public TreePath getTreePath() {
/* 216 */     return this.treePath;
/*     */   }
/*     */   
/*     */   public String getOriginalPathAsString() {
/* 220 */     StringBuilder sb = new StringBuilder();
/* 221 */     for (int i = 1; i < this.originalResourcePath.size(); i++) {
/* 222 */       sb.append("/");
/* 223 */       sb.append((String)this.originalResourcePath.get(i));
/*     */     }
/* 225 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public VersionDef getVersionDef() {
/* 229 */     return this.versionDef;
/*     */   }
/*     */   
/*     */   ResourceType getResourceType() {
/* 233 */     if (isResourceTreeAvailable()) {
/* 234 */       return getResourceTree().getResourceType();
/*     */     }
/* 236 */     return ResourceType.VERSION;
/*     */   }
/*     */   
/*     */   public Link getCurrentResourceLink(OperationType operation)
/*     */   {
/* 241 */     if (operation == OperationType.EXECUTION) {
/* 242 */       return null;
/*     */     }
/*     */     
/* 245 */     if ((!isResourceTreeAvailable()) && (operation == OperationType.DESCRIPTION)) {
/* 246 */       return new Link("self", "self", new Path(this.basePath, "describe"), Link.Kind.DESCRIBE);
/*     */     }
/*     */     
/*     */ 
/* 250 */     ResourceType resourceType = getResourceType();
/* 251 */     if (resourceType != ResourceType.VERSION) {
/* 252 */       ResourceTree resourceTree = getResourceTree();
/* 253 */       Link selfLink = resourceTree.getCurrentResource().getSelfLink(this.basePath);
/*     */       
/* 255 */       if (resourceType == ResourceType.ATTACHMENT) {
/* 256 */         return new Link("self", "self", new Path(selfLink.getHref(), Arrays.asList(new String[] { "enclosure", resourceTree.getSelectedAttributeName() })), Link.Kind.OTHER);
/*     */       }
/*     */       
/*     */ 
/* 260 */       if (operation == OperationType.DESCRIPTION) {
/* 261 */         return new Link("self", "self", new Path(selfLink.getHref(), "describe"), Link.Kind.DESCRIBE);
/*     */       }
/*     */       
/*     */ 
/* 265 */       return selfLink;
/*     */     }
/*     */     
/*     */ 
/* 269 */     return new Link("self", "self", new Path(this.basePath), getVersionDef() == null ? Link.Kind.COLLECTION : Link.Kind.ITEM);
/*     */   }
/*     */   
/*     */   public Map<String, String> getEffectiveDateRangeProperties()
/*     */   {
/* 274 */     return this.effDateRangeProperties;
/*     */   }
/*     */   
/*     */   public boolean isEffectiveDateRangeOperation() {
/* 278 */     return !this.effDateRangeProperties.isEmpty();
/*     */   }
/*     */   
/*     */   String getMetadataProperties() {
/* 282 */     return this.metadataContext;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ResourceProcessingContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */