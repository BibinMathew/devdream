/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.Verb;
/*    */ import oracle.adf.internal.model.rest.core.http.exception.OperationNotSupportedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ class DeleteMethod
/*    */   implements HttpMethod
/*    */ {
/*    */   private final HttpOperationType operationType;
/*    */   
/*    */   DeleteMethod(HttpMethodInfo info)
/*    */   {
/* 16 */     Verb verb = info.getVerb();
/*    */     
/* 18 */     if (verb != null) {
/* 19 */       throw new OperationNotSupportedException();
/*    */     }
/* 21 */     this.operationType = HttpOperationType.RESOURCE;
/* 22 */     this.operationType.setOperation(OperationType.DELETION);
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 28 */     return HttpMethod.Type.DELETE.toString();
/*    */   }
/*    */   
/*    */   public HttpOperationType getOperationType()
/*    */   {
/* 33 */     return this.operationType;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\DeleteMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */