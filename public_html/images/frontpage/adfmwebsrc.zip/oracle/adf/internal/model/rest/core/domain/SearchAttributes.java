/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import oracle.jbo.AttributeList;
/*    */ import oracle.jbo.NameValuePairs;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SearchAttributes
/*    */ {
/*    */   private final AttributeList searchAttributeList;
/*    */   private final Map<String, String> effDateRangeProperties;
/*    */   
/*    */   SearchAttributes(AttributeList searchAttributes)
/*    */   {
/* 19 */     this.searchAttributeList = unmodifiableAttributeList(searchAttributes);
/* 20 */     this.effDateRangeProperties = Collections.emptyMap();
/*    */   }
/*    */   
/*    */   public SearchAttributes(Map<String, Object> searchAttributes, Map<String, String> effDateRangeProperties)
/*    */   {
/* 25 */     this.searchAttributeList = unmodifiableAttributeList(convertMapToAttributeList(searchAttributes));
/* 26 */     this.effDateRangeProperties = effDateRangeProperties;
/*    */   }
/*    */   
/*    */   AttributeList getSearchAttributeList() {
/* 30 */     return this.searchAttributeList;
/*    */   }
/*    */   
/*    */   Map<String, String> getEffDateRangeProperties() {
/* 34 */     return this.effDateRangeProperties;
/*    */   }
/*    */   
/*    */   private AttributeList convertMapToAttributeList(Map<String, Object> map) {
/* 38 */     if (map.isEmpty()) {
/* 39 */       return null;
/*    */     }
/*    */     
/* 42 */     String[] attributeNames = new String[map.size()];
/* 43 */     Object[] attributeValues = new Object[map.size()];
/*    */     
/* 45 */     int i = 0;
/* 46 */     for (Map.Entry<String, Object> entry : map.entrySet()) {
/* 47 */       attributeNames[i] = ((String)entry.getKey());
/* 48 */       attributeValues[i] = entry.getValue();
/* 49 */       i++;
/*    */     }
/*    */     
/* 52 */     return new NameValuePairs(attributeNames, attributeValues);
/*    */   }
/*    */   
/*    */   private AttributeList unmodifiableAttributeList(AttributeList attrList) {
/* 56 */     return new UnmodifiableAttributeList(attrList);
/*    */   }
/*    */   
/*    */   private class UnmodifiableAttributeList implements AttributeList {
/*    */     private final AttributeList attrList;
/*    */     
/*    */     UnmodifiableAttributeList(AttributeList attrList) {
/* 63 */       this.attrList = attrList;
/*    */     }
/*    */     
/*    */     public Object getAttribute(int index) {
/* 67 */       return this.attrList.getAttribute(index);
/*    */     }
/*    */     
/*    */     public Object getAttribute(String name) {
/* 71 */       return this.attrList.getAttribute(name);
/*    */     }
/*    */     
/*    */     public void setAttribute(int index, Object value) {
/* 75 */       throw new UnsupportedOperationException();
/*    */     }
/*    */     
/*    */     public void setAttribute(String name, Object value) {
/* 79 */       throw new UnsupportedOperationException();
/*    */     }
/*    */     
/*    */     public int getAttributeCount()
/*    */     {
/* 84 */       return this.attrList.getAttributeCount();
/*    */     }
/*    */     
/*    */     public int getAttributeIndexOf(String name) {
/* 88 */       return this.attrList.getAttributeIndexOf(name);
/*    */     }
/*    */     
/*    */     public String[] getAttributeNames() {
/* 92 */       return this.attrList.getAttributeNames();
/*    */     }
/*    */     
/*    */     public Object[] getAttributeValues() {
/* 96 */       return this.attrList.getAttributeValues();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\SearchAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */