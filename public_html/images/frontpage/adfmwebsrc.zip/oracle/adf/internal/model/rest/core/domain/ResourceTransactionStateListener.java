/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.List;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ import oracle.adf.internal.model.rest.core.topology.ResourceTreePath;
/*    */ import oracle.adf.internal.model.rest.core.topology.TreePath;
/*    */ import oracle.jbo.TransactionStateEvent;
/*    */ import oracle.jbo.TransactionStateListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceTransactionStateListener
/*    */   implements TransactionStateListener
/*    */ {
/*    */   ResourceProcessingContext context;
/*    */   
/*    */   public ResourceTransactionStateListener(ResourceProcessingContext context)
/*    */   {
/* 19 */     this.context = context;
/*    */   }
/*    */   
/*    */   public void doneCommit(TransactionStateEvent event) {
/* 23 */     TreePath treePath = EffectiveDateUtil.rebuildTreePath(this.context.getResourceTree(), this.context.getTreePath(), this.context.getEffectiveDateRangeProperties());
/*    */     
/*    */ 
/*    */ 
/* 27 */     if (treePath != null) {
/* 28 */       this.context.setTreePath(treePath);
/* 29 */       Resource currentResource = ((ResourceTreePath)treePath.getResourcePaths().get(0)).getResource();
/* 30 */       if (currentResource != null) {
/* 31 */         this.context.getResourceTree().setCurrentResource(currentResource);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void doneRollback(TransactionStateEvent event) {}
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceTransactionStateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */