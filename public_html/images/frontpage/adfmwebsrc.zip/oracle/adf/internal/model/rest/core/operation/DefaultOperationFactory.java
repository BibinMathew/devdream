/*     */ package oracle.adf.internal.model.rest.core.operation;
/*     */ 
/*     */ import oracle.adf.internal.model.rest.core.common.Operation;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceType;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultOperationFactory
/*     */ {
/*     */   public static Operation createOperation(ResourceType resourceType, OperationType operationType)
/*     */   {
/*  13 */     Operation operation = null;
/*     */     
/*  15 */     switch (resourceType)
/*     */     {
/*     */     case RESOURCE_ITEM: 
/*     */     case RESOURCE_COLLECTION: 
/*  19 */       switch (operationType)
/*     */       {
/*     */       case CREATION: 
/*  22 */         operation = new ResourceCreation();
/*  23 */         break;
/*     */       
/*     */ 
/*     */       case EXECUTION: 
/*  27 */         operation = new ActionExecution();
/*  28 */         break;
/*     */       
/*     */ 
/*     */       case REPRESENTATION: 
/*  32 */         operation = new ResourceRepresentation(resourceType);
/*  33 */         break;
/*     */       
/*     */ 
/*     */       case DELETION: 
/*  37 */         operation = new ResourceDeletion();
/*  38 */         break;
/*     */       
/*     */ 
/*     */       case UPDATE: 
/*  42 */         operation = new ResourceUpdate();
/*  43 */         break;
/*     */       
/*     */ 
/*     */       case REPLACEMENT: 
/*  47 */         operation = new ResourceReplacement();
/*  48 */         break;
/*     */       
/*     */ 
/*     */       default: 
/*  52 */         operation = null; }
/*  53 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case ATTACHMENT: 
/*  61 */       switch (operationType)
/*     */       {
/*     */       case REPRESENTATION: 
/*  64 */         operation = new ContentGeneration();
/*  65 */         break;
/*     */       
/*     */ 
/*     */       case DELETION: 
/*  69 */         operation = new ContentDeletion();
/*  70 */         break;
/*     */       
/*     */ 
/*     */       case REPLACEMENT: 
/*  74 */         operation = new ContentReplacement();
/*  75 */         break;
/*     */       
/*     */       case UPDATE: 
/*     */       default: 
/*  79 */         operation = null; }
/*  80 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case VERSION: 
/*  87 */       switch (operationType)
/*     */       {
/*     */       case REPRESENTATION: 
/*  90 */         operation = new VersionRepresentation();
/*  91 */         break;
/*     */       
/*     */ 
/*     */       default: 
/*  95 */         operation = null;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */     
/* 104 */     return operation;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\DefaultOperationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */