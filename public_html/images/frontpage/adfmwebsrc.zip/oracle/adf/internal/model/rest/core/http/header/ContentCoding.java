/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ public class ContentCoding
/*    */ {
/*    */   public static final String WILD_CARD = "*";
/*    */   private final String value;
/*    */   
/*    */   public ContentCoding(String value)
/*    */   {
/* 10 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 14 */     return this.value;
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 19 */     if (this == object) {
/* 20 */       return true;
/*    */     }
/* 22 */     if (!(object instanceof ContentCoding)) {
/* 23 */       return false;
/*    */     }
/* 25 */     ContentCoding other = (ContentCoding)object;
/* 26 */     if (this.value == null ? other.value != null : !this.value.equals(other.value)) {
/* 27 */       return false;
/*    */     }
/* 29 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 34 */     int PRIME = 37;
/* 35 */     int result = 1;
/* 36 */     result = 37 * result + (this.value == null ? 0 : this.value.hashCode());
/* 37 */     return result;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 42 */     return this.value;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\ContentCoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */