/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import oracle.adf.internal.model.rest.core.binding.inputhandler.ResourceInputHandlerImpl;
/*    */ import oracle.adf.model.config.AdfmConfig;
/*    */ import oracle.adf.share.logging.ADFLogger;
/*    */ import oracle.jbo.common.JBOClass;
/*    */ import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonUtil
/*    */ {
/* 16 */   private static final ADFLogger _logger = ADFLogger.createADFLogger(CommonUtil.class.getName());
/* 17 */   private static final ResourceInputHandlerImpl DEFAULT_INPUT_HANDLER = new ResourceInputHandlerImpl();
/*    */   
/*    */ 
/*    */ 
/*    */   public static JUCtrlInputValueHandler getDefaultInputHandler()
/*    */   {
/* 23 */     JUCtrlInputValueHandler defaultInputHandler = null;
/* 24 */     String defaultInputHandlerProperty = (String)AdfmConfig.getCustomProperty("adf.rest.defaultinputhandler");
/* 25 */     if (defaultInputHandlerProperty != null) {
/*    */       try
/*    */       {
/* 28 */         Class inputHandler = JBOClass.forName(defaultInputHandlerProperty);
/* 29 */         if (JUCtrlInputValueHandler.class.isAssignableFrom(inputHandler))
/*    */         {
/* 31 */           defaultInputHandler = (JUCtrlInputValueHandler)inputHandler.newInstance();
/*    */         }
/*    */         else
/*    */         {
/* 35 */           _logger.log(Level.FINE, "Error while setting the default BindingContext input handler. The informed class does not implement " + JUCtrlInputValueHandler.class.getName() + ". Class name: " + defaultInputHandlerProperty);
/*    */         }
/*    */         
/*    */ 
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 42 */         _logger.log(Level.FINE, "Error while creating the default input handler. Provided class name: " + defaultInputHandlerProperty, e);
/*    */       }
/*    */     }
/*    */     
/* 46 */     if (defaultInputHandler == null) {
/* 47 */       defaultInputHandler = DEFAULT_INPUT_HANDLER;
/*    */     }
/*    */     
/* 50 */     return defaultInputHandler;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\CommonUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */