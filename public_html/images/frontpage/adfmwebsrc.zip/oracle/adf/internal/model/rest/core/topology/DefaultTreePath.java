/*    */ package oracle.adf.internal.model.rest.core.topology;
/*    */ 
/*    */ import java.util.Set;
/*    */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameter.Type;
/*    */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap;
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*    */ 
/*    */ public final class DefaultTreePath implements TreePath
/*    */ {
/*    */   private final ResourceTree tree;
/*    */   private final boolean expandAllFirstLevelAccessors;
/*    */   private final Set<String> accessorsToExpand;
/*    */   private final Resource topLevelResource;
/*    */   private final int offset;
/*    */   
/*    */   public DefaultTreePath(ResourceTree tree, ResourceParameterMap parameterMap)
/*    */   {
/* 19 */     this.topLevelResource = tree.getCurrentResource();
/* 20 */     this.tree = tree;
/* 21 */     oracle.adf.internal.model.rest.core.common.parameter.ExpandParam expandParam = null;
/* 22 */     oracle.adf.internal.model.rest.core.common.parameter.OffsetParam offsetParam = null;
/* 23 */     oracle.adf.internal.model.rest.core.common.parameter.ListParam fieldsParam = null;
/* 24 */     if (parameterMap != null) {
/* 25 */       expandParam = (oracle.adf.internal.model.rest.core.common.parameter.ExpandParam)ResourceParameter.Type.EXPAND.castTo(parameterMap.get(ResourceParameter.Type.EXPAND));
/* 26 */       offsetParam = (oracle.adf.internal.model.rest.core.common.parameter.OffsetParam)ResourceParameter.Type.OFFSET.castTo(parameterMap.get(ResourceParameter.Type.OFFSET));
/* 27 */       fieldsParam = (oracle.adf.internal.model.rest.core.common.parameter.ListParam)ResourceParameter.Type.FIELDS.castTo(parameterMap.get(ResourceParameter.Type.FIELDS));
/*    */     }
/* 29 */     Set<String> accessors = java.util.Collections.emptySet();
/* 30 */     accessors = (expandParam == null) && (fieldsParam == null) ? accessors : new java.util.HashSet();
/*    */     
/* 32 */     if (fieldsParam != null) {
/* 33 */       accessors.addAll(fieldsParam.getAccessorFilterMap().keySet());
/* 34 */       this.expandAllFirstLevelAccessors = false;
/* 35 */     } else if (expandParam != null) {
/* 36 */       accessors.addAll(expandParam.getAccessorsToExpand());
/* 37 */       this.expandAllFirstLevelAccessors = expandParam.isExpandAllFirstLevelAccessorsEnabled();
/*    */     } else {
/* 39 */       this.expandAllFirstLevelAccessors = false;
/*    */     }
/*    */     
/* 42 */     this.accessorsToExpand = accessors;
/*    */     
/* 44 */     if (offsetParam != null) {
/* 45 */       this.offset = offsetParam.getOffset().intValue();
/*    */     } else {
/* 47 */       this.offset = 0;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public java.util.List<DefaultResourcePath> getResourcePaths()
/*    */   {
/* 54 */     Resource currentResource = this.tree.getCurrentResource();
/*    */     java.util.List<DefaultResourcePath> resourcePaths;
/* 56 */     java.util.List<DefaultResourcePath> resourcePaths; if (currentResource.isCollection()) {
/* 57 */       java.util.List<oracle.adf.internal.model.rest.core.domain.ResourceItem> children = oracle.adf.internal.model.rest.core.domain.ResourceCollection.asCollection(currentResource).getChildren(this.offset);
/* 58 */       resourcePaths = DefaultResourcePath.wrap(children);
/*    */     } else {
/* 60 */       resourcePaths = new java.util.ArrayList(1);
/* 61 */       resourcePaths.add(new DefaultResourcePath(oracle.adf.internal.model.rest.core.domain.ResourceItem.asItem(currentResource)));
/*    */     }
/* 63 */     return resourcePaths;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final boolean isExpandableResourcePath(ResourceTreePath resourcePath, String childName)
/*    */   {
/* 72 */     if ((resourcePath.getParent() == null) && ((this.expandAllFirstLevelAccessors) || (resourcePath.getResource().isAccessorExpandable(childName)))) {
/* 73 */       return true;
/*    */     }
/*    */     
/* 76 */     return (!this.accessorsToExpand.isEmpty()) && (this.accessorsToExpand.contains(TreePathUtil.createAccessorPath(resourcePath.getAccessorPath(), childName)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Resource getTopLevelResource()
/*    */   {
/* 83 */     return this.topLevelResource;
/*    */   }
/*    */   
/*    */   public boolean isCollectionTreePath()
/*    */   {
/* 88 */     return this.topLevelResource.isCollection();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\topology\DefaultTreePath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */