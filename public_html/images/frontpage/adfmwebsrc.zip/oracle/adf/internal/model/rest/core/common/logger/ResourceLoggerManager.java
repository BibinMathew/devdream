/*    */ package oracle.adf.internal.model.rest.core.common.logger;
/*    */ 
/*    */ import oracle.adf.share.logging.ADFLogger;
/*    */ import oracle.adfinternal.model.logging.contextual.ContextualLoggingManager;
/*    */ import oracle.adfinternal.model.logging.contextual.LogDomain;
/*    */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLogger;
/*    */ import oracle.adfinternal.model.logging.contextual.logger.ContextualLoggerProvider;
/*    */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*    */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLoggerProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceLoggerManager
/*    */ {
/*    */   private static final String DIAGNOSTIC_LOGGER_NAME = "oracle.adfdiagnostics.rest";
/*    */   private static final String REST_ROOT_LOGGER_NAME = "oracle.adf.model.rest.log";
/*    */   private static final String OPERATION_LOGGER_NAME = "oracle.adf.model.rest.log.operation";
/*    */   private static final String SERIALIZER_LOGGER_NAME = "oracle.adf.model.rest.log.operation.serializer";
/*    */   private static final String DESCRIBER_LOGGER_NAME = "oracle.adf.model.rest.log.operation.describer";
/*    */   private static final String DIAGNOSTIC_DOMAIN_ROOT_LOGGER = "RESTDiagnostic";
/*    */   private static final String NORMAL_DOMAIN_ROOT_LOGGER = "RESTNormal";
/*    */   private static final String LOGGER_COMPONENT = "REST";
/* 25 */   private static final ContextualLoggerProvider LOGGER_PROVIDER = new ContextualLoggerProvider("oracle.adf.model.rest.log");
/* 26 */   private static final FunctionalLoggerProvider DIAGNOSTIC_PROVIDER = new FunctionalLoggerProvider("oracle.adfdiagnostics.rest", "REST");
/*    */   
/* 28 */   private static final LogDomain<FunctionalLogger> DIAGNOSTIC_DOMAIN = new LogDomain("RESTDiagnostic", DIAGNOSTIC_PROVIDER);
/*    */   
/* 30 */   private static final LogDomain<ContextualLogger> NORMAL_DOMAIN = new LogDomain("RESTNormal", LOGGER_PROVIDER);
/*    */   
/*    */ 
/* 33 */   public static final ContextualLoggerProvider OPERATION_PROVIDER = new ContextualLoggerProvider("oracle.adf.model.rest.log.operation");
/* 34 */   public static final ContextualLoggerProvider SERIALIZER_PROVIDER = new ContextualLoggerProvider("oracle.adf.model.rest.log.operation.serializer");
/* 35 */   public static final ContextualLoggerProvider DESCRIBER_PROVIDER = new ContextualLoggerProvider("oracle.adf.model.rest.log.operation.describer");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   static
/*    */   {
/* 42 */     DIAGNOSTIC_DOMAIN.setDefaultLoggerProvider(DIAGNOSTIC_PROVIDER);
/* 43 */     NORMAL_DOMAIN.setDefaultLoggerProvider(LOGGER_PROVIDER);
/*    */   }
/*    */   
/*    */   public static ADFLogger getRESTLogger() {
/* 47 */     return ADFLogger.createADFLogger("oracle.adf.model.rest.log");
/*    */   }
/*    */   
/*    */   public static FunctionalLogger getDiagnosticLogger() {
/* 51 */     ContextualLoggingManager<FunctionalLogger> manager = ContextualLoggingManager.getInstance(DIAGNOSTIC_DOMAIN);
/* 52 */     return (FunctionalLogger)manager.getCurrentLogger();
/*    */   }
/*    */   
/*    */   public static ContextualLogger setCurrentLogger(ContextualLoggerProvider provider) {
/* 56 */     ContextualLoggingManager<ContextualLogger> manager = ContextualLoggingManager.getInstance(NORMAL_DOMAIN);
/* 57 */     return (ContextualLogger)manager.openLogger(provider);
/*    */   }
/*    */   
/*    */   public static ContextualLogger getCurrentLogger() {
/* 61 */     ContextualLoggingManager<ContextualLogger> manager = ContextualLoggingManager.getInstance(NORMAL_DOMAIN);
/* 62 */     return (ContextualLogger)manager.getCurrentLogger();
/*    */   }
/*    */   
/*    */   public static void removeCurrentLogger() {
/* 66 */     ContextualLoggingManager manager = ContextualLoggingManager.getInstance(NORMAL_DOMAIN);
/* 67 */     manager.closeCurrentLogger();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\logger\ResourceLoggerManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */