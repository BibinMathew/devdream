/*     */ package oracle.adf.internal.model.rest.core.http.header;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class EntityTag
/*     */ {
/*     */   private String value;
/*  11 */   private boolean strongValidator = true;
/*     */   
/*     */   public static final String WEAK_PREFIX = "W/";
/*     */   private static final String FORMAT = "\"%s\"";
/*     */   private static final String WEAK_FORMAT = "W/\"%s\"";
/*     */   private static final String ETAG_FORMAT = "((W/)?\"(.*?)\")";
/*     */   private static final String VALIDATION_FORMAT = "(.*?)((W/)?\"(.*?)\")";
/*  18 */   private static final Pattern VALIDATION_PATTERN = Pattern.compile("(.*?)((W/)?\"(.*?)\")");
/*     */   private static final String SEPARATOR = ",";
/*     */   
/*     */   private EntityTag(String value, boolean strongValidator)
/*     */   {
/*  23 */     this.value = value;
/*  24 */     this.strongValidator = strongValidator;
/*     */   }
/*     */   
/*     */   public String getValue() {
/*  28 */     return this.value;
/*     */   }
/*     */   
/*     */   public String getFormattedValue() {
/*  32 */     if (this.strongValidator) {
/*  33 */       return String.format("\"%s\"", new Object[] { this.value });
/*     */     }
/*  35 */     return String.format("W/\"%s\"", new Object[] { this.value });
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  40 */     return getFormattedValue();
/*     */   }
/*     */   
/*     */   public boolean isStrongValidator() {
/*  44 */     return this.strongValidator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<EntityTag> parseEntityTags(String etags)
/*     */   {
/*  55 */     String trimmedEtags = etags.trim();
/*     */     
/*  57 */     int lastETagEnd = 0;
/*  58 */     LinkedList<EntityTag> entityTags = new LinkedList();
/*  59 */     Matcher matcher = VALIDATION_PATTERN.matcher(trimmedEtags);
/*  60 */     while (matcher.find())
/*     */     {
/*  62 */       String charsBeforeEtag = matcher.group(1);
/*  63 */       String trimmedCharsBeforeEtag = charsBeforeEtag.trim();
/*  64 */       String weakValidator = matcher.group(3);
/*  65 */       String etagNoQuotes = matcher.group(4);
/*  66 */       lastETagEnd = matcher.end(2);
/*     */       
/*  68 */       if (entityTags.isEmpty())
/*     */       {
/*  70 */         if (trimmedCharsBeforeEtag.length() > 0) {
/*  71 */           throw new IllegalArgumentException("Invalid characters before the first ETag: " + charsBeforeEtag);
/*     */         }
/*     */       }
/*  74 */       else if (!",".equals(trimmedCharsBeforeEtag)) {
/*  75 */         throw new IllegalArgumentException("The only character allowed (and required) between ETags is the separator, found: " + charsBeforeEtag);
/*     */       }
/*     */       
/*  78 */       entityTags.add(new EntityTag(etagNoQuotes, weakValidator == null));
/*     */     }
/*     */     
/*  81 */     if (lastETagEnd < trimmedEtags.length()) {
/*  82 */       throw new IllegalArgumentException("Extra characters were found after the last ETag. Last Etag: '" + (entityTags.isEmpty() ? "" : entityTags.getLast()) + "' Extra characters: '" + etags.substring(lastETagEnd) + "'");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  88 */     return entityTags;
/*     */   }
/*     */   
/*     */   public static EntityTag parseEntityTag(String etag) {
/*  92 */     String value = null;
/*  93 */     boolean strongValidator = true;
/*  94 */     if (etag.startsWith("W/"))
/*     */     {
/*  96 */       value = etag.substring("W/".length() + 1, etag.length() - 1);
/*  97 */       strongValidator = false;
/*     */     }
/*     */     else {
/* 100 */       value = etag.substring(1, etag.length() - 1);
/*     */     }
/*     */     
/* 103 */     return new EntityTag(value, strongValidator);
/*     */   }
/*     */   
/*     */   public static EntityTag createStrongEntityTag(String value) {
/* 107 */     return parseEntityTag(String.format("\"%s\"", new Object[] { value }));
/*     */   }
/*     */   
/*     */   public static EntityTag createWeakEntityTag(String value) {
/* 111 */     return parseEntityTag(String.format("W/\"%s\"", new Object[] { value }));
/*     */   }
/*     */   
/*     */   public boolean weakValidateWith(EntityTag tag) {
/* 115 */     return this.value.equals(tag.getValue());
/*     */   }
/*     */   
/*     */   public boolean strongValidateWith(EntityTag tag) {
/* 119 */     return (this.strongValidator) && (equals(tag));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 125 */     if (this == object) {
/* 126 */       return true;
/*     */     }
/* 128 */     if (!(object instanceof EntityTag)) {
/* 129 */       return false;
/*     */     }
/* 131 */     EntityTag other = (EntityTag)object;
/* 132 */     if (this.value == null ? other.value != null : !this.value.equals(other.value)) {
/* 133 */       return false;
/*     */     }
/* 135 */     if (this.strongValidator != other.strongValidator) {
/* 136 */       return false;
/*     */     }
/* 138 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 143 */     int PRIME = 37;
/* 144 */     int result = 1;
/* 145 */     result = 37 * result + (this.value == null ? 0 : this.value.hashCode());
/* 146 */     result = 37 * result + (this.strongValidator ? 0 : 1);
/* 147 */     return result;
/*     */   }
/*     */   
/*     */   public static String format(List<EntityTag> entityTags) {
/* 151 */     if ((entityTags == null) || (entityTags.isEmpty())) {
/* 152 */       return null;
/*     */     }
/*     */     
/* 155 */     StringBuilder sb = new StringBuilder();
/* 156 */     java.util.Iterator<EntityTag> iterator = entityTags.iterator();
/*     */     for (;;)
/*     */     {
/* 159 */       sb.append(((EntityTag)iterator.next()).getFormattedValue());
/* 160 */       if (!iterator.hasNext()) break;
/* 161 */       sb.append(",").append(" ");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 166 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\EntityTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */