package oracle.adf.internal.model.rest.core.common.listener.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import oracle.adf.internal.model.rest.core.lifecycle.ResourceLifecyclePhase;

@Target({java.lang.annotation.ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ResourceLifecycleListenerConfig
{
  ResourceLifecyclePhase[] listenTo() default {};
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\listener\annotation\ResourceLifecycleListenerConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */