/*    */ package oracle.adf.internal.model.rest.core.exception;
/*    */ 
/*    */ import oracle.jbo.CSMessageBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidHeaderValueException
/*    */   extends BadRequestException
/*    */ {
/*    */   public InvalidHeaderValueException(String header, String value)
/*    */   {
/* 14 */     super(CSMessageBundle.class, "27513", new Object[] { header, value });
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\exception\InvalidHeaderValueException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */