/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface HttpMethod
/*    */ {
/*    */   public abstract HttpOperationType getOperationType();
/*    */   
/*    */ 
/*    */ 
/*    */   public static enum Type
/*    */   {
/* 14 */     GET,  POST,  DELETE,  PUT,  PATCH,  OPTIONS,  HEAD,  TRACE,  CONNECT;
/*    */     
/*    */     private Type() {}
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\HttpMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */