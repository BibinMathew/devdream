package oracle.adf.internal.model.rest.core.domain;

public class ResourceItemDescription
{
  public static final String NAME = "item";
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\ResourceItemDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */