/*     */ package oracle.adf.internal.model.rest.core.lifecycle;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PhaseMapping
/*     */ {
/*  24 */   private static final Map<OperationType, Set<ResourceLifecyclePhase>> OPERATION_PHASE_MAP = new HashMap(OperationType.values().length);
/*  25 */   static { OPERATION_PHASE_MAP.put(OperationType.CREATION, createResourceLifecyclePhaseSet(new ResourceLifecyclePhase[] { ResourceLifecyclePhase.INIT_CONTEXT, ResourceLifecyclePhase.PREPARE_MODEL, ResourceLifecyclePhase.CHECK_SECURITY, ResourceLifecyclePhase.PROCESS_UPDATE_MODEL, ResourceLifecyclePhase.VALIDATE_MODEL_UPDATES, ResourceLifecyclePhase.CHECK_METADATA_CONTEXT, ResourceLifecyclePhase.DATA_COMMIT, ResourceLifecyclePhase.METADATA_COMMIT, ResourceLifecyclePhase.PREPARE_RESPONSE, ResourceLifecyclePhase.GENERATE_RESPONSE }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  37 */     OPERATION_PHASE_MAP.put(OperationType.EXECUTION, createResourceLifecyclePhaseSet(new ResourceLifecyclePhase[] { ResourceLifecyclePhase.INIT_CONTEXT, ResourceLifecyclePhase.PREPARE_MODEL, ResourceLifecyclePhase.APPLY_INPUT_VALUES, ResourceLifecyclePhase.VALIDATE_INPUT_VALUES, ResourceLifecyclePhase.CHECK_SECURITY, ResourceLifecyclePhase.PROCESS_UPDATE_MODEL, ResourceLifecyclePhase.VALIDATE_MODEL_UPDATES, ResourceLifecyclePhase.CHECK_METADATA_CONTEXT, ResourceLifecyclePhase.DATA_COMMIT, ResourceLifecyclePhase.METADATA_COMMIT, ResourceLifecyclePhase.PREPARE_RESPONSE, ResourceLifecyclePhase.GENERATE_RESPONSE }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */     OPERATION_PHASE_MAP.put(OperationType.DESCRIPTION, createResourceLifecyclePhaseSet(new ResourceLifecyclePhase[] { ResourceLifecyclePhase.INIT_CONTEXT, ResourceLifecyclePhase.PREPARE_MODEL, ResourceLifecyclePhase.CHECK_SECURITY, ResourceLifecyclePhase.CHECK_METADATA_CONTEXT, ResourceLifecyclePhase.PREPARE_RESPONSE, ResourceLifecyclePhase.GENERATE_RESPONSE }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */     OPERATION_PHASE_MAP.put(OperationType.REPRESENTATION, createResourceLifecyclePhaseSet(new ResourceLifecyclePhase[] { ResourceLifecyclePhase.INIT_CONTEXT, ResourceLifecyclePhase.PREPARE_MODEL, ResourceLifecyclePhase.CHECK_SECURITY, ResourceLifecyclePhase.CHECK_METADATA_CONTEXT, ResourceLifecyclePhase.PREPARE_RESPONSE, ResourceLifecyclePhase.GENERATE_RESPONSE }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     OPERATION_PHASE_MAP.put(OperationType.UPDATE, createResourceLifecyclePhaseSet(new ResourceLifecyclePhase[] { ResourceLifecyclePhase.INIT_CONTEXT, ResourceLifecyclePhase.PREPARE_MODEL, ResourceLifecyclePhase.CHECK_SECURITY, ResourceLifecyclePhase.PROCESS_UPDATE_MODEL, ResourceLifecyclePhase.VALIDATE_MODEL_UPDATES, ResourceLifecyclePhase.CHECK_METADATA_CONTEXT, ResourceLifecyclePhase.DATA_COMMIT, ResourceLifecyclePhase.METADATA_COMMIT, ResourceLifecyclePhase.PREPARE_RESPONSE, ResourceLifecyclePhase.GENERATE_RESPONSE }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */     OPERATION_PHASE_MAP.put(OperationType.REPLACEMENT, createResourceLifecyclePhaseSet(new ResourceLifecyclePhase[] { ResourceLifecyclePhase.INIT_CONTEXT, ResourceLifecyclePhase.PREPARE_MODEL, ResourceLifecyclePhase.CHECK_SECURITY, ResourceLifecyclePhase.PROCESS_UPDATE_MODEL, ResourceLifecyclePhase.VALIDATE_MODEL_UPDATES, ResourceLifecyclePhase.CHECK_METADATA_CONTEXT, ResourceLifecyclePhase.DATA_COMMIT, ResourceLifecyclePhase.METADATA_COMMIT, ResourceLifecyclePhase.PREPARE_RESPONSE, ResourceLifecyclePhase.GENERATE_RESPONSE }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     OPERATION_PHASE_MAP.put(OperationType.DELETION, createResourceLifecyclePhaseSet(new ResourceLifecyclePhase[] { ResourceLifecyclePhase.INIT_CONTEXT, ResourceLifecyclePhase.PREPARE_MODEL, ResourceLifecyclePhase.CHECK_SECURITY, ResourceLifecyclePhase.PROCESS_UPDATE_MODEL, ResourceLifecyclePhase.VALIDATE_MODEL_UPDATES, ResourceLifecyclePhase.CHECK_METADATA_CONTEXT, ResourceLifecyclePhase.DATA_COMMIT, ResourceLifecyclePhase.METADATA_COMMIT, ResourceLifecyclePhase.PREPARE_RESPONSE }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Set<ResourceLifecyclePhase> createResourceLifecyclePhaseSet(ResourceLifecyclePhase... phases)
/*     */   {
/* 109 */     return new TreeSet(Arrays.asList(phases));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Set<ResourceLifecyclePhase> getPhases(OperationType operationType, ResourceProcessingContext resourceBindingContext)
/*     */   {
/* 120 */     Set<ResourceLifecyclePhase> phases = (Set)OPERATION_PHASE_MAP.get(operationType);
/* 121 */     Set<ResourceLifecyclePhase> retPhases = new TreeSet(phases);
/* 122 */     if (resourceBindingContext.isBatchMode()) {
/* 123 */       retPhases.remove(ResourceLifecyclePhase.METADATA_COMMIT);
/* 124 */       retPhases.remove(ResourceLifecyclePhase.DATA_COMMIT);
/*     */     }
/*     */     
/* 127 */     return retPhases;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\PhaseMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */