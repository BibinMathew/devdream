/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ 
/*    */ public abstract class AbstractResourceOperation extends AbstractOperation
/*    */ {
/*    */   public void processPrecondition(ResourceProcessingContext context)
/*    */   {
/* 10 */     if (context.isResourceTreeAvailable()) {
/* 11 */       Resource currentResource = context.getResourceTree().getCurrentResource();
/* 12 */       context.processCondition(currentResource.getChangeIndicator());
/*    */     }
/*    */   }
/*    */   
/*    */   public void prepareResponse(ResourceProcessingContext context)
/*    */   {
/* 18 */     if ((this.responseHandler.isEntityGenerationAllowed()) && (context.isResourceTreeAvailable())) {
/* 19 */       Resource currentResource = context.getResourceTree().getCurrentResource();
/* 20 */       this.responseHandler.setStateIdentifier(currentResource.getChangeIndicator());
/*    */     }
/* 22 */     super.prepareResponse(context);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\AbstractResourceOperation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */