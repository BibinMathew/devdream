/*     */ package oracle.adf.internal.model.rest.core.payload.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Stack;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*     */ import oracle.adf.internal.model.rest.core.helper.ResourceTreeManager;
/*     */ import oracle.adf.internal.model.rest.core.helper.ResourceTreeManager.AttributeType;
/*     */ import oracle.adf.internal.model.rest.core.payload.ResourceParser;
/*     */ import oracle.adf.internal.model.rest.core.payload.ResourceParser.TokenType;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.domain.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLResourceParser
/*     */   implements ResourceParser
/*     */ {
/*     */   private final XMLStreamReader reader;
/*     */   private final ResourceTreeManager treeManager;
/*  29 */   private final Stack<String> nestedResourceNameStack = new Stack();
/*     */   
/*     */   public XMLResourceParser(XMLStreamReader reader, ResourceTreeManager treeManager)
/*     */   {
/*  33 */     this.reader = reader;
/*  34 */     this.treeManager = treeManager;
/*     */   }
/*     */   
/*     */   public ResourceParser.TokenType next()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  42 */       while (this.reader.hasNext())
/*     */       {
/*  44 */         this.reader.next();
/*  45 */         if ((this.reader.isStartElement()) && (this.reader.getLocalName().equals("item")))
/*     */         {
/*  47 */           return ResourceParser.TokenType.START_ITEM;
/*     */         }
/*  49 */         if ((this.reader.isEndElement()) && (this.reader.getLocalName().equals("item")))
/*     */         {
/*  51 */           return ResourceParser.TokenType.END_ITEM;
/*     */         }
/*  53 */         if ((this.reader.isEndElement()) && (this.nestedResourceNameStack.size() > 0) && (this.reader.getLocalName().equals(this.nestedResourceNameStack.peek())))
/*     */         {
/*     */ 
/*  56 */           this.nestedResourceNameStack.pop();
/*  57 */           return ResourceParser.TokenType.END_COLLECTION;
/*     */         }
/*  59 */         if (this.reader.isStartElement())
/*     */         {
/*  61 */           String name = this.reader.getLocalName();
/*     */           
/*     */ 
/*  64 */           if (this.treeManager.getAttributeType(name) == ResourceTreeManager.AttributeType.ACCESSOR)
/*     */           {
/*     */ 
/*  67 */             this.nestedResourceNameStack.push(name);
/*  68 */             return ResourceParser.TokenType.START_COLLECTION;
/*     */           }
/*     */           
/*     */ 
/*  72 */           Attribute attribute = this.treeManager.setCurrentAttribute(name);
/*  73 */           if (attribute == null)
/*     */           {
/*  75 */             throw new JboException("No attribute name " + name + " found.");
/*     */           }
/*     */           
/*  78 */           Object val = null;
/*  79 */           if (!Boolean.valueOf(this.reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil")).booleanValue())
/*     */           {
/*  81 */             this.reader.next();
/*  82 */             String value = this.reader.getText().trim();
/*  83 */             val = TypeFactory.getInstance(attribute.getJavaType(), value);
/*     */           }
/*  85 */           this.treeManager.setAttributeValue(val);
/*  86 */           return ResourceParser.TokenType.ATTR_VALUE;
/*     */         }
/*     */       }
/*  89 */       return ResourceParser.TokenType.CLOSE;
/*     */     }
/*     */     catch (XMLStreamException ex)
/*     */     {
/*  93 */       throw new IOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getNestedResourceName()
/*     */   {
/* 100 */     return this.nestedResourceNameStack.isEmpty() ? null : (String)this.nestedResourceNameStack.peek();
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\xml\XMLResourceParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */