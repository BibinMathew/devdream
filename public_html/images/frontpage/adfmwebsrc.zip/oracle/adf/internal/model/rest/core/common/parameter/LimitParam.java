/*    */ package oracle.adf.internal.model.rest.core.common.parameter;
/*    */ 
/*    */ public class LimitParam
/*    */   extends ResourceParameter
/*    */ {
/*    */   private Integer limit;
/*    */   
/*    */   public LimitParam(String[] parameterValues)
/*    */   {
/* 10 */     if ((parameterValues != null) && (parameterValues.length > 0) && (parameterValues[0] != null)) {
/* 11 */       this.limit = Integer.valueOf(Integer.parseInt(parameterValues[0]));
/*    */     }
/*    */   }
/*    */   
/*    */   public Integer getLimit() {
/* 16 */     return this.limit;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\parameter\LimitParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */