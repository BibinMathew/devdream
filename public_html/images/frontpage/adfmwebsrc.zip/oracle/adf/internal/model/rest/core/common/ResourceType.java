package oracle.adf.internal.model.rest.core.common;

public enum ResourceType
{
  RESOURCE_ITEM,  RESOURCE_COLLECTION,  ATTACHMENT,  VERSION;
  
  private ResourceType() {}
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\ResourceType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */