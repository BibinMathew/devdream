/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class MediaType
/*    */ {
/*    */   private final String type;
/*    */   private final String subType;
/*    */   private HashMap<String, String> parameters;
/*    */   public static final String MEDIA_TYPE_SEPARATOR = "/";
/*    */   public static final String MEDIA_TYPE_PARAM_SEPARATOR = ";";
/*    */   public static final String MEDIA_TYPE_PARAM_VALUE_SEPARATOR = "=";
/*    */   
/*    */   public MediaType(String type, String subType) {
/* 15 */     if ((type == null) || (subType == null)) {
/* 16 */       throw new IllegalArgumentException("Null argument is not allowed. Type: " + type + "; SubType: " + subType);
/*    */     }
/* 18 */     this.type = type;
/* 19 */     this.subType = subType;
/*    */   }
/*    */   
/*    */   public String getType() {
/* 23 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getSubType() {
/* 27 */     return this.subType;
/*    */   }
/*    */   
/*    */   public void setParameters(HashMap<String, String> parameters) {
/* 31 */     this.parameters = parameters;
/*    */   }
/*    */   
/*    */   public HashMap<String, String> getParameters() {
/* 35 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 39 */     StringBuilder mediaType = new StringBuilder(this.type + "/" + this.subType);
/* 40 */     if ((this.parameters != null) && (this.parameters.size() > 0)) {
/* 41 */       for (java.util.Map.Entry<String, String> entry : this.parameters.entrySet()) {
/* 42 */         mediaType.append(";").append((String)entry.getKey()).append("=").append((String)entry.getValue());
/*    */       }
/*    */     }
/* 45 */     return mediaType.toString();
/*    */   }
/*    */   
/*    */   public static MediaType parseMediaType(String mt) {
/* 49 */     MediaType mediaType = null;
/* 50 */     String[] mtArray = mt.split(";");
/* 51 */     String[] mediaTypeComponents = mtArray[0].split("/");
/*    */     
/* 53 */     mediaType = new MediaType(mediaTypeComponents[0], mediaTypeComponents[1]);
/*    */     
/* 55 */     if (mtArray.length > 1) {
/* 56 */       HashMap<String, String> parameters = new HashMap(mtArray.length - 1);
/* 57 */       for (int i = 1; i < mtArray.length; i++) {
/* 58 */         String[] nameValuePair = mtArray[i].split("=");
/* 59 */         parameters.put(nameValuePair[0], nameValuePair[1]);
/*    */       }
/*    */     }
/*    */     
/* 63 */     return mediaType;
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 68 */     if (this == object) {
/* 69 */       return true;
/*    */     }
/* 71 */     if (!(object instanceof MediaType)) {
/* 72 */       return false;
/*    */     }
/* 74 */     MediaType other = (MediaType)object;
/* 75 */     if (this.type == null ? other.type != null : !this.type.equals(other.type)) {
/* 76 */       return false;
/*    */     }
/* 78 */     if (this.subType == null ? other.subType != null : !this.subType.equals(other.subType)) {
/* 79 */       return false;
/*    */     }
/* 81 */     if (this.parameters == null ? other.parameters != null : !this.parameters.equals(other.parameters)) {
/* 82 */       return false;
/*    */     }
/* 84 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 89 */     int PRIME = 37;
/* 90 */     int result = 1;
/* 91 */     result = 37 * result + (this.type == null ? 0 : this.type.hashCode());
/* 92 */     result = 37 * result + (this.subType == null ? 0 : this.subType.hashCode());
/* 93 */     result = 37 * result + (this.parameters == null ? 0 : this.parameters.hashCode());
/* 94 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\MediaType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */