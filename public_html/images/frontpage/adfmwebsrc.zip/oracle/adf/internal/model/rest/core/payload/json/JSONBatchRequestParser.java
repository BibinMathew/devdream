/*    */ package oracle.adf.internal.model.rest.core.payload.json;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.common.Condition;
/*    */ import oracle.adf.internal.model.rest.core.common.ConditionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.BatchPart;
/*    */ import oracle.adf.internal.model.rest.core.payload.BatchRequestParser;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.map.ObjectMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JSONBatchRequestParser
/*    */   implements BatchRequestParser
/*    */ {
/*    */   private JsonParser parser;
/*    */   private ObjectMapper mapper;
/*    */   
/*    */   JSONBatchRequestParser(ObjectMapper mapper, JsonParser parser)
/*    */   {
/* 32 */     this.parser = parser;
/* 33 */     this.mapper = mapper;
/*    */   }
/*    */   
/*    */   private List<String> getArrayValues(JsonNode arrayNode) {
/* 37 */     if (!arrayNode.isArray()) {
/* 38 */       throw new IllegalArgumentException("The json node is not an array.");
/*    */     }
/*    */     
/* 41 */     List<String> values = new ArrayList(arrayNode.size());
/* 42 */     Iterator<JsonNode> elements = arrayNode.getElements();
/*    */     
/* 44 */     while (elements.hasNext()) {
/* 45 */       values.add(((JsonNode)elements.next()).getTextValue());
/*    */     }
/*    */     
/* 48 */     return values;
/*    */   }
/*    */   
/*    */   public void parse(Collection<BatchPart> parts) throws IOException {
/* 52 */     JsonNode node = (JsonNode)this.mapper.readValue(this.parser, JsonNode.class);
/* 53 */     Iterator<JsonNode> iter = node.get("parts").getElements();
/* 54 */     while (iter.hasNext()) {
/* 55 */       JsonNode partNode = (JsonNode)iter.next();
/*    */       
/* 57 */       String id = partNode.get("id").getTextValue();
/* 58 */       String operation = partNode.get("operation").getTextValue();
/* 59 */       String path = partNode.get("path").getTextValue();
/*    */       
/* 61 */       BatchPart part = new BatchPart(id, operation, path);
/*    */       
/* 63 */       Map<ConditionType, List<String>> conditions = new HashMap();
/* 64 */       JsonNode ifMatchNode = partNode.get("ifMatch");
/* 65 */       if (ifMatchNode != null) {
/* 66 */         if (ifMatchNode.isNull()) {
/* 67 */           conditions.put(ConditionType.MATCH, null);
/*    */         } else {
/* 69 */           conditions.put(ConditionType.MATCH, getArrayValues(ifMatchNode));
/*    */         }
/*    */       }
/*    */       
/* 73 */       JsonNode ifNoneMatchNode = partNode.get("ifNoneMatch");
/* 74 */       if (ifNoneMatchNode != null) {
/* 75 */         if (ifNoneMatchNode.isNull()) {
/* 76 */           conditions.put(ConditionType.NONE_MATCH, null);
/*    */         } else {
/* 78 */           conditions.put(ConditionType.NONE_MATCH, getArrayValues(ifNoneMatchNode));
/*    */         }
/*    */       }
/*    */       
/* 82 */       if (!conditions.isEmpty()) {
/* 83 */         part.setCondition(Condition.createCondition(conditions));
/*    */       }
/*    */       
/* 86 */       JsonNode payload = partNode.get("payload");
/* 87 */       if (payload != null) {
/* 88 */         ByteArrayOutputStream os = null;
/*    */         try {
/* 90 */           os = new ByteArrayOutputStream();
/* 91 */           this.mapper.writeValue(os, payload);
/* 92 */           part.setPayloadByteArray(os.toByteArray());
/*    */         } finally {
/* 94 */           if (os != null) {
/* 95 */             os.close();
/*    */           }
/*    */         }
/*    */       }
/* 99 */       parts.add(part);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\json\JSONBatchRequestParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */