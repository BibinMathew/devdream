/*     */ package oracle.adf.internal.model.rest.core.lifecycle;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import oracle.adf.internal.model.rest.core.common.Operation;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.common.ResourceContext;
/*     */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*     */ import oracle.adf.internal.model.rest.core.common.ResponseHandler.ErrorType;
/*     */ import oracle.adf.internal.model.rest.core.common.listener.ResourceLifecycleEvent;
/*     */ import oracle.adf.internal.model.rest.core.common.listener.ResourceLifecycleListener;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.domain.Resource;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceTree;
/*     */ import oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException;
/*     */ import oracle.adf.internal.model.rest.core.exception.PreconditionFailedException;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceException;
/*     */ import oracle.adf.model.binding.DCBindingContainer;
/*     */ import oracle.adf.share.annotations.RecoverableException;
/*     */ import oracle.adfinternal.model.logging.contextual.logger.functional.FunctionalLogger;
/*     */ import oracle.jbo.JboException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceLifecycleProcessor
/*     */ {
/*  40 */   private final Map<ResourceLifecyclePhase, Set<ResourceLifecycleListenerWrapper>> listenerMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceProcessingContext execute(ResourceContext resourceContext, OperationType operationType, ResponseHandler responseHandler)
/*     */   {
/*  53 */     ResourceProcessingContext resourceBindingContext = new ResourceProcessingContext(resourceContext);
/*  54 */     ResourceLifecycleContext context = new ResourceLifecycleContext(resourceBindingContext, operationType, responseHandler);
/*     */     
/*  56 */     executeLifecycle(context);
/*  57 */     return resourceBindingContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addListener(ResourceLifecycleListener listener)
/*     */   {
/*  65 */     ResourceLifecycleListenerWrapper listenerWrapper = ResourceLifecycleListenerWrapper.wrap(listener);
/*     */     
/*  67 */     for (ResourceLifecyclePhase listenerPhase : listenerWrapper.getListenTo()) {
/*  68 */       Set<ResourceLifecycleListenerWrapper> phaseListeners = (Set)this.listenerMap.get(listenerPhase);
/*  69 */       if (phaseListeners == null) {
/*  70 */         phaseListeners = new HashSet();
/*  71 */         this.listenerMap.put(listenerPhase, phaseListeners);
/*     */       }
/*  73 */       phaseListeners.add(listenerWrapper);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void notifyPhaseListeners(ResourceLifecyclePhase phase, ResourceLifecycleContext lifecycleContext)
/*     */   {
/*  84 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*     */     try {
/*  86 */       ResourceProcessingContext context = lifecycleContext.getResourceProcessingContext();
/*  87 */       Set<ResourceLifecycleListenerWrapper> listeners = (Set)this.listenerMap.get(phase);
/*  88 */       if (listeners == null) {
/*  89 */         return;
/*     */       }
/*  91 */       event = new ResourceLifecycleEvent(context.getResourcePath(), phase, lifecycleContext.getResponseHandler());
/*  92 */       for (ResourceLifecycleListenerWrapper listener : listeners)
/*  93 */         listener.notify(event);
/*     */     } catch (Exception ex) {
/*     */       ResourceLifecycleEvent event;
/*  96 */       logger.warning("Error while notifying the listeners", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void executeLifecycle(ResourceLifecycleContext context)
/*     */   {
/* 110 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/* 111 */     ResourceLifecycle lifecycle = new ResourceLifecycle();
/* 112 */     ResourceProcessingContext resourceBindingContext = context.getResourceProcessingContext();
/* 113 */     ResponseHandler responseHandler = context.getResponseHandler();
/*     */     try {
/* 115 */       for (ResourceLifecyclePhase phase : PhaseMapping.getPhases(context.getOperationType(), resourceBindingContext)) {
/* 116 */         if (logger.isConfig()) {
/* 117 */           Map<String, String> contextData = new HashMap(1);
/* 118 */           contextData.put("Phase Name", phase.toString());
/* 119 */           logger.beginActivity(Level.CONFIG, "Lifecycle Phase", contextData);
/*     */         }
/*     */         try
/*     */         {
/* 123 */           logger.beginActivity(Level.FINE, "Notifying listeners", null);
/* 124 */           notifyPhaseListeners(phase, context);
/* 125 */           logger.endCurrentActivity();
/*     */           try {
/* 127 */             logger.beginActivity(Level.FINE, "Executing phase", null);
/* 128 */             phase.executePhase(lifecycle, context);
/*     */           } finally {
/* 130 */             logger.endCurrentActivity();
/*     */           }
/*     */           
/* 133 */           logger.beginActivity(Level.FINE, "Checking errors", null);
/* 134 */           checkErrors(lifecycle, context);
/* 135 */           logger.endCurrentActivity();
/*     */         } finally {
/* 137 */           if (logger.isConfig()) {
/* 138 */             logger.endCurrentActivity();
/*     */           }
/*     */         }
/*     */       }
/* 142 */       responseHandler.finish();
/*     */     } catch (Exception ex) {
/* 144 */       if (logger.isConfig()) {
/* 145 */         Map<String, String> contextData = new HashMap(1);
/* 146 */         contextData.put("Cause", ex.getMessage());
/* 147 */         logger.config("The resource lifecycle was interrupted", contextData);
/*     */       }
/*     */       
/* 150 */       if (((ex instanceof CannotGenerateContentException)) && (responseHandler.getError() == ResponseHandler.ErrorType.PRECONDITION_FAILED)) {
/* 151 */         logger.fine(ex);
/* 152 */         ex = new PreconditionFailedException("The precondition failed and it was not possible to generate a response payload to the client.");
/*     */       }
/*     */       
/* 155 */       JboException jboEx = convertToJboException(ex);
/*     */       
/* 157 */       configureStateIdentifier(context);
/* 158 */       rollbackOperation(context);
/*     */       
/* 160 */       if (isRecoverableException(jboEx)) {
/* 161 */         DCBindingContainer bindingContainer = resourceBindingContext.getBindingContainer();
/* 162 */         if (bindingContainer != null) {
/* 163 */           if ((jboEx instanceof ResourceException))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 168 */             lifecycle.reportErrors(context, (ResourceException)jboEx);
/*     */           } else {
/* 170 */             bindingContainer.processException(jboEx);
/* 171 */             lifecycle.reportErrors(context, jboEx);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 177 */       throw jboEx;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void rollbackOperation(ResourceLifecycleContext context)
/*     */   {
/* 186 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*     */     try {
/* 188 */       if ((context.getOperation() != null) && (context.getOperation().isCommitNeeded())) {
/* 189 */         context.getResourceProcessingContext().getResourceTree().rollbackTransaction();
/*     */       }
/*     */     } catch (Exception ex) {
/* 192 */       logger.severe("Could not rollback the operation", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void configureStateIdentifier(ResourceLifecycleContext context)
/*     */   {
/* 204 */     FunctionalLogger logger = ResourceLoggerManager.getDiagnosticLogger();
/*     */     try {
/* 206 */       ResourceProcessingContext processingContext = context.getResourceProcessingContext();
/* 207 */       ResponseHandler responseHandler = context.getResponseHandler();
/* 208 */       if ((responseHandler.getStateIdentifier() == null) && (processingContext.isResourceTreeAvailable())) {
/* 209 */         Resource currentResource = processingContext.getResourceTree().getCurrentResource();
/* 210 */         if (currentResource != null) {
/* 211 */           responseHandler.setStateIdentifier(currentResource.getChangeIndicator());
/*     */         }
/*     */       }
/*     */     } catch (Exception ex) {
/* 215 */       logger.severe("Error while setting the state identifier in the ResponseHandler", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private JboException convertToJboException(Exception ex)
/*     */   {
/*     */     JboException jboEx;
/*     */     
/*     */     JboException jboEx;
/*     */     
/* 226 */     if ((ex instanceof JboException)) {
/* 227 */       jboEx = (JboException)ex;
/*     */     } else {
/* 229 */       jboEx = new JboException(ex);
/*     */     }
/* 231 */     return jboEx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkErrors(ResourceLifecycle lifecycle, ResourceLifecycleContext context)
/*     */   {
/* 240 */     List exList = lifecycle.hasErrors(context);
/* 241 */     if (!exList.isEmpty()) {
/* 242 */       lifecycle.reportErrors(context, exList);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isRecoverableException(Exception ex)
/*     */   {
/* 251 */     for (Throwable cex = ex; cex != null; cex = cex.getCause()) {
/* 252 */       if (cex.getClass().isAnnotationPresent(RecoverableException.class)) {
/* 253 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 257 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ResourceLifecycleProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */