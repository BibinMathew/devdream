/*     */ package oracle.adf.internal.model.rest.core.payload;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import oracle.adf.internal.model.rest.core.common.Condition;
/*     */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.ActionResult;
/*     */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*     */ import oracle.adf.internal.model.rest.core.domain.BatchPart;
/*     */ import oracle.adf.internal.model.rest.core.domain.Cardinality;
/*     */ import oracle.adf.internal.model.rest.core.domain.FinderDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.Link;
/*     */ import oracle.adf.internal.model.rest.core.domain.ParameterDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.Path;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription.CollectionSection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceDescription.ResourceAnnotationsSection;
/*     */ import oracle.adf.internal.model.rest.core.domain.ResourceProperty;
/*     */ import oracle.adf.internal.model.rest.core.domain.Version;
/*     */ import oracle.adf.model.rest.RestTypeConverter;
/*     */ import oracle.adf.model.rest.core.describer.json.JSONTypeMap;
/*     */ import oracle.adf.model.rest.core.describer.json.JSONTypeMap.JSONType;
/*     */ import oracle.jbo.JboException;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JSONGenerator
/*     */   implements PayloadGenerator
/*     */ {
/*  42 */   private static final JsonFactory JSON_FACTORY = new JsonFactory();
/*     */   private final JsonGenerator gen;
/*  44 */   private static final ObjectMapper MAPPER = new ObjectMapper(JSON_FACTORY);
/*     */   private PayloadType payloadType;
/*     */   
/*     */   public JSONGenerator(OutputStream out) throws IOException
/*     */   {
/*  49 */     this.gen = JSON_FACTORY.createJsonGenerator(out, JsonEncoding.UTF8);
/*     */   }
/*     */   
/*     */   public JSONGenerator(Writer writer) throws IOException {
/*  53 */     this.gen = JSON_FACTORY.createJsonGenerator(writer);
/*     */   }
/*     */   
/*     */   public JSONGenerator(JsonGenerator gen) {
/*  57 */     this.gen = gen;
/*     */   }
/*     */   
/*     */   public Object getTarget() {
/*  61 */     return this.gen;
/*     */   }
/*     */   
/*     */   public void startResource() throws IOException {
/*  65 */     this.gen.writeStartObject();
/*     */   }
/*     */   
/*     */   public void endResource() throws IOException {
/*  69 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void addLink(Link link) throws IOException
/*     */   {
/*  74 */     if (link == null) {
/*  75 */       throw new IllegalArgumentException("null argument");
/*     */     }
/*     */     
/*  78 */     this.gen.writeStartObject();
/*  79 */     this.gen.writeStringField("rel", link.getRel());
/*  80 */     this.gen.writeStringField("href", link.getHref().createHref());
/*  81 */     this.gen.writeStringField("name", link.getName());
/*  82 */     this.gen.writeStringField("kind", link.getKind());
/*     */     
/*  84 */     Cardinality cardinality = link.getCardinality();
/*  85 */     if (cardinality != null) {
/*  86 */       createCardinality(cardinality);
/*     */     }
/*     */     
/*  89 */     List<ResourceProperty> properties = link.getProperties();
/*     */     
/*  91 */     if (!properties.isEmpty()) {
/*  92 */       this.gen.writeFieldName("properties");
/*  93 */       this.gen.writeStartObject();
/*  94 */       createResourceProperties(properties);
/*  95 */       this.gen.writeEndObject();
/*     */     }
/*     */     
/*  98 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void createLinks(List<Link> links) throws IOException {
/* 102 */     if ((links == null) || (links.isEmpty())) {
/* 103 */       return;
/*     */     }
/*     */     
/* 106 */     startLinks();
/*     */     
/* 108 */     addLink(links);
/*     */     
/* 110 */     endLinks();
/*     */   }
/*     */   
/*     */   public void createFinders(List<FinderDescription> finders) throws IOException {
/* 114 */     if ((finders == null) || (finders.isEmpty())) {
/* 115 */       return;
/*     */     }
/*     */     
/* 118 */     this.gen.writeArrayFieldStart("finders");
/* 119 */     for (FinderDescription finder : finders) {
/* 120 */       this.gen.writeStartObject();
/* 121 */       this.gen.writeStringField("name", finder.getName());
/* 122 */       String title = finder.getTitle();
/* 123 */       if (title != null) {
/* 124 */         this.gen.writeStringField("title", finder.getTitle());
/*     */       }
/* 126 */       String description = finder.getDescriptionText();
/* 127 */       if (description != null) {
/* 128 */         this.gen.writeObjectFieldStart("annotations");
/* 129 */         this.gen.writeStringField("description", description);
/* 130 */         this.gen.writeEndObject();
/*     */       }
/*     */       
/* 133 */       this.gen.writeArrayFieldStart("attributes");
/* 134 */       for (Attribute attribute : finder.getAttributes()) {
/* 135 */         this.gen.writeStartObject();
/* 136 */         attribute.serializeDescription(getPayloadType(), getTarget());
/* 137 */         String descriptionText = finder.getDescriptionTextForAttr(attribute.getName());
/* 138 */         if (descriptionText != null) {
/* 139 */           addDescriptionFromAnnotation(descriptionText);
/*     */         }
/* 141 */         this.gen.writeEndObject();
/*     */       }
/* 143 */       this.gen.writeEndArray();
/* 144 */       this.gen.writeEndObject();
/*     */     }
/* 146 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void addLink(List<Link> links) throws IOException {
/* 150 */     if ((links != null) && (links.size() > 0)) {
/* 151 */       for (Link link : links) {
/* 152 */         addLink(link);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addAttributeLink(List<Attribute> attrs, Path resourceHref) throws IOException
/*     */   {
/* 159 */     if ((attrs != null) && (attrs.size() > 0)) {
/* 160 */       for (Attribute attr : attrs) {
/* 161 */         addAttributeLink(attr, resourceHref);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addAttributeLink(Attribute attribute, Path resourceHref) throws IOException {
/* 167 */     if (attribute.canStreamContent()) {
/* 168 */       addLink(attribute.createContentLink(resourceHref));
/*     */     } else {
/* 170 */       attribute.serializeLink(getPayloadType(), getTarget());
/*     */     }
/*     */   }
/*     */   
/*     */   public void endLinks() throws IOException {
/* 175 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void startLinks() throws IOException {
/* 179 */     this.gen.writeFieldName("links");
/* 180 */     this.gen.writeStartArray();
/*     */   }
/*     */   
/*     */   public void setup() {
/* 184 */     this.gen.useDefaultPrettyPrinter();
/*     */   }
/*     */   
/* 187 */   public void startPayload() throws IOException { this.gen.writeStartObject(); }
/*     */   
/*     */   public void startDescription() throws IOException
/*     */   {
/* 191 */     this.gen.writeStartObject();
/* 192 */     this.gen.writeFieldName("Resources");
/* 193 */     this.gen.writeStartObject();
/*     */   }
/*     */   
/*     */   public void startResourceDescription(ResourceDescription resourceDescription) throws IOException {
/* 197 */     this.gen.writeFieldName(resourceDescription.getName());
/* 198 */     this.gen.writeStartObject();
/* 199 */     this.gen.writeBooleanField("discrColumnType", resourceDescription.isDiscrColumnType());
/*     */     
/* 201 */     List<String> docCategories = resourceDescription.getDocCategories();
/* 202 */     if (!docCategories.isEmpty()) {
/* 203 */       this.gen.writeFieldName("docCategories");
/* 204 */       this.gen.writeStartArray();
/* 205 */       for (String category : docCategories) {
/* 206 */         this.gen.writeString(category);
/*     */       }
/* 208 */       this.gen.writeEndArray();
/*     */     }
/*     */     
/* 211 */     String label = resourceDescription.getLabel();
/* 212 */     if (label != null) {
/* 213 */       this.gen.writeStringField("title", label);
/*     */     }
/*     */     
/* 216 */     String pluralLabel = resourceDescription.getPluralLabel();
/* 217 */     if (pluralLabel != null) {
/* 218 */       this.gen.writeStringField("titlePlural", pluralLabel);
/*     */     }
/*     */     
/* 221 */     startAttributeDescription();
/* 222 */     for (Attribute attribute : resourceDescription.getAttributes()) {
/* 223 */       startAttributeDescriptionItem();
/* 224 */       addAttributeDescriptionItem(attribute);
/* 225 */       String descriptionText = resourceDescription.getDescriptionText(attribute);
/* 226 */       if (descriptionText != null) {
/* 227 */         addDescriptionFromAnnotation(descriptionText);
/*     */       }
/* 229 */       endAttributeDescriptionItem();
/*     */     }
/* 231 */     endAttributeDescription();
/*     */   }
/*     */   
/*     */   public void endResourceDescription(ResourceDescription resourceDescription) throws IOException {
/* 235 */     createLinks(resourceDescription.getLinks());
/* 236 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void endDescription() throws IOException {
/* 240 */     this.gen.writeEndObject();
/* 241 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void endPayload() throws IOException {
/* 245 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void createActionResult(ActionResult actionResult)
/*     */     throws IOException
/*     */   {
/* 251 */     this.gen.writeStartObject();
/* 252 */     Object result = actionResult.getResult();
/* 253 */     Object payload = RestTypeConverter.toPayloadType(result);
/* 254 */     this.gen.writeStringField("result", payload.toString());
/* 255 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void startActionDescription() throws IOException {
/* 259 */     this.gen.writeFieldName("actions");
/* 260 */     this.gen.writeStartArray();
/*     */   }
/*     */   
/*     */   public void endActionDescription() throws IOException {
/* 264 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void startActionDescriptionItem() throws IOException {
/* 268 */     this.gen.writeStartObject();
/*     */   }
/*     */   
/*     */   public void endActionDescriptionItem() throws IOException {
/* 272 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void addActionDescriptionAttribute(String name, String value) throws IOException {
/* 276 */     this.gen.writeStringField(name, value);
/*     */   }
/*     */   
/*     */   public void addActionDescriptionAttribute(String name, Collection<String> valueCollection) throws IOException {
/* 280 */     this.gen.writeArrayFieldStart(name);
/* 281 */     for (String value : valueCollection) {
/* 282 */       this.gen.writeString(value);
/*     */     }
/* 284 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void createActionDescription(ActionDescription actionDescription) throws IOException {
/* 288 */     this.gen.writeStringField("name", actionDescription.getName());
/*     */     
/* 290 */     if (actionDescription.getDescription() != null) {
/* 291 */       this.gen.writeStringField("description", actionDescription.getDescription());
/*     */     }
/*     */     
/* 294 */     List<ParameterDescription> parameters = actionDescription.getParameters();
/*     */     
/* 296 */     if (!parameters.isEmpty()) {
/* 297 */       this.gen.writeFieldName("parameters");
/* 298 */       this.gen.writeStartArray();
/* 299 */       for (ParameterDescription parameter : parameters) {
/* 300 */         this.gen.writeStartObject();
/* 301 */         this.gen.writeStringField("name", parameter.getName());
/* 302 */         JSONTypeMap.JSONType jsonType = null;
/*     */         try {
/* 304 */           jsonType = JSONTypeMap.getJSONType(parameter.getTypeName());
/*     */         } catch (ClassNotFoundException e) {
/* 306 */           throw new JboException(e);
/*     */         }
/* 308 */         this.gen.writeStringField("type", jsonType.toString());
/* 309 */         this.gen.writeBooleanField("mandatory", parameter.isMandatory());
/* 310 */         this.gen.writeEndObject();
/*     */       }
/*     */       
/* 313 */       this.gen.writeEndArray();
/*     */     }
/*     */     
/* 316 */     if (actionDescription.getResultType() != null) {
/* 317 */       JSONTypeMap.JSONType jsonType = null;
/*     */       try {
/* 319 */         jsonType = JSONTypeMap.getJSONType(actionDescription.getResultType());
/*     */       } catch (ClassNotFoundException e) {
/* 321 */         throw new JboException(e);
/*     */       }
/* 323 */       this.gen.writeStringField("resultType", jsonType.toString());
/*     */     }
/*     */     
/*     */ 
/* 327 */     for (Map.Entry<String, String> entry : actionDescription.getProperties().entrySet()) {
/* 328 */       this.gen.writeStringField((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */     
/* 331 */     if (!actionDescription.getRequestType().isEmpty()) {
/* 332 */       this.gen.writeArrayFieldStart("requestType");
/* 333 */       for (String value : actionDescription.getRequestType()) {
/* 334 */         this.gen.writeString(value);
/*     */       }
/* 336 */       this.gen.writeEndArray();
/*     */     }
/*     */     
/* 339 */     if (!actionDescription.getResponseType().isEmpty()) {
/* 340 */       this.gen.writeArrayFieldStart("responseType");
/* 341 */       for (String value : actionDescription.getResponseType()) {
/* 342 */         this.gen.writeString(value);
/*     */       }
/* 344 */       this.gen.writeEndArray();
/*     */     }
/*     */   }
/*     */   
/*     */   public void createAttribute(Attribute attr) throws IOException
/*     */   {
/* 350 */     String name = attr.getName();
/* 351 */     if (attr.canSerializeValue(this.payloadType)) {
/* 352 */       this.gen.writeFieldName(name);
/* 353 */       attr.serializeValue(getPayloadType(), getTarget());
/*     */     }
/*     */   }
/*     */   
/*     */   public void startAttributeDescription() throws IOException {
/* 358 */     this.gen.writeFieldName("attributes");
/* 359 */     this.gen.writeStartArray();
/*     */   }
/*     */   
/*     */   public void endAttributeDescription() throws IOException {
/* 363 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void startAttributeDescriptionItem() throws IOException {
/* 367 */     this.gen.writeStartObject();
/*     */   }
/*     */   
/*     */   public void endAttributeDescriptionItem() throws IOException {
/* 371 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void addAttributeDescriptionItem(Attribute attr) throws IOException {
/* 375 */     attr.serializeDescription(getPayloadType(), getTarget());
/*     */   }
/*     */   
/*     */   private void addDescriptionFromAnnotation(String descriptionText) throws IOException {
/* 379 */     this.gen.writeObjectFieldStart("annotations");
/* 380 */     this.gen.writeStringField("description", descriptionText);
/* 381 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void startResourceCollectionDescriptionSection() throws IOException {
/* 385 */     this.gen.writeFieldName("collection");
/* 386 */     this.gen.writeStartObject();
/*     */   }
/*     */   
/*     */   public void endResourceCollectionDescriptionSection() throws IOException {
/* 390 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void startResourceDescriptionSection() throws IOException {
/* 394 */     this.gen.writeFieldName("item");
/* 395 */     this.gen.writeStartObject();
/*     */   }
/*     */   
/*     */   public void endResourceDescriptionSection() throws IOException {
/* 399 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void createResourceAnnotationsSection(ResourceDescription.ResourceAnnotationsSection resAn) throws IOException {
/* 403 */     if (resAn.isEmpty()) {
/* 404 */       return;
/*     */     }
/*     */     
/* 407 */     this.gen.writeFieldName("annotations");
/* 408 */     this.gen.writeStartObject();
/* 409 */     String description = resAn.getDescription();
/* 410 */     if (description != null) {
/* 411 */       this.gen.writeStringField("description", description);
/*     */     }
/* 413 */     Map<String, String> childDescriptions = resAn.getChildDescriptions();
/* 414 */     if (!childDescriptions.isEmpty()) {
/* 415 */       this.gen.writeFieldName("children");
/* 416 */       this.gen.writeStartArray();
/* 417 */       for (Map.Entry<String, String> entry : childDescriptions.entrySet()) {
/* 418 */         this.gen.writeStartObject();
/* 419 */         this.gen.writeStringField("name", (String)entry.getKey());
/* 420 */         this.gen.writeStringField("description", (String)entry.getValue());
/* 421 */         this.gen.writeEndObject();
/*     */       }
/* 423 */       this.gen.writeEndArray();
/*     */     }
/* 425 */     if (!resAn.getKeyWordList().isEmpty()) {
/* 426 */       List<String> keywordList = resAn.getKeyWordList();
/* 427 */       this.gen.writeFieldName("keywords");
/* 428 */       this.gen.writeStartArray();
/* 429 */       for (String keyword : keywordList) {
/* 430 */         this.gen.writeString(keyword);
/*     */       }
/* 432 */       this.gen.writeEndArray();
/*     */     }
/* 434 */     if (!resAn.getCategoryMap().isEmpty()) {
/* 435 */       Map<String, List<String>> categoryMap = resAn.getCategoryMap();
/* 436 */       this.gen.writeFieldName("categories");
/* 437 */       this.gen.writeStartObject();
/* 438 */       for (String categoryName : categoryMap.keySet()) {
/* 439 */         this.gen.writeFieldName(categoryName);
/* 440 */         this.gen.writeStartArray();
/* 441 */         for (String categoryValue : (List)categoryMap.get(categoryName)) {
/* 442 */           this.gen.writeString(categoryValue);
/*     */         }
/* 444 */         this.gen.writeEndArray();
/*     */       }
/* 446 */       this.gen.writeEndObject();
/*     */     }
/* 448 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void startChildrenDescriptionSection() throws IOException
/*     */   {
/* 453 */     this.gen.writeFieldName("children");
/* 454 */     this.gen.writeStartObject();
/*     */   }
/*     */   
/*     */   public void endChildrenDescriptionSection() throws IOException {
/* 458 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void createCardinality(Cardinality cardinality)
/*     */     throws IOException
/*     */   {
/* 464 */     this.gen.writeFieldName("cardinality");
/* 465 */     this.gen.writeStartObject();
/* 466 */     this.gen.writeStringField("value", cardinality.getFormattedValue());
/* 467 */     this.gen.writeStringField("sourceAttributes", cardinality.getFormattedSourceAttributeNames());
/* 468 */     this.gen.writeStringField("destinationAttributes", cardinality.getFormattedDestinationAttributeNames());
/* 469 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public PayloadType getPayloadType()
/*     */   {
/* 474 */     return this.payloadType;
/*     */   }
/*     */   
/*     */   public void setPayloadType(PayloadType payloadType)
/*     */   {
/* 479 */     this.payloadType = payloadType;
/*     */   }
/*     */   
/*     */   public void createPart(BatchPart part) throws IOException
/*     */   {
/* 484 */     this.gen.writeStartObject();
/* 485 */     this.gen.writeStringField("id", part.getId());
/* 486 */     String operation = part.getOperation().toString();
/* 487 */     this.gen.writeStringField("path", part.getPath());
/* 488 */     this.gen.writeStringField("operation", operation);
/* 489 */     Condition condition = part.getCondition();
/* 490 */     if (condition != null) {
/* 491 */       switch (condition.getConditionType())
/*     */       {
/*     */       case MATCH: 
/* 494 */         this.gen.writeFieldName("ifMatch");
/* 495 */         break;
/*     */       
/*     */ 
/*     */       case NONE_MATCH: 
/* 499 */         this.gen.writeFieldName("ifNoneMatch");
/* 500 */         break;
/*     */       
/*     */ 
/*     */       default: 
/* 504 */         throw new JboException("Unknown condition: " + condition);
/*     */       }
/*     */       
/*     */       
/* 508 */       Collection<String> states = condition.getStates();
/* 509 */       if ((states == null) || (states.isEmpty())) {
/* 510 */         this.gen.writeNull();
/*     */       } else {
/* 512 */         this.gen.writeStartArray();
/* 513 */         for (String state : states) {
/* 514 */           this.gen.writeString(state);
/*     */         }
/* 516 */         this.gen.writeEndArray();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void finalizePart() throws IOException
/*     */   {
/* 523 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 528 */     this.gen.close();
/*     */   }
/*     */   
/*     */   public void createEmptyResource() throws IOException
/*     */   {
/* 533 */     this.gen.writeNull();
/*     */   }
/*     */   
/*     */   public void addPartPreconditionSucceeded(boolean preconditionFailed) throws IOException
/*     */   {
/* 538 */     this.gen.writeBooleanField("preconditionSucceeded", preconditionFailed);
/*     */   }
/*     */   
/*     */   public void startPartPayload() throws IOException
/*     */   {
/* 543 */     this.gen.writeFieldName("payload");
/*     */   }
/*     */   
/*     */   public void startBatch() throws IOException
/*     */   {
/* 548 */     this.gen.writeArrayFieldStart("parts");
/*     */   }
/*     */   
/*     */   public void endBatch() throws IOException
/*     */   {
/* 553 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void startVersions() throws IOException
/*     */   {
/* 558 */     this.gen.writeStartObject();
/* 559 */     this.gen.writeFieldName("items");
/* 560 */     this.gen.writeStartArray();
/*     */   }
/*     */   
/*     */   public void endVersions(List<Link> currentLinks) throws IOException
/*     */   {
/* 565 */     this.gen.writeEndArray();
/* 566 */     createLinks(currentLinks);
/* 567 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void startVersion(Version version) throws IOException
/*     */   {
/* 572 */     this.gen.writeStartObject();
/* 573 */     this.gen.writeStringField("version", version.getDisplayName());
/*     */     
/* 575 */     String lifecycle = version.getLifecycle();
/* 576 */     if (lifecycle != null) {
/* 577 */       this.gen.writeStringField("lifecycle", lifecycle.toString());
/*     */     }
/*     */     
/* 580 */     if (version.isLatest()) {
/* 581 */       this.gen.writeBooleanField("isLatest", true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endVersion() throws IOException
/*     */   {
/* 587 */     this.gen.writeEndObject();
/*     */   }
/*     */   
/*     */   public void createCollectionSectionAttributes(ResourceDescription.CollectionSection collectionSection) throws IOException
/*     */   {
/* 592 */     this.gen.writeNumberField("rangeSize", collectionSection.getRangeSize());
/*     */   }
/*     */   
/*     */   public void startResourceCollectionItems()
/*     */     throws IOException
/*     */   {
/* 598 */     this.gen.writeFieldName("items");
/* 599 */     this.gen.writeStartArray();
/*     */   }
/*     */   
/*     */   public void endResourceCollectionItems() throws IOException
/*     */   {
/* 604 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void startNestedResource(String childName)
/*     */     throws IOException
/*     */   {
/* 610 */     this.gen.writeFieldName(childName);
/* 611 */     this.gen.writeStartArray();
/*     */   }
/*     */   
/*     */   public void endNestedResource() throws IOException
/*     */   {
/* 616 */     this.gen.writeEndArray();
/*     */   }
/*     */   
/*     */   public void createResourceProperty(ResourceProperty property) throws IOException
/*     */   {
/* 621 */     this.gen.writeObjectField((String)property.getKey(), property.getValue());
/*     */   }
/*     */   
/*     */   public void createResourceProperties(List<ResourceProperty> properties) throws IOException
/*     */   {
/* 626 */     for (ResourceProperty property : properties) {
/* 627 */       createResourceProperty(property);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\payload\JSONGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */