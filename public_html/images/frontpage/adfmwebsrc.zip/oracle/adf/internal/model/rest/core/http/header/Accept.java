/*     */ package oracle.adf.internal.model.rest.core.http.header;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Accept implements Header
/*     */ {
/*     */   public static final String NAME = "Accept";
/*     */   private List<MediaRange> mediaRanges;
/*     */   
/*     */   public Accept() {}
/*     */   
/*     */   public Accept(List<MediaRange> mediaRanges)
/*     */   {
/*  17 */     this.mediaRanges = mediaRanges;
/*     */   }
/*     */   
/*     */   public void setMediaRanges(List<MediaRange> mediaRanges) {
/*  21 */     this.mediaRanges = mediaRanges;
/*     */   }
/*     */   
/*     */   public List<MediaRange> getMediaRanges() {
/*  25 */     return this.mediaRanges;
/*     */   }
/*     */   
/*     */   public AcceptBestMatchResult findBestMatch(java.util.Set<MediaType> supportedMedias) {
/*  29 */     AcceptBestMatchResult result = null;
/*  30 */     MediaRange bestMediaRange = null;
/*  31 */     MediaType bestSuppportedMediaType = null;
/*  32 */     int matchScore = 0;
/*  33 */     for (Iterator i$ = this.mediaRanges.iterator(); i$.hasNext();) { mediaRange = (MediaRange)i$.next();
/*  34 */       for (MediaType supportedMedia : supportedMedias) {
/*  35 */         int currentMediaScore = calculateMediaScore(mediaRange, supportedMedia);
/*  36 */         if (currentMediaScore > matchScore) {
/*  37 */           bestMediaRange = mediaRange;
/*  38 */           matchScore = currentMediaScore;
/*  39 */           bestSuppportedMediaType = supportedMedia;
/*  40 */         } else if ((currentMediaScore == matchScore) && (matchScore > 0) && (bestMediaRange != null) && (mediaRange.getQualityFactor().compareTo(bestMediaRange.getQualityFactor()) > 0))
/*     */         {
/*  42 */           bestMediaRange = mediaRange;
/*  43 */           matchScore = currentMediaScore;
/*  44 */           bestSuppportedMediaType = supportedMedia;
/*     */         }
/*     */       } }
/*     */     MediaRange mediaRange;
/*  48 */     if ((bestMediaRange != null) && (bestSuppportedMediaType != null)) {
/*  49 */       result = new AcceptBestMatchResult(bestMediaRange, bestSuppportedMediaType);
/*     */     }
/*     */     
/*  52 */     return result;
/*     */   }
/*     */   
/*     */   private int calculateMediaScore(MediaRange mediaRange, MediaType supportedMedia) {
/*  56 */     int currentMediaScore = 0;
/*  57 */     MediaType mediaTypeRequested = mediaRange.getMediaType();
/*  58 */     if (mediaTypeRequested.getType().equals(supportedMedia.getType())) {
/*  59 */       currentMediaScore += 100;
/*  60 */       HashMap<String, String> supportedMediaParameters; if (mediaTypeRequested.getSubType().equals(supportedMedia.getSubType())) {
/*  61 */         currentMediaScore += 10;
/*  62 */         HashMap<String, String> mediaTypeRequestedParameters = mediaTypeRequested.getParameters();
/*  63 */         supportedMediaParameters = supportedMedia.getParameters();
/*  64 */         if ((mediaTypeRequestedParameters != null) && (supportedMediaParameters != null)) {
/*  65 */           for (String key : mediaTypeRequestedParameters.keySet()) {
/*  66 */             if (supportedMediaParameters.get(key) != null) {
/*  67 */               currentMediaScore++;
/*     */             }
/*     */           }
/*     */         }
/*  71 */       } else if (!mediaTypeRequested.getSubType().equals("*")) {
/*  72 */         currentMediaScore = 0;
/*     */       }
/*  74 */     } else if (mediaTypeRequested.getSubType().equals("*")) {
/*  75 */       currentMediaScore = 10;
/*     */     }
/*     */     
/*  78 */     return currentMediaScore;
/*     */   }
/*     */   
/*     */   public static final Accept createDefaultAccept() {
/*  82 */     MediaType mediaType = new MediaType("*", "*");
/*  83 */     MediaRange mediaRange = new MediaRange(mediaType);
/*  84 */     ArrayList<MediaRange> mediaRanges = new ArrayList(1);
/*  85 */     mediaRanges.add(mediaRange);
/*  86 */     return new Accept(mediaRanges);
/*     */   }
/*     */   
/*     */   public static Accept parse(String acceptHeaderValue) {
/*  90 */     String[] mediaRanges = acceptHeaderValue.split(",");
/*  91 */     return new Accept(parseMediaRange(mediaRanges));
/*     */   }
/*     */   
/*     */   private static List<MediaRange> parseMediaRange(String[] mrs) {
/*  95 */     ArrayList<MediaRange> mediaRanges = new ArrayList();
/*  96 */     for (String mr : mrs) {
/*  97 */       String[] splitMediaRange = mr.split(";");
/*  98 */       String mt = splitMediaRange[0].trim();
/*  99 */       if (mt.equals("*")) {
/* 100 */         mt = "*/*";
/*     */       }
/* 102 */       String[] parameters = null;
/*     */       
/* 104 */       if (splitMediaRange.length > 1) {
/* 105 */         parameters = new String[splitMediaRange.length - 1];
/* 106 */         copyArraySkippingItems(1, splitMediaRange, parameters);
/*     */       }
/*     */       
/* 109 */       MediaType mediaType = parseMediaType(mt, parameters);
/* 110 */       String[] acceptParameters = null;
/* 111 */       if (parameters != null) {
/* 112 */         int mediaTypeParametersSize = 0;
/* 113 */         HashMap<String, String> mediaTypeParameters = mediaType.getParameters();
/* 114 */         if (mediaTypeParameters != null) {
/* 115 */           mediaTypeParametersSize = mediaType.getParameters().size();
/*     */         }
/*     */         
/* 118 */         int parametersLeft = parameters.length - mediaTypeParametersSize;
/* 119 */         if (parametersLeft > 0) {
/* 120 */           acceptParameters = new String[parametersLeft];
/* 121 */           copyArraySkippingItems(mediaTypeParametersSize, parameters, acceptParameters);
/*     */         }
/*     */       }
/* 124 */       MediaRange mediaRange = createMediaRange(mediaType, acceptParameters);
/* 125 */       mediaRanges.add(mediaRange);
/*     */     }
/*     */     
/* 128 */     return mediaRanges;
/*     */   }
/*     */   
/*     */   private static void copyArraySkippingItems(int itemsToSkip, Object[] fromArray, Object[] toArray) {
/* 132 */     for (int i = itemsToSkip; i < fromArray.length; i++) {
/* 133 */       toArray[(i - itemsToSkip)] = fromArray[i];
/*     */     }
/*     */   }
/*     */   
/*     */   private static MediaType parseMediaType(String mt, String[] parameters) {
/* 138 */     String[] splitMt = mt.split("/");
/* 139 */     MediaType mediaType = new MediaType(splitMt[0], splitMt[1]);
/* 140 */     if (parameters == null) {
/* 141 */       return mediaType;
/*     */     }
/*     */     
/* 144 */     HashMap<String, String> mediaTypeParameters = new HashMap(parameters.length);
/*     */     
/* 146 */     for (int i = 0; i < parameters.length; i++) {
/* 147 */       String[] splitParameter = parameters[i].split("=");
/* 148 */       if (splitParameter[0].equals("q")) {
/* 149 */         if (i != 0)
/*     */           break;
/* 151 */         mediaTypeParameters = null; break;
/*     */       }
/*     */       
/*     */ 
/* 155 */       mediaTypeParameters.put(splitParameter[0], splitParameter[1]);
/*     */     }
/*     */     
/* 158 */     mediaType.setParameters(mediaTypeParameters);
/* 159 */     return mediaType;
/*     */   }
/*     */   
/*     */   private static MediaRange createMediaRange(MediaType mediaType, String[] parameters) {
/* 163 */     if (parameters == null) {
/* 164 */       return new MediaRange(mediaType);
/*     */     }
/*     */     
/* 167 */     HashMap<String, String> acceptParameters = new HashMap(parameters.length);
/*     */     
/* 169 */     for (int i = 0; i < parameters.length; i++) {
/* 170 */       String[] splitParameter = parameters[i].split("=");
/* 171 */       acceptParameters.put(splitParameter[0], splitParameter[1]);
/*     */     }
/*     */     
/* 174 */     return new MediaRange(mediaType, acceptParameters);
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 179 */     return "Accept";
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\Accept.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */