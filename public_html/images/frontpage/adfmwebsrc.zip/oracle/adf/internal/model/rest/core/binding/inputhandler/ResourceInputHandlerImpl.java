/*     */ package oracle.adf.internal.model.rest.core.binding.inputhandler;
/*     */ 
/*     */ import oracle.adf.model.rest.core.describer.json.JSONStreamDescriber;
/*     */ import oracle.adf.model.rest.core.describer.json.JSONValueDescriber;
/*     */ import oracle.adf.model.rest.core.serializer.json.JSONValueSerializer;
/*     */ import oracle.adf.model.rest.core.serializer.stream.BaseResourceStreamSerializer;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.common.JboTypeMap;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceInputHandlerImpl
/*     */   implements ResourceInputHandler
/*     */ {
/*  47 */   private static final JSONStreamDescriber jsonStreamDescriber = new JSONStreamDescriber();
/*  48 */   private static final JSONValueDescriber jsonValueDescriber = new JSONValueDescriber();
/*  49 */   private static final JSONValueSerializer jsonValueSerializer = new JSONValueSerializer();
/*  50 */   private static final BaseResourceStreamSerializer baseStreamSeializer = new BaseResourceStreamSerializer();
/*     */   
/*     */   public final JSONValueDescriber getJSONDescriber(AttributeDef attrDef)
/*     */   {
/*  54 */     return getJSONValueDescriber(attrDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JSONValueDescriber getJSONValueDescriber(AttributeDef attrDef)
/*     */   {
/*  64 */     int sqlType = JboTypeMap.javaTypeToSQLTypeId(attrDef.getJavaType().getName());
/*     */     
/*  66 */     if (isLobType(sqlType)) {
/*  67 */       return jsonStreamDescriber;
/*     */     }
/*  69 */     return jsonValueDescriber;
/*     */   }
/*     */   
/*     */   public final BaseResourceStreamSerializer getStreamSerializer(AttributeDef attrDef)
/*     */   {
/*  74 */     return getResourceStreamSerializer(attrDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseResourceStreamSerializer getResourceStreamSerializer(AttributeDef attrDef)
/*     */   {
/*  84 */     int sqlType = JboTypeMap.javaTypeToSQLTypeId(attrDef.getJavaType().getName());
/*     */     
/*  86 */     if (isLobType(sqlType)) {
/*  87 */       return baseStreamSeializer;
/*     */     }
/*  89 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isLobType(int sqlType) {
/*  93 */     return (sqlType == 2004) || (sqlType == 2005) || (sqlType == 2007);
/*     */   }
/*     */   
/*     */   public final JSONValueSerializer getJSONSerializer(AttributeDef attrDef)
/*     */   {
/*  98 */     return getJSONValueSerializer(attrDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JSONValueSerializer getJSONValueSerializer(AttributeDef attrDef)
/*     */   {
/* 108 */     int sqlType = attrDef.getSQLType();
/* 109 */     int typeGroup = JboTypeMap.getTypeGroup(sqlType);
/* 110 */     if (isLobType(sqlType)) {
/* 111 */       return null;
/*     */     }
/*     */     
/* 114 */     if ((typeGroup == JboTypeMap.NUMBER) || (typeGroup == JboTypeMap.DATE) || (typeGroup == JboTypeMap.CHAR)) {
/* 115 */       return jsonValueSerializer;
/*     */     }
/*     */     
/* 118 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getInputValue(JUCtrlValueBinding binding, int index)
/*     */   {
/* 127 */     return binding.getInputValue(binding, index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputValue(JUCtrlValueBinding binding, int index, Object value)
/*     */   {
/* 136 */     binding.setInputValue(binding, index, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNewInputValue(JUCtrlValueBinding binding, int index, Object value)
/*     */   {
/* 145 */     return binding.isNewInputValue(binding, index, value);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\binding\inputhandler\ResourceInputHandlerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */