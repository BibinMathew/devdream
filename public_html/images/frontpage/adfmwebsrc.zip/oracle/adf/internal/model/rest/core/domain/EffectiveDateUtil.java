/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.EffectiveDateParam;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameter.Type;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap;
/*     */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*     */ import oracle.adf.internal.model.rest.core.topology.BasicResourceTreePath;
/*     */ import oracle.adf.internal.model.rest.core.topology.BasicTreePath;
/*     */ import oracle.adf.internal.model.rest.core.topology.ResourceTreePath;
/*     */ import oracle.adf.internal.model.rest.core.topology.TreePath;
/*     */ import oracle.jbo.Key;
/*     */ import oracle.jbo.Row;
/*     */ import oracle.jbo.VariableValueManager;
/*     */ import oracle.jbo.server.ApplicationModuleImpl;
/*     */ import oracle.jbo.server.EffectiveDateHelper;
/*     */ import oracle.jbo.server.EffectiveDateRangeOperation;
/*     */ import oracle.jbo.server.ViewDefImpl;
/*     */ import oracle.jbo.server.ViewObjectImpl;
/*     */ import oracle.jbo.server.ViewRowImpl;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierBinding;
/*     */ import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EffectiveDateUtil
/*     */ {
/*     */   public static enum EffectiveDateOperation
/*     */   {
/*  33 */     CREATE,  UPDATE,  DELETE;
/*     */     
/*     */ 
/*     */ 
/*     */     private EffectiveDateOperation() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void prepareEffectiveDate(ResourceTree tree, ResourceParameterMap parameterMap, Map<String, String> effDateRangeProperties)
/*     */   {
/*  44 */     EffectiveDateParam effDateParam = (EffectiveDateParam)ResourceParameter.Type.EFFECTIVE_DATE.castTo(parameterMap.get(ResourceParameter.Type.EFFECTIVE_DATE));
/*  45 */     Object effectiveDate = null;
/*     */     
/*  47 */     if (effDateParam != null) {
/*  48 */       effectiveDate = effDateParam.getDate();
/*     */     }
/*     */     
/*  51 */     if ((effectiveDate == null) && (!effDateRangeProperties.isEmpty())) {
/*  52 */       String dateStr = (String)effDateRangeProperties.get("RangeStartDate");
/*  53 */       if (dateStr != null) {
/*  54 */         effectiveDate = EffectiveDateRangeOperation.getDate(dateStr);
/*     */       }
/*     */     }
/*     */     
/*  58 */     if (effectiveDate != null) {
/*  59 */       ApplicationModuleImpl am = (ApplicationModuleImpl)tree.getTree().getApplicationModule();
/*  60 */       if (am != null) {
/*  61 */         am.getRootApplicationModule().setProperty("SysEffectiveDate", effectiveDate);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TreePath rebuildTreePath(ResourceTree resourceTree, TreePath treePath, Map<String, String> effDateRangeProperties)
/*     */   {
/*  73 */     if (treePath == null) {
/*  74 */       return null;
/*     */     }
/*  76 */     List<Key> keyList = ((ResourceTreePath)treePath.getResourcePaths().get(0)).getResourceKeyPath();
/*     */     
/*  78 */     if (keyList.size() == 0) {
/*  79 */       return treePath;
/*     */     }
/*     */     
/*  82 */     List<Key> parentKeyPath = keyList.subList(0, keyList.size() - 1);
/*  83 */     JUCtrlHierNodeBinding parentNode = resourceTree.getTree().findNodeByKeyPath(parentKeyPath);
/*     */     
/*  85 */     if (!Resource.isCollection(parentNode))
/*     */     {
/*  87 */       return treePath;
/*     */     }
/*     */     
/*  90 */     if ((treePath == null) || (!isResourceMissing(treePath))) {
/*  91 */       return treePath;
/*     */     }
/*     */     
/*     */ 
/*  95 */     BasicTreePath newTreePath = null;
/*     */     
/*  97 */     for (ResourceTreePath resourcePath : treePath.getResourcePaths()) {
/*  98 */       Resource resource = resourcePath.getResource();
/*  99 */       if (isResourceMissing(resourcePath, false))
/*     */       {
/* 101 */         resource = findDateEffectiveResource(resourceTree, resourcePath, effDateRangeProperties);
/* 102 */         if (resource == null) {
/* 103 */           throw new ResourceNotFoundException("Resource with key path not found: " + resourcePath.getResourceKeyPath());
/*     */         }
/*     */         
/* 106 */         if (newTreePath == null) {
/* 107 */           newTreePath = new BasicTreePath(resourceTree, resource);
/* 108 */           resourceTree.setCurrentResource(resource);
/*     */         }
/* 110 */         BasicResourceTreePath newResourcePath = new BasicResourceTreePath(resource);
/* 111 */         newTreePath.addResourcePath(newResourcePath);
/* 112 */         addChildResourcePath(resourceTree, resourcePath, newResourcePath, effDateRangeProperties);
/*     */       }
/*     */     }
/*     */     
/* 116 */     return newTreePath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void addChildResourcePath(ResourceTree resourceTree, ResourceTreePath oldResourcePath, BasicResourceTreePath newResourcePath, Map<String, String> effDateRangeProperties)
/*     */   {
/* 123 */     for (String childName : oldResourcePath.getChildrenNames()) {
/* 124 */       Collection<? extends ResourceTreePath> childResourcePaths = oldResourcePath.getChildren(childName);
/* 125 */       for (ResourceTreePath childResourcePath : childResourcePaths) {
/* 126 */         Resource childResource = childResourcePath.getResource();
/* 127 */         if (childResource == null) {
/* 128 */           childResource = findDateEffectiveResource(resourceTree, oldResourcePath, effDateRangeProperties);
/*     */         }
/* 130 */         if (childResource == null) {
/* 131 */           throw new ResourceNotFoundException("Resource with key path not found: " + childResourcePath.getResourceKeyPath());
/*     */         }
/*     */         
/* 134 */         BasicResourceTreePath newChildResourcePath = new BasicResourceTreePath(childResource);
/*     */         
/* 136 */         newResourcePath.addChildResourcePath(newResourcePath.getResource().getName(), newChildResourcePath);
/*     */         
/* 138 */         addChildResourcePath(resourceTree, childResourcePath, newChildResourcePath, effDateRangeProperties);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static Resource findDateEffectiveResource(ResourceTree resourceTree, ResourceTreePath resourcePath, Map<String, String> effDateRangeProperties)
/*     */   {
/* 146 */     List<Key> keyList = resourcePath.getResourceKeyPath();
/* 147 */     List<Key> parentKeyPath = keyList.subList(0, keyList.size() - 1);
/* 148 */     JUCtrlHierNodeBinding parentNode = resourceTree.getTree().findNodeByKeyPath(parentKeyPath);
/* 149 */     ViewObjectImpl vo = (ViewObjectImpl)parentNode.getViewObject();
/*     */     
/* 151 */     Resource resource = null;
/* 152 */     if ((Resource.isCollection(parentNode)) && (vo.isEffectiveDated()))
/*     */     {
/* 154 */       Key key = (Key)keyList.get(keyList.size() - 1);
/* 155 */       Key surKey = EffectiveDateHelper.getSurrogateKeyForDateEffectiveRow((ViewDefImpl)vo.getDef(), key);
/* 156 */       ViewRowImpl row = (ViewRowImpl)vo.findDateEffectiveRowByKey(surKey)[0];
/*     */       
/* 158 */       if (row == null) {
/* 159 */         throw new ResourceNotFoundException("Could not find date effective row with key: " + surKey);
/*     */       }
/* 161 */       Key newKey = row.getKey();
/* 162 */       parentNode.myUpdateValuesFromRows(null, true);
/*     */       
/* 164 */       JUCtrlHierNodeBinding parentBinding = parentNode.getParent();
/* 165 */       if (parentBinding != null) {
/* 166 */         ViewObjectImpl parentVO = (ViewObjectImpl)parentBinding.getViewObject();
/* 167 */         if ((parentVO != null) && (parentVO.isEffectiveDated())) {
/* 168 */           parentVO.ensureVariableManager().setVariableValue("SysEffectiveDateBindVar", row.getEffectiveDate());
/*     */         }
/*     */       }
/*     */       
/* 172 */       JUCtrlHierNodeBinding newNode = ResourceCollection.findChildNode(parentNode, newKey);
/* 173 */       resource = new ResourceItem(resourceTree, newNode);
/*     */     }
/*     */     
/* 176 */     return resource;
/*     */   }
/*     */   
/*     */   private static boolean isResourceMissing(TreePath treePath) {
/* 180 */     for (ResourceTreePath resourcePath : treePath.getResourcePaths()) {
/* 181 */       if (isResourceMissing(resourcePath, true)) {
/* 182 */         return true;
/*     */       }
/*     */     }
/* 185 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean isResourceMissing(ResourceTreePath resourcePath, boolean bRecurse) {
/* 189 */     ResourceItem resource = resourcePath.getResource();
/*     */     
/* 191 */     if (resource == null) {
/* 192 */       return true;
/*     */     }
/*     */     
/* 195 */     Key rowKey = resource.getNode().getRow().getKey();
/* 196 */     if (!rowKey.equals(resource.getKey())) {
/* 197 */       return true;
/*     */     }
/*     */     
/* 200 */     if (bRecurse) {
/* 201 */       for (String childName : resourcePath.getChildrenNames()) {
/* 202 */         for (ResourceTreePath childResourcePath : resourcePath.getChildren(childName)) {
/* 203 */           if (isResourceMissing(childResourcePath, true)) {
/* 204 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 210 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void doEffectiveDateRangeOperation(Map<String, String> effDateRangeProperties, TreePath treePath, EffectiveDateOperation operation)
/*     */   {
/* 222 */     List<ResourceItem> rowsToPost = new ArrayList(treePath.getResourcePaths().size());
/* 223 */     findResources(treePath, rowsToPost);
/*     */     
/* 225 */     switch (operation)
/*     */     {
/*     */     case CREATE: 
/* 228 */       for (ResourceItem resource : rowsToPost) {
/* 229 */         ViewRowImpl row = (ViewRowImpl)resource.getNode().getRow();
/* 230 */         performRangeCreate(row, effDateRangeProperties);
/*     */       }
/* 232 */       break;
/*     */     
/*     */ 
/*     */     case UPDATE: 
/* 236 */       List<ViewRowImpl> rows = new ArrayList(rowsToPost.size());
/*     */       
/* 238 */       for (int i = rowsToPost.size() - 1; i >= 0; i--) {
/* 239 */         ViewRowImpl row = (ViewRowImpl)((ResourceItem)rowsToPost.get(i)).getNode().getRow();
/* 240 */         rows.add(row);
/*     */       }
/* 242 */       for (ViewRowImpl row : rows) {
/* 243 */         performRangeUpdate(row, effDateRangeProperties);
/*     */       }
/* 245 */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   private static void findResources(TreePath treePath, List<ResourceItem> rowsToPost)
/*     */   {
/* 251 */     for (ResourceTreePath resourcePath : treePath.getResourcePaths()) {
/* 252 */       Resource resource = resourcePath.getResource();
/* 253 */       if (resource.isItem()) {
/* 254 */         rowsToPost.add(ResourceItem.asItem(resource));
/*     */       }
/* 256 */       findChildren(resourcePath, rowsToPost);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void findChildren(ResourceTreePath resourcePath, List<ResourceItem> rowsToPost) {
/* 261 */     for (String childName : resourcePath.getChildrenNames()) {
/* 262 */       Collection<? extends ResourceTreePath> childResourcePaths = resourcePath.getChildren(childName);
/* 263 */       for (ResourceTreePath childResourcePath : childResourcePaths) {
/* 264 */         Resource childResource = childResourcePath.getResource();
/* 265 */         if (childResource.isItem())
/*     */         {
/* 267 */           rowsToPost.add(ResourceItem.asItem(childResource));
/*     */         }
/*     */         
/* 270 */         findChildren(childResourcePath, rowsToPost);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void performRangeCreate(ViewRowImpl row, Map<String, String> effDateRangeProperties)
/*     */   {
/* 277 */     EffectiveDateRangeOperation.create(row, effDateRangeProperties);
/*     */   }
/*     */   
/*     */ 
/*     */   private static void performRangeUpdate(ViewRowImpl row, Map<String, String> effDateRangeProperties)
/*     */   {
/* 283 */     EffectiveDateRangeOperation.modifyRange(row, effDateRangeProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void doEffectiveDateRangeDelete(ResourceItem resource, Map<String, String> effDateRangeProperties)
/*     */   {
/* 291 */     ViewRowImpl row = (ViewRowImpl)resource.getNode().getRow();
/* 292 */     ResourceTree tree = resource.getTree();
/* 293 */     Resource nextCurrentResource = resource.getParent();
/* 294 */     EffectiveDateRangeOperation.modifyRange(row, effDateRangeProperties);
/* 295 */     tree.setCurrentResource(nextCurrentResource);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\EffectiveDateUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */