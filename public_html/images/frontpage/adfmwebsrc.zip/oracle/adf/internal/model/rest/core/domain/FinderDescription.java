/*    */ package oracle.adf.internal.model.rest.core.domain;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import oracle.jbo.LocaleContext;
/*    */ import oracle.jbo.server.RowFinder;
/*    */ import oracle.jbo.server.RowFinderAnnotation;
/*    */ import oracle.jbo.server.RowFinderAnnotation.RowFinderAttributeAnnot;
/*    */ 
/*    */ public class FinderDescription
/*    */ {
/*    */   public static final String NAME_PLURAL = "finders";
/*    */   public static final String NAME_ATTR = "name";
/*    */   public static final String ATTRIBUTES_ATTR = "attributes";
/*    */   public static final String TITLE_ATTR = "title";
/*    */   public static final String ANNOT_ATTR = "annotations";
/*    */   public static final String DESC_ATTR = "description";
/*    */   private final RowFinderAnnotation annotations;
/*    */   private final Finder finder;
/*    */   private final LocaleContext localeContext;
/*    */   
/*    */   public FinderDescription(Finder finder, RowFinderAnnotation annotations, LocaleContext localeContext)
/*    */   {
/* 23 */     this.finder = finder;
/* 24 */     this.annotations = annotations;
/* 25 */     this.localeContext = localeContext;
/*    */   }
/*    */   
/*    */   public FinderDescription(Finder finder) {
/* 29 */     this.finder = finder;
/* 30 */     this.annotations = null;
/* 31 */     this.localeContext = null;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 35 */     return this.finder.getName();
/*    */   }
/*    */   
/*    */   public Collection<Attribute> getAttributes() {
/* 39 */     return this.finder.getAttributes();
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 43 */     return (String)this.finder.getRowFinder().getProperty("LABEL");
/*    */   }
/*    */   
/*    */   public String getDescriptionText() {
/* 47 */     if (this.annotations != null) {
/* 48 */       return this.annotations.getDescription(this.localeContext);
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */   
/*    */   public String getDescriptionTextForAttr(String attrName) {
/*    */     RowFinderAnnotation.RowFinderAttributeAnnot attrAnnot;
/* 55 */     if ((this.annotations != null) && ((attrAnnot = this.annotations.getAttribute(attrName)) != null)) {
/* 56 */       return attrAnnot.getDescription(this.localeContext);
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\FinderDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */