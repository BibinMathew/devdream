/*     */ package oracle.adf.internal.model.rest.core.helper;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import oracle.adf.internal.model.rest.core.domain.Link;
/*     */ import oracle.adf.internal.model.rest.core.domain.Link.Kind;
/*     */ import oracle.adf.internal.model.rest.core.domain.Path;
/*     */ import oracle.adf.internal.model.rest.core.domain.Version;
/*     */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*     */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*     */ import oracle.adf.model.config.AdfmConfig;
/*     */ import oracle.jbo.version.VersionConfig;
/*     */ import oracle.jbo.version.VersionDef;
/*     */ import oracle.jbo.version.VersionDef.Lifecycle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VersionHelper
/*     */ {
/*     */   public static void generateVersionRepresentation(ResourceProcessingContext context, PayloadGenerator generator)
/*     */     throws IOException
/*     */   {
/*  57 */     generator.setup();
/*     */     
/*  59 */     VersionDef version = context.getVersionDef();
/*  60 */     String basePath = context.getOriginalBasePath();
/*  61 */     if (version == null)
/*     */     {
/*  63 */       generator.startVersions();
/*     */       
/*  65 */       VersionConfig config = AdfmConfig.getVersionConfig();
/*  66 */       if (config.isVersioningEnabled())
/*     */       {
/*  68 */         version = config.getLatestVersion();
/*  69 */         VersionDef current = version;
/*  70 */         VersionDef next = null;
/*     */         do {
/*  72 */           VersionDef previous = current.getPreviousVersion();
/*     */           
/*  74 */           generateVersionRepresentation(generator, basePath, current, next, previous);
/*     */           
/*  76 */           next = current;
/*  77 */           current = previous;
/*  78 */         } while (current != null);
/*     */       }
/*     */       
/*  81 */       List<Link> currentLinks = createCurrentLinks(basePath, version);
/*  82 */       generator.endVersions(currentLinks);
/*     */     }
/*     */     else {
/*  85 */       generateVersionRepresentation(generator, basePath, version);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void generateVersionRepresentation(PayloadGenerator generator, String basePath, VersionDef version) throws IOException
/*     */   {
/*  91 */     generateVersionRepresentation(generator, basePath, version, version.getNextVersion(), version.getPreviousVersion());
/*     */   }
/*     */   
/*     */   private static void generateVersionRepresentation(PayloadGenerator generator, String basePath, VersionDef current, VersionDef next, VersionDef previous)
/*     */     throws IOException
/*     */   {
/*  97 */     VersionDef.Lifecycle lifecycle = current.getLifecycle();
/*  98 */     Version version = new Version(current.getDisplayName(), lifecycle == VersionDef.Lifecycle.active ? null : lifecycle.toString(), next == null);
/*     */     
/*     */ 
/* 101 */     generator.startVersion(version);
/* 102 */     createVersionLinks(generator, basePath, current, next, previous);
/* 103 */     generator.endVersion();
/*     */   }
/*     */   
/*     */   private static void createVersionLinks(PayloadGenerator generator, String basePath, VersionDef current, VersionDef next, VersionDef previous)
/*     */     throws IOException
/*     */   {
/* 109 */     List<Link> versionLinks = new ArrayList();
/* 110 */     Path currentPath = new Path(basePath, current.getDisplayName());
/* 111 */     versionLinks.add(new Link("self", "self", currentPath, Link.Kind.ITEM));
/*     */     
/* 113 */     versionLinks.add(new Link("canonical", "canonical", currentPath, Link.Kind.ITEM));
/*     */     
/* 115 */     if (previous != null) {
/* 116 */       versionLinks.add(new Link("predecessor-version", "predecessor-version", new Path(basePath, previous.getDisplayName()), Link.Kind.ITEM));
/*     */     }
/*     */     
/*     */ 
/* 120 */     if (next != null) {
/* 121 */       versionLinks.add(new Link("successor-version", "successor-version", new Path(basePath, next.getDisplayName()), Link.Kind.ITEM));
/*     */     }
/*     */     
/*     */ 
/* 125 */     versionLinks.add(new Link("describe", "describe", new Path(currentPath, "describe"), Link.Kind.DESCRIBE));
/*     */     
/*     */ 
/* 128 */     generator.createLinks(versionLinks);
/*     */   }
/*     */   
/*     */   private static List<Link> createCurrentLinks(String basePath, VersionDef current) throws IOException {
/* 132 */     List<Link> currentLinks = new ArrayList(3);
/* 133 */     currentLinks.add(new Link("self", "self", new Path(basePath), Link.Kind.COLLECTION));
/*     */     
/* 135 */     currentLinks.add(new Link("canonical", "canonical", new Path(basePath), Link.Kind.COLLECTION));
/*     */     
/* 137 */     if (current != null) {
/* 138 */       currentLinks.add(new Link("current", "current", new Path(basePath, current.getDisplayName()), Link.Kind.ITEM));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 143 */     return currentLinks;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\helper\VersionHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */