/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ public class Coding implements Comparable<Coding> {
/*    */   private final ContentCoding contentCoding;
/*    */   private final QualityFactor qualityFactor;
/*    */   
/*    */   public Coding(ContentCoding contentCoding) {
/*  8 */     this(contentCoding, new QualityFactor());
/*    */   }
/*    */   
/*    */   public Coding(ContentCoding contentCoding, QualityFactor qualityFactor) {
/* 12 */     this.contentCoding = contentCoding;
/* 13 */     this.qualityFactor = qualityFactor;
/*    */   }
/*    */   
/*    */   public ContentCoding getContentCoding() {
/* 17 */     return this.contentCoding;
/*    */   }
/*    */   
/*    */   public QualityFactor getQualityFactor() {
/* 21 */     return this.qualityFactor;
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 26 */     if (this == object) {
/* 27 */       return true;
/*    */     }
/* 29 */     if (!(object instanceof Coding)) {
/* 30 */       return false;
/*    */     }
/* 32 */     Coding other = (Coding)object;
/* 33 */     if (this.contentCoding == null ? other.contentCoding != null : !this.contentCoding.equals(other.contentCoding)) {
/* 34 */       return false;
/*    */     }
/* 36 */     if (this.qualityFactor == null ? other.qualityFactor != null : !this.qualityFactor.equals(other.qualityFactor)) {
/* 37 */       return false;
/*    */     }
/* 39 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 44 */     int PRIME = 37;
/* 45 */     int result = 1;
/* 46 */     result = 37 * result + (this.contentCoding == null ? 0 : this.contentCoding.hashCode());
/* 47 */     result = 37 * result + (this.qualityFactor == null ? 0 : this.qualityFactor.hashCode());
/* 48 */     return result;
/*    */   }
/*    */   
/*    */   public int compareTo(Coding coding)
/*    */   {
/* 53 */     int compareTo = this.qualityFactor.compareTo(coding.getQualityFactor());
/* 54 */     if ((compareTo == 0) && 
/* 55 */       (!this.contentCoding.equals(coding.getContentCoding()))) {
/* 56 */       return this.contentCoding.getValue().compareTo(coding.getContentCoding().getValue());
/*    */     }
/*    */     
/* 59 */     return compareTo;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\Coding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */