/*     */ package oracle.adf.internal.model.rest.core.common;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import oracle.adf.internal.model.rest.core.common.parameter.ResourceParameterMap;
/*     */ import oracle.adf.internal.model.rest.core.payload.ParserFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceContext
/*     */ {
/*     */   private static final Pattern VERB_REGEX;
/*     */   private static final String URL_SEPARATOR = "/";
/*     */   private static final String LATEST_VERSION = "latest";
/*     */   private final Verb verb;
/*     */   private final String basePath;
/*     */   private final String pathInfo;
/*     */   private final List<String> originalPath;
/*     */   private List<String> resourcePath;
/*     */   private ParserFactory parserFactory;
/*     */   private ResourceParameterMap parameterMap;
/*     */   private Locale locale;
/*     */   private List<String> verbPath;
/*     */   private InputStream in;
/*     */   private Map<String, String> properties;
/*     */   private EntityContentMapping entityContentMap;
/*     */   private Condition precondition;
/*     */   private boolean batchMode;
/*     */   private String version;
/*  37 */   private Map<String, String> effDateRangeProperties = Collections.emptyMap();
/*     */   
/*     */   static {
/*  40 */     String patternPrefix = "/(";
/*  41 */     String patternSufix = ")";
/*  42 */     StringBuilder patternVerbs = new StringBuilder();
/*     */     
/*  44 */     Verb[] verbs = Verb.values();
/*  45 */     for (int i = 0; i < verbs.length; i++) {
/*  46 */       patternVerbs.append(verbs[i].toString());
/*  47 */       if (verbs.length != i + 1) {
/*  48 */         patternVerbs.append("|");
/*     */       }
/*     */     }
/*     */     
/*  52 */     VERB_REGEX = Pattern.compile(patternPrefix + patternVerbs + patternSufix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceContext(String basePath, String pathInfo)
/*     */   {
/*  60 */     this(basePath, pathInfo, null, null, null, "latest");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceContext(String basePath, String pathInfo, Map<String, String[]> parameterMap)
/*     */   {
/*  68 */     this(basePath, pathInfo, parameterMap, null, null, "latest");
/*     */   }
/*     */   
/*     */   public ResourceContext(String basePath, String pathInfo, Map<String, String[]> parameterMap, Locale locale, InputStream in)
/*     */   {
/*  73 */     this(basePath, pathInfo, parameterMap, locale, in, null);
/*     */   }
/*     */   
/*     */   public ResourceContext(String basePath, String pathInfo, Map<String, String[]> parameterMap, Locale locale, InputStream in, String version)
/*     */   {
/*  78 */     if (version == null)
/*     */     {
/*  80 */       pathInfo = parseVersion(pathInfo);
/*     */     } else {
/*  82 */       this.version = version;
/*     */     }
/*     */     
/*  85 */     this.pathInfo = pathInfo;
/*  86 */     this.basePath = basePath;
/*  87 */     List pathInfoList = createPathList(this.pathInfo);
/*  88 */     this.verb = configureVerb(this.pathInfo);
/*     */     
/*  90 */     if (this.resourcePath == null) {
/*  91 */       this.resourcePath = Collections.unmodifiableList(pathInfoList);
/*     */     }
/*  93 */     this.originalPath = Collections.unmodifiableList(pathInfoList);
/*     */     
/*  95 */     this.parameterMap = createResourceParameterMap(parameterMap);
/*     */     
/*  97 */     this.locale = locale;
/*  98 */     this.in = in;
/*     */   }
/*     */   
/*     */   private List<String> createPathList(String pathInfo) {
/* 102 */     ArrayList<String> pathList = new ArrayList();
/* 103 */     if ((pathInfo == null) || (pathInfo.isEmpty()) || ("/".equals(pathInfo))) {
/* 104 */       return pathList;
/*     */     }
/*     */     
/* 107 */     String[] slashSep = pathInfo.split("/");
/* 108 */     pathList.addAll(Arrays.asList(slashSep));
/*     */     
/* 110 */     if (pathList.size() < 2) {
/* 111 */       throw new IllegalArgumentException("pathInfo does not contain enought information. pathInfo: " + pathInfo);
/*     */     }
/*     */     
/* 114 */     return pathList;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getBasePath()
/*     */   {
/* 120 */     return this.basePath;
/*     */   }
/*     */   
/*     */   public String getPathInfo() {
/* 124 */     return this.pathInfo;
/*     */   }
/*     */   
/*     */   public void setParserFactory(ParserFactory parserFactory) {
/* 128 */     this.parserFactory = parserFactory;
/*     */   }
/*     */   
/*     */   public ParserFactory getParserFactory() {
/* 132 */     return this.parserFactory;
/*     */   }
/*     */   
/*     */   private ResourceParameterMap createResourceParameterMap(Map<String, String[]> parameterMap) {
/* 136 */     return new ResourceParameterMap(parameterMap);
/*     */   }
/*     */   
/*     */   public void setResourceParameterMap(Map<String, String[]> parameterMap) {
/* 140 */     this.parameterMap = createResourceParameterMap(parameterMap);
/*     */   }
/*     */   
/*     */   public void setResourceParameterMap(ResourceParameterMap parameterMap) {
/* 144 */     this.parameterMap = parameterMap;
/*     */   }
/*     */   
/*     */   public ResourceParameterMap getResourceParameterMap() {
/* 148 */     return this.parameterMap;
/*     */   }
/*     */   
/*     */   private Verb configureVerb(String pathInfo) {
/* 152 */     if (pathInfo == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     Verb verbType = null;
/*     */     
/* 157 */     Matcher verbMatcher = VERB_REGEX.matcher(pathInfo);
/* 158 */     if (verbMatcher.find()) {
/* 159 */       String verbString = verbMatcher.group().substring("/".length());
/* 160 */       verbType = Verb.valueOf(verbString.toUpperCase());
/* 161 */       String verbPathString = pathInfo.substring(verbMatcher.end());
/* 162 */       this.verbPath = Arrays.asList(verbPathString.split("/"));
/* 163 */       String resourcePathString = pathInfo.substring(0, verbMatcher.start() + 1);
/* 164 */       this.resourcePath = Collections.unmodifiableList(Arrays.asList(resourcePathString.split("/")));
/*     */     }
/*     */     
/*     */ 
/* 168 */     return verbType;
/*     */   }
/*     */   
/*     */   public boolean isVerbExecution() {
/* 172 */     return this.verb != null;
/*     */   }
/*     */   
/*     */   public List<String> getResourcePath() {
/* 176 */     return this.resourcePath;
/*     */   }
/*     */   
/*     */   public Verb getVerb() {
/* 180 */     return this.verb;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 184 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 188 */     return this.locale;
/*     */   }
/*     */   
/*     */   public List<String> getVerbPath() {
/* 192 */     return this.verbPath;
/*     */   }
/*     */   
/*     */   public void setInputStream(InputStream in) {
/* 196 */     this.in = in;
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() {
/* 200 */     return this.in;
/*     */   }
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 204 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Map<String, String> properties) {
/* 208 */     if (properties == null) {
/* 209 */       this.properties = Collections.emptyMap();
/*     */     } else {
/* 211 */       this.properties = Collections.unmodifiableMap(properties);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setEntityContentMap(EntityContentMapping entityContentMap) {
/* 216 */     this.entityContentMap = entityContentMap;
/*     */   }
/*     */   
/*     */   public EntityContentMapping getEntityContentMap() {
/* 220 */     return this.entityContentMap;
/*     */   }
/*     */   
/*     */   public void setPrecondition(Condition precondition) {
/* 224 */     this.precondition = precondition;
/*     */   }
/*     */   
/*     */   public Condition getPrecondition() {
/* 228 */     return this.precondition;
/*     */   }
/*     */   
/*     */   List<String> getOriginalPath() {
/* 232 */     return this.originalPath;
/*     */   }
/*     */   
/*     */   public void setBatchMode(boolean batchMode) {
/* 236 */     this.batchMode = batchMode;
/*     */   }
/*     */   
/*     */   public boolean isBatchMode() {
/* 240 */     return this.batchMode;
/*     */   }
/*     */   
/*     */   private String parseVersion(String pathInfo) {
/* 244 */     int index = -1;
/* 245 */     if (pathInfo != null) {
/* 246 */       int length = pathInfo.length();
/* 247 */       if (length > 1) {
/* 248 */         index = pathInfo.indexOf("/", 1);
/* 249 */         if (index == -1) {
/* 250 */           index = length;
/*     */         }
/*     */         
/* 253 */         this.version = pathInfo.substring(1, index);
/* 254 */         pathInfo = pathInfo.substring(index, length);
/*     */       }
/*     */     }
/* 257 */     return pathInfo;
/*     */   }
/*     */   
/*     */   public String getVersion() {
/* 261 */     return this.version;
/*     */   }
/*     */   
/*     */   public void setEffectiveDateRangeProperties(Map<String, String> effDateRangeProperties) {
/* 265 */     if (effDateRangeProperties == null) {
/* 266 */       this.effDateRangeProperties = Collections.emptyMap();
/*     */     } else {
/* 268 */       this.effDateRangeProperties = Collections.unmodifiableMap(effDateRangeProperties);
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<String, String> getEffectiveDateRangeProperties() {
/* 273 */     return this.effDateRangeProperties;
/*     */   }
/*     */   
/*     */   public String getMetadataProperties() {
/* 277 */     return this.properties != null ? (String)this.properties.get("Metadata-Context") : null;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\ResourceContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */