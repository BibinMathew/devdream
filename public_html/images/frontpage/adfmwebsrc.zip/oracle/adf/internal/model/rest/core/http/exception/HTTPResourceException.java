/*    */ package oracle.adf.internal.model.rest.core.http.exception;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.http.StatusCode;
/*    */ 
/*    */ public class HTTPResourceException extends Exception {
/*    */   private StatusCode httpErrorCode;
/*    */   private String entityTag;
/*    */   private String requestInfo;
/*    */   
/*    */   public String getRequestInfo() {
/* 11 */     return this.requestInfo;
/*    */   }
/*    */   
/*    */ 
/*    */   public HTTPResourceException(StatusCode statusCode, String requestInfo)
/*    */   {
/* 17 */     this.httpErrorCode = statusCode;
/* 18 */     this.requestInfo = requestInfo;
/*    */   }
/*    */   
/*    */   public HTTPResourceException(Throwable cause, StatusCode statusCode, String requestInfo) {
/* 22 */     super(cause);
/* 23 */     this.httpErrorCode = statusCode;
/* 24 */     this.requestInfo = requestInfo;
/*    */   }
/*    */   
/*    */   public HTTPResourceException(String message, Throwable cause, StatusCode statusCode, String requestInfo)
/*    */   {
/* 29 */     super(message, cause);
/* 30 */     this.httpErrorCode = statusCode;
/* 31 */     this.requestInfo = requestInfo;
/*    */   }
/*    */   
/*    */   public HTTPResourceException(String message, StatusCode statusCode, String requestInfo) {
/* 35 */     super(message);
/* 36 */     this.httpErrorCode = statusCode;
/* 37 */     this.requestInfo = requestInfo;
/*    */   }
/*    */   
/*    */   public void setEntityTag(String entityTag) {
/* 41 */     this.entityTag = entityTag;
/*    */   }
/*    */   
/*    */   public String getEntityTag() {
/* 45 */     return this.entityTag;
/*    */   }
/*    */   
/*    */   public int getHttpErrorCode() {
/* 49 */     return this.httpErrorCode.getCode();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\exception\HTTPResourceException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */