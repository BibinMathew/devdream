/*    */ package oracle.adf.internal.model.rest.core.topology;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TreePathUtil
/*    */ {
/*    */   public static String createAccessorPath(String parentAccessorPath, String child)
/*    */   {
/* 12 */     String accessorPathPrefix = parentAccessorPath + ".";
/* 13 */     return accessorPathPrefix + child;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\topology\TreePathUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */