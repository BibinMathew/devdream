package oracle.adf.internal.model.rest.core.lifecycle;

public enum ResourceLifecyclePhase
{
  INIT_CONTEXT,  PREPARE_MODEL,  APPLY_INPUT_VALUES,  VALIDATE_INPUT_VALUES,  CHECK_SECURITY,  PROCESS_UPDATE_MODEL,  VALIDATE_MODEL_UPDATES,  CHECK_METADATA_CONTEXT,  DATA_COMMIT,  METADATA_COMMIT,  PREPARE_RESPONSE,  GENERATE_RESPONSE;
  
  private ResourceLifecyclePhase() {}
  
  abstract void executePhase(ResourceLifecycle paramResourceLifecycle, ResourceLifecycleContext paramResourceLifecycleContext)
    throws Exception;
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\ResourceLifecyclePhase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */