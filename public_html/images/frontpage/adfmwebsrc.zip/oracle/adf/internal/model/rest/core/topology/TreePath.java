package oracle.adf.internal.model.rest.core.topology;

import java.util.List;
import oracle.adf.internal.model.rest.core.domain.Resource;

public abstract interface TreePath
{
  public static final String ACCESSOR_PATH_SEPARATOR_REGEX = "\\.";
  public static final String ACCESSOR_PATH_SEPARATOR = ".";
  
  public abstract List<? extends ResourceTreePath> getResourcePaths();
  
  public abstract boolean isExpandableResourcePath(ResourceTreePath paramResourceTreePath, String paramString);
  
  public abstract Resource getTopLevelResource();
  
  public abstract boolean isCollectionTreePath();
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\topology\TreePath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */