/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import oracle.adf.internal.model.rest.core.exception.InvalidHeaderValueException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EffectiveOf
/*    */   implements Header
/*    */ {
/*    */   public static final String NAME = "Effective-Of";
/* 19 */   private static final Set<String> VALID_HEADER_ATTRIBUTES = new HashSet(6);
/* 20 */   static { VALID_HEADER_ATTRIBUTES.add("RangeMode");
/* 21 */     VALID_HEADER_ATTRIBUTES.add("RangeSpan");
/* 22 */     VALID_HEADER_ATTRIBUTES.add("RangeStartDate");
/* 23 */     VALID_HEADER_ATTRIBUTES.add("RangeEndDate");
/* 24 */     VALID_HEADER_ATTRIBUTES.add("RangeStartSequence");
/* 25 */     VALID_HEADER_ATTRIBUTES.add("RangeEndSequence");
/*    */   }
/*    */   
/*    */   private final Map<String, String> rangeProperties;
/* 29 */   public EffectiveOf(String headerStr) { Map<String, String> map = new HashMap();
/* 30 */     String[] effectiveOfAttributes = headerStr.split(";");
/*    */     
/* 32 */     for (String keyValue : effectiveOfAttributes) {
/* 33 */       String[] kv = keyValue.split("=");
/* 34 */       map.put(kv[0].trim(), kv[1].trim());
/*    */     }
/*    */     
/* 37 */     if (!VALID_HEADER_ATTRIBUTES.containsAll(map.keySet())) {
/* 38 */       throw new InvalidHeaderValueException("Effective-Of", headerStr);
/*    */     }
/*    */     
/* 41 */     this.rangeProperties = Collections.unmodifiableMap(map);
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 46 */     return "Effective-Of";
/*    */   }
/*    */   
/*    */   public Map<String, String> getEffectiveDateRangeProperties() {
/* 50 */     return this.rangeProperties;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\EffectiveOf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */