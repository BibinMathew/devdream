/*    */ package oracle.adf.internal.model.rest.core.http.header;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class IfNoneMatch implements Header {
/*    */   public static final String NAME = "If-None-Match";
/*    */   public static final String ANY_ETAG = "*";
/*  8 */   private boolean anyETagMatcher = false;
/*    */   private List<EntityTag> entityTags;
/*    */   
/* 11 */   public IfNoneMatch(String value) { if (value.equals("*")) {
/* 12 */       this.anyETagMatcher = true;
/*    */     } else {
/* 14 */       this.entityTags = EntityTag.parseEntityTags(value);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isAnyETagMatcher() {
/* 19 */     return this.anyETagMatcher;
/*    */   }
/*    */   
/*    */   public List<EntityTag> getEntityTags() {
/* 23 */     return this.entityTags;
/*    */   }
/*    */   
/*    */   public boolean proccessNoneMatch(EntityTag currentEntityTag, boolean strongValidation) {
/* 27 */     if (currentEntityTag == null) {
/* 28 */       return true;
/*    */     }
/* 30 */     if (this.anyETagMatcher) {
/* 31 */       return false;
/*    */     }
/*    */     
/* 34 */     boolean match = false;
/* 35 */     for (EntityTag entityTag : this.entityTags) {
/* 36 */       if (strongValidation) {
/* 37 */         match = entityTag.strongValidateWith(currentEntityTag);
/*    */       } else {
/* 39 */         match = entityTag.weakValidateWith(currentEntityTag);
/*    */       }
/* 41 */       if (match) {
/*    */         break;
/*    */       }
/*    */     }
/* 45 */     return !match;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 50 */     return "If-None-Match";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\header\IfNoneMatch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */