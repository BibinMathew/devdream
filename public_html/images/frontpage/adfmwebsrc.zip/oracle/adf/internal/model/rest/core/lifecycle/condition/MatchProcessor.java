/*    */ package oracle.adf.internal.model.rest.core.lifecycle.condition;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.Condition;
/*    */ import oracle.adf.internal.model.rest.core.exception.PreconditionFailedException;
/*    */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MatchProcessor
/*    */   extends ConditionProcessor
/*    */ {
/*    */   MatchProcessor(Condition condition)
/*    */   {
/* 18 */     super(condition);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void process(String currentState)
/*    */   {
/* 25 */     if (this.codition.isAnyStateAllowed()) {
/* 26 */       return;
/*    */     }
/*    */     
/* 29 */     for (String conditionState : this.codition.getStates()) {
/* 30 */       if (conditionSucceeded(currentState, conditionState)) {
/* 31 */         return;
/*    */       }
/*    */     }
/* 34 */     throw new PreconditionFailedException("The resource state was modified");
/*    */   }
/*    */   
/*    */   protected boolean testCondition(boolean stateModified)
/*    */   {
/* 39 */     return !stateModified;
/*    */   }
/*    */   
/*    */   public void process(ResourceNotFoundException ex)
/*    */   {
/* 44 */     throw new PreconditionFailedException(ex);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\lifecycle\condition\MatchProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */