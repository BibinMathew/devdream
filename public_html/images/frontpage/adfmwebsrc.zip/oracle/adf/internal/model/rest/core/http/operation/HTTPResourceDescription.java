/*    */ package oracle.adf.internal.model.rest.core.http.operation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException;
/*    */ import oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException;
/*    */ import oracle.adf.internal.model.rest.core.helper.ResourceDescribeHelper;
/*    */ import oracle.adf.internal.model.rest.core.http.DescribeHelperConfig;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ import oracle.adf.internal.model.rest.core.operation.AbstractResourceOperation;
/*    */ import oracle.adf.internal.model.rest.core.payload.PayloadGenerator;
/*    */ 
/*    */ class HTTPResourceDescription
/*    */   extends AbstractResourceOperation
/*    */ {
/*    */   public HTTPResourceDescription()
/*    */   {
/* 21 */     this.dependentOnResource = false;
/*    */   }
/*    */   
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 26 */     if (!this.responseHandler.isEntityGenerationAllowed()) {
/* 27 */       throw new CannotGenerateContentException("The entity generation is not enabled in the ResponseHandler.");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 33 */     if ((!context.isResourceTreeAvailable()) && (context.getOriginalResourcePath().size() > 1)) {
/* 34 */       throw new ResourceNotFoundException("Describe was requested to an non-existent resource.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void applyInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public void execute(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public void generateResponse(ResourceProcessingContext context)
/*    */     throws IOException
/*    */   {
/* 48 */     PayloadGenerator generator = this.responseHandler.getPayloadGenerator();
/* 49 */     if (context.isResourceTreeAvailable()) {
/* 50 */       ResourceDescribeHelper describeHelper = new ResourceDescribeHelper(context, new DescribeHelperConfig());
/* 51 */       describeHelper.describeResource(generator);
/*    */     } else {
/* 53 */       ResourceDescribeHelper.describeAllResources(context, generator, new DescribeHelperConfig(), getSecurityName());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void validateInputValues(ResourceProcessingContext context) {}
/*    */   
/*    */ 
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 63 */     return false;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 68 */     return OperationType.DESCRIPTION;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 73 */     return ActionType.DESCRIBE;
/*    */   }
/*    */   
/*    */   public boolean isAuthorized(ResourceProcessingContext context)
/*    */   {
/* 78 */     if (context.isResourceTreeAvailable()) {
/* 79 */       return super.isAuthorized(context);
/*    */     }
/* 81 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\operation\HTTPResourceDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */