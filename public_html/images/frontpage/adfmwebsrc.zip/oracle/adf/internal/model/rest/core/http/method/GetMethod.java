/*    */ package oracle.adf.internal.model.rest.core.http.method;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.Verb;
/*    */ import oracle.adf.internal.model.rest.core.http.exception.OperationNotSupportedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class GetMethod
/*    */   implements HttpMethod
/*    */ {
/*    */   private final HttpOperationType operationType;
/*    */   
/*    */   GetMethod(HttpMethodInfo info)
/*    */   {
/* 18 */     Verb verb = info.getVerb();
/*    */     
/* 20 */     if (verb != null) {
/* 21 */       switch (verb)
/*    */       {
/*    */       case DESCRIBE: 
/* 24 */         this.operationType = HttpOperationType.RESOURCE;
/* 25 */         this.operationType.setOperation(OperationType.DESCRIPTION);
/* 26 */         break;
/*    */       
/*    */ 
/*    */       default: 
/* 30 */         throw new OperationNotSupportedException();
/*    */       }
/*    */     }
/*    */     else {
/* 34 */       this.operationType = HttpOperationType.RESOURCE;
/* 35 */       this.operationType.setOperation(OperationType.REPRESENTATION);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 41 */     return HttpMethod.Type.GET.toString();
/*    */   }
/*    */   
/*    */   public HttpOperationType getOperationType()
/*    */   {
/* 46 */     return this.operationType;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\http\method\GetMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */