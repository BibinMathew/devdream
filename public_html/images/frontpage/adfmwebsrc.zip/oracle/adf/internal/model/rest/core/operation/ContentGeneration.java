/*    */ package oracle.adf.internal.model.rest.core.operation;
/*    */ 
/*    */ import java.util.Map;
/*    */ import oracle.adf.internal.model.rest.core.common.OperationType;
/*    */ import oracle.adf.internal.model.rest.core.common.ResponseHandler;
/*    */ import oracle.adf.internal.model.rest.core.domain.ActionType;
/*    */ import oracle.adf.internal.model.rest.core.domain.Attribute;
/*    */ import oracle.adf.internal.model.rest.core.exception.CannotGenerateContentException;
/*    */ import oracle.adf.internal.model.rest.core.lifecycle.ResourceProcessingContext;
/*    */ import oracle.adf.model.rest.core.serializer.StreamSerializerInfo;
/*    */ 
/*    */ class ContentGeneration extends AbstractContentOperation
/*    */ {
/*    */   public void init(ResourceProcessingContext context)
/*    */   {
/* 16 */     super.init(context);
/* 17 */     if (this.attribute.getValue() == null) {
/* 18 */       throw new oracle.adf.internal.model.rest.core.exception.ResourceNotFoundException("The content is null.");
/*    */     }
/*    */   }
/*    */   
/*    */   public void prepareResponse(ResourceProcessingContext context)
/*    */   {
/* 24 */     this.responseHandler.setProperties(this.currentContentInfo.getClientProperties());
/*    */     
/* 26 */     if (!this.responseHandler.isContentGenerationAllowed()) {
/* 27 */       throw new CannotGenerateContentException("The generation of this content is not allowed. Content-Type: " + this.currentContentInfo.getContentType());
/*    */     }
/*    */     
/* 30 */     super.prepareResponse(context);
/*    */   }
/*    */   
/*    */   public void generateResponse(ResourceProcessingContext context) throws Exception
/*    */   {
/* 35 */     StreamSerializerInfo serializeInfo = new StreamSerializerInfo();
/* 36 */     Map<String, String> properties = context.getProperties();
/* 37 */     if (properties != null) {
/* 38 */       serializeInfo.putAll(properties);
/*    */     }
/* 40 */     this.attribute.serializeContent(serializeInfo, this.responseHandler.getOutputStream());
/*    */   }
/*    */   
/*    */   public boolean isCommitNeeded()
/*    */   {
/* 45 */     return false;
/*    */   }
/*    */   
/*    */   public OperationType getOperationType()
/*    */   {
/* 50 */     return OperationType.REPRESENTATION;
/*    */   }
/*    */   
/*    */   public ActionType getActionType()
/*    */   {
/* 55 */     return ActionType.GET_ITEM;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\operation\ContentGeneration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */