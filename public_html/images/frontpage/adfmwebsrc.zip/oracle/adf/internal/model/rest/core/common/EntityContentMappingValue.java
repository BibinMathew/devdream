/*    */ package oracle.adf.internal.model.rest.core.common;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public final class EntityContentMappingValue {
/*    */   private final String[] contentTypes;
/*    */   private final String[] supportedContentType;
/*    */   
/*    */   public EntityContentMappingValue(String[] contentTypes, String[] supportedContentType) {
/* 10 */     this.contentTypes = ((String[])Arrays.copyOf(contentTypes, contentTypes.length));
/* 11 */     this.supportedContentType = ((String[])Arrays.copyOf(supportedContentType, supportedContentType.length));
/*    */   }
/*    */   
/*    */   public String[] getContentType() {
/* 15 */     return (String[])Arrays.copyOf(this.contentTypes, this.contentTypes.length);
/*    */   }
/*    */   
/*    */   public String[] getSupportedContentTypes() {
/* 19 */     return (String[])Arrays.copyOf(this.supportedContentType, this.supportedContentType.length);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\common\EntityContentMappingValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */