/*     */ package oracle.adf.internal.model.rest.core.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import oracle.adf.internal.model.rest.core.common.RESTUtil;
/*     */ import oracle.adf.model.rest.RestURLEncoder;
/*     */ 
/*     */ 
/*     */ public class Path
/*     */ {
/*     */   public static final String PATH_SEPARATOR = "/";
/*     */   public static final String ID_TEMPLATE = "{id}";
/*     */   public static final String CHILD_FOLDER = "child";
/*     */   public static final String EXPRESSION_TEMPLATE = "{expression}";
/*     */   public static final String ENCLOSURE_FOLDER = "enclosure";
/*     */   public static final String LOV_FOLDER = "lov";
/*     */   private static final String PAYLOAD_CHAR_ENCODING = "UTF-8";
/*     */   private static final String LAST_PATH_PART_REGEX = "/[^/]+$";
/*     */   private final String basePath;
/*     */   private final List<String> pathSegments;
/*     */   
/*     */   public Path(String basePath)
/*     */   {
/*  26 */     this.basePath = basePath;
/*  27 */     this.pathSegments = Collections.emptyList();
/*     */   }
/*     */   
/*     */   public Path(String basePath, String path) {
/*  31 */     this.basePath = basePath;
/*  32 */     this.pathSegments = Collections.unmodifiableList(parsePath(path));
/*     */   }
/*     */   
/*     */   public Path(String basePath, List<String> pathSegments) {
/*  36 */     this.basePath = basePath;
/*  37 */     this.pathSegments = Collections.unmodifiableList(new ArrayList(pathSegments));
/*     */   }
/*     */   
/*     */   public Path(Path parentPath, String path) {
/*  41 */     this.basePath = parentPath.getBasePath();
/*  42 */     List<String> segments = new ArrayList(parentPath.getPathSegments());
/*  43 */     segments.addAll(parsePath(path));
/*  44 */     this.pathSegments = Collections.unmodifiableList(segments);
/*     */   }
/*     */   
/*     */   public Path(Path parentPath, List<String> pathSegments) {
/*  48 */     this.basePath = parentPath.getBasePath();
/*  49 */     List<String> segments = new ArrayList(parentPath.getPathSegments());
/*  50 */     segments.addAll(pathSegments);
/*  51 */     this.pathSegments = Collections.unmodifiableList(segments);
/*     */   }
/*     */   
/*     */   public String getBasePath()
/*     */   {
/*  56 */     return this.basePath;
/*     */   }
/*     */   
/*     */   public List<String> getPathSegments() {
/*  60 */     return this.pathSegments;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  66 */     return createString(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createString(boolean encode)
/*     */   {
/*  76 */     StringBuilder sb = new StringBuilder(this.basePath);
/*  77 */     if (this.pathSegments != null) {
/*  78 */       for (String segment : this.pathSegments) {
/*  79 */         sb.append("/");
/*  80 */         if ((encode) && (RESTUtil.isPathGenerationEncoded().booleanValue()) && (!segment.equals("{id}")) && (!segment.equals("{expression}")))
/*     */         {
/*  82 */           segment = RestURLEncoder.encodeSegment(segment);
/*     */         }
/*  84 */         sb.append(segment);
/*     */       }
/*     */     }
/*     */     
/*  88 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String createHref()
/*     */   {
/*  93 */     return createString(true);
/*     */   }
/*     */   
/*     */   private final List<String> parsePath(String path) {
/*  97 */     return Arrays.asList(path.split("/"));
/*     */   }
/*     */   
/*     */   static String changeVersion(String basePath, String newVersion) {
/* 101 */     return basePath.replaceAll("/[^/]+$", "/" + newVersion);
/*     */   }
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/* 106 */     if (this == object) {
/* 107 */       return true;
/*     */     }
/* 109 */     if (!(object instanceof Path)) {
/* 110 */       return false;
/*     */     }
/* 112 */     Path other = (Path)object;
/*     */     
/* 114 */     String thisPathString = createString(false);
/* 115 */     String otherPathString = other.createString(false);
/*     */     
/* 117 */     if (thisPathString == null ? otherPathString != null : !thisPathString.equals(otherPathString)) {
/* 118 */       return false;
/*     */     }
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 125 */     int PRIME = 37;
/* 126 */     int result = 1;
/* 127 */     String thisPathString = createString(false);
/* 128 */     result = 37 * result + (thisPathString == null ? 0 : thisPathString.hashCode());
/* 129 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\internal\model\rest\core\domain\Path.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */