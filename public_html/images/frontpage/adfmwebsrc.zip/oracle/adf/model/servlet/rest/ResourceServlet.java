/*     */ package oracle.adf.model.servlet.rest;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import oracle.adf.internal.model.rest.core.common.logger.ResourceLoggerManager;
/*     */ import oracle.adf.internal.model.rest.core.http.HttpRequestData;
/*     */ import oracle.adf.internal.model.rest.core.http.RESTHttpRequestExecutor;
/*     */ import oracle.adf.internal.model.rest.core.http.RESTHttpResponseWrapper;
/*     */ import oracle.adf.internal.model.rest.core.http.header.DefaultHeaderConfigurator;
/*     */ import oracle.adf.internal.model.rest.core.http.header.HeaderConfigurator;
/*     */ import oracle.adf.internal.model.rest.core.http.header.HeaderConfiguratorInfo;
/*     */ import oracle.adf.internal.model.rest.core.http.method.HttpMethod.Type;
/*     */ import oracle.adf.model.rest.core.common.ServiceConfiguration;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.logging.ADFLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 3093705886674318554L;
/*     */   private static final String HEADER_PREFIX = "Header_";
/*     */   private static final String INIT_PARAM_SUPPRESS_HEADERS = "SuppressHeaders";
/*     */   private static final String INIT_PARAM_CHARACTER_ENCODING = "CharacterEncoding";
/*     */   private static final String DEFAULT_CHARACTER_ENCODING = "UTF-8";
/*     */   private static final String SUPPRESS_HEADERS_SEPARATOR = ",";
/*     */   private static final String ENABLE_ANTI_CSRF_PARAM = "enableAntiCSRF";
/*     */   private static final String INIT_PARAM_HEADER_CONFIGURATOR_CLASS = "HeaderConfiguratorClass";
/*     */   private Boolean antiCSRFEnabled;
/*     */   private String characterEncoding;
/*     */   private Class<? extends HeaderConfigurator> headerConfiguratorClass;
/*     */   private Map<String, String> headerConfiguratorSetupMap;
/*     */   private Set<String> headerConfiguratorSuppressedHeaders;
/*     */   
/*     */   public void init(ServletConfig config)
/*     */     throws ServletException
/*     */   {
/*  63 */     super.init(config);
/*  64 */     ServletContext context = config.getServletContext();
/*  65 */     ADFContext oldCtx = ADFContext.initADFContext(context, null, null, null);
/*  66 */     ADFLogger logger = ResourceLoggerManager.getRESTLogger();
/*  67 */     logger.info("Configuring the web-application to use RPX files.");
/*     */     try {
/*  69 */       ServiceConfiguration serviceConfig = new ServiceConfiguration();
/*  70 */       serviceConfig.setup();
/*     */     } finally {
/*  72 */       ADFContext.resetADFContext(oldCtx);
/*     */     }
/*  74 */     logger.info("RPX configuration completed");
/*     */     
/*  76 */     this.antiCSRFEnabled = Boolean.valueOf(config.getInitParameter("enableAntiCSRF"));
/*  77 */     logger.info("Anti-CSRF enabled: " + this.antiCSRFEnabled);
/*  78 */     logger.fine("HTTP methods excluded from the Anti-CSRF validation: " + RESTHttpRequestExecutor.ANTI_CSRF_METHODS_TO_IGNORE);
/*     */     
/*  80 */     logger.fine("Obtaining HeaderConfigurator configurations");
/*  81 */     this.headerConfiguratorClass = getResponseHeaderConfiguratorClass(config);
/*  82 */     this.headerConfiguratorSetupMap = createHeaderConfiguratorSetupMap(config);
/*  83 */     this.headerConfiguratorSuppressedHeaders = createHeaderConfiguratorSuppressedHeaders(config);
/*  84 */     logger.fine("HeaderConfigurator configurations obtained");
/*     */     
/*  86 */     this.characterEncoding = getCharacterEncoding(config);
/*  87 */     logger.info("Character encoding: " + this.characterEncoding);
/*     */   }
/*     */   
/*     */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  93 */     execute(request, response, HttpMethod.Type.GET);
/*     */   }
/*     */   
/*     */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  99 */     execute(request, response, HttpMethod.Type.POST);
/*     */   }
/*     */   
/*     */   protected void doDelete(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 105 */     execute(request, response, HttpMethod.Type.DELETE);
/*     */   }
/*     */   
/*     */   protected void doOptions(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 111 */     execute(request, response, HttpMethod.Type.OPTIONS);
/*     */   }
/*     */   
/*     */   protected void doHead(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 117 */     execute(request, response, HttpMethod.Type.HEAD);
/*     */   }
/*     */   
/*     */   protected void doPut(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 123 */     execute(request, response, HttpMethod.Type.PUT);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doPatch(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 130 */     execute(request, response, HttpMethod.Type.PATCH);
/*     */   }
/*     */   
/*     */   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
/*     */   {
/* 135 */     String method = req.getMethod();
/*     */     
/* 137 */     if (method.equals(HttpMethod.Type.PATCH.name())) {
/* 138 */       doPatch(req, resp);
/*     */     } else {
/* 140 */       super.service(req, resp);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getCharacterEncoding(ServletConfig config)
/*     */   {
/* 150 */     String characterEncoding = config.getInitParameter("CharacterEncoding");
/* 151 */     if (characterEncoding == null) {
/* 152 */       return "UTF-8";
/*     */     }
/*     */     
/* 155 */     return characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Set<String> createHeaderConfiguratorSuppressedHeaders(ServletConfig config)
/*     */   {
/* 165 */     ADFLogger logger = ResourceLoggerManager.getRESTLogger();
/* 166 */     String suppressedHeaderInitParam = config.getInitParameter("SuppressHeaders");
/* 167 */     if (suppressedHeaderInitParam != null) {
/* 168 */       Set<String> suppressedHeaders = new HashSet(Arrays.asList(suppressedHeaderInitParam.split(",")));
/* 169 */       if (logger.isFiner()) {
/* 170 */         logger.finer("Suppressed headers: " + suppressedHeaders);
/*     */       }
/* 172 */       return Collections.unmodifiableSet(suppressedHeaders);
/*     */     }
/*     */     
/* 175 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, String> createHeaderConfiguratorSetupMap(ServletConfig config)
/*     */   {
/* 185 */     ADFLogger logger = ResourceLoggerManager.getRESTLogger();
/* 186 */     Map<String, String> setupMap = new HashMap();
/* 187 */     Enumeration<String> enumeration = config.getInitParameterNames();
/* 188 */     while (enumeration.hasMoreElements()) {
/* 189 */       String element = (String)enumeration.nextElement();
/* 190 */       String[] header = element.split("Header_");
/* 191 */       if (header.length == 2) {
/* 192 */         String value = config.getInitParameter(element);
/* 193 */         setupMap.put(header[1], value);
/* 194 */         logger.finer("Header provided. Name: " + header[1] + " Value: " + value);
/*     */       }
/*     */     }
/* 197 */     return Collections.unmodifiableMap(setupMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class<? extends HeaderConfigurator> getResponseHeaderConfiguratorClass(ServletConfig config)
/*     */   {
/* 218 */     String headerConfiguratorParameter = config.getInitParameter("HeaderConfiguratorClass");
/* 219 */     if (headerConfiguratorParameter != null) {
/* 220 */       ADFLogger logger = ResourceLoggerManager.getRESTLogger();
/*     */       try {
/* 222 */         logger.finer("Header Configurator custom implementation provided: " + headerConfiguratorParameter);
/* 223 */         Class cls = Class.forName(headerConfiguratorParameter);
/* 224 */         if (HeaderConfigurator.class.isAssignableFrom(cls)) {
/* 225 */           return cls;
/*     */         }
/* 227 */         logger.warning(headerConfiguratorParameter + " does not implement HeaderConfigurator. Default implementation will be used instead.");
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 231 */         logger.warning(headerConfiguratorParameter + " could not be instantiated.", e);
/*     */       }
/*     */     }
/* 234 */     return DefaultHeaderConfigurator.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void execute(HttpServletRequest request, HttpServletResponse response, HttpMethod.Type httpMethodType)
/*     */     throws IOException
/*     */   {
/* 248 */     ADFLogger logger = ResourceLoggerManager.getRESTLogger();
/*     */     
/* 250 */     request.setCharacterEncoding(this.characterEncoding);
/* 251 */     response.setCharacterEncoding(this.characterEncoding);
/*     */     
/* 253 */     HashMap<String, List<String>> requestHeaders = new HashMap();
/* 254 */     Enumeration<String> requestHeaderNames = request.getHeaderNames();
/*     */     
/* 256 */     while (requestHeaderNames.hasMoreElements()) {
/* 257 */       String headerName = (String)requestHeaderNames.nextElement();
/* 258 */       requestHeaders.put(headerName, Collections.list(request.getHeaders(headerName)));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 264 */     if (response.containsHeader("Metadata-Context"))
/*     */     {
/*     */ 
/*     */ 
/* 268 */       List<String> previous = (List)requestHeaders.put("Metadata-Context", Arrays.asList(new String[] { (String)request.getAttribute("Metadata-Context") }));
/*     */       
/* 270 */       if (logger.isFine()) {
/* 271 */         logger.fine("Replaced Metadata-Context request header " + previous + " with " + requestHeaders.get("Metadata-Context"));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 276 */     HttpRequestData requestData = new HttpRequestData(request.getContentType(), request.getContextPath(), request.getServletPath(), request.getPathInfo(), request.getParameterMap(), requestHeaders, request.getInputStream(), request.getLocale(), httpMethodType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 281 */     RESTHttpRequestExecutor executor = new RESTHttpRequestExecutor();
/* 282 */     executor.setAntiCSRFEnabled(this.antiCSRFEnabled.booleanValue());
/*     */     
/* 284 */     HeaderConfiguratorInfo info = new HeaderConfiguratorInfo();
/* 285 */     info.setSuppressedHeaders(this.headerConfiguratorSuppressedHeaders);
/* 286 */     info.setSetupMap(this.headerConfiguratorSetupMap);
/*     */     
/* 288 */     executor.setResponseHeaderConfiguratorInfo(info);
/*     */     
/*     */     HeaderConfigurator headerConfigurator;
/*     */     try
/*     */     {
/* 293 */       headerConfigurator = (HeaderConfigurator)this.headerConfiguratorClass.newInstance();
/*     */     } catch (Exception ex) {
/* 295 */       logger.warning("The provided header configurator class could not be instantiated, the default implementation will be used instead. Class name: " + this.headerConfiguratorClass.getName(), ex);
/*     */       
/* 297 */       headerConfigurator = new DefaultHeaderConfigurator();
/*     */     }
/*     */     
/* 300 */     executor.execute(requestData, new RESTHttpResponseWrapperImpl(response, headerConfigurator, null));
/*     */   }
/*     */   
/*     */   private static class RESTHttpResponseWrapperImpl implements RESTHttpResponseWrapper
/*     */   {
/*     */     private final HttpServletResponse resp;
/*     */     private final HeaderConfigurator headerConfigurator;
/*     */     
/*     */     private RESTHttpResponseWrapperImpl(HttpServletResponse resp, HeaderConfigurator headerConfigurator) {
/* 309 */       this.resp = resp;
/* 310 */       this.headerConfigurator = headerConfigurator;
/*     */     }
/*     */     
/*     */     public OutputStream getOutpuStream()
/*     */     {
/*     */       try {
/* 316 */         return this.resp.getOutputStream();
/*     */       } catch (IOException e) {
/* 318 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public HeaderConfigurator getHeaderConfigurator()
/*     */     {
/* 324 */       return this.headerConfigurator;
/*     */     }
/*     */     
/*     */     public void setupResponseHeaders(int statusCode, Map<String, String> headers)
/*     */     {
/* 329 */       for (Map.Entry<String, String> entry : headers.entrySet()) {
/* 330 */         this.resp.setHeader((String)entry.getKey(), (String)entry.getValue());
/*     */       }
/* 332 */       this.resp.setStatus(statusCode);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\rest\ResourceServlet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */