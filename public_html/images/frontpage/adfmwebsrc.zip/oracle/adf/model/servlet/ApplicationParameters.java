/*    */ package oracle.adf.model.servlet;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.adf.share.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationParameters
/*    */   extends HashMap
/*    */ {
/*    */   private static final long serialVersionUID = 3523400379544437170L;
/*    */   
/*    */   public ApplicationParameters()
/*    */   {
/* 52 */     new HashMap(4);
/*    */   }
/*    */   
/*    */   public Object get(Object key)
/*    */   {
/* 57 */     Object rtn = super.get(key);
/* 58 */     if ((rtn == null) && ("_http_Session".equals(key)))
/*    */     {
/* 60 */       Object request = ADFContext.getCurrent().getEnvironment().getRequest();
/*    */       
/*    */ 
/* 63 */       if ((request instanceof HttpServletRequest))
/*    */       {
/* 65 */         rtn = ((HttpServletRequest)request).getSession(true);
/*    */       }
/*    */     }
/*    */     
/* 69 */     return rtn;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\ApplicationParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */