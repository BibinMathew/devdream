/*     */ package oracle.adf.model.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.logging.Level;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import oracle.adf.model.BindingRequestHandler;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.logging.ADFLogger;
/*     */ import oracle.adf.share.logging.ADFLoggerUtil;
/*     */ import oracle.adf.share.logging.internal.LoggingUtils;
/*     */ import oracle.adf.share.perf.StateTracker;
/*     */ import oracle.adf.share.perf.Timer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ADFBindingFilter
/*     */   implements Filter
/*     */ {
/*     */   public static final String INIT_PARAMETER_NAME = "CpxFileName";
/*     */   public static final String INIT_PARAMETER_ENCODING = "encoding";
/*     */   public static final String INIT_PARAMETER_UNAUTHORIZED_PAGE = "unauthorizedErrorPage";
/*     */   public static final String INIT_PARAMETER_SINGLE_THREADED_SESSION = "singleThreadedSession";
/*     */   public static final String INIT_PARAMETER_AUTHORIZATION_HANDLER = "authorizationHandler";
/*     */   public static final String INIT_PARAMETER_LOCK_TIMEOUT = "adf.filterlocktimeout";
/*     */   public static final String SESSION_INVALIDATE_BINDINGCONTAINER_DEF = "adf_session_invalidate_bindingcontainer_def";
/*  54 */   private static final ADFLogger LOG = ADFLogger.createADFLogger(ADFBindingFilter.class);
/*  55 */   private static ADFLogger ADFDIAGNOSTICSLOGGER = ADFLoggerUtil.getADFDiagnosticsLogger();
/*     */   
/*     */   private static final String ADF_COMPONENT_NAME = "Component";
/*     */   private static final String COMPONENT_NAME = "oracle.adf.model";
/*  59 */   private static String FILTER_SENSOR_GROUP = "/oracle/adf/model/servlet/ADFBindingFilter";
/*     */   
/*  61 */   private static String FILTER_TIMER_NAME = "doFilter";
/*  62 */   private static String FILTER_URL_NAME = "url";
/*     */   
/*  64 */   private Timer sFilterTimer = null;
/*  65 */   private StateTracker sUrlState = null;
/*     */   
/*     */   private FilterConfig mFilterConfig;
/*  68 */   private boolean mIsDesignTime = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */   private WeakReference mOC4JContextRef = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/*  89 */     ADFContext oldContext = null;
/*     */     
/*     */     try
/*     */     {
/*  93 */       oldContext = ADFContext.initADFContext(filterConfig.getServletContext(), null, null, null);
/*     */       
/*  95 */       this.mFilterConfig = filterConfig;
/*     */       
/*  97 */       ServletContext servletContext = this.mFilterConfig.getServletContext();
/*     */       
/*     */ 
/* 100 */       this.mOC4JContextRef = new WeakReference(BindingRequestHandler.loadApplication());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       this.mIsDesignTime = "Design Time Engine Servlet Context".equals(servletContext.getServletContextName());
/*     */       
/*     */ 
/* 110 */       this.sFilterTimer = Timer.createTimer(Level.INFO, FILTER_SENSOR_GROUP, FILTER_TIMER_NAME, "ADFBindingFilter doFilter timer");
/*     */       
/*     */ 
/* 113 */       this.sUrlState = StateTracker.createStateTracker(Level.INFO, FILTER_SENSOR_GROUP, FILTER_URL_NAME, (byte)5, "", "ADFBindingFilter request URL");
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 119 */       ADFContext.resetADFContext(oldContext);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 128 */     this.mFilterConfig = null;
/*     */     
/* 130 */     Object context = null;
/* 131 */     if ((context = this.mOC4JContextRef.get()) != null)
/*     */     {
/* 133 */       BindingRequestHandler.destroyApplication(context);
/*     */     }
/* 135 */     this.mOC4JContextRef = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 153 */     if (this.mIsDesignTime)
/*     */     {
/* 155 */       chain.doFilter(request, response);
/* 156 */       return;
/*     */     }
/*     */     
/*     */ 
/* 160 */     boolean isActive = this.sUrlState.isActive();
/* 161 */     if (isActive)
/*     */     {
/* 163 */       this.sFilterTimer.start();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 170 */       if (LOG.isFine())
/*     */       {
/* 172 */         request = new LoggingRequestWrapper((HttpServletRequest)request);
/*     */       }
/*     */       
/* 175 */       BindingRequestHandler requestHandler = new HttpBindingRequestHandler(this.mFilterConfig.getServletContext(), (HttpServletRequest)request, (HttpServletResponse)response);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */       requestHandler.setUnauthorizedPage(getInitParameter("unauthorizedErrorPage"));
/*     */       
/*     */ 
/* 184 */       requestHandler.setAuthorizationHandler(getInitParameter("authorizationHandler"));
/*     */       
/*     */ 
/* 187 */       requestHandler.setTargetEncoding(getInitParameter("encoding"));
/*     */       
/*     */ 
/* 190 */       requestHandler.setBindingContextDefName(getInitParameter("CpxFileName"));
/*     */       
/*     */ 
/* 193 */       String timeOutString = getInitParameter("adf.filterlocktimeout");
/* 194 */       int timeout = timeOutString == null ? -1 : Integer.valueOf(timeOutString).intValue();
/* 195 */       requestHandler.setSessionLockTimeOutPeriod(timeout);
/*     */       
/* 197 */       String singleThreadedSessionS = getInitParameter("singleThreadedSession");
/*     */       
/*     */ 
/* 200 */       if (singleThreadedSessionS != null)
/*     */       {
/* 202 */         requestHandler.setSingleThreadedSession(new Boolean(singleThreadedSessionS).booleanValue());
/*     */       }
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 208 */         logRequestBegin((HttpServletRequest)request);
/* 209 */         if (requestHandler.beginRequest())
/*     */         {
/* 211 */           chain.doFilter(request, response);
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 216 */         requestHandler.endRequest();
/* 217 */         logRequestEnd();
/*     */       }
/*     */     }
/*     */     catch (RuntimeException r)
/*     */     {
/* 222 */       ADFContext.logDiagnosticsForException(r);
/* 223 */       throw r;
/*     */     }
/*     */     finally
/*     */     {
/* 227 */       if (isActive)
/*     */       {
/*     */         try
/*     */         {
/* 231 */           this.sUrlState.update(LoggingUtils.getUrl((HttpServletRequest)request));
/*     */         }
/*     */         finally
/*     */         {
/* 235 */           this.sFilterTimer.stop();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getInitParameter(String paramName)
/*     */   {
/* 249 */     String param = this.mFilterConfig.getInitParameter(paramName);
/* 250 */     if (param == null)
/*     */     {
/* 252 */       param = this.mFilterConfig.getServletContext().getInitParameter(paramName);
/*     */     }
/* 254 */     return param;
/*     */   }
/*     */   
/*     */   private void logRequestBegin(HttpServletRequest request)
/*     */   {
/* 259 */     if (ADFDIAGNOSTICSLOGGER.isConfig())
/*     */     {
/* 261 */       HashMap<String, String> ctxData = new HashMap(1);
/* 262 */       ctxData.put("URL", request.getRequestURL().toString());
/* 263 */       ctxData.put("Component", "oracle.adf.model");
/* 264 */       ADFDIAGNOSTICSLOGGER.begin("ADF web request", ctxData);
/*     */     }
/*     */   }
/*     */   
/*     */   private void logRequestEnd()
/*     */   {
/* 270 */     if (ADFDIAGNOSTICSLOGGER.isConfig())
/*     */     {
/* 272 */       ADFDIAGNOSTICSLOGGER.end("ADF web request");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\ADFBindingFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */