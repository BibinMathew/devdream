/*    */ package oracle.adf.model.servlet.rest.binding.inputhandler;
/*    */ 
/*    */ import oracle.adf.internal.model.rest.core.binding.inputhandler.ResourceInputHandlerImpl;
/*    */ import oracle.adf.model.rest.core.describer.json.JSONLinkDescriber;
/*    */ import oracle.adf.model.rest.core.describer.json.JSONValueDescriber;
/*    */ import oracle.adf.model.rest.core.serializer.json.JSONLinkSerializer;
/*    */ import oracle.adf.model.rest.core.serializer.json.JSONValueSerializer;
/*    */ import oracle.adf.model.rest.core.serializer.stream.BaseResourceStreamSerializer;
/*    */ import oracle.jbo.AttributeDef;
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public final class LinkInputHandler
/*    */   extends ResourceInputHandlerImpl
/*    */ {
/*    */   protected JSONValueDescriber getJSONValueDescriber(AttributeDef attrDef)
/*    */   {
/* 19 */     return new JSONLinkDescriber();
/*    */   }
/*    */   
/*    */   protected JSONValueSerializer getJSONValueSerializer(AttributeDef attrDef)
/*    */   {
/* 24 */     return new JSONLinkSerializer();
/*    */   }
/*    */   
/*    */   protected BaseResourceStreamSerializer getResourceStreamSerializer(AttributeDef attrDef)
/*    */   {
/* 29 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\rest\binding\inputhandler\LinkInputHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */