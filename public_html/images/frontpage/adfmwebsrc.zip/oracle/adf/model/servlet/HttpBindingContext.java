/*    */ package oracle.adf.model.servlet;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import oracle.adf.model.BindingContext;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.jbo.SessionContextManager;
/*    */ import oracle.jbo.common.SessionContextManagerImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpBindingContext
/*    */   extends BindingContext
/*    */ {
/*    */   private static final long serialVersionUID = -466180156409946781L;
/*    */   
/*    */   public void touch()
/*    */   {
/* 28 */     super.touch();
/* 29 */     setCurrent(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void scopeInvalidated(String scopeName, Object externalContext)
/*    */   {
/* 36 */     SessionContextManagerImpl.getInstance().setCurrentSession(new HttpSessionContextImpl((HttpSession)externalContext));
/*    */     
/*    */ 
/* 39 */     super.scopeInvalidated(scopeName, externalContext);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final BindingContext getContext(ServletRequest request)
/*    */   {
/* 49 */     return (BindingContext)ADFContext.getCurrent().getSessionScope().get("data");
/*    */   }
/*    */   
/*    */ 
/*    */   public void addPersistentState(String name, Serializable psState)
/*    */   {
/* 55 */     super.addPersistentState(name, psState);
/*    */     
/* 57 */     touch();
/*    */   }
/*    */   
/*    */   public void removePersistentState(String name)
/*    */   {
/* 62 */     super.removePersistentState(name);
/*    */     
/* 64 */     touch();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\HttpBindingContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */