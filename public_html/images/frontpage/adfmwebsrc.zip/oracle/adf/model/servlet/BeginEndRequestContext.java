/*     */ package oracle.adf.model.servlet;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.Environment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeginEndRequestContext
/*     */   extends HashMap
/*     */ {
/*     */   private static final long serialVersionUID = -8825408458025927023L;
/*     */   
/*     */   BeginEndRequestContext(HashMap map)
/*     */   {
/* 118 */     super(map);
/*     */   }
/*     */   
/*     */   public Object get(Object key)
/*     */   {
/* 123 */     if ("_http_request_".equals(key))
/*     */     {
/* 125 */       return ADFContext.getCurrent().getEnvironment().getRequest();
/*     */     }
/* 127 */     if ("_http_response_".equals(key))
/*     */     {
/* 129 */       return ADFContext.getCurrent().getEnvironment().getResponse();
/*     */     }
/*     */     
/*     */ 
/* 133 */     return super.get(key);
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\BeginEndRequestContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */