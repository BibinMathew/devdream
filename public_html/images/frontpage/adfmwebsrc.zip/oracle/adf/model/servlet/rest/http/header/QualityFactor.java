package oracle.adf.model.servlet.rest.http.header;

@Deprecated
public class QualityFactor {}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\rest\http\header\QualityFactor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */