/*    */ package oracle.adf.model.servlet;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletRequestWrapper;
/*    */ import oracle.adf.share.logging.ADFLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingRequestWrapper
/*    */   extends HttpServletRequestWrapper
/*    */ {
/* 20 */   private static final ADFLogger LOG = ADFLogger.createADFLogger(LoggingRequestWrapper.class);
/*    */   
/*    */ 
/*    */   private static final String logStr = "Setting the value of 'bindings' to ";
/*    */   
/*    */ 
/*    */ 
/*    */   public LoggingRequestWrapper(HttpServletRequest servletRequest)
/*    */   {
/* 29 */     super(servletRequest);
/*    */   }
/*    */   
/*    */ 
/*    */   public void setAttribute(String key, Object object)
/*    */   {
/* 35 */     if ((key != null) && (key.equals("bindings"))) {
/*    */       String value;
/*    */       String value;
/* 38 */       if (object == null)
/*    */       {
/* 40 */         value = "null";
/*    */       }
/*    */       else
/*    */       {
/* 44 */         value = object.toString();
/*    */       }
/*    */       
/* 47 */       LOG.fine("Setting the value of 'bindings' to " + value);
/*    */     }
/*    */     
/* 50 */     super.setAttribute(key, object);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\LoggingRequestWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */