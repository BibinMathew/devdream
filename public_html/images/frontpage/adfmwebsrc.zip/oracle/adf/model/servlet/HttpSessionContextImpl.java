/*    */ package oracle.adf.model.servlet;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.adf.share.Environment;
/*    */ import oracle.jbo.SessionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ class HttpSessionContextImpl
/*    */   implements SessionContext
/*    */ {
/* 14 */   private String mId = null;
/*    */   
/*    */ 
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public HttpSessionContextImpl() {}
/*    */   
/*    */ 
/*    */   public HttpSessionContextImpl(HttpSession session)
/*    */   {
/* 25 */     this.mId = session.getId();
/*    */   }
/*    */   
/*    */   public int getType()
/*    */   {
/* 30 */     return 1;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 35 */     if (this.mId == null)
/*    */     {
/* 37 */       this.mId = getHttpSession().getId();
/*    */     }
/*    */     
/* 40 */     return this.mId;
/*    */   }
/*    */   
/*    */   private HttpSession getHttpSession()
/*    */   {
/* 45 */     Object request = ADFContext.getCurrent().getEnvironment().getRequest();
/*    */     
/*    */ 
/* 48 */     if ((request instanceof HttpServletRequest))
/*    */     {
/* 50 */       return ((HttpServletRequest)request).getSession(true);
/*    */     }
/*    */     
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\HttpSessionContextImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */