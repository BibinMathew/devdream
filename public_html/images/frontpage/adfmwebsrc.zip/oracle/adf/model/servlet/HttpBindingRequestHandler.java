/*     */ package oracle.adf.model.servlet;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import oracle.adf.model.BindingContext;
/*     */ import oracle.adf.model.BindingRequestHandler;
/*     */ import oracle.adf.model.MetadataContext;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.http.ServletADFContext;
/*     */ import oracle.jbo.SessionContext;
/*     */ import oracle.jbo.http.HttpSessionCookieProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpBindingRequestHandler
/*     */   extends BindingRequestHandler
/*     */ {
/*     */   private final ServletContext mServletContext;
/*     */   private final HttpServletRequest mRequest;
/*     */   private final HttpServletResponse mResponse;
/*     */   
/*     */   public HttpBindingRequestHandler(ServletContext servletContext, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  36 */     this.mServletContext = servletContext;
/*  37 */     this.mRequest = request;
/*  38 */     this.mResponse = response;
/*     */   }
/*     */   
/*     */   protected SessionContext createSessionContext(ADFContext adfContext)
/*     */   {
/*  43 */     return new HttpSessionContextImpl(this.mRequest.getSession(true));
/*     */   }
/*     */   
/*     */   protected BindingContext createBindingContext(ADFContext adfContext)
/*     */   {
/*  48 */     return new HttpBindingContext();
/*     */   }
/*     */   
/*     */   protected ADFContext initADFContext()
/*     */   {
/*  53 */     ServletADFContext.initThreadContext(this.mServletContext, this.mRequest, this.mResponse);
/*     */     
/*     */ 
/*  56 */     return ADFContext.getCurrent();
/*     */   }
/*     */   
/*     */   protected void resetADFContext()
/*     */   {
/*  61 */     ServletADFContext.resetThreadContext(this.mRequest);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Properties initializeContextForDataControl(ADFContext adfContext, Properties context)
/*     */   {
/*  67 */     return new HttpSessionCookieProperties(super.initializeContextForDataControl(adfContext, context));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected HashMap initializeContextForBeginRequest(ADFContext adfContext, HashMap context)
/*     */   {
/*  74 */     return initializeBeginEndRequestContext(adfContext, super.initializeContextForBeginRequest(adfContext, context));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected HashMap initializeContextForEndRequest(ADFContext adfContext, HashMap context)
/*     */   {
/*  81 */     return initializeBeginEndRequestContext(adfContext, super.initializeContextForEndRequest(adfContext, context));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private HashMap initializeBeginEndRequestContext(ADFContext adfContext, HashMap context)
/*     */   {
/*  88 */     return new BeginEndRequestContext(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void initMetadataContext()
/*     */   {
/*  95 */     String metadataContextHeaderStr = this.mRequest.getHeader("Metadata-Context");
/*     */     
/*     */ 
/*  98 */     Map<String, String> metadataProperties = MetadataContext.setupMetadataContext(metadataContextHeaderStr);
/*  99 */     String headerStr = MetadataContext.buildHeaderValue(metadataProperties);
/* 100 */     if (headerStr != null)
/*     */     {
/* 102 */       this.mResponse.setHeader("Metadata-Context", headerStr);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 107 */       this.mRequest.setAttribute("Metadata-Context", headerStr);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\servlet\HttpBindingRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */