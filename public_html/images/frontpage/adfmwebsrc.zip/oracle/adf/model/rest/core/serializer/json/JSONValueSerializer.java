/*     */ package oracle.adf.model.rest.core.serializer.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import oracle.adf.model.rest.RestTypeConverter;
/*     */ import oracle.adf.model.rest.core.serializer.ResourceValueSerializer;
/*     */ import oracle.adf.model.rest.core.serializer.ValueSerializerType;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.domain.TypeFactory;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONValueSerializer
/*     */   implements ResourceValueSerializer<JsonNode, JsonGenerator, JSONValueInfo>
/*     */ {
/*  33 */   private static final JsonFactory JSON_FACTORY = new JsonFactory();
/*  34 */   private static final ObjectMapper MAPPER = new ObjectMapper(JSON_FACTORY);
/*     */   
/*     */ 
/*     */ 
/*     */   public void serialize(JUCtrlValueBinding valb, JsonGenerator target, JSONValueInfo info)
/*     */   {
/*     */     try
/*     */     {
/*  42 */       target.writeObject(RestTypeConverter.toPayloadType(valb.getInputValue(), valb.getAttributeDef()));
/*     */     } catch (IOException e) {
/*  44 */       throw new JboException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object deserialize(JUCtrlValueBinding valb, JsonNode source, JSONValueInfo info)
/*     */   {
/*  50 */     AttributeDef attrDef = null;
/*  51 */     if (valb != null) {
/*  52 */       attrDef = valb.getAttributeDef();
/*     */     } else {
/*  54 */       attrDef = (AttributeDef)info.get("attributeDef");
/*     */     }
/*     */     
/*  57 */     Object originalValue = null;
/*     */     try {
/*  59 */       originalValue = MAPPER.readValue(source, String.class);
/*     */     } catch (IOException ex) {
/*  61 */       throw new JboException(ex);
/*     */     }
/*     */     
/*  64 */     return RestTypeConverter.toJavaType((String)originalValue, attrDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void serializeLink(JUCtrlValueBinding valb, JsonGenerator target, JSONValueInfo info)
/*     */   {
/*     */     try
/*     */     {
/*  77 */       target.writeStartObject();
/*  78 */       target.writeStringField("rel", "external");
/*  79 */       target.writeStringField("href", getHref(valb, info));
/*  80 */       target.writeStringField("name", valb.getName());
/*  81 */       target.writeStringField("kind", "other");
/*  82 */       target.writeEndObject();
/*     */     } catch (IOException e) {
/*  84 */       throw new JboException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getHref(JUCtrlValueBinding valb, JSONValueInfo info)
/*     */   {
/*  97 */     return (String)TypeFactory.getInstance(String.class, valb.getInputValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueSerializerType getType(JUCtrlValueBinding valb, JSONValueInfo info)
/*     */   {
/* 108 */     return ValueSerializerType.VALUE;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\json\JSONValueSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */