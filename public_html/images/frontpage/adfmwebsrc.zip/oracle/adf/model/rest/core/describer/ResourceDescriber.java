/*     */ package oracle.adf.model.rest.core.describer;
/*     */ 
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.LocaleContext;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ResourceDescriber<T, I extends DescriberInfo>
/*     */ {
/*     */   public static final String ATTRIBUTE_NAME_PROP = "name";
/*     */   public static final String ATTRIBUTE_TYPE_PROP = "type";
/*     */   public static final String ATTRIBUTE_UPDATABLE_PROP = "updatable";
/*     */   public static final String ATTRIBUTE_MANDATORY_PROP = "mandatory";
/*     */   public static final String ATTRIBUTE_REQUIRED_PROP = "required";
/*     */   public static final String ATTRIBUTE_QUERYABLE_PROP = "queryable";
/*     */   public static final String ATTRIBUTE_PRECISION_PROP = "precision";
/*     */   public static final String ATTRIBUTE_ALLOWCHANGES_PROP = "allowChanges";
/*     */   public static final String ATTRIBUTE_SCALE_PROP = "scale";
/*     */   public static final String ATTRIBUTE_TITLE_PROP = "title";
/*     */   public static final String ATTRIBUTE_TITLE_PLURAL_PROP = "titlePlural";
/*     */   public static final String ATTRIBUTE_CONTROL_TYPE_PROP = "controlType";
/*     */   public static final String ATTRIBUTE_CURRENCY_CODE_PROP = "currencyCode";
/*     */   public static final String ATTRIBUTE_MAX_LENGTH = "maxLength";
/*     */   public static final String ATTRIBUTE_MIN_LENGTH = "minLength";
/*     */   public static final String ATTRIBUTE_MIN_VALUE = "minValue";
/*     */   public static final String ATTRIBUTE_MAX_VALUE = "maxValue";
/*     */   public static final String ATTRIBUTE_CHILD_REF_LOV = "childRef";
/*     */   public static final String ATTRIBUTE_ATTR_MAP_LOV = "attributeMap";
/*     */   public static final String ATTRIBUTE_DISPLAY_ATTRS_LOV = "displayAttributes";
/*     */   public static final String ATTRIBUTE_DEPENDENCIES = "dependencies";
/*     */   public static final String ATTRIBUTE_DELIMITER_LOV = "delimeter";
/*     */   public static final String ATTRIBUTE_SOURCE_LOV = "source";
/*     */   public static final String ATTRIBUTE_TARGET_LOV = "target";
/*     */   public static final String ATTRIBUTE_DERIVED_LOV = "derived";
/*     */   public static final String ATTRIBUTE_LOV_RESOURCE_PATH = "lovResourcePath";
/*     */   public static final String ATTRIBUTE_LOV_RESOURCE_PATH_RESOURCE = "resource";
/*     */   public static final String ATTRIBUTE_LOV_RESOURCE_PATH_FILTER = "filter";
/*     */   public static final String ATTRIBUTE_LOV_RESOURCE_LOV = "lovResource";
/*     */   public static final String ATTRIBUTE_LOV = "lov";
/*     */   public static final String ATTRIBUTE_SECRET = "secret";
/*     */   public static final String ACTION_NAME_PROP = "name";
/*     */   public static final String ACTION_DESCRIPTION_PROP = "description";
/*     */   public static final String ACTION_RESULT_TYPE_PROP = "resultType";
/*     */   public static final String ACTION_REQUEST_TYPE_PROP = "requestType";
/*     */   public static final String ACTION_RESPONSE_TYPE_PROP = "responseType";
/*     */   public static final String ACTION_METHOD_PROP = "method";
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/octet-stream";
/*     */   public static final String STREAM_OBJECT_TYPE = "attachment";
/*     */   public static final String URL_OBJECT_TYPE = "URL";
/*     */   public static final String PATCH_HTTP_METHOD = "PATCH";
/*     */   public static final String PUT_HTTP_METHOD = "PUT";
/*     */   public static final String GET_HTTP_METHOD = "GET";
/*     */   public static final String POST_HTTP_METHOD = "POST";
/*     */   public static final String DELETE_HTTP_METHOD = "DELETE";
/*     */   public static final String UPDATE_ACTION = "update";
/*     */   public static final String REPLACE_ACTION = "replace";
/*     */   public static final String READ_ACTION = "get";
/*     */   public static final String CREATE_ACTION = "create";
/*     */   public static final String DELETE_ACTION = "delete";
/*     */   public static final String ACTION_NAME_PLURAL = "actions";
/*     */   public static final String ATTRIBUTE_PROPERTIES = "properties";
/*     */   public static final String COMMA_SEPARATOR = ",";
/*     */   public static final String LOV_INFO_PROP = "LOVInfo";
/*     */   
/*     */   public abstract void catalogDescribe(AttributeDef paramAttributeDef, LocaleContext paramLocaleContext, T paramT, I paramI);
/*     */   
/*     */   public abstract void describe(JUCtrlValueBinding paramJUCtrlValueBinding, T paramT, I paramI);
/*     */   
/*     */   public static enum Action
/*     */   {
/*  97 */     CREATE("create", "POST"), 
/*  98 */     READ("get", "GET"), 
/*  99 */     UPDATE("update", "PATCH"), 
/* 100 */     REPLACE("replace", "PUT"), 
/* 101 */     DELETE("delete", "DELETE");
/*     */     
/*     */     private final String httpMethod;
/*     */     private final String name;
/*     */     
/*     */     private Action(String name, String httpMethod) {
/* 107 */       this.name = name;
/* 108 */       this.httpMethod = httpMethod;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 112 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getHttpMethod() {
/* 116 */       return this.httpMethod;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\describer\ResourceDescriber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */