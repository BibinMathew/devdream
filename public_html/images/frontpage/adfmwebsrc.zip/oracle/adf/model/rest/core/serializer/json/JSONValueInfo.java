package oracle.adf.model.rest.core.serializer.json;

import oracle.adf.model.rest.core.serializer.ValueSerializerInfo;

public class JSONValueInfo
  extends ValueSerializerInfo
{
  private static final long serialVersionUID = 5681046510180814811L;
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\json\JSONValueInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */