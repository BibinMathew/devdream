/*     */ package oracle.adf.model.rest.core.serializer;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamSerializerInfo
/*     */   extends HashMap<String, Object>
/*     */ {
/*     */   private static final long serialVersionUID = -7674592527109798216L;
/*     */   
/*     */   public StreamSerializerInfo()
/*     */   {
/*  21 */     super(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/*  32 */     put("Content-Type", contentType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  40 */     return (String)get("Content-Type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStateId(String stateId)
/*     */   {
/*  49 */     put("ETag", stateId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStateId()
/*     */   {
/*  57 */     return (String)get("ETag");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isClientProperty(String propertyName)
/*     */   {
/*  66 */     Object propertyValue = get(propertyName);
/*  67 */     return isClientProperty(propertyName, propertyValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClientProperty(String propertyName)
/*     */   {
/*  77 */     Object value = get(propertyName);
/*  78 */     if (isClientProperty(propertyName, value)) {
/*  79 */       return (String)value;
/*     */     }
/*  81 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isClientProperty(String propertyName, Object propertyValue)
/*     */   {
/*  91 */     return propertyValue instanceof String;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getClientProperties()
/*     */   {
/* 100 */     HashMap<String, String> clientProperties = new HashMap();
/*     */     
/* 102 */     for (Map.Entry<String, Object> entry : entrySet()) {
/* 103 */       String property = (String)entry.getKey();
/* 104 */       Object value = entry.getValue();
/* 105 */       if (isClientProperty(property, value)) {
/* 106 */         clientProperties.put(property, (String)value);
/*     */       }
/*     */     }
/* 109 */     return clientProperties;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\StreamSerializerInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */