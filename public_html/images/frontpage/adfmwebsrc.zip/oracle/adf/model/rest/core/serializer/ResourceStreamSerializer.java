package oracle.adf.model.rest.core.serializer;

import java.io.InputStream;
import java.io.OutputStream;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

public abstract interface ResourceStreamSerializer
{
  public static final String DEFAULT_CONTENT_TYPE = "application/octet-stream";
  public static final String CONTENT_TYPE_PROP = "Content-Type";
  public static final String ETAG_PROP = "ETag";
  
  public abstract void serializeStream(JUCtrlValueBinding paramJUCtrlValueBinding, OutputStream paramOutputStream, StreamSerializerInfo paramStreamSerializerInfo);
  
  public abstract void deserializeStream(JUCtrlValueBinding paramJUCtrlValueBinding, InputStream paramInputStream, StreamSerializerInfo paramStreamSerializerInfo);
  
  public abstract StreamSerializerInfo getStreamInfo(JUCtrlValueBinding paramJUCtrlValueBinding);
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\ResourceStreamSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */