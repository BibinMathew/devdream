/*    */ package oracle.adf.model.rest.core.serializer.json;
/*    */ 
/*    */ import oracle.adf.model.rest.core.serializer.ValueSerializerType;
/*    */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSONLinkSerializer
/*    */   extends JSONValueSerializer
/*    */ {
/*    */   public final ValueSerializerType getType(JUCtrlValueBinding valb, JSONValueInfo info)
/*    */   {
/* 30 */     return ValueSerializerType.LINK;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\json\JSONLinkSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */