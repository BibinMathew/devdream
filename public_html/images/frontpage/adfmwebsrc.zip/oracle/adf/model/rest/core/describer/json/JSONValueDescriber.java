/*     */ package oracle.adf.model.rest.core.describer.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import oracle.adf.model.rest.RestURLEncoder;
/*     */ import oracle.adf.model.rest.core.describer.DescriberInfo.LOVResourceInfo;
/*     */ import oracle.adf.model.rest.core.describer.DescriberInfo.LOVResourceInfo.DescribeLOVResourcePathItem;
/*     */ import oracle.adf.model.rest.core.describer.ResourceDescriber;
/*     */ import oracle.adf.model.rest.core.describer.ResourceDescriber.Action;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeHints;
/*     */ import oracle.jbo.AttributeHints.ControlType;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.LocaleContext;
/*     */ import oracle.jbo.Row;
/*     */ import oracle.jbo.common.JboTypeMap;
/*     */ import oracle.jbo.common.ListBindingDef;
/*     */ import oracle.jbo.common.rest.JsonTypeMap;
/*     */ import oracle.jbo.server.AttributeDefImpl;
/*     */ import oracle.jbo.server.BoundParameter;
/*     */ import oracle.jbo.server.ViewAttributeDefImpl;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONValueDescriber
/*     */   implements ResourceDescriber<JsonGenerator, JSONDescriberInfo>
/*     */ {
/*     */   private static final String ATTR_HINT_INPUT_HANDLER = "inputHandler";
/*     */   private static final String ATTR_HINT_CONTENT_TYPE = "contentType";
/*     */   private static final String LOV_RESOURCE_PROPERTY = "LOVResource";
/*  65 */   private static final String[] REQUEST_TYPE = { "application/octet-stream" };
/*  66 */   private static final String[] RESPONSE_TYPE = { "application/octet-stream" };
/*  67 */   private static final String[] PROPERTIES_TO_FILTER = { "inputHandler", "contentType", "REQUIRED", "LOVResource" };
/*     */   
/*     */ 
/*     */   private static final String RES_ID_SUFFIX = "_ResId";
/*     */   
/*     */ 
/*     */   private final Map<String, Object> overriddenProperties;
/*     */   
/*     */ 
/*     */   public JSONValueDescriber(Map<String, Object> overriddenProperties)
/*     */   {
/*  78 */     this.overriddenProperties = new HashMap(overriddenProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JSONValueDescriber()
/*     */   {
/*  86 */     this.overriddenProperties = null;
/*     */   }
/*     */   
/*     */   public void catalogDescribe(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*     */   {
/*     */     try
/*     */     {
/*  93 */       String serializedObjectType = getCatalogSerializedObjectType(attrDef, localeContext, target, info);
/*  94 */       describeCatalogStructure(attrDef, localeContext, target, info, serializedObjectType);
/*  95 */       describeCatalogActions(attrDef, localeContext, target, info);
/*     */     } catch (IOException e) {
/*  97 */       throw new JboException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getCatalogSerializedObjectType(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*     */   {
/* 113 */     return getSerializedObjectType(attrDef, attrDef.getUIHelper(), localeContext, target, info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void describeCatalogStructure(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info, String serializedObjectType)
/*     */     throws IOException
/*     */   {
/* 129 */     describeStructure(attrDef, attrDef.getUIHelper(), localeContext, target, info, serializedObjectType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void describeCatalogActions(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*     */     throws IOException
/*     */   {
/* 143 */     describeActions(attrDef, attrDef.getUIHelper(), localeContext, target, info);
/*     */   }
/*     */   
/*     */   public void describe(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info)
/*     */   {
/*     */     try {
/* 149 */       String serializedObjectType = getSerializedObjectType(valb, target, info);
/* 150 */       describeStructure(valb, target, info, serializedObjectType);
/* 151 */       describeActions(valb, target, info);
/*     */     } catch (IOException e) {
/* 153 */       throw new JboException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getSerializedObjectType(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info)
/*     */   {
/* 166 */     AttributeDef attrDef = valb.getAttributeDef();
/* 167 */     return getSerializedObjectType(attrDef, valb.getCurrentRow().getAttributeHints(attrDef.getName()), valb.getLocaleContext(), target, info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void describeStructure(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info, String serializedObjectType)
/*     */     throws IOException
/*     */   {
/* 181 */     AttributeDef attrDef = valb.getAttributeDef();
/* 182 */     describeStructure(attrDef, valb.getCurrentRow().getAttributeHints(attrDef.getName()), valb.getLocaleContext(), target, info, serializedObjectType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void describeActions(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info)
/*     */     throws IOException
/*     */   {
/* 194 */     AttributeDef attrDef = valb.getAttributeDef();
/* 195 */     describeActions(attrDef, valb.getCurrentRow().getAttributeHints(attrDef.getName()), valb.getLocaleContext(), target, info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getSerializedObjectType(AttributeDef attrDef, AttributeHints attrHints, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*     */   {
/* 209 */     return JSONTypeMap.getJSONType(attrDef).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void describeStructure(AttributeDef attrDef, AttributeHints attributeHints, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info, String serializedObjectType)
/*     */     throws IOException
/*     */   {
/* 227 */     processFirstClassProperties(attrDef, target, serializedObjectType);
/*     */     
/* 229 */     Map attrProperties = attrDef.getProperties();
/* 230 */     String lovResource = null;
/* 231 */     if ((attrProperties != null) && (!attrProperties.isEmpty())) {
/* 232 */       lovResource = (String)attrProperties.remove("lovResource");
/* 233 */       processOtherProperties(attrProperties, attrDef, attributeHints, localeContext, target);
/*     */     }
/*     */     
/*     */ 
/* 237 */     if ((attrDef instanceof AttributeDefImpl)) {
/* 238 */       List<String> dependencies = ((AttributeDefImpl)attrDef).getBackwardDependenciesNames();
/* 239 */       if (dependencies != null) {
/* 240 */         target.writeArrayFieldStart("dependencies");
/* 241 */         String[] dependenciesArray = new String[dependencies.size()];
/* 242 */         writeArrayItems((String[])dependencies.toArray(dependenciesArray), target);
/* 243 */         target.writeEndArray();
/*     */       }
/*     */     }
/*     */     
/* 247 */     if (attrDef.getLOVName() != null) {
/*     */       Map<String, String> lovProperties;
/* 249 */       if (lovResource != null) {
/* 250 */         int maxSize = 1;
/* 251 */         Map<String, String> lovProperties = new HashMap(1);
/* 252 */         lovProperties.put("lovResource", lovResource);
/*     */       } else {
/* 254 */         lovProperties = Collections.emptyMap();
/*     */       }
/* 256 */       describeLOV(attrDef, attributeHints, localeContext, target, info, lovProperties);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processFirstClassProperties(AttributeDef attrDef, JsonGenerator target, String serializedObjectType) throws IOException {
/* 261 */     String attrName = attrDef.getName();
/* 262 */     Object type = Boolean.valueOf(attrDef.isMandatory());
/* 263 */     String mandatoryPropName = "mandatory";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 268 */     if ((attrDef instanceof BoundParameter)) {
/* 269 */       mandatoryPropName = "required";
/* 270 */       BoundParameter bp = (BoundParameter)attrDef;
/* 271 */       attrName = bp.getAttributeName();
/* 272 */       type = bp.getRequired();
/* 273 */       if (type == null) {
/* 274 */         type = "Optional";
/*     */       }
/*     */     }
/*     */     
/* 278 */     writeProperty(target, "name", attrName);
/* 279 */     writeProperty(target, "type", serializedObjectType);
/* 280 */     writeProperty(target, "updatable", Boolean.valueOf(attrDef.getUpdateableFlag() == 2));
/* 281 */     writeProperty(target, mandatoryPropName, type);
/* 282 */     writeProperty(target, "queryable", Boolean.valueOf(attrDef.isQueriable()));
/* 283 */     writeProperty(target, "allowChanges", JsonTypeMap.getRestAttrAllowChangesValue(Byte.valueOf(attrDef.getUpdateableFlag())));
/* 284 */     int precision = attrDef.getPrecision();
/* 285 */     if (precision > 0) {
/* 286 */       writeProperty(target, "precision", Integer.valueOf(attrDef.getPrecision()));
/*     */     }
/*     */     
/* 289 */     if ((attrDef instanceof ViewAttributeDefImpl)) {
/* 290 */       String currencyCode = ((ViewAttributeDefImpl)attrDef).getXSDViewAttrName("currencyCode");
/* 291 */       if (currencyCode != null) {
/* 292 */         writeProperty(target, "currencyCode", currencyCode);
/*     */       }
/*     */     }
/*     */     
/* 296 */     int scale = attrDef.getScale();
/* 297 */     if ((scale > 0) && (JboTypeMap.isNumericType(attrDef.getSQLType()))) {
/* 298 */       writeProperty(target, "scale", Integer.valueOf(scale));
/*     */     }
/*     */   }
/*     */   
/*     */   private void processOtherProperties(Map attrProperties, AttributeDef attrDef, AttributeHints attributeHints, LocaleContext localeContext, JsonGenerator target) throws IOException {
/* 303 */     Map<String, Object> hints = new HashMap(attrProperties.size());
/* 304 */     for (Object key : attrProperties.keySet()) {
/* 305 */       String hintKey = (String)key;
/* 306 */       int suffixIndex = hintKey.indexOf("_ResId");
/* 307 */       if (suffixIndex > -1) {
/* 308 */         hintKey = hintKey.substring(0, suffixIndex);
/*     */       }
/* 310 */       Object hintValue = attributeHints.getHint(localeContext, hintKey);
/* 311 */       hints.put(hintKey, hintValue);
/*     */     }
/* 313 */     writeStructureProperties(attrDef.getSQLType(), attributeHints, localeContext, target, hints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void writeStructureProperties(int attributeSQLType, AttributeHints attributeHints, LocaleContext localeContext, JsonGenerator target, Map attrProperties)
/*     */     throws IOException
/*     */   {
/* 321 */     Map<Object, Object> propertiesCopy = new HashMap(attrProperties);
/*     */     
/* 323 */     filterProperties(propertiesCopy);
/*     */     
/* 325 */     if (propertiesCopy.remove("LABEL") != null) {
/* 326 */       writeProperty(target, "title", attributeHints.getLabel(localeContext));
/*     */     }
/*     */     
/* 329 */     String pluralLabel = (String)propertiesCopy.remove("LABEL_PLURAL");
/* 330 */     if (pluralLabel != null) {
/* 331 */       writeProperty(target, "titlePlural", pluralLabel);
/*     */     }
/*     */     
/* 334 */     if (propertiesCopy.remove("CONTROLTYPE") != null) {
/* 335 */       int controlTypeCod = attributeHints.getControlType(localeContext);
/* 336 */       AttributeHints.ControlType controlType = AttributeHints.ControlType.getControlType(controlTypeCod);
/* 337 */       writeProperty(target, "controlType", controlType.getXmlTag());
/*     */     }
/*     */     
/* 340 */     if (JboTypeMap.isNumericType(attributeSQLType)) {
/* 341 */       writeNumericTypeProperties(attributeHints, localeContext, target, propertiesCopy);
/* 342 */     } else if (JboTypeMap.isCharType(attributeSQLType)) {
/* 343 */       writeCharTypeProperties(attributeHints, localeContext, target, propertiesCopy);
/*     */     }
/*     */     
/*     */ 
/* 347 */     propertiesCopy.remove("LABEL_ResId");
/* 348 */     propertiesCopy.remove("LABEL_PLURAL_ResId");
/* 349 */     propertiesCopy.remove("TOOLTIP_ResId");
/*     */     
/* 351 */     if (!propertiesCopy.isEmpty()) {
/* 352 */       target.writeFieldName("properties");
/* 353 */       target.writeStartObject();
/* 354 */       Set<Map.Entry<Object, Object>> entries = propertiesCopy.entrySet();
/* 355 */       for (Map.Entry entry : entries) {
/* 356 */         Object value = entry.getValue();
/* 357 */         writeProperty(target, entry.getKey().toString(), value == null ? null : value.toString());
/*     */       }
/* 359 */       target.writeEndObject();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void describeActions(AttributeDef attrDef, AttributeHints attrHints, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void writeProperty(JsonGenerator target, String propertyName, Object defaultValue)
/*     */     throws IOException
/*     */   {
/* 388 */     Object value = defaultValue;
/*     */     
/* 390 */     if ((value instanceof Collection))
/*     */     {
/* 392 */       Collection<Object> valueCollection = (Collection)value;
/* 393 */       value = valueCollection.toArray(new Object[valueCollection.size()]);
/*     */     }
/*     */     
/* 396 */     if (this.overriddenProperties != null) {
/* 397 */       Object overriddenValue = this.overriddenProperties.get(propertyName);
/* 398 */       if (overriddenValue != null)
/*     */       {
/* 400 */         if ((value.getClass().isArray()) && (!overriddenValue.getClass().isArray())) {
/* 401 */           value = new Object[] { overriddenValue };
/*     */         } else {
/* 403 */           value = overriddenValue;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 408 */     if ((value != null) && (value.getClass().isArray())) {
/* 409 */       target.writeArrayFieldStart(propertyName);
/* 410 */       for (Object item : (Object[])value) {
/* 411 */         target.writeObject(item);
/*     */       }
/* 413 */       target.writeEndArray();
/*     */     } else {
/* 415 */       target.writeObjectField(propertyName, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void serializeActions(List<? extends Map<String, Object>> actions, JsonGenerator target)
/*     */     throws IOException
/*     */   {
/* 427 */     target.writeArrayFieldStart("actions");
/* 428 */     for (Map<String, Object> actionProperties : actions) {
/* 429 */       serializeAction(target, actionProperties);
/*     */     }
/* 431 */     target.writeEndArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void serializeAction(JsonGenerator target, Map<String, Object> actionProperties)
/*     */     throws IOException
/*     */   {
/* 442 */     target.writeStartObject();
/* 443 */     Set<Map.Entry<String, Object>> entries = actionProperties.entrySet();
/* 444 */     for (Map.Entry<String, Object> entry : entries) {
/* 445 */       writeProperty(target, (String)entry.getKey(), entry.getValue());
/*     */     }
/* 447 */     target.writeEndObject();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<ResourceDescriber.Action, String[]> getCatalogRequestType(AttributeDef attrDef, LocaleContext localeContext, JSONDescriberInfo info)
/*     */   {
/* 460 */     return getRequestType(attrDef, attrDef.getUIHelper(), localeContext, info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<ResourceDescriber.Action, String[]> getCatalogResponseType(AttributeDef attrDef, LocaleContext localeContext, JSONDescriberInfo info)
/*     */   {
/* 473 */     return getResponseType(attrDef, attrDef.getUIHelper(), localeContext, info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<ResourceDescriber.Action, String[]> getResponseType(JUCtrlValueBinding valb, JSONDescriberInfo info)
/*     */   {
/* 484 */     AttributeDef attrDef = valb.getAttributeDef();
/* 485 */     return getResponseType(attrDef, valb.getCurrentRow().getAttributeHints(attrDef.getName()), valb.getLocaleContext(), info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<ResourceDescriber.Action, String[]> getRequestType(JUCtrlValueBinding valb, JSONDescriberInfo info)
/*     */   {
/* 496 */     AttributeDef attrDef = valb.getAttributeDef();
/* 497 */     return getRequestType(attrDef, valb.getCurrentRow().getAttributeHints(attrDef.getName()), valb.getLocaleContext(), info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<ResourceDescriber.Action, String[]> getResponseType(AttributeDef attrDef, AttributeHints attrHints, LocaleContext localeContext, JSONDescriberInfo info)
/*     */   {
/* 513 */     Map<ResourceDescriber.Action, String[]> map = new HashMap(1);
/* 514 */     String contentTypeHint = attrHints.getHint(localeContext, "contentType");
/* 515 */     String[] responseType = RESPONSE_TYPE;
/* 516 */     if (contentTypeHint != null) {
/* 517 */       responseType = new String[] { contentTypeHint };
/*     */     }
/* 519 */     map.put(ResourceDescriber.Action.READ, responseType);
/* 520 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<ResourceDescriber.Action, String[]> getRequestType(AttributeDef attrDef, AttributeHints attrHints, LocaleContext localeContext, JSONDescriberInfo info)
/*     */   {
/* 535 */     Map<ResourceDescriber.Action, String[]> map = new HashMap();
/* 536 */     String contentTypeHint = attrHints.getHint(localeContext, "contentType");
/* 537 */     String[] requestType = REQUEST_TYPE;
/* 538 */     if (contentTypeHint != null) {
/* 539 */       requestType = new String[] { contentTypeHint };
/*     */     }
/* 541 */     map.put(ResourceDescriber.Action.CREATE, requestType);
/* 542 */     map.put(ResourceDescriber.Action.UPDATE, requestType);
/* 543 */     map.put(ResourceDescriber.Action.REPLACE, requestType);
/* 544 */     return map;
/*     */   }
/*     */   
/*     */   private void writeNumericTypeProperties(AttributeHints attributeHints, LocaleContext localeContext, JsonGenerator target, Map attrProperties) throws IOException
/*     */   {
/* 549 */     writeHintAttribute("minValue", "minValue", attributeHints, localeContext, target, attrProperties);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 556 */     writeHintAttribute("maxValue", "maxValue", attributeHints, localeContext, target, attrProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeCharTypeProperties(AttributeHints attributeHints, LocaleContext localeContext, JsonGenerator target, Map attrProperties)
/*     */     throws IOException
/*     */   {
/* 566 */     writeHintAttribute("minLength", "minLength", attributeHints, localeContext, target, attrProperties);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 573 */     writeHintAttribute("maxLength", "maxLength", attributeHints, localeContext, target, attrProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeHintAttribute(String hintName, String attributeName, AttributeHints attributeHints, LocaleContext localeContext, JsonGenerator target, Map attrProperties)
/*     */     throws IOException
/*     */   {
/* 583 */     String hintValue = (String)attrProperties.remove(hintName);
/* 584 */     if (hintValue == null) {
/* 585 */       hintValue = attributeHints.getHint(localeContext, hintName);
/*     */     }
/*     */     
/* 588 */     if (hintValue != null) {
/* 589 */       writeProperty(target, attributeName, hintValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private void filterProperties(Map properties)
/*     */   {
/* 595 */     for (String property : PROPERTIES_TO_FILTER) {
/* 596 */       properties.remove(property);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void describeLOV(AttributeDef attrDef, AttributeHints attributeHints, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info, Map<String, String> lovProperties)
/*     */     throws IOException
/*     */   {
/* 613 */     ListBindingDef bindingDef = attrDef.getListBindingDef();
/* 614 */     target.writeFieldName("lov");
/* 615 */     target.writeStartObject();
/*     */     
/* 617 */     target.writeStringField("childRef", bindingDef.getListVOName());
/*     */     
/* 619 */     target.writeArrayFieldStart("attributeMap");
/* 620 */     String[] allListAttrNames = bindingDef.getListAttrNames();
/*     */     
/* 622 */     String[] resourceAttrNames = bindingDef.getAttrNames();
/* 623 */     String[] lovAttrNames = (String[])Arrays.copyOf(allListAttrNames, resourceAttrNames.length);
/*     */     
/* 625 */     writeLOVAttributeMapEntries(target, resourceAttrNames, lovAttrNames, false);
/*     */     
/* 627 */     String[] resourceDerivedAttrNames = bindingDef.getDerivedAttrNames();
/* 628 */     if ((resourceDerivedAttrNames != null) && (resourceDerivedAttrNames.length > 0)) {
/* 629 */       String[] lovDerivedAttrNames = (String[])Arrays.copyOfRange(allListAttrNames, resourceAttrNames.length, allListAttrNames.length);
/* 630 */       writeLOVAttributeMapEntries(target, resourceDerivedAttrNames, lovDerivedAttrNames, true);
/*     */     }
/*     */     
/* 633 */     target.writeEndArray();
/*     */     
/* 635 */     target.writeArrayFieldStart("displayAttributes");
/* 636 */     writeArrayItems(bindingDef.getListDisplayAttrNames(), target);
/* 637 */     target.writeEndArray();
/*     */     
/* 639 */     String delimiter = bindingDef.getDelimiter();
/* 640 */     if ((delimiter != null) && (!delimiter.isEmpty())) {
/* 641 */       target.writeStringField("delimeter", delimiter);
/*     */     }
/*     */     
/* 644 */     DescriberInfo.LOVResourceInfo lOVResourceInfo = info.getLOVResourceInfo();
/* 645 */     if (lOVResourceInfo != null) {
/* 646 */       writeLOVResource(target, lOVResourceInfo);
/*     */     }
/*     */     
/* 649 */     target.writeEndObject();
/*     */   }
/*     */   
/*     */   private void writeLOVResource(JsonGenerator target, DescriberInfo.LOVResourceInfo lovInfo) throws IOException {
/* 653 */     target.writeArrayFieldStart("lovResourcePath");
/*     */     
/* 655 */     for (DescriberInfo.LOVResourceInfo.DescribeLOVResourcePathItem pathItem : lovInfo.getLOVResourcePath()) {
/* 656 */       target.writeStartObject();
/* 657 */       target.writeStringField("resource", pathItem.getResourceName());
/* 658 */       if (pathItem.getFinderName() != null) {
/* 659 */         target.writeStringField("filter", createLOVResourceFilterValue(pathItem.getFinderName(), pathItem.getFinderParameters()));
/*     */       }
/* 661 */       target.writeEndObject();
/*     */     }
/* 663 */     target.writeEndArray();
/*     */   }
/*     */   
/*     */   private void writeArrayItems(String[] arrayItems, JsonGenerator target)
/*     */     throws IOException
/*     */   {
/* 669 */     if (arrayItems == null) {
/* 670 */       return;
/*     */     }
/* 672 */     for (String attrName : arrayItems) {
/* 673 */       target.writeString(attrName);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeLOVAttributeMapEntries(JsonGenerator target, String[] resourceAttrs, String[] lovAttrs, boolean derived) throws IOException {
/* 678 */     for (int i = 0; i < resourceAttrs.length; i++) {
/* 679 */       target.writeStartObject();
/* 680 */       target.writeStringField("source", lovAttrs[i]);
/* 681 */       target.writeStringField("target", resourceAttrs[i]);
/* 682 */       if (derived) {
/* 683 */         target.writeBooleanField("derived", true);
/*     */       }
/* 685 */       target.writeEndObject();
/*     */     }
/*     */   }
/*     */   
/*     */   private String createLOVResourceFilterValue(String finderName, Map<String, String> finderParameters) {
/* 690 */     String prefix = "?finder=";
/* 691 */     StringBuilder finderValue = new StringBuilder();
/* 692 */     finderValue.append(finderName);
/*     */     
/* 694 */     if (!finderParameters.isEmpty()) {
/* 695 */       finderValue.append(";");
/* 696 */       for (Map.Entry<String, String> entry : finderParameters.entrySet()) {
/* 697 */         finderValue.append((String)entry.getKey());
/* 698 */         finderValue.append("=");
/* 699 */         finderValue.append((String)entry.getValue());
/* 700 */         finderValue.append(",");
/*     */       }
/*     */       
/* 703 */       finderValue.delete(finderValue.length() - 1, finderValue.length());
/*     */     }
/*     */     
/* 706 */     return "?finder=" + RestURLEncoder.encodeSegment(finderValue.toString());
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\describer\json\JSONValueDescriber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */