/*     */ package oracle.adf.model.rest.core.describer.json;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.common.JBOClass;
/*     */ import oracle.jbo.common.JboTypeMap;
/*     */ import oracle.jbo.domain.LobStreamInterface;
/*     */ import oracle.jbo.server.AttributeDefImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONTypeMap
/*     */ {
/*     */   private static final Map<JSONType, Class> jsonToJavaTypeMap;
/*     */   private static final Set<String> booleanPropertySets;
/*     */   private static final String BOOLEAN_10_PROPERTY_SET_NAME = "oracle.jbo.valuemaps.Boolean10PropertySet";
/*     */   private static final String BOOLEAN_TF_PROPERTY_SET_NAME = "oracle.jbo.valuemaps.BooleanTFPropertySet";
/*     */   private static final String BOOLEAN_YN_PROPERTY_SET_NAME = "oracle.jbo.valuemaps.BooleanYNPropertySet";
/*     */   
/*     */   public static enum JSONType
/*     */   {
/*  31 */     ARRAY, 
/*  32 */     BOOLEAN, 
/*  33 */     INTEGER, 
/*  34 */     NUMBER, 
/*  35 */     STRING, 
/*  36 */     OBJECT, 
/*  37 */     LOB;
/*     */     
/*     */     private JSONType() {}
/*  40 */     public String toString() { return name().toLowerCase(); }
/*     */   }
/*     */   
/*     */ 
/*     */   static
/*     */   {
/*  46 */     Set<String> set = new HashSet(3);
/*  47 */     set.add("oracle.jbo.valuemaps.Boolean10PropertySet");
/*  48 */     set.add("oracle.jbo.valuemaps.BooleanTFPropertySet");
/*  49 */     set.add("oracle.jbo.valuemaps.BooleanYNPropertySet");
/*  50 */     booleanPropertySets = Collections.unmodifiableSet(set);
/*     */     
/*  52 */     Map<JSONType, Class> map = new HashMap(7);
/*  53 */     map.put(JSONType.ARRAY, List.class);
/*  54 */     map.put(JSONType.BOOLEAN, Boolean.class);
/*  55 */     map.put(JSONType.INTEGER, Integer.class);
/*  56 */     map.put(JSONType.NUMBER, Number.class);
/*  57 */     map.put(JSONType.STRING, String.class);
/*  58 */     map.put(JSONType.OBJECT, Object.class);
/*  59 */     map.put(JSONType.LOB, LobStreamInterface.class);
/*  60 */     jsonToJavaTypeMap = Collections.unmodifiableMap(map);
/*     */   }
/*     */   
/*     */   public static Class getJavaType(String jsonType) {
/*  64 */     return (Class)jsonToJavaTypeMap.get(JSONType.valueOf(jsonType));
/*     */   }
/*     */   
/*     */   public static JSONType getJSONType(String className) throws ClassNotFoundException {
/*  68 */     Class clazz = JBOClass.forName(className);
/*  69 */     return getJSONType(clazz);
/*     */   }
/*     */   
/*     */   public static JSONType getJSONType(Class clazz) throws ClassNotFoundException {
/*  73 */     int sqlTypeId = JboTypeMap.javaTypeToSQLTypeId(clazz.getName());
/*  74 */     return getJSONType(sqlTypeId, clazz, null);
/*     */   }
/*     */   
/*     */   public static JSONType getJSONType(AttributeDef attrDef) {
/*  78 */     if (isMappedBoolean(attrDef)) {
/*  79 */       return JSONType.BOOLEAN;
/*     */     }
/*  81 */     int attrSqlType = attrDef.getSQLType();
/*  82 */     if (attrSqlType == -1)
/*     */     {
/*  84 */       attrSqlType = JboTypeMap.javaTypeToSQLTypeId(attrDef.getJavaType().getName());
/*     */     }
/*     */     
/*  87 */     return getJSONType(attrSqlType, attrDef.getJavaType(), Integer.valueOf(attrDef.getScale()));
/*     */   }
/*     */   
/*     */   public static boolean isMappedBoolean(AttributeDef attrDef) {
/*  91 */     boolean mappedBoolean = false;
/*  92 */     if ((attrDef instanceof AttributeDefImpl)) {
/*  93 */       String valueMapPropertySet = ((AttributeDefImpl)attrDef).getTypeValueMapPropertySet();
/*  94 */       if (valueMapPropertySet != null) {
/*  95 */         mappedBoolean = booleanPropertySets.contains(valueMapPropertySet);
/*     */       }
/*     */     }
/*  98 */     return mappedBoolean;
/*     */   }
/*     */   
/*     */   private static JSONType getJSONType(int attrSqlType, Class javaType, Integer scale) {
/* 102 */     if (javaType.equals(Boolean.class)) {
/* 103 */       return JSONType.BOOLEAN;
/*     */     }
/*     */     
/* 106 */     if ((javaType != null) && (LobStreamInterface.class.isAssignableFrom(javaType))) {
/* 107 */       return JSONType.LOB;
/*     */     }
/*     */     
/* 110 */     if (JboTypeMap.isNumericType(attrSqlType)) {
/* 111 */       if ((scale != null) && (scale.intValue() <= 0)) {
/* 112 */         return JSONType.INTEGER;
/*     */       }
/* 114 */       return JSONType.NUMBER;
/*     */     }
/*     */     
/* 117 */     if ((JboTypeMap.isCharType(attrSqlType)) || (JboTypeMap.isDateType(attrSqlType))) {
/* 118 */       return JSONType.STRING;
/*     */     }
/*     */     
/* 121 */     return JSONType.OBJECT;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\describer\json\JSONTypeMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */