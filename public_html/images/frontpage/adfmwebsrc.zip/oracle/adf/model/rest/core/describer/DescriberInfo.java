/*     */ package oracle.adf.model.rest.core.describer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import oracle.adf.model.rest.LOVResource;
/*     */ import oracle.adf.model.rest.LOVResourcePathItem;
/*     */ import oracle.adf.model.rest.RestTypeConverter;
/*     */ import oracle.jbo.ApplicationModule;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeHints;
/*     */ import oracle.jbo.ExprEval;
/*     */ import oracle.jbo.Session;
/*     */ import oracle.jbo.Variable;
/*     */ import oracle.jbo.VariableValueManager;
/*     */ import oracle.jbo.ViewObject;
/*     */ import oracle.jbo.common.ListBindingDef;
/*     */ import oracle.jbo.server.BoundParameter;
/*     */ import oracle.jbo.server.RowFinder;
/*     */ import oracle.jbo.server.ViewAccessorDef;
/*     */ import oracle.jbo.server.ViewAttributeDefImpl;
/*     */ import oracle.jbo.server.ViewObjectImpl;
/*     */ 
/*     */ 
/*     */ public abstract class DescriberInfo
/*     */   extends HashMap<String, Object>
/*     */ {
/*     */   public DescriberInfo(int initialCapacity)
/*     */   {
/*  34 */     super(initialCapacity);
/*     */   }
/*     */   
/*     */   public DescriberInfo(int initialCapacity, float loadFactor) {
/*  38 */     super(initialCapacity, loadFactor);
/*     */   }
/*     */   
/*     */   public DescriberInfo(Map<? extends String, ? extends Object> m) {
/*  42 */     super(m);
/*     */   }
/*     */   
/*     */   public final void setLOVInfo(LOVResourceInfo lovInfo) {
/*  46 */     put("LOVInfo", lovInfo);
/*     */   }
/*     */   
/*     */   public final LOVResourceInfo getLOVResourceInfo() {
/*  50 */     return (LOVResourceInfo)get("LOVInfo");
/*     */   }
/*     */   
/*     */   public static final class LOVResourceInfo
/*     */   {
/*     */     private final List<DescribeLOVResourcePathItem> lovResourcePath;
/*     */     
/*     */     private static List<LOVResourcePathItem> getResourcePathItems(AttributeDef attrDef) {
/*  58 */       LOVResource lovResource = LOVResource.lookupLOVResource(attrDef);
/*  59 */       List<LOVResourcePathItem> items = Collections.emptyList();
/*  60 */       items = lovResource == null ? items : lovResource.getItems();
/*  61 */       return items;
/*     */     }
/*     */     
/*     */     public LOVResourceInfo(AttributeDef attrDef, ViewObject vo, ViewObject topLevelResourceLOVVo) {
/*  65 */       List<LOVResourcePathItem> resourceFinderPairs = getResourcePathItems(attrDef);
/*  66 */       List<DescribeLOVResourcePathItem> resourcePath = new ArrayList(resourceFinderPairs.size());
/*     */       
/*  68 */       ViewObjectImpl currentResourceLOVVo = null;
/*  69 */       ViewAttributeDefImpl currentAttributeWithLOV = null;
/*  70 */       for (int i = 0; i < resourceFinderPairs.size(); i++)
/*     */       {
/*  72 */         LOVResourcePathItem resourceFinderPair = (LOVResourcePathItem)resourceFinderPairs.get(i);
/*  73 */         String resourceName = resourceFinderPair.getResource();
/*  74 */         String finderName = resourceFinderPair.getFinder();
/*     */         
/*  76 */         if (currentResourceLOVVo == null) {
/*  77 */           currentResourceLOVVo = (ViewObjectImpl)topLevelResourceLOVVo;
/*     */         } else {
/*  79 */           currentResourceLOVVo = (ViewObjectImpl)currentResourceLOVVo.findAttributeDef(resourceName).getAccessorVO(currentResourceLOVVo);
/*     */         }
/*     */         
/*     */ 
/*  83 */         currentAttributeWithLOV = getAttributeDefForFinderPair((ViewAttributeDefImpl)attrDef, vo, resourceFinderPairs, i);
/*     */         
/*     */ 
/*  86 */         Map<String, String> finderParameters = Collections.emptyMap();
/*  87 */         if (currentAttributeWithLOV != null) {
/*  88 */           List<LOVResourcePathItem> currentAttributeResourceFinderPairs = getResourcePathItems(currentAttributeWithLOV);
/*  89 */           finderName = ((LOVResourcePathItem)currentAttributeResourceFinderPairs.get(currentAttributeResourceFinderPairs.size() - 1)).getFinder();
/*  90 */           finderParameters = getFinderParametersForLOV((ViewObjectImpl)vo, currentAttributeWithLOV, currentResourceLOVVo, finderName);
/*     */         }
/*     */         
/*  93 */         resourcePath.add(new DescribeLOVResourcePathItem(resourceName, currentResourceLOVVo, finderName, finderParameters));
/*     */       }
/*  95 */       this.lovResourcePath = Collections.unmodifiableList(resourcePath);
/*     */     }
/*     */     
/*     */     private static ViewAttributeDefImpl getAttributeDefForFinderPair(ViewAttributeDefImpl attrDef, ViewObject vo, List<LOVResourcePathItem> resourceFinderPairs, int finderIndex)
/*     */     {
/* 100 */       if (finderIndex == resourceFinderPairs.size() - 1) {
/* 101 */         return attrDef;
/*     */       }
/* 103 */       Set<String> dependencies = ((ViewObjectImpl)vo).getBackwardDependencies(attrDef.getName());
/* 104 */       if ((dependencies != null) && (dependencies.size() > 0))
/*     */       {
/* 106 */         for (String attrName : dependencies) {
/* 107 */           ViewAttributeDefImpl masterLOVAttr = (ViewAttributeDefImpl)vo.lookupAttributeDef(attrName);
/* 108 */           if ((masterLOVAttr.getLOVName() != null) && (matchesLOVFinderPath(masterLOVAttr, resourceFinderPairs, finderIndex))) {
/* 109 */             return masterLOVAttr;
/*     */           }
/*     */         }
/*     */       }
/* 113 */       return null;
/*     */     }
/*     */     
/*     */     private static boolean matchesLOVFinderPath(ViewAttributeDefImpl attrDef, List<LOVResourcePathItem> resourceFinderPairs, int finderIndex) {
/* 117 */       List<LOVResourcePathItem> resourceFindersToMatch = getResourcePathItems(attrDef);
/*     */       
/* 119 */       if (resourceFindersToMatch.size() != finderIndex + 1)
/* 120 */         return false;
/* 121 */       for (int i = 0; i <= finderIndex; i++)
/*     */       {
/*     */ 
/* 124 */         String argResourceName = ((LOVResourcePathItem)resourceFinderPairs.get(i)).getResource();
/* 125 */         String argFinderName = ((LOVResourcePathItem)resourceFinderPairs.get(i)).getFinder();
/* 126 */         String compareResourceName = ((LOVResourcePathItem)resourceFindersToMatch.get(i)).getResource();
/* 127 */         String compareFinderName = ((LOVResourcePathItem)resourceFindersToMatch.get(i)).getFinder();
/* 128 */         if ((argFinderName == null) && (!argResourceName.equals(compareResourceName)))
/*     */         {
/* 130 */           return false;
/*     */         }
/* 132 */         if (argFinderName != null) if (((argResourceName.equals(compareResourceName)) && (argFinderName.equals(compareFinderName)) ? 1 : 0) == 0)
/*     */           {
/* 134 */             return false;
/*     */           }
/*     */       }
/* 137 */       return true;
/*     */     }
/*     */     
/*     */     private static Map<String, String> getFinderParametersForLOV(ViewObjectImpl vo, AttributeDef attrDef, ViewObjectImpl finderVO, String finderName)
/*     */     {
/* 142 */       String lbName = attrDef.getLOVName();
/* 143 */       if (lbName != null) {
/* 144 */         ListBindingDef lb = vo.lookupListBindingDef(lbName);
/* 145 */         Set<String> finderParams = getVisibleParamsForFinder(finderVO, finderName);
/* 146 */         if (finderParams.size() > 0) {
/* 147 */           ViewAccessorDef accessor = vo.findViewAccessorDef(lb.getListVOName());
/* 148 */           ViewObjectImpl accessorVO = (ViewObjectImpl)vo.lookupAttributeDef(accessor.getName()).getAccessorVO(vo);
/*     */           
/* 150 */           Map<String, String> accessorParams = getLiteralMappedParamsForAccessor(accessorVO, accessor);
/* 151 */           Map<String, String> exposedFinderParams = new HashMap(finderParams.size());
/* 152 */           for (String finderParamName : finderParams) {
/* 153 */             String literalValue = (String)accessorParams.get(finderParamName);
/* 154 */             if (literalValue != null) {
/* 155 */               exposedFinderParams.put(finderParamName, literalValue);
/*     */             }
/*     */           }
/* 158 */           return exposedFinderParams;
/*     */         }
/*     */       }
/* 161 */       return Collections.emptyMap();
/*     */     }
/*     */     
/*     */     private static Set<String> getVisibleParamsForFinder(ViewObjectImpl vo, String finderName) {
/* 165 */       RowFinder finder = vo.lookupRowFinder(finderName);
/* 166 */       Set<String> mappableParams = Collections.emptySet();
/* 167 */       ArrayList<BoundParameter> finderParams = finder.getRowFinderParameterList(true);
/* 168 */       if ((finderParams != null) && (finderParams.size() > 0)) {
/* 169 */         mappableParams = new HashSet(finderParams.size());
/* 170 */         for (BoundParameter p : finderParams) {
/* 171 */           Variable v = vo.ensureVariableManager().lookupVariable(p.getName());
/* 172 */           if (v.getUIHelper().getPayloadHint(vo.getApplicationModule().getSession().getLocaleContext()) != "Hide")
/*     */           {
/* 174 */             mappableParams.add(v.getName());
/*     */           }
/*     */         }
/*     */       }
/* 178 */       return mappableParams;
/*     */     }
/*     */     
/*     */     private static Map<String, String> getLiteralMappedParamsForAccessor(ViewObjectImpl accessorVO, ViewAccessorDef va)
/*     */     {
/* 183 */       Map<String, String> mappedParams = Collections.emptyMap();
/* 184 */       List<BoundParameter> parameters = va.getBoundParameterList();
/* 185 */       if ((parameters != null) && (parameters.size() > 0)) {
/* 186 */         mappedParams = new HashMap(parameters.size());
/* 187 */         for (BoundParameter p : parameters) {
/* 188 */           Object literalValue = getLiteralValue(p);
/* 189 */           if (literalValue != null) {
/* 190 */             String stringValue = RestTypeConverter.toPayloadType(literalValue, accessorVO.ensureVariableManager().lookupVariable(p.getName())).toString();
/* 191 */             mappedParams.put(p.getName(), stringValue);
/*     */           }
/*     */         }
/*     */       }
/* 195 */       return mappedParams;
/*     */     }
/*     */     
/*     */     private static Object getLiteralValue(BoundParameter p) {
/*     */       try {
/* 200 */         return p.getExprEval().evaluate(null);
/*     */       } catch (Throwable t) {}
/* 202 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public List<DescribeLOVResourcePathItem> getLOVResourcePath()
/*     */     {
/* 208 */       return this.lovResourcePath;
/*     */     }
/*     */     
/*     */     public static final class DescribeLOVResourcePathItem {
/*     */       private final String resourceName;
/*     */       private final String finderName;
/*     */       private final Map<String, String> finderParameters;
/*     */       private final ViewObjectImpl finderOwner;
/*     */       
/*     */       public DescribeLOVResourcePathItem(String resourceName, ViewObjectImpl finderOwner, String finderName, Map<String, String> finderParameters) {
/* 218 */         this.resourceName = resourceName;
/* 219 */         this.finderOwner = finderOwner;
/* 220 */         this.finderName = finderName;
/* 221 */         this.finderParameters = finderParameters;
/*     */       }
/*     */       
/*     */       public String getResourceName()
/*     */       {
/* 226 */         return this.resourceName;
/*     */       }
/*     */       
/*     */       public String getFinderName() {
/* 230 */         return this.finderName;
/*     */       }
/*     */       
/*     */       public Map<String, String> getFinderParameters() {
/* 234 */         return this.finderParameters;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\describer\DescriberInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */