package oracle.adf.model.rest.core.serializer;

public enum ValueSerializerType
{
  VALUE,  LINK;
  
  private ValueSerializerType() {}
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\ValueSerializerType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */