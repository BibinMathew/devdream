/*    */ package oracle.adf.model.rest.core.serializer;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ValueSerializerInfo
/*    */   extends HashMap<String, Object>
/*    */ {
/*    */   private static final long serialVersionUID = -7234406701320130343L;
/*    */   
/*    */   public ValueSerializerInfo()
/*    */   {
/* 15 */     super(1);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\ValueSerializerInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */