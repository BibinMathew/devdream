/*     */ package oracle.adf.model.rest.core.describer.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import oracle.adf.model.rest.core.describer.ResourceDescriber.Action;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.AttributeHints;
/*     */ import oracle.jbo.LocaleContext;
/*     */ import oracle.jbo.Row;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONStreamDescriber
/*     */   extends JSONValueDescriber
/*     */ {
/*     */   public JSONStreamDescriber() {}
/*     */   
/*     */   public JSONStreamDescriber(Map<String, Object> overriddenProperties)
/*     */   {
/*  37 */     super(overriddenProperties);
/*     */   }
/*     */   
/*     */   protected final void describeCatalogActions(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*     */     throws IOException
/*     */   {
/*  43 */     Map<ResourceDescriber.Action, String[]> responseType = getCatalogResponseType(attrDef, localeContext, info);
/*  44 */     Map<ResourceDescriber.Action, String[]> requestType = getCatalogRequestType(attrDef, localeContext, info);
/*     */     
/*  46 */     describeStreamActions(attrDef, attrDef.getUIHelper(), responseType, requestType, target);
/*     */   }
/*     */   
/*     */   protected final void describeActions(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info)
/*     */     throws IOException
/*     */   {
/*  52 */     Map<ResourceDescriber.Action, String[]> responseType = getResponseType(valb, info);
/*  53 */     Map<ResourceDescriber.Action, String[]> requestType = getRequestType(valb, info);
/*  54 */     AttributeDef attrDef = valb.getAttributeDef();
/*  55 */     describeStreamActions(attrDef, valb.getCurrentRow().getAttributeHints(attrDef.getName()), responseType, requestType, target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void describeStreamActions(AttributeDef attrDef, AttributeHints attrHints, Map<ResourceDescriber.Action, String[]> responseType, Map<ResourceDescriber.Action, String[]> requestType, JsonGenerator target)
/*     */     throws IOException
/*     */   {
/*  73 */     ArrayList<HashMap<String, Object>> actions = null;
/*     */     
/*  75 */     HashMap<String, Object> readActionProperties = new LinkedHashMap(3);
/*  76 */     readActionProperties.put("name", ResourceDescriber.Action.READ.toString());
/*  77 */     readActionProperties.put("method", ResourceDescriber.Action.READ.getHttpMethod());
/*  78 */     readActionProperties.put("responseType", responseType.get(ResourceDescriber.Action.READ));
/*     */     
/*  80 */     if (attrDef.getUpdateableFlag() == 2) {
/*  81 */       HashMap<String, Object> replaceActionProperties = new LinkedHashMap(3);
/*  82 */       replaceActionProperties.put("name", ResourceDescriber.Action.REPLACE.toString());
/*  83 */       replaceActionProperties.put("method", ResourceDescriber.Action.REPLACE.getHttpMethod());
/*  84 */       replaceActionProperties.put("requestType", requestType.get(ResourceDescriber.Action.REPLACE));
/*     */       
/*  86 */       HashMap<String, Object> deleteActionProperties = new LinkedHashMap(2);
/*  87 */       deleteActionProperties.put("name", ResourceDescriber.Action.DELETE.toString());
/*  88 */       deleteActionProperties.put("method", ResourceDescriber.Action.DELETE.getHttpMethod());
/*     */       
/*  90 */       actions = new ArrayList(2);
/*  91 */       actions.add(replaceActionProperties);
/*  92 */       actions.add(deleteActionProperties);
/*     */     } else {
/*  94 */       actions = new ArrayList(1);
/*     */     }
/*  96 */     actions.add(readActionProperties);
/*     */     
/*  98 */     serializeActions(actions, target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final String getCatalogSerializedObjectType(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*     */   {
/* 105 */     return "attachment";
/*     */   }
/*     */   
/*     */   protected final String getSerializedObjectType(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info)
/*     */   {
/* 110 */     return "attachment";
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\describer\json\JSONStreamDescriber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */