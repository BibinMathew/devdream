/*     */ package oracle.adf.model.rest.core.serializer.stream;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import oracle.adf.internal.model.rest.core.state.StateIdBuilder;
/*     */ import oracle.adf.internal.model.rest.core.state.StateIdBuilderFactory;
/*     */ import oracle.adf.model.rest.core.serializer.ResourceStreamSerializer;
/*     */ import oracle.adf.model.rest.core.serializer.StreamSerializerInfo;
/*     */ import oracle.jbo.AttributeDef;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.Row;
/*     */ import oracle.jbo.domain.LobStreamInterface;
/*     */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseResourceStreamSerializer
/*     */   implements ResourceStreamSerializer
/*     */ {
/*     */   private static final String ATTR_HINT_CONTENT_TYPE = "contentType";
/*  28 */   protected static final String[] REQUEST_TYPES = { "application/octet-stream" };
/*     */   
/*     */   protected static final int DEFAULT_BUFFER_SIZE = 1024;
/*     */   
/*     */   private final Map<String, Object> defaultProperties;
/*     */   
/*     */   public BaseResourceStreamSerializer()
/*     */   {
/*  36 */     this.defaultProperties = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseResourceStreamSerializer(Map<String, Object> defaultProperties)
/*     */   {
/*  45 */     this.defaultProperties = new HashMap(defaultProperties);
/*     */   }
/*     */   
/*     */ 
/*     */   public void serializeStream(JUCtrlValueBinding valb, OutputStream target, StreamSerializerInfo info)
/*     */   {
/*  51 */     LobStreamInterface lobAttr = (LobStreamInterface)valb.getAttribute();
/*     */     
/*  53 */     if (lobAttr == null) {
/*  54 */       return;
/*     */     }
/*     */     
/*  57 */     InputStream in = null;
/*     */     try {
/*     */       try {
/*  60 */         in = lobAttr.getInputStream();
/*  61 */         int len = 0;
/*  62 */         byte[] buffer = new byte[getBufferSize()];
/*  63 */         while ((len = in.read(buffer)) != -1) {
/*  64 */           target.write(buffer, 0, len);
/*     */         }
/*     */       } finally {
/*  67 */         if (in != null) {
/*  68 */           lobAttr.closeInputStream();
/*     */         }
/*     */       }
/*     */     } catch (Exception ex) {
/*  72 */       throw new JboException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void deserializeStream(JUCtrlValueBinding valb, InputStream source, StreamSerializerInfo info)
/*     */   {
/*  80 */     LobStreamInterface lobAttr = (LobStreamInterface)valb.getAttribute();
/*  81 */     Row row = valb.getCurrentRow();
/*     */     
/*  83 */     row.lock();
/*  84 */     if (lobAttr == null) {
/*     */       try {
/*  86 */         lobAttr = (LobStreamInterface)valb.getAttributeDef().getJavaType().newInstance();
/*     */       } catch (Exception e) {
/*  88 */         throw new JboException(e);
/*     */       }
/*  90 */       row.setAttribute(valb.getName(), lobAttr);
/*     */     }
/*     */     
/*  93 */     OutputStream out = null;
/*     */     try {
/*     */       try {
/*  96 */         out = lobAttr.getOutputStream();
/*  97 */         int len = 0;
/*  98 */         byte[] buffer = new byte[getBufferSize()];
/*  99 */         while ((len = source.read(buffer)) != -1) {
/* 100 */           out.write(buffer, 0, len);
/*     */         }
/*     */       } finally {
/* 103 */         if (out != null) {
/* 104 */           lobAttr.closeOutputStream();
/*     */         }
/*     */       }
/*     */     } catch (Exception ex) {
/* 108 */       throw new JboException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getBufferSize()
/*     */   {
/* 118 */     return 1024;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StreamSerializerInfo getStreamInfo(JUCtrlValueBinding valb)
/*     */   {
/* 129 */     StreamSerializerInfo info = new StreamSerializerInfo();
/* 130 */     if (this.defaultProperties != null) {
/* 131 */       info.putAll(this.defaultProperties);
/*     */     }
/* 133 */     if (info.getContentType() == null) {
/* 134 */       String contentTypeHint = valb.getHint("contentType");
/* 135 */       String responseType = "application/octet-stream";
/* 136 */       if (contentTypeHint != null) {
/* 137 */         responseType = contentTypeHint;
/*     */       }
/* 139 */       info.setContentType(responseType);
/*     */     }
/* 141 */     if (info.getStateId() == null) {
/* 142 */       info.setStateId(StateIdBuilderFactory.getInstance().createStateId(valb));
/*     */     }
/*     */     
/* 145 */     return info;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\stream\BaseResourceStreamSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */