/*    */ package oracle.adf.model.rest.core.describer.json;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import oracle.adf.model.rest.core.describer.ResourceDescriber.Action;
/*    */ import oracle.jbo.AttributeDef;
/*    */ import oracle.jbo.JboException;
/*    */ import oracle.jbo.LocaleContext;
/*    */ import oracle.jbo.uicli.binding.JUCtrlValueBinding;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSONLinkDescriber
/*    */   extends JSONValueDescriber
/*    */ {
/*    */   public JSONLinkDescriber() {}
/*    */   
/*    */   public JSONLinkDescriber(Map<String, Object> overriddenProperties)
/*    */   {
/* 37 */     super(overriddenProperties);
/*    */   }
/*    */   
/*    */   protected final void describeActions(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info) throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 44 */       Map<ResourceDescriber.Action, String[]> responseType = getResponseType(valb, info);
/* 45 */       describeLinkActions(responseType, target);
/*    */     } catch (IOException e) {
/* 47 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected final void describeCatalogActions(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info) throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 55 */       Map<ResourceDescriber.Action, String[]> responseTypes = getCatalogResponseType(attrDef, localeContext, info);
/* 56 */       describeLinkActions(responseTypes, target);
/*    */     } catch (IOException e) {
/* 58 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void describeLinkActions(Map<ResourceDescriber.Action, String[]> responseType, JsonGenerator target)
/*    */     throws IOException
/*    */   {
/* 70 */     ArrayList<HashMap<String, Object>> actions = new ArrayList(1);
/*    */     
/* 72 */     HashMap<String, Object> readActionProperties = new LinkedHashMap(3);
/* 73 */     readActionProperties.put("name", ResourceDescriber.Action.READ.toString());
/* 74 */     readActionProperties.put("method", ResourceDescriber.Action.READ.getHttpMethod());
/* 75 */     readActionProperties.put("responseType", responseType.get(ResourceDescriber.Action.READ));
/*    */     
/* 77 */     actions.add(readActionProperties);
/*    */     
/* 79 */     serializeActions(actions, target);
/*    */   }
/*    */   
/*    */ 
/*    */   protected final String getCatalogSerializedObjectType(AttributeDef attrDef, LocaleContext localeContext, JsonGenerator target, JSONDescriberInfo info)
/*    */   {
/* 85 */     return "URL";
/*    */   }
/*    */   
/*    */   protected final String getSerializedObjectType(JUCtrlValueBinding valb, JsonGenerator target, JSONDescriberInfo info)
/*    */   {
/* 90 */     return "URL";
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\describer\json\JSONLinkDescriber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */