/*    */ package oracle.adf.model.rest.core.describer.json;
/*    */ 
/*    */ import oracle.adf.model.rest.core.describer.DescriberInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSONDescriberInfo
/*    */   extends DescriberInfo
/*    */ {
/*    */   public JSONDescriberInfo()
/*    */   {
/* 12 */     super(1);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\describer\json\JSONDescriberInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */