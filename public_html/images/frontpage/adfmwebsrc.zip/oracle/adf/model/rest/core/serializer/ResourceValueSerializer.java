package oracle.adf.model.rest.core.serializer;

import oracle.jbo.uicli.binding.JUCtrlValueBinding;

public abstract interface ResourceValueSerializer<S, T, I extends ValueSerializerInfo>
{
  public static final String LINK_OTHER_KIND = "other";
  public static final String LINK_EXTERNAL_REL = "external";
  public static final String LINK_REL_PROP = "rel";
  public static final String LINK_HREF_PROP = "href";
  public static final String LINK_NAME_PROP = "name";
  public static final String LINK_KIND_PROP = "kind";
  
  public abstract void serialize(JUCtrlValueBinding paramJUCtrlValueBinding, T paramT, I paramI);
  
  public abstract void serializeLink(JUCtrlValueBinding paramJUCtrlValueBinding, T paramT, I paramI);
  
  public abstract Object deserialize(JUCtrlValueBinding paramJUCtrlValueBinding, S paramS, I paramI);
  
  public abstract ValueSerializerType getType(JUCtrlValueBinding paramJUCtrlValueBinding, I paramI);
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\rest\core\serializer\ResourceValueSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */