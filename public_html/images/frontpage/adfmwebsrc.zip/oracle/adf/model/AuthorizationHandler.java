package oracle.adf.model;

public abstract interface AuthorizationHandler
{
  public abstract void handleAuthorizationFailure();
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\AuthorizationHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */