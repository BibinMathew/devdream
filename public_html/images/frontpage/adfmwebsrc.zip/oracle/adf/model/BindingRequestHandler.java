/*     */ package oracle.adf.model;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import oracle.adf.model.binding.DCBindingContainerDef;
/*     */ import oracle.adf.model.binding.DCUtil;
/*     */ import oracle.adf.model.dcframe.DataControlFrameImpl;
/*     */ import oracle.adf.share.ADFConfig;
/*     */ import oracle.adf.share.ADFConstants;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.ADFScope;
/*     */ import oracle.adf.share.Environment;
/*     */ import oracle.adf.share.mds.MDSTransManager;
/*     */ import oracle.adf.share.mds.MDSUtil;
/*     */ import oracle.adf.share.security.ADFSecurityUtil;
/*     */ import oracle.adf.share.security.AuthenticationService;
/*     */ import oracle.adf.share.security.SecurityContext;
/*     */ import oracle.adf.share.security.authentication.AuthenticationServiceUtil;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.SessionContext;
/*     */ import oracle.jbo.SessionContextManager;
/*     */ import oracle.jbo.common.Diagnostic;
/*     */ import oracle.jbo.common.JboStringUtil;
/*     */ import oracle.jbo.common.SessionContextManagerImpl;
/*     */ import oracle.jbo.http.ORDRegisterer;
/*     */ import oracle.jbo.pool.ResourcePoolManager;
/*     */ import oracle.jbo.server.ConnectionPoolManagerFactory;
/*     */ import oracle.jbo.uicli.mom.JUMetaObjectManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BindingRequestHandler
/*     */ {
/*     */   public static final String SESSION_INVALIDATE_BINDINGCONTAINER_DEF = "adf_session_invalidate_bindingcontainer_def";
/*  48 */   private static String SESSION_LOCK = "_session_lock_";
/*     */   
/*  50 */   private String mBindingContextDefName = null;
/*  51 */   private String mTargetEncoding = null;
/*  52 */   private String mUnauthorizedPage = null;
/*  53 */   private String mAuthorizationHandlerClassName = null;
/*  54 */   private boolean mSingleThreadedSession = false;
/*  55 */   private BindingContext mBindingContext = null;
/*  56 */   private boolean mInvokeBeginEndRequest = false;
/*  57 */   private ThreadLocal<Boolean> mTLSInvokeBeginEndRequest = new ThreadLocal()
/*     */   {
/*     */     protected Boolean initialValue()
/*     */     {
/*  61 */       return Boolean.valueOf(true);
/*     */     }
/*     */   };
/*  64 */   private long mSessionTimeout = -1L;
/*     */   
/*     */   public void setBindingContextDefName(String bindingContextDefName)
/*     */   {
/*  68 */     this.mBindingContextDefName = bindingContextDefName;
/*     */   }
/*     */   
/*     */   public void setSingleThreadedSession(boolean singleThreadedSession)
/*     */   {
/*  73 */     this.mSingleThreadedSession = singleThreadedSession;
/*     */   }
/*     */   
/*     */   public void setTargetEncoding(String targetEncoding)
/*     */   {
/*  78 */     this.mTargetEncoding = targetEncoding;
/*     */   }
/*     */   
/*     */   public void setUnauthorizedPage(String unauthorizedPage)
/*     */   {
/*  83 */     this.mUnauthorizedPage = unauthorizedPage;
/*     */   }
/*     */   
/*     */   public void setAuthorizationHandler(String authorizationHandlerClassName)
/*     */   {
/*  88 */     this.mAuthorizationHandlerClassName = authorizationHandlerClassName;
/*     */   }
/*     */   
/*     */   public void setSessionLockTimeOutPeriod(long timeout)
/*     */   {
/*  93 */     this.mSessionTimeout = timeout;
/*     */   }
/*     */   
/*     */   public boolean beginRequest()
/*     */   {
/*  98 */     ADFContext adfContext = initADFContext();
/*     */     
/* 100 */     adfContext.useLockedMDSSession();
/*     */     
/* 102 */     if (JUMetaObjectManager.isStatelessApplication())
/*     */     {
/*     */ 
/* 105 */       initMetadataContext();
/*     */     }
/*     */     
/* 108 */     MDSTransManager.beginFlushCurrentMDSSess();
/*     */     
/* 110 */     Serializable snapshot = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 115 */     SessionContextManagerImpl.getInstance().setCurrentSession(createSessionContext(adfContext));
/* 116 */     Map sessionScope = adfContext.getSessionScope();
/* 117 */     Map requestScope = adfContext.getRequestScope();
/* 118 */     Environment adfEnv = adfContext.getEnvironment();
/* 119 */     if (this.mTargetEncoding != null)
/*     */     {
/*     */       try
/*     */       {
/* 123 */         adfEnv.setRequestCharacterEncoding(this.mTargetEncoding);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 127 */         throw new JboException(e);
/*     */       }
/*     */     }
/* 130 */     boolean initializeSession = false;
/* 131 */     boolean sBoxStateCleared = false;
/*     */     
/*     */ 
/* 134 */     if (JUMetaObjectManager.isStatelessApplication())
/*     */     {
/* 136 */       this.mBindingContext = createBindingContext(adfContext);
/* 137 */       BindingContext.setCurrent(this.mBindingContext);
/* 138 */       this.mBindingContext.setLockTimeout(this.mSessionTimeout);
/* 139 */       initializeSession = true;
/*     */     }
/*     */     else
/*     */     {
/* 143 */       while (this.mBindingContext == null)
/*     */       {
/* 145 */         this.mBindingContext = BindingContext.getCurrent();
/* 146 */         if (this.mBindingContext == null)
/*     */         {
/* 148 */           synchronized (SESSION_LOCK)
/*     */           {
/* 150 */             this.mBindingContext = BindingContext.getCurrent();
/* 151 */             if (this.mBindingContext == null)
/*     */             {
/* 153 */               this.mBindingContext = createBindingContext(adfContext);
/* 154 */               BindingContext.setCurrent(this.mBindingContext);
/* 155 */               this.mBindingContext.setLockTimeout(this.mSessionTimeout);
/* 156 */               initializeSession = true;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */         DataControlFrameImpl currentFrame = null;
/*     */         
/* 168 */         boolean doSessionLocking = (this.mSingleThreadedSession) || (MDSUtil.isSboxStateCleanFlagSet());
/* 169 */         if (doSessionLocking)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */           this.mBindingContext.lock(this.mSessionTimeout);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */           currentFrame = this.mBindingContext.getCurrentFrame();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */           currentFrame.lock(this.mSessionTimeout);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */         if (this.mBindingContext != BindingContext.getCurrent())
/*     */         {
/* 209 */           if (this.mBindingContext != null)
/*     */           {
/* 211 */             if (doSessionLocking)
/*     */             {
/* 213 */               this.mBindingContext.unlock();
/*     */             }
/*     */             else
/*     */             {
/* 217 */               currentFrame.unlock();
/*     */             }
/*     */           }
/* 220 */           this.mBindingContext = null;
/*     */         }
/*     */         
/* 223 */         if ((MDSUtil.isSboxStateCleanFlagSet()) && (!sBoxStateCleared))
/*     */         {
/* 225 */           snapshot = DCUtil.clearSessStateForSandbox();
/*     */           
/*     */ 
/* 228 */           this.mBindingContext = null;
/*     */           
/*     */ 
/*     */ 
/* 232 */           sBoxStateCleared = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 238 */     if (initializeSession)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/* 244 */         ORDRegisterer.registerRenderer(sessionScope);
/*     */       }
/*     */       catch (NoClassDefFoundError noClass)
/*     */       {
/* 248 */         if (Diagnostic.isOn())
/*     */         {
/* 250 */           Diagnostic.println("**** FAILED To register ORDRegister");
/*     */         }
/*     */       }
/*     */     }
/* 254 */     this.mBindingContext.initialize(this.mBindingContextDefName);
/* 255 */     BindingContext.setCurrent(this.mBindingContext);
/*     */     
/*     */ 
/* 258 */     this.mBindingContext.touch();
/* 259 */     adfContext.getADFConfig();
/* 260 */     if (snapshot != null)
/*     */     {
/* 262 */       this.mBindingContext.restoreSnapshot(snapshot);
/* 263 */       this.mBindingContext.removeSnapshot(snapshot);
/*     */     }
/*     */     
/* 266 */     if (sBoxStateCleared)
/*     */     {
/*     */ 
/*     */ 
/* 270 */       MDSUtil.clearSboxStateCleanFlag();
/*     */     }
/*     */     
/* 273 */     this.mInvokeBeginEndRequest = ((Boolean)this.mTLSInvokeBeginEndRequest.get()).booleanValue();
/* 274 */     this.mTLSInvokeBeginEndRequest.set(Boolean.valueOf(false));
/* 275 */     if (this.mInvokeBeginEndRequest)
/*     */     {
/* 277 */       invokeBeginRequest(adfContext);
/*     */     }
/* 279 */     if (!isPageViewable())
/*     */     {
/* 281 */       if (!adfContext.getSecurityContext().isAuthenticated())
/*     */       {
/* 283 */         String successURL = adfEnv.getRequestURI();
/* 284 */         String queryString = adfEnv.getRequestQueryString();
/* 285 */         if (queryString != null)
/*     */         {
/* 287 */           successURL = successURL + '?' + queryString;
/*     */         }
/* 289 */         successURL = adfEnv.encodeResourceURL(successURL);
/* 290 */         sessionScope.put(ADFConstants.AUTH_SUCCESS_URL, successURL);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 295 */         AuthenticationService authService = AuthenticationServiceUtil.getAuthenticationService();
/*     */         
/* 297 */         if (authService != null)
/*     */         {
/* 299 */           String cancelUrl = (String)sessionScope.get(ADFConstants.AUTH_CANCEL_URL);
/* 300 */           authService.login(successURL, cancelUrl, null);
/* 301 */           return false;
/*     */         }
/*     */       }
/* 304 */       if ((this.mUnauthorizedPage != null) && (this.mUnauthorizedPage.length() > 0))
/*     */       {
/* 306 */         getDefaultAuthorizationHandler().redirect(this.mUnauthorizedPage);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 314 */         getAuthorizationHandler().handleAuthorizationFailure();
/*     */       }
/* 316 */       return false;
/*     */     }
/* 318 */     savePathInfo();
/* 319 */     return true;
/*     */   }
/*     */   
/*     */   public void endRequest()
/*     */   {
/*     */     try
/*     */     {
/* 326 */       MDSTransManager.reset();
/* 327 */       ADFContext adfContext = ADFContext.getCurrent();
/* 328 */       if (this.mInvokeBeginEndRequest)
/*     */       {
/* 330 */         invokeEndRequest(adfContext);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 337 */         if ((this.mBindingContext != null) && (JUMetaObjectManager.isStatelessApplication()))
/*     */         {
/* 339 */           this.mBindingContext.release();
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 344 */         if (this.mBindingContext != null)
/*     */         {
/* 346 */           this.mBindingContext.unlock();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 352 */           this.mBindingContext.getCurrentFrame().unlock();
/*     */         }
/*     */         
/* 355 */         this.mTLSInvokeBeginEndRequest.remove();
/* 356 */         SessionContextManagerImpl.getInstance().removeCurrentSession();
/* 357 */         JboStringUtil.reset();
/*     */         
/*     */ 
/* 360 */         resetADFContext();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isPageViewable()
/*     */   {
/* 378 */     if (this.mBindingContext == null)
/*     */     {
/* 380 */       return true;
/*     */     }
/* 382 */     Environment adfEnv = ADFContext.getCurrent().getEnvironment();
/*     */     
/* 384 */     String path = adfEnv.getRequestPathInfo();
/* 385 */     if ((path == null) || (path.length() == 0))
/*     */     {
/* 387 */       path = adfEnv.getRequestServletPath();
/*     */     }
/* 389 */     if ((path == null) || (path.length() == 0))
/*     */     {
/* 391 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 398 */     DCBindingContainerDef bcDef = this.mBindingContext.findBindingContainerDefByPath(path);
/*     */     
/* 400 */     if (bcDef == null)
/*     */     {
/* 402 */       return true;
/*     */     }
/* 404 */     Map sessionScope = ADFContext.getCurrent().getSessionScope();
/*     */     
/* 406 */     Object val = sessionScope.get("adf_session_invalidate_bindingcontainer_def");
/* 407 */     if (val != null)
/*     */     {
/* 409 */       JUMetaObjectManager.getJUMom().invalidateBindingContainerDef(this.mBindingContext, bcDef.getFullName());
/*     */       
/* 411 */       sessionScope.remove("adf_session_invalidate_bindingcontainer_def");
/*     */     }
/* 413 */     return bcDef.isViewAuthorized(this.mBindingContext);
/*     */   }
/*     */   
/*     */   private void invokeBeginRequest(ADFContext adfContext)
/*     */   {
/* 418 */     HashMap requestCtx = initializeContextForBeginRequest(adfContext, new HashMap(2));
/* 419 */     this.mBindingContext.beginRequest(adfContext, requestCtx);
/*     */   }
/*     */   
/*     */   private void invokeEndRequest(ADFContext adfContext)
/*     */   {
/* 424 */     HashMap requestCtx = initializeContextForEndRequest(adfContext, new HashMap(2));
/* 425 */     this.mBindingContext.endRequest(adfContext, requestCtx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HashMap initializeContextForBeginRequest(ADFContext adfContext, HashMap context)
/*     */   {
/* 436 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HashMap initializeContextForEndRequest(ADFContext adfContext, HashMap context)
/*     */   {
/* 447 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Properties initializeContextForDataControl(ADFContext adfContext, Properties context)
/*     */   {
/* 459 */     return context;
/*     */   }
/*     */   
/*     */   public static Object loadApplication()
/*     */   {
/* 464 */     return ADFContext.getCurrent().getApplication().getId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void destroyApplication(Object applicationContext)
/*     */   {
/* 516 */     ((ResourcePoolManager)ConnectionPoolManagerFactory.getConnectionPoolManager()).classLoaderShuttingDown();
/*     */   }
/*     */   
/*     */   AuthorizationHandler getAuthorizationHandler()
/*     */   {
/* 521 */     AuthorizationHandler authHandler = null;
/* 522 */     if (this.mAuthorizationHandlerClassName == null)
/*     */     {
/* 524 */       authHandler = getDefaultAuthorizationHandler();
/*     */     }
/*     */     else
/*     */     {
/* 528 */       authHandler = (AuthorizationHandler)DCUtil.createNewInstance(this.mAuthorizationHandlerClassName);
/*     */     }
/*     */     
/* 531 */     return authHandler;
/*     */   }
/*     */   
/*     */   AuthorizationHandlerImpl getDefaultAuthorizationHandler()
/*     */   {
/* 536 */     return new AuthorizationHandlerImpl();
/*     */   }
/*     */   
/*     */ 
/*     */   void savePathInfo()
/*     */   {
/* 542 */     if ((!ADFSecurityUtil.isAuthenticationRequired()) || (!ADFSecurityUtil.isSSO()))
/*     */     {
/* 544 */       return;
/*     */     }
/* 546 */     ADFContext adfContext = ADFContext.getCurrent();
/* 547 */     if (adfContext.getSecurityContext().isAuthenticated())
/*     */     {
/* 549 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 554 */       Environment adfEnv = adfContext.getEnvironment();
/* 555 */       String path = adfEnv.getRequestURI();
/* 556 */       if ((path != null) && (path.length() > 0))
/*     */       {
/* 558 */         Map scopeMap = adfContext.getSessionScope();
/* 559 */         if ((scopeMap instanceof ADFScope))
/*     */         {
/* 561 */           ((ADFScope)scopeMap).putTransient(ADFConstants.AUTH_CANCEL_URL, path);
/*     */         }
/*     */         else
/*     */         {
/* 565 */           scopeMap.put(ADFConstants.AUTH_CANCEL_URL, path);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RuntimeException r) {}
/*     */   }
/*     */   
/*     */   protected abstract ADFContext initADFContext();
/*     */   
/*     */   protected abstract void resetADFContext();
/*     */   
/*     */   protected abstract BindingContext createBindingContext(ADFContext paramADFContext);
/*     */   
/*     */   protected abstract SessionContext createSessionContext(ADFContext paramADFContext);
/*     */   
/*     */   protected void initMetadataContext() {}
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\BindingRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */