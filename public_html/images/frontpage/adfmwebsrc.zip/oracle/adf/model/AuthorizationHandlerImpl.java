/*    */ package oracle.adf.model;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.adf.share.Environment;
/*    */ import oracle.jbo.JboException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationHandlerImpl
/*    */   implements AuthorizationHandler
/*    */ {
/* 38 */   Environment adfEnv = null;
/*    */   
/*    */   public AuthorizationHandlerImpl()
/*    */   {
/* 42 */     this.adfEnv = ADFContext.getCurrent().getEnvironment();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void handleAuthorizationFailure()
/*    */   {
/*    */     try
/*    */     {
/* 53 */       HttpServletResponse response = (HttpServletResponse)this.adfEnv.getResponse();
/* 54 */       if (response != null)
/*    */       {
/* 56 */         response.sendError(401);
/*    */       }
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 61 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void redirect(String url)
/*    */   {
/*    */     try
/*    */     {
/* 73 */       this.adfEnv.redirect(url);
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 77 */       throw new JboException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\AuthorizationHandlerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */