/*     */ package oracle.adf.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import oracle.adf.model.config.AdfmConfig;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.logging.ADFLogger;
/*     */ import oracle.adf.share.mds.ADFSessionOptions;
/*     */ import oracle.adf.share.mds.MDSLockedSessionManager;
/*     */ import oracle.adf.share.mds.MDSLockedSessionOperations;
/*     */ import oracle.adf.share.mds.MDSTransManager;
/*     */ import oracle.jbo.CSMessageBundle;
/*     */ import oracle.jbo.JboException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetadataContext
/*     */ {
/*     */   public static final String NAME = "Metadata-Context";
/*     */   private static final String METADATA_CONTEXT_PARAM_SEPARATOR = ";";
/*     */   private static final String METADATA_CONTEXT_PARAM_VALUE_SEPARATOR = "=";
/*     */   private static final char METADATA_CONTEXT_NAME_MARKER = '"';
/*     */   private static final String LABEL_STR = "label";
/*     */   private static final String SANDBOX_STR = "sandbox";
/*     */   private static final String TRIMCC_STR = "trimcc";
/*     */   private static final String LABEL_LATEST = "latest";
/*  60 */   private static final ADFLogger LOG = ADFLogger.createADFLogger("oracle.adf.model.log.BindingFilter");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> setupMetadataContext(String headerStr)
/*     */   {
/*  92 */     return setupMetadataContext(parseMetadataContext(headerStr));
/*     */   }
/*     */   
/*     */   private static Map<String, String> parseMetadataContext(String headerStr) {
/*  96 */     Map<String, String> map = new HashMap();
/*     */     
/*  98 */     if (headerStr != null) {
/*  99 */       String[] metadataContextAttributes = headerStr.split(";");
/* 100 */       for (String keyValue : metadataContextAttributes) {
/* 101 */         int index = keyValue.indexOf("=");
/* 102 */         if (index < 1) {
/*     */           break;
/*     */         }
/*     */         
/* 106 */         String key = keyValue.substring(0, index).trim();
/* 107 */         String value = keyValue.substring(index + 1).trim();
/* 108 */         if ("label".equals(key)) {
/* 109 */           String mdslabel = parseMetadataLabel(value);
/* 110 */           if (isStringEmpty(mdslabel)) {
/* 111 */             map = null;
/* 112 */             break;
/*     */           }
/* 114 */           map.put("baseLabel", mdslabel);
/* 115 */         } else if ("sandbox".equals(key)) {
/* 116 */           String sboxname = stripQuotes(value);
/* 117 */           if (isStringEmpty(sboxname)) {
/* 118 */             map = null;
/* 119 */             break;
/*     */           }
/* 121 */           map.put("sboxname", sboxname);
/* 122 */         } else if ("trimcc".equals(key)) {
/* 123 */           String trimcc = stripQuotes(value);
/* 124 */           if (isStringEmpty(trimcc)) {
/* 125 */             map = null;
/* 126 */             break;
/*     */           }
/* 128 */           map.put("custClasses", trimcc);
/*     */         } else {
/* 130 */           map = null;
/* 131 */           break;
/*     */         }
/*     */       }
/*     */       
/* 135 */       if ((map == null) || (map.isEmpty())) {
/* 136 */         throw new JboException(CSMessageBundle.class, "27513", new Object[] { "Metadata-Context", headerStr });
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 141 */     return map;
/*     */   }
/*     */   
/*     */   private static String parseMetadataLabel(String baseLabel) {
/* 145 */     if (baseLabel.charAt(0) == '"')
/* 146 */       return stripQuotes(baseLabel);
/* 147 */     if ("latest".equals(baseLabel)) {
/* 148 */       return "__latest__";
/*     */     }
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   private static String stripQuotes(String value) {
/* 154 */     int length = value.length();
/* 155 */     if ((length > 1) && (value.charAt(0) == '"') && (value.charAt(length - 1) == '"'))
/*     */     {
/* 157 */       return value.substring(1, length - 1);
/*     */     }
/* 159 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isStringEmpty(String value) {
/* 163 */     return (value == null) || (value.isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> setupMetadataContext(Map<String, String> originalMetadataProperties)
/*     */   {
/* 189 */     Map<String, String> metadataProperties = new HashMap();
/* 190 */     List<String> paramNames = new ArrayList();
/* 191 */     List<Object> paramValues = new ArrayList();
/*     */     
/* 193 */     ADFContext adfContext = ADFContext.findCurrent();
/* 194 */     LOG.finest("Setting up ADFSessionOptions in " + adfContext);
/*     */     
/* 196 */     String sboxname = (String)originalMetadataProperties.get("sboxname");
/* 197 */     String mdslabel = null;
/* 198 */     if (sboxname == null) {
/* 199 */       mdslabel = (String)originalMetadataProperties.get("baseLabel");
/* 200 */       if (mdslabel == null)
/*     */       {
/*     */ 
/* 203 */         mdslabel = getDefaultMetadataLabel();
/*     */       }
/* 205 */       LOG.fine("Setting MDS label to " + mdslabel);
/* 206 */       paramNames.add("baseLabel");
/* 207 */       paramValues.add(mdslabel);
/* 208 */       metadataProperties.put("baseLabel", mdslabel);
/*     */     } else {
/* 210 */       LOG.fine("Setting sandbox name to " + sboxname);
/* 211 */       paramNames.add("sboxname");
/* 212 */       paramValues.add(sboxname);
/* 213 */       metadataProperties.put("sboxname", sboxname);
/*     */     }
/*     */     
/* 216 */     String trimcc = (String)originalMetadataProperties.get("custClasses");
/* 217 */     if (trimcc == null)
/*     */     {
/* 219 */       trimcc = "";
/*     */     }
/* 221 */     if (trimcc.length() == 0) {
/* 222 */       LOG.fine("Resetting CC list to original");
/*     */     } else {
/* 224 */       LOG.fine("Trimming CC list to " + trimcc);
/*     */     }
/* 226 */     paramNames.add("custClasses");
/* 227 */     paramValues.add(trimcc);
/* 228 */     metadataProperties.put("custClasses", trimcc);
/*     */     
/* 230 */     ADFSessionOptions so = (ADFSessionOptions)adfContext.getCurrentADFSessionOptions();
/* 231 */     boolean hasValues = hasValues(paramValues);
/* 232 */     if (so != null) {
/* 233 */       if (checkCurrentSession(so, paramNames, paramValues, adfContext.hasMDSSession(), hasValues))
/*     */       {
/* 235 */         so.setParams(paramNames, paramValues, 20);
/* 236 */         if (mdslabel != null) {
/* 237 */           metadataProperties.put("label", so.getLabel());
/*     */         }
/* 239 */         return metadataProperties;
/*     */       }
/* 241 */     } else if (hasValues) {
/* 242 */       throw new JboException("Could not set Metadata Context because ADFSessionOptions is null.");
/*     */     }
/*     */     
/* 245 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */   private static boolean checkCurrentSession(ADFSessionOptions so, List<String> paramNames, List<Object> paramValues, boolean hasMDSSession, boolean hasValues)
/*     */   {
/* 250 */     String sandboxName = so.getSandboxName();
/* 251 */     String baseLabel = so.getBaseLabel();
/* 252 */     String label = so.getLabel();
/* 253 */     String custClassName = so.getTrimCustClassListToClass();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 258 */     if (((hasMDSSession) || (sandboxName != null) || (baseLabel != null) || (label != null) || (custClassName != null)) && (so.testSetParams(paramNames, paramValues)))
/*     */     {
/*     */ 
/*     */ 
/* 262 */       String obj = hasMDSSession ? "MDSSession" : "ADFSessionOptions";
/* 263 */       StringBuilder msg = new StringBuilder("Current ").append(obj);
/* 264 */       msg.append(" is already initialized with SandboxName=").append(sandboxName);
/* 265 */       msg.append(" BaseLabel=").append(baseLabel);
/* 266 */       msg.append(" Label=").append(label);
/* 267 */       msg.append(" TrimCustClassName=").append(custClassName);
/* 268 */       msg.append(" and cannot be changed to " + paramNames + paramValues);
/* 269 */       LOG.warning(msg.toString());
/* 270 */       if (hasValues) {
/* 271 */         throw new JboException("Metadata Context cannot be changed after " + obj + " is setup.");
/*     */       }
/* 273 */       LOG.warning("Metadata Context will not be reset after " + obj + " is setup.");
/* 274 */       return false;
/*     */     }
/*     */     
/* 277 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean hasValues(List<Object> paramValues)
/*     */   {
/* 282 */     for (Object value : paramValues) {
/* 283 */       if ((value != null) && (
/* 284 */         (!(value instanceof String)) || (((String)value).length() > 0))) {
/* 285 */         return true;
/*     */       }
/*     */     }
/* 288 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String buildHeaderValue(Map<String, String> metadataProperties)
/*     */   {
/* 300 */     if (metadataProperties.isEmpty()) {
/* 301 */       return null;
/*     */     }
/*     */     
/* 304 */     String headerStr = null;
/* 305 */     String sboxname = (String)metadataProperties.get("sboxname");
/* 306 */     if (!isStringEmpty(sboxname)) {
/* 307 */       headerStr = "sandbox=\"" + sboxname + '"';
/*     */     }
/*     */     else
/*     */     {
/* 311 */       String mdslabel = (String)metadataProperties.get("label");
/* 312 */       if (!isStringEmpty(mdslabel)) {
/* 313 */         headerStr = "label=\"" + mdslabel + '"';
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 318 */     String trimcc = (String)metadataProperties.get("custClasses");
/* 319 */     if (!isStringEmpty(trimcc)) {
/* 320 */       if (headerStr == null) {
/* 321 */         headerStr = "trimcc=\"" + trimcc + '"';
/*     */       }
/*     */       else
/*     */       {
/* 325 */         headerStr = headerStr + ";" + "trimcc" + "=" + '"' + trimcc + '"';
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 331 */     return headerStr;
/*     */   }
/*     */   
/*     */   private static String getDefaultMetadataLabel() {
/* 335 */     String dfltMDSLabelProp = (String)AdfmConfig.getCustomProperty("adf.web.defaultmetadatalabel");
/* 336 */     if (dfltMDSLabelProp != null) {
/* 337 */       String label = parseMetadataLabel(dfltMDSLabelProp);
/* 338 */       if (!isStringEmpty(label)) {
/* 339 */         return label;
/*     */       }
/*     */     }
/* 342 */     return dfltMDSLabelProp;
/*     */   }
/*     */   
/*     */   public static ADFSessionOptions createADFSessionOptions(String headerStr) {
/* 346 */     if (headerStr == null) {
/* 347 */       return null;
/*     */     }
/*     */     
/* 350 */     ADFSessionOptions so = new ADFSessionOptions();
/*     */     
/* 352 */     Map<String, String> metadataProperties = parseMetadataContext(headerStr);
/* 353 */     String str = (String)metadataProperties.get("sboxname");
/* 354 */     if (str != null) {
/* 355 */       so.setParam("sboxname", str, 1);
/*     */     }
/* 357 */     str = (String)metadataProperties.get("baseLabel");
/* 358 */     if (str != null) {
/* 359 */       so.setParam("baseLabel", str, 1);
/*     */     }
/* 361 */     str = (String)metadataProperties.get("custClasses");
/* 362 */     if (str != null) {
/* 363 */       so.setParam("custClasses", str, 1);
/*     */     }
/*     */     
/* 366 */     return so;
/*     */   }
/*     */   
/*     */   public static MDSLockedSessionOperations lockPrepareSession() throws Exception
/*     */   {
/* 371 */     MDSLockedSessionManager mdlm = MDSTransManager.registerMDSLockedSessionManager();
/*     */     
/* 373 */     MDSLockedSessionOperations mdsOperations = mdlm.getMDSLockedSessionOperations();
/* 374 */     return mdsOperations;
/*     */   }
/*     */   
/*     */   public static void releaseFlushSession(MDSLockedSessionOperations mdsOperations) throws Exception {
/* 378 */     if (mdsOperations.isMDSRefreshNeeded()) {
/* 379 */       mdsOperations.flushMDSSessionChanges();
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isUsingSandbox() {
/* 384 */     ADFContext adfContext = ADFContext.findCurrent();
/* 385 */     if (adfContext == null) {
/* 386 */       return false;
/*     */     }
/*     */     
/* 389 */     ADFSessionOptions so = (ADFSessionOptions)adfContext.getCurrentADFSessionOptions();
/* 390 */     if (so == null) {
/* 391 */       return false;
/*     */     }
/*     */     
/* 394 */     return so.getSandboxName() != null;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\adf\model\MetadataContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */