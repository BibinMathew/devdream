/*     */ package oracle.jbo.http;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Properties;
/*     */ import oracle.jbo.common.Diagnostic;
/*     */ import oracle.jbo.common.ampool.ApplicationPool;
/*     */ import oracle.jbo.common.ampool.SessionCookie;
/*     */ import oracle.jbo.common.ampool.SessionCookieFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class SharedSessionCookieFactory
/*     */   implements SessionCookieFactory
/*     */ {
/*     */   private int mPoolSize;
/*     */   private SharedSessionCookieImpl[] mSharedCookies;
/*  52 */   private int mIndex = 0;
/*  53 */   private Object mSyncLock = new Object();
/*     */   
/*     */ 
/*     */   public SharedSessionCookieFactory(int poolSize)
/*     */   {
/*  58 */     this.mPoolSize = poolSize;
/*  59 */     this.mSharedCookies = new SharedSessionCookieImpl[this.mPoolSize];
/*     */   }
/*     */   
/*     */   public SharedSessionCookieFactory()
/*     */   {
/*  64 */     this(1);
/*     */   }
/*     */   
/*     */   public int getPoolSize()
/*     */   {
/*  69 */     return this.mPoolSize;
/*     */   }
/*     */   
/*     */   public void setPoolSize(int poolSize)
/*     */   {
/*  74 */     synchronized (this.mSyncLock)
/*     */     {
/*  76 */       int grow = poolSize - this.mPoolSize;
/*  77 */       if (grow > 0)
/*     */       {
/*  79 */         SharedSessionCookieImpl[] sharedCookies = new SharedSessionCookieImpl[poolSize];
/*  80 */         System.arraycopy(this.mSharedCookies, 0, sharedCookies, 0, this.mPoolSize);
/*     */         
/*     */ 
/*  83 */         this.mPoolSize = poolSize;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public SessionCookie createSessionCookie(String applicationId, String sessionId, ApplicationPool pool, Properties properties)
/*     */   {
/*  90 */     synchronized (this.mSyncLock)
/*     */     {
/*  92 */       SharedSessionCookieImpl cookie = this.mSharedCookies[this.mIndex];
/*     */       
/*  94 */       if (cookie == null)
/*     */       {
/*  96 */         Class cookieClass = getSessionCookieClass();
/*  97 */         if (SharedSessionCookieImpl.class.getName().equals(cookieClass.getName()))
/*     */         {
/*  99 */           cookie = new SharedSessionCookieImpl(applicationId, Integer.toString(this.mIndex), pool);
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/*     */ 
/* 106 */             Constructor cons = cookieClass.getConstructor(new Class[] { String.class, String.class, ApplicationPool.class });
/*     */             
/*     */ 
/* 109 */             cookie = (SharedSessionCookieImpl)cons.newInstance(new Object[] { applicationId, Integer.toString(this.mIndex), pool });
/*     */ 
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 114 */             if (Diagnostic.isOn())
/*     */             {
/* 116 */               Diagnostic.println("Could not create a SessionCookie of the specified class:  " + cookieClass.getName());
/* 117 */               Diagnostic.printStackTrace(e);
/*     */             }
/*     */             
/* 120 */             cookie = new SharedSessionCookieImpl(applicationId, Integer.toString(this.mIndex), pool);
/*     */           }
/*     */         }
/* 123 */         this.mSharedCookies[this.mIndex] = cookie;
/*     */       }
/*     */       
/* 126 */       if (this.mIndex < this.mPoolSize - 1)
/*     */       {
/* 128 */         this.mIndex += 1;
/*     */       }
/*     */       else
/*     */       {
/* 132 */         this.mIndex = 0;
/*     */       }
/* 134 */       return cookie;
/*     */     }
/*     */   }
/*     */   
/*     */   public Class getSessionCookieClass()
/*     */   {
/* 140 */     return SharedSessionCookieImpl.class;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\SharedSessionCookieFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */