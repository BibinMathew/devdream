/*     */ package oracle.jbo.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.NotActiveException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import oracle.adf.share.http.ServletADFContext;
/*     */ import oracle.jbo.common.Diagnostic;
/*     */ import oracle.jbo.common.PropertyMetadata;
/*     */ import oracle.jbo.common.ampool.AMPoolMessageBundle;
/*     */ import oracle.jbo.common.ampool.ApplicationPool;
/*     */ import oracle.jbo.common.ampool.ApplicationPoolException;
/*     */ import oracle.jbo.common.ampool.PoolMgr;
/*     */ import oracle.jbo.common.ampool.SessionCookie;
/*     */ import oracle.jbo.common.ampool.SessionCookieFactory;
/*     */ import oracle.jbo.common.ampool.SessionCookieListener;
/*     */ import oracle.jbo.uicli.mom.JUMetaObjectManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpContainer
/*     */   implements HttpSessionBindingListener, SessionCookieListener, Serializable
/*     */ {
/*     */   static final long serialVersionUID = -4535142613500954819L;
/*     */   public static final String PAGE_CONTEXT_CONTAINER_NAME = "jbo.PageContext";
/*     */   public static final String SESSION_CONTEXT_CONTAINER_NAME = "jbo.SessionContext";
/*     */   public static final String APPLICATION_COOKIE_PREFIX = "jbo.ApplicationCookie.";
/*     */   public static final String APPLICATION_BINDING_LISTENER_PREFIX = "ApplicationBindingListener_";
/*     */   public static final String APPLICATION_PREFIX = "Application_";
/*  69 */   private HashMap mCookies = new HashMap(1);
/*     */   
/*  71 */   private transient HashMap mResources = null;
/*  72 */   private transient boolean mRefreshingSession = false;
/*  73 */   private transient HttpSession mSession = null;
/*  74 */   private transient Object mLock = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   private transient Object mContextRef = null;
/*     */   
/*  83 */   private static HashMap mSessionLockMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public HttpContainer(Object contextRef)
/*     */   {
/*  94 */     this.mContextRef = contextRef;
/*  95 */     initialize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpContainer()
/*     */   {
/* 106 */     initialize();
/*     */   }
/*     */   
/*     */   private static Object getSessionSyncLock(Object key)
/*     */   {
/* 111 */     synchronized (mSessionLockMap)
/*     */     {
/* 113 */       Object syncLock = mSessionLockMap.get(key);
/*     */       
/* 115 */       if (syncLock == null)
/*     */       {
/* 117 */         syncLock = new Object();
/* 118 */         mSessionLockMap.put(key, syncLock);
/*     */       }
/* 120 */       return syncLock;
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private static Object removeSessionSyncLock(Object key)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 11	oracle/jbo/http/HttpContainer:mSessionLockMap	Ljava/util/HashMap;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: getstatic 11	oracle/jbo/http/HttpContainer:mSessionLockMap	Ljava/util/HashMap;
/*     */     //   9: aload_0
/*     */     //   10: invokevirtual 15	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   13: aload_1
/*     */     //   14: monitorexit
/*     */     //   15: areturn
/*     */     //   16: astore_2
/*     */     //   17: aload_1
/*     */     //   18: monitorexit
/*     */     //   19: aload_2
/*     */     //   20: athrow
/*     */     // Line number table:
/*     */     //   Java source line #126	-> byte code offset #0
/*     */     //   Java source line #128	-> byte code offset #6
/*     */     //   Java source line #129	-> byte code offset #16
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	21	0	key	Object
/*     */     //   4	14	1	Ljava/lang/Object;	Object
/*     */     //   16	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	15	16	finally
/*     */     //   16	19	16	finally
/*     */   }
/*     */   
/*     */   public Object getValue(Object key)
/*     */   {
/* 134 */     Object rtn = null;
/*     */     
/* 136 */     if (this.mResources != null)
/*     */     {
/* 138 */       rtn = getValue(this.mResources, key);
/*     */     }
/*     */     
/* 141 */     return rtn;
/*     */   }
/*     */   
/*     */   public Object removeValue(Object key, Properties userProperties)
/*     */   {
/* 146 */     Object rtn = null;
/*     */     
/* 148 */     if (this.mResources != null)
/*     */     {
/* 150 */       rtn = removeValue(this.mResources, key, userProperties, true);
/*     */     }
/*     */     
/* 153 */     return rtn;
/*     */   }
/*     */   
/*     */   public Object removeValueInternal(Object key)
/*     */   {
/* 158 */     Object rtn = null;
/*     */     
/* 160 */     if (this.mResources != null)
/*     */     {
/* 162 */       rtn = removeValue(this.mResources, key, null, false);
/*     */     }
/*     */     
/* 165 */     return rtn;
/*     */   }
/*     */   
/*     */   public void clear(Properties userProperties)
/*     */   {
/* 170 */     HashMap resources = null;
/* 171 */     HashMap cookies = null;
/* 172 */     BindingEvent ev = null;
/*     */     
/* 174 */     synchronized (this.mLock)
/*     */     {
/* 176 */       if (this.mResources != null)
/*     */       {
/* 178 */         resources = (HashMap)this.mResources.clone();
/* 179 */         this.mResources.clear();
/*     */       }
/*     */       
/* 182 */       cookies = (HashMap)this.mCookies.clone();
/* 183 */       this.mCookies.clear();
/* 184 */       ev = buildBindingEvent(userProperties);
/*     */     }
/*     */     
/* 187 */     if (resources != null)
/*     */     {
/* 189 */       Iterator values = resources.values().iterator();
/*     */       
/* 191 */       while (values.hasNext())
/*     */       {
/* 193 */         Object value = values.next();
/* 194 */         fireValueUnbound(value, ev);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 199 */     Iterator values = cookies.values().iterator();
/* 200 */     while (values.hasNext())
/*     */     {
/* 202 */       Object value = values.next();
/* 203 */       fireValueUnbound(value, ev);
/*     */     }
/*     */   }
/*     */   
/*     */   public void timeout(Properties userProperties)
/*     */   {
/* 209 */     HashMap resources = null;
/* 210 */     HashMap cookies = null;
/* 211 */     BindingEvent ev = null;
/*     */     
/* 213 */     synchronized (this.mLock)
/*     */     {
/* 215 */       if (this.mResources != null)
/*     */       {
/* 217 */         resources = (HashMap)this.mResources.clone();
/* 218 */         this.mResources.clear();
/*     */       }
/*     */       
/* 221 */       cookies = (HashMap)this.mCookies.clone();
/* 222 */       this.mCookies.clear();
/*     */       
/* 224 */       ev = buildBindingEvent(userProperties);
/*     */     }
/*     */     
/* 227 */     if (resources != null)
/*     */     {
/* 229 */       Iterator listenerEnum = resources.values().iterator();
/* 230 */       while (listenerEnum.hasNext())
/*     */       {
/* 232 */         Object listener = listenerEnum.next();
/* 233 */         fireTimeout(listener, ev);
/*     */       }
/*     */     }
/*     */     
/* 237 */     Iterator listenerEnum = cookies.values().iterator();
/* 238 */     while (listenerEnum.hasNext())
/*     */     {
/* 240 */       Object listener = listenerEnum.next();
/* 241 */       fireTimeout(listener, ev);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object putValue(Object key, Object value, Properties userProperties)
/*     */   {
/* 247 */     if (this.mResources == null)
/*     */     {
/* 249 */       this.mResources = new HashMap();
/*     */     }
/*     */     
/* 252 */     return setValue(this.mResources, key, value, userProperties);
/*     */   }
/*     */   
/*     */   public void valueBound(HttpSessionBindingEvent e)
/*     */   {
/* 257 */     synchronized (this.mLock)
/*     */     {
/* 259 */       if (!this.mRefreshingSession)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 264 */         this.mSession = e.getSession();
/* 265 */         initialize();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void valueUnbound(HttpSessionBindingEvent e)
/*     */   {
/* 272 */     boolean timeout = false;
/* 273 */     synchronized (this.mLock)
/*     */     {
/* 275 */       if (!this.mRefreshingSession)
/*     */       {
/* 277 */         if (this.mSession != null)
/*     */         {
/* 279 */           removeSessionSyncLock(this.mSession);
/*     */         }
/*     */         
/* 282 */         this.mSession = null;
/* 283 */         timeout = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 298 */     if (timeout)
/*     */     {
/* 300 */       timeout(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpContainer getInstanceFromSession(HttpSession session)
/*     */   {
/* 312 */     HttpContainer container = null;
/* 313 */     boolean isNewContainer = false;
/*     */     
/* 315 */     synchronized (getSessionSyncLock(session))
/*     */     {
/* 317 */       container = (HttpContainer)session.getValue("jbo.SessionContext");
/*     */       
/* 319 */       if (container == null)
/*     */       {
/* 321 */         container = new HttpContainer();
/*     */         
/* 323 */         session.putValue("jbo.SessionContext", container);
/* 324 */         isNewContainer = true;
/*     */       }
/*     */     }
/*     */     
/* 328 */     if (!isNewContainer)
/*     */     {
/* 330 */       synchronized (container.mLock)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 337 */         container.mSession = session;
/*     */       }
/*     */     }
/*     */     
/* 341 */     return container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionCookie getSessionCookie(String applicationId)
/*     */   {
/* 352 */     String key = "jbo.ApplicationCookie." + applicationId;
/* 353 */     return (SessionCookie)getValue(this.mCookies, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionCookie[] getSessionCookies()
/*     */   {
/* 361 */     synchronized (this.mLock)
/*     */     {
/* 363 */       SessionCookie[] cookies = new SessionCookie[this.mCookies.size()];
/* 364 */       this.mCookies.values().toArray(cookies);
/*     */       
/* 366 */       return cookies;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionCookie(String applicationId, SessionCookie cookie)
/*     */   {
/* 380 */     String key = "jbo.ApplicationCookie." + applicationId;
/* 381 */     Object rtn = setValue(this.mCookies, key, cookie, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 387 */     if (cookie != null)
/*     */     {
/* 389 */       cookie.setSessionCookieListener(this);
/*     */     }
/* 391 */     else if (rtn != null)
/*     */     {
/* 393 */       ((SessionCookie)rtn).setSessionCookieListener(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encodeURL(String url)
/*     */   {
/* 405 */     synchronized (this.mLock)
/*     */     {
/* 407 */       HttpSessionCookieHelper helper = HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
/*     */       
/*     */ 
/* 410 */       url = helper.encodeURL(url, getSessionCookies());
/*     */       
/* 412 */       return url;
/*     */     }
/*     */   }
/*     */   
/*     */   private Object setValue(HashMap target, Object key, Object value, Properties properties)
/*     */   {
/* 418 */     Object rtn = null;
/* 419 */     boolean fireValueBound = false;
/* 420 */     boolean fireValueUnbound = false;
/* 421 */     BindingEvent ev = null;
/*     */     
/* 423 */     synchronized (this.mLock)
/*     */     {
/* 425 */       boolean exists = getValue(target, key) != null;
/* 426 */       if (!exists)
/*     */       {
/* 428 */         if (value != null)
/*     */         {
/* 430 */           rtn = target.put(key, value);
/* 431 */           ev = buildBindingEvent(null);
/* 432 */           fireValueBound = true;
/*     */         }
/*     */       }
/* 435 */       else if ((exists) && (value == null))
/*     */       {
/* 437 */         rtn = target.remove(key);
/* 438 */         ev = buildBindingEvent(null);
/* 439 */         fireValueUnbound = true;
/*     */       }
/*     */     }
/*     */     
/* 443 */     if (fireValueBound)
/*     */     {
/* 445 */       fireValueBound(rtn, ev);
/*     */     }
/* 447 */     else if (fireValueUnbound)
/*     */     {
/* 449 */       fireValueUnbound(rtn, ev);
/*     */     }
/*     */     
/* 452 */     return rtn;
/*     */   }
/*     */   
/*     */   private Object getValue(HashMap target, Object key)
/*     */   {
/* 457 */     return target.get(key);
/*     */   }
/*     */   
/*     */   private BindingEvent buildBindingEvent(Properties props)
/*     */   {
/* 462 */     synchronized (this.mLock)
/*     */     {
/* 464 */       BindingEvent ev = new BindingEvent(this.mContextRef != null ? this.mContextRef : this.mSession);
/*     */       
/* 466 */       if (props != null)
/*     */       {
/* 468 */         ev.setUserProperties(props);
/*     */       }
/* 470 */       return ev;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private Object removeValue(HashMap target, Object key, Properties properties, boolean notify)
/*     */   {
/* 477 */     Object rtn = null;
/* 478 */     BindingEvent ev = null;
/*     */     
/* 480 */     synchronized (this.mLock)
/*     */     {
/* 482 */       rtn = target.remove(key);
/* 483 */       ev = buildBindingEvent(properties);
/*     */     }
/*     */     
/* 486 */     if ((notify) && (rtn != null))
/*     */     {
/* 488 */       fireValueUnbound(rtn, ev);
/*     */     }
/*     */     
/* 491 */     return rtn;
/*     */   }
/*     */   
/*     */   private void fireValueUnbound(Object value, BindingEvent ev)
/*     */   {
/* 496 */     if ((value != null) && ((value instanceof BindingListener)))
/*     */     {
/* 498 */       ((BindingListener)value).valueUnbound(ev);
/*     */     }
/*     */   }
/*     */   
/*     */   private void fireValueBound(Object value, BindingEvent ev)
/*     */   {
/* 504 */     if ((value != null) && ((value instanceof BindingListener)))
/*     */     {
/* 506 */       ((BindingListener)value).valueBound(ev);
/*     */     }
/*     */   }
/*     */   
/*     */   private void fireTimeout(Object object, BindingEvent ev)
/*     */   {
/* 512 */     if ((object != null) && ((object instanceof BindingListener)))
/*     */     {
/* 514 */       ((BindingListener)object).timeout(ev);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initialize()
/*     */   {
/* 520 */     if (this.mLock == null)
/*     */     {
/* 522 */       this.mLock = new Object();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cookieUpdated()
/*     */   {
/* 531 */     synchronized (this.mLock)
/*     */     {
/* 533 */       if (this.mSession != null)
/*     */       {
/*     */         try
/*     */         {
/* 537 */           this.mRefreshingSession = true;
/* 538 */           this.mSession.putValue("jbo.SessionContext", this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (IllegalStateException iex) {}finally
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 551 */           this.mRefreshingSession = false;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 562 */       in.defaultReadObject();
/*     */     }
/*     */     catch (NotActiveException naex) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 569 */     initialize();
/*     */     
/* 571 */     SessionCookie[] cookies = getSessionCookies();
/* 572 */     for (int i = 0; i < cookies.length; i++)
/*     */     {
/* 574 */       cookies[i].setSessionCookieListener(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SessionCookie findSessionCookie(HttpSession session, String applicationId, String applicationDefinitionName, Properties cookieProperties)
/*     */   {
/* 628 */     HttpContainer container = getInstanceFromSession(session);
/* 629 */     synchronized (container.mLock)
/*     */     {
/* 631 */       boolean createdWebAppThreadContext = false;
/*     */       try
/*     */       {
/* 634 */         if (cookieProperties != null)
/*     */         {
/* 636 */           HttpServletRequest request = (HttpServletRequest)cookieProperties.get("jbo.http.httprequest");
/*     */           
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/* 642 */             ServletADFContext.initThreadContext(null, request, null);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 647 */             createdWebAppThreadContext = true;
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 654 */         if (!createdWebAppThreadContext)
/*     */         {
/* 656 */           if (Diagnostic.isOn())
/*     */           {
/* 658 */             Diagnostic.println("***********WARNING*************:  HttpContainer.findSessionCookie could not instantiate ServletADFContext.");
/* 659 */             Diagnostic.println("Please pass HttpSessionCookieFactory.PROP_HTTP_REQUEST through the cookieProperties");
/*     */           }
/*     */         }
/*     */         
/* 663 */         SessionCookie cookie = container.getSessionCookie(applicationId);
/* 664 */         if (cookie == null)
/*     */         {
/* 666 */           Properties poolProps = new Properties();
/* 667 */           poolProps.put("jbo.jndi.use_default_context", "true");
/*     */           
/*     */ 
/* 670 */           ApplicationPool pool = JUMetaObjectManager.createPool(applicationDefinitionName, poolProps);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 677 */           SessionCookieFactory factory = pool.getSessionCookieFactory();
/* 678 */           if (PropertyMetadata.ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME.getDefault().equals(factory.getClass().getName()))
/*     */           {
/* 680 */             pool.setSessionCookieFactory(new HttpSessionCookieFactory());
/*     */           }
/*     */           
/* 683 */           Properties httpCookieProps = new HttpSessionCookieProperties();
/* 684 */           if (cookieProperties != null)
/*     */           {
/* 686 */             httpCookieProps.putAll(cookieProperties);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 693 */           if (session != null)
/*     */           {
/* 695 */             httpCookieProps.put("jbo.http.httpsession", session);
/*     */           }
/*     */           
/*     */ 
/* 699 */           httpCookieProps.put("jbo.iswebapp", new Boolean(true));
/*     */           
/*     */ 
/*     */           try
/*     */           {
/* 704 */             cookie = pool.createSessionCookie(applicationId, null, httpCookieProps);
/*     */ 
/*     */           }
/*     */           catch (ApplicationPoolException apex)
/*     */           {
/* 709 */             if ("30012".equals(apex.getErrorCode()))
/*     */             {
/* 711 */               cookie = apex.getSessionCookie();
/*     */             }
/*     */             else
/*     */             {
/* 715 */               throw apex;
/*     */             }
/*     */           }
/*     */           
/* 719 */           container.setSessionCookie(applicationId, cookie);
/*     */         }
/*     */         else
/*     */         {
/* 723 */           configName = JUMetaObjectManager.getConfigName(applicationDefinitionName);
/*     */           
/*     */ 
/* 726 */           String cookieConfigName = cookie.getEnvConfigurationName();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 733 */           if ((configName != null) && (cookieConfigName != null) && (cookieConfigName.indexOf(configName) < 0))
/*     */           {
/*     */ 
/*     */ 
/* 737 */             throw new ApplicationPoolException(AMPoolMessageBundle.class, "30018", new Object[] { cookie.getApplicationId(), cookie.getSessionId(), cookieConfigName, configName });
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 748 */         String configName = cookie;
/*     */         
/*     */ 
/*     */ 
/* 752 */         if (createdWebAppThreadContext)
/*     */         {
/* 754 */           ServletADFContext.resetThreadContext(); } return configName;
/*     */       }
/*     */       finally
/*     */       {
/* 752 */         if (createdWebAppThreadContext)
/*     */         {
/* 754 */           ServletADFContext.resetThreadContext();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SessionCookie findSessionCookie(HttpSession session, String applicationId, String poolName, String configPackage, String configSection, Properties poolProps, Properties cookieProps)
/*     */   {
/* 852 */     HttpContainer container = getInstanceFromSession(session);
/* 853 */     synchronized (container.mLock)
/*     */     {
/* 855 */       boolean createdWebAppThreadContext = false;
/*     */       try
/*     */       {
/* 858 */         if (cookieProps != null)
/*     */         {
/* 860 */           HttpServletRequest request = (HttpServletRequest)cookieProps.get("jbo.http.httprequest");
/*     */           
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/* 866 */             ServletADFContext.initThreadContext(null, request, null);
/*     */           }
/*     */           catch (Exception e) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 875 */           createdWebAppThreadContext = true;
/*     */         }
/*     */         
/* 878 */         if (!createdWebAppThreadContext)
/*     */         {
/* 880 */           if (Diagnostic.isOn())
/*     */           {
/* 882 */             Diagnostic.println("***********WARNING*************:  HttpContainer.findSessionCookie could not instantiate ServletADFContext.");
/* 883 */             Diagnostic.println("Please pass HttpSessionCookieFactory.PROP_HTTP_REQUEST through the cookieProps");
/*     */           }
/*     */         }
/*     */         
/* 887 */         String configName = null;
/* 888 */         if ((configPackage != null) && (configSection != null))
/*     */         {
/* 890 */           configName = configPackage + "." + configSection;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 896 */         SessionCookie cookie = container.getSessionCookie(applicationId);
/* 897 */         if (cookie == null)
/*     */         {
/*     */ 
/*     */ 
/* 901 */           if (poolProps == null)
/*     */           {
/* 903 */             poolProps = new Properties();
/*     */           }
/* 905 */           poolProps.put("jbo.jndi.use_default_context", "true");
/*     */           
/*     */ 
/* 908 */           ApplicationPool pool = PoolMgr.getInstance().findPool(poolName, configPackage, configSection, poolProps);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 916 */           SessionCookieFactory factory = pool.getSessionCookieFactory();
/* 917 */           if (PropertyMetadata.ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME.getDefault().equals(factory.getClass().getName()))
/*     */           {
/* 919 */             pool.setSessionCookieFactory(new HttpSessionCookieFactory());
/*     */           }
/*     */           
/* 922 */           Properties httpCookieProps = new HttpSessionCookieProperties();
/*     */           
/* 924 */           if (cookieProps != null)
/*     */           {
/* 926 */             httpCookieProps.putAll(cookieProps);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 933 */           if (session != null)
/*     */           {
/* 935 */             httpCookieProps.put("jbo.http.httpsession", session);
/*     */           }
/*     */           
/*     */ 
/*     */           try
/*     */           {
/* 941 */             cookie = pool.createSessionCookie(applicationId, null, httpCookieProps);
/*     */ 
/*     */           }
/*     */           catch (ApplicationPoolException apex)
/*     */           {
/*     */ 
/* 947 */             if ("30012".equals(apex.getErrorCode()))
/*     */             {
/* 949 */               cookie = apex.getSessionCookie();
/*     */             }
/*     */             else
/*     */             {
/* 953 */               throw apex;
/*     */             }
/*     */           }
/*     */           
/* 957 */           container.setSessionCookie(applicationId, cookie);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 962 */           cookieConfigName = cookie.getEnvConfigurationName();
/* 963 */           if ((cookieConfigName != null) && (configName != null) && (cookieConfigName.indexOf(configName) < 0))
/*     */           {
/*     */ 
/*     */ 
/* 967 */             throw new ApplicationPoolException(AMPoolMessageBundle.class, "30018", new Object[] { cookie.getApplicationId(), cookie.getSessionId(), cookieConfigName, configName });
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 978 */         String cookieConfigName = cookie;
/*     */         
/*     */ 
/*     */ 
/* 982 */         if (createdWebAppThreadContext)
/*     */         {
/* 984 */           ServletADFContext.resetThreadContext(); } return cookieConfigName;
/*     */       }
/*     */       finally
/*     */       {
/* 982 */         if (createdWebAppThreadContext)
/*     */         {
/* 984 */           ServletADFContext.resetThreadContext();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */