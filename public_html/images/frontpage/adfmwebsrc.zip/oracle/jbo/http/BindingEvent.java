/*    */ package oracle.jbo.http;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BindingEvent
/*    */ {
/* 19 */   private Properties mUserProperties = null;
/* 20 */   private Object mContextRef = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   BindingEvent(Object contextRef)
/*    */   {
/* 27 */     this.mContextRef = contextRef;
/*    */   }
/*    */   
/*    */   void setUserProperties(Properties properties)
/*    */   {
/* 32 */     this.mUserProperties = properties;
/*    */   }
/*    */   
/*    */   Properties getUserProperties()
/*    */   {
/* 37 */     return this.mUserProperties;
/*    */   }
/*    */   
/*    */   Object getParentContext()
/*    */   {
/* 42 */     return this.mContextRef;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\BindingEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */