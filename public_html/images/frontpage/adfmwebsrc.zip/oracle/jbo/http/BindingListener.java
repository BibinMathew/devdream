package oracle.jbo.http;

abstract interface BindingListener
{
  public abstract void valueBound(BindingEvent paramBindingEvent);
  
  public abstract void valueUnbound(BindingEvent paramBindingEvent);
  
  public abstract void timeout(BindingEvent paramBindingEvent);
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\BindingListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */