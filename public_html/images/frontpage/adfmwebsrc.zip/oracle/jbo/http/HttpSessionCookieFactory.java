/*     */ package oracle.jbo.http;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.security.Principal;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.Environment;
/*     */ import oracle.jbo.JboException;
/*     */ import oracle.jbo.common.Diagnostic;
/*     */ import oracle.jbo.common.ampool.ApplicationPool;
/*     */ import oracle.jbo.common.ampool.SessionCookie;
/*     */ import oracle.jbo.common.ampool.SessionCookieFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpSessionCookieFactory
/*     */   implements SessionCookieFactory
/*     */ {
/*     */   public static final String PROP_HTTP_REQUEST = "jbo.http.httprequest";
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String PROP_HTTP_SESSION = "jbo.http.httpsession";
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String HTTP_SERVLET_REQUEST = "jbo.http.httprequest";
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String HTTP_SESSION = "jbo.http.httpsession";
/*     */   
/*     */   public SessionCookie createSessionCookie(String applicationId, String sessionId, ApplicationPool pool, Properties properties)
/*     */   {
/*  85 */     SessionCookie cookie = null;
/*  86 */     Principal userPrincipal = null;
/*     */     
/*  88 */     if (properties != null)
/*     */     {
/*  90 */       userPrincipal = (Principal)properties.get("jbo.userprincipal");
/*     */     }
/*     */     
/*  93 */     ADFContext context = ADFContext.getCurrent();
/*     */     
/*  95 */     Object request = context.hasEnvironment() ? context.getEnvironment().getRequest() : null;
/*     */     
/*  97 */     HttpSessionCookieHelper helper = HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
/*     */     
/*     */ 
/* 100 */     if ((request != null) && ((request instanceof HttpServletRequest)))
/*     */     {
/* 102 */       if (userPrincipal == null)
/*     */       {
/*     */         try
/*     */         {
/* 106 */           userPrincipal = ((HttpServletRequest)request).getUserPrincipal();
/*     */         }
/*     */         catch (NoSuchMethodError e) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */       if (sessionId == null) {
/* 118 */         sessionId = helper.generateSessionId((HttpServletRequest)request);
/*     */       }
/* 120 */     } else if (properties != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 125 */       if (sessionId == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 130 */         HttpSession session = (HttpSession)properties.get("jbo.http.httpsession");
/* 131 */         if (session != null)
/*     */         {
/* 133 */           sessionId = helper.generateSessionId(session);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 139 */     Class cookieClass = getSessionCookieClass();
/* 140 */     if (HttpSessionCookieImpl.class.getName().equals(cookieClass.getName()))
/*     */     {
/* 142 */       cookie = new HttpSessionCookieImpl(applicationId, sessionId, pool, userPrincipal, (HttpSession)null);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 148 */       Constructor cons = null;
/*     */       try
/*     */       {
/*     */         try
/*     */         {
/* 153 */           cons = cookieClass.getConstructor(new Class[] { String.class, String.class, ApplicationPool.class, Principal.class });
/*     */         }
/*     */         catch (NoSuchMethodException r) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */         if (cons != null)
/*     */         {
/* 163 */           cookie = (SessionCookie)cons.newInstance(new Object[] { applicationId, sessionId, pool, userPrincipal });
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 169 */         if (cookie == null)
/*     */         {
/*     */           try
/*     */           {
/* 173 */             cons = cookieClass.getConstructor(new Class[] { String.class, String.class, ApplicationPool.class, Principal.class, HttpServletRequest.class });
/*     */           }
/*     */           catch (NoSuchMethodException r) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */           if (cons != null)
/*     */           {
/* 184 */             cookie = (SessionCookie)cons.newInstance(new Object[] { applicationId, sessionId, pool, userPrincipal, (request instanceof HttpServletRequest) ? (HttpServletRequest)request : (HttpServletRequest)null });
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */         if (cookie == null)
/*     */         {
/*     */           try
/*     */           {
/* 197 */             cons = cookieClass.getConstructor(new Class[] { String.class, String.class, ApplicationPool.class, Principal.class, HttpSession.class });
/*     */           }
/*     */           catch (NoSuchMethodException r) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */           if (cons != null)
/*     */           {
/* 208 */             cookie = (SessionCookie)cons.newInstance(new Object[] { applicationId, sessionId, pool, userPrincipal, (request instanceof HttpServletRequest) ? ((HttpServletRequest)request).getSession(true) : (HttpSession)null });
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 217 */         if (cookie == null)
/*     */         {
/* 219 */           throw new JboException("HttpSessionCookieImpl constructor not found");
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 225 */         if (Diagnostic.isOn())
/*     */         {
/* 227 */           Diagnostic.println("Could not create a SessionCookie of the specified class:  " + cookieClass.getName());
/* 228 */           Diagnostic.printStackTrace(e);
/*     */         }
/*     */         
/* 231 */         cookie = new HttpSessionCookieImpl(applicationId, sessionId, pool, userPrincipal, (HttpSession)null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 236 */     return cookie;
/*     */   }
/*     */   
/*     */   public Class getSessionCookieClass()
/*     */   {
/* 241 */     return HttpSessionCookieImpl.class;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpSessionCookieFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */