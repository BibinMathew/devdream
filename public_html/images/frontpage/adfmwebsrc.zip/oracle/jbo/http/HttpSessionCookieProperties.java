/*    */ package oracle.jbo.http;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.adf.share.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionCookieProperties
/*    */   extends Properties
/*    */ {
/*    */   private static final long serialVersionUID = -9172189788417736088L;
/*    */   
/*    */   public HttpSessionCookieProperties() {}
/*    */   
/*    */   public HttpSessionCookieProperties(Properties props)
/*    */   {
/* 46 */     super(props);
/*    */   }
/*    */   
/*    */   public Object get(Object key)
/*    */   {
/* 51 */     Object rtn = super.get(key);
/* 52 */     if (rtn == null)
/*    */     {
/* 54 */       if ("jbo.http.httprequest".equals(key))
/*    */       {
/* 56 */         rtn = ADFContext.getCurrent().getEnvironment().getRequest();
/*    */       }
/* 58 */       else if ("jbo.http.httpsession".equals(key))
/*    */       {
/* 60 */         Object request = ADFContext.getCurrent().getEnvironment().getRequest();
/*    */         
/*    */ 
/* 63 */         if ((request instanceof HttpServletRequest))
/*    */         {
/* 65 */           rtn = ((HttpServletRequest)request).getSession(true);
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 70 */     return rtn;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpSessionCookieProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */