/*     */ package oracle.jbo.http;
/*     */ 
/*     */ import oracle.jbo.common.ampool.ApplicationPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class SharedSessionCookieImpl
/*     */   extends HttpSessionCookieImpl
/*     */ {
/*     */   private static final long serialVersionUID = -448761946657645725L;
/*     */   
/*     */   public SharedSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool)
/*     */   {
/*  93 */     super(applicationId, sessionId, pool);
/*     */   }
/*     */   
/*     */ 
/*     */   public void releaseApplicationModule(int releaseFlags, long waitTimeout)
/*     */   {
/*  99 */     super.releaseApplicationModule(2, waitTimeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeFromPool() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFailoverEnabled()
/*     */   {
/* 112 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\SharedSessionCookieImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */