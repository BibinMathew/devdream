/*    */ package oracle.jbo.http;
/*    */ 
/*    */ import java.util.AbstractMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ORDRegisterer
/*    */ {
/*    */   public static final String DISP_RENDERER_KEY = "Renderer";
/*    */   public static final String EDIT_RENDERER_KEY = "EditRenderer";
/*    */   private static final String ORD_IM_PACKAGE = "oracle_ord_im";
/*    */   public static final String ORD_DISPLAYRENDERER_CLASSNAME = "oracle.ord.html.OrdBuildURLRenderer";
/*    */   public static final String ORD_EDITRENDERER_CLASSNAME = "oracle.ord.html.OrdUploadFileRenderer";
/*    */   private static final String ORDIMAGEDOMAIN_DISP_RENDERER_KEY = "oracle_ord_im_OrdImageDomain_Renderer";
/*    */   private static final String ORDAUDIODOMAIN_DISP_RENDERER_KEY = "oracle_ord_im_OrdAudioDomain_Renderer";
/*    */   private static final String ORDVIDEODOMAIN_DISP_RENDERER_KEY = "oracle_ord_im_OrdVideoDomain_Renderer";
/*    */   private static final String ORDDOCDOMAIN_DISP_RENDERER_KEY = "oracle_ord_im_OrdDocDomain_Renderer";
/*    */   private static final String ORDIMAGEDOMAIN_EDIT_RENDERER_KEY = "oracle_ord_im_OrdImageDomain_EditRenderer";
/*    */   private static final String ORDAUDIODOMAIN_EDIT_RENDERER_KEY = "oracle_ord_im_OrdAudioDomain_EditRenderer";
/*    */   private static final String ORDVIDEODOMAIN_EDIT_RENDERER_KEY = "oracle_ord_im_OrdVideoDomain_EditRenderer";
/*    */   private static final String ORDDOCDOMAIN_EDIT_RENDERER_KEY = "oracle_ord_im_OrdDocDomain_EditRenderer";
/*    */   
/*    */   public static void registerRenderer(HttpSession session)
/*    */   {
/* 57 */     registerRenderer(new AbstractMap()
/*    */     {
/*    */       public Object put(Object key, Object value)
/*    */       {
/* 61 */         this.val$session.setAttribute(key.toString(), value);
/* 62 */         return value;
/*    */       }
/*    */       
/*    */       public Set entrySet()
/*    */       {
/* 67 */         return null;
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public static void registerRenderer(Map sessionScope)
/*    */   {
/* 74 */     sessionScope.put("oracle_ord_im_OrdImageDomain_Renderer", "oracle.ord.html.OrdBuildURLRenderer");
/* 75 */     sessionScope.put("oracle_ord_im_OrdAudioDomain_Renderer", "oracle.ord.html.OrdBuildURLRenderer");
/* 76 */     sessionScope.put("oracle_ord_im_OrdVideoDomain_Renderer", "oracle.ord.html.OrdBuildURLRenderer");
/* 77 */     sessionScope.put("oracle_ord_im_OrdDocDomain_Renderer", "oracle.ord.html.OrdBuildURLRenderer");
/*    */     
/* 79 */     sessionScope.put("oracle_ord_im_OrdImageDomain_EditRenderer", "oracle.ord.html.OrdUploadFileRenderer");
/* 80 */     sessionScope.put("oracle_ord_im_OrdAudioDomain_EditRenderer", "oracle.ord.html.OrdUploadFileRenderer");
/* 81 */     sessionScope.put("oracle_ord_im_OrdVideoDomain_EditRenderer", "oracle.ord.html.OrdUploadFileRenderer");
/* 82 */     sessionScope.put("oracle_ord_im_OrdDocDomain_EditRenderer", "oracle.ord.html.OrdUploadFileRenderer");
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\ORDRegisterer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */