/*     */ package oracle.jbo.http;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import oracle.jbo.client.Configuration;
/*     */ import oracle.jbo.common.Diagnostic;
/*     */ import oracle.jbo.common.JboEnvUtil;
/*     */ import oracle.jbo.common.PropertyMetadata;
/*     */ import oracle.jbo.common.ampool.PoolMgr;
/*     */ import oracle.jbo.common.ampool.SessionCookie;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpSessionCookieHelperImpl
/*     */   implements HttpSessionCookieHelper
/*     */ {
/*     */   public String readCookieValue(HttpServletRequest request, String applicationName)
/*     */   {
/*  44 */     return readCookieValueInternal(request, request.getCookies(), applicationName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String readCookieValue(Cookie[] cookies, String applicationName)
/*     */   {
/*  52 */     return readCookieValueInternal(null, cookies, applicationName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String readCookieValueInternal(HttpServletRequest request, Cookie[] cookies, String applicationName)
/*     */   {
/*  60 */     String cookieName = null;
/*     */     try
/*     */     {
/*  63 */       cookieName = URLEncoder.encode(applicationName, "UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  70 */     String cookieValue = null;
/*     */     
/*  72 */     Cookie cookie = null;
/*     */     
/*  74 */     if (cookies != null)
/*     */     {
/*  76 */       for (int i = 0; i < cookies.length; i++)
/*     */       {
/*  78 */         if (cookies[i].getName().equals(cookieName))
/*     */         {
/*  80 */           cookie = cookies[i];
/*  81 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  86 */     if (cookie != null)
/*     */     {
/*  88 */       cookieValue = cookie.getValue();
/*     */ 
/*     */     }
/*  91 */     else if (request != null)
/*     */     {
/*  93 */       cookieValue = request.getParameter(cookieName);
/*     */     }
/*     */     
/*  96 */     String decryptCookieValue = Configuration.getRestoredChecksumValue(cookieValue);
/*     */     
/*     */ 
/*  99 */     return decryptCookieValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeCookieValue(HttpServletResponse response, String applicationName, String cookieValue)
/*     */   {
/* 107 */     int cookieAge = JboEnvUtil.getPropertyAsInt(PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.getName(), Integer.valueOf(PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.getDefault()).intValue());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 112 */     writeCookieValueInternal(response, applicationName, cookieValue, cookieAge);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeCookieValue(HttpServletResponse response, SessionCookie sessionCookie)
/*     */   {
/* 119 */     int cookieAge = PoolMgr.getProperty(PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.getName(), sessionCookie.getEnvironment(), Integer.valueOf(PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.getDefault()).intValue());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     writeCookieValueInternal(response, sessionCookie.getApplicationId(), sessionCookie.getValue(), cookieAge);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeCookieValueInternal(HttpServletResponse response, String applicationName, String cookieValue, int cookieAge)
/*     */   {
/* 138 */     if (response.isCommitted())
/*     */     {
/* 140 */       if (Diagnostic.isOn())
/*     */       {
/* 142 */         Diagnostic.println("WARNING:  Cannot write SessionCookie value to a commited response.");
/*     */       }
/* 144 */       return;
/*     */     }
/*     */     
/*     */ 
/* 148 */     String encCookieValue = Configuration.getChecksumValue(cookieValue);
/* 149 */     String cookieName = null;
/*     */     try
/*     */     {
/* 152 */       cookieName = URLEncoder.encode(applicationName, "UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {}
/*     */     
/*     */ 
/*     */ 
/* 158 */     Cookie cookie = new Cookie(cookieName, encCookieValue);
/*     */     
/*     */ 
/* 161 */     if (cookieAge >= 0)
/*     */     {
/* 163 */       cookie.setMaxAge(cookieAge);
/*     */     }
/*     */     
/* 166 */     response.addCookie(cookie);
/*     */   }
/*     */   
/*     */   public String generateSessionId(HttpSession session)
/*     */   {
/* 171 */     return session.getId();
/*     */   }
/*     */   
/*     */   public String generateSessionId(HttpServletRequest request)
/*     */   {
/* 176 */     return request.getSession(true).getId();
/*     */   }
/*     */   
/*     */   public String encodeURL(String url, SessionCookie[] cookies)
/*     */   {
/* 181 */     String path = null;
/* 182 */     String query = "";
/* 183 */     String amp = "";
/*     */     
/*     */ 
/* 186 */     int question = url.indexOf('?');
/* 187 */     if (question < 0)
/*     */     {
/* 189 */       amp = "?";
/*     */     }
/*     */     else
/*     */     {
/* 193 */       amp = "&";
/*     */     }
/*     */     
/* 196 */     StringBuffer sb = new StringBuffer(url);
/* 197 */     for (int i = 0; i < cookies.length; i++)
/*     */     {
/* 199 */       sb.append(amp);
/* 200 */       sb.append("jbo.ApplicationCookie.");
/* 201 */       sb.append(cookies[i].getApplicationId());
/* 202 */       sb.append('=');
/* 203 */       sb.append(cookies[i].getValue());
/* 204 */       amp = "&";
/*     */     }
/*     */     
/* 207 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpSessionCookieHelperImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */