/*    */ package oracle.jbo.http;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.jbo.common.ampool.ApplicationPool;
/*    */ import oracle.jbo.common.ampool.EnvInfoProvider;
/*    */ import oracle.jbo.common.ampool.OCIEnvInfoProvider;
/*    */ import oracle.jbo.common.ampool.SessionCookie;
/*    */ import oracle.jbo.common.ampool.SessionCookieFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OCISessionCookieFactory
/*    */   implements SessionCookieFactory
/*    */ {
/* 41 */   private HttpSessionCookieFactory mFactory = new HttpSessionCookieFactory();
/*    */   
/*    */ 
/*    */   public SessionCookie createSessionCookie(String name, String value, ApplicationPool pool, Properties properties)
/*    */   {
/* 46 */     SessionCookie cookie = this.mFactory.createSessionCookie(name, value, pool, properties);
/*    */     
/*    */ 
/* 49 */     if (properties != null)
/*    */     {
/* 51 */       HttpServletRequest request = (HttpServletRequest)properties.get("jbo.http.httprequest");
/*    */       
/*    */ 
/* 54 */       if (request != null)
/*    */       {
/*    */ 
/*    */ 
/* 58 */         Hashtable env = pool.getEnvironment();
/* 59 */         String ociUserName = (String)env.get("user");
/*    */         
/*    */ 
/* 62 */         String ociPassword = (String)env.get("password");
/*    */         
/*    */ 
/*    */ 
/*    */ 
/* 67 */         Map sessionScope = ADFContext.getCurrent().getSessionScope();
/* 68 */         String proxyUserName = (String)sessionScope.get("user");
/*    */         
/*    */ 
/* 71 */         String proxyPassword = (String)sessionScope.get("password");
/*    */         
/*    */ 
/* 74 */         EnvInfoProvider provider = new OCIEnvInfoProvider(ociUserName, ociPassword, proxyUserName, proxyPassword);
/*    */         
/*    */ 
/* 77 */         cookie.setEnvInfoProvider(provider);
/*    */       }
/*    */     }
/*    */     
/* 81 */     return cookie;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\OCISessionCookieFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */