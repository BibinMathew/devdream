/*    */ package oracle.jbo.http;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import oracle.jbo.ApplicationModule;
/*    */ import oracle.jbo.common.ampool.ApplicationPool;
/*    */ import oracle.jbo.common.ampool.RemoteCookieHelper;
/*    */ import oracle.jbo.common.ampool.RemotePoolCookie;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpRemoteSessionCookieImpl
/*    */   extends HttpSessionCookieImpl
/*    */   implements RemotePoolCookie
/*    */ {
/*    */   private static final long serialVersionUID = 8938562033335165821L;
/* 29 */   private RemoteCookieHelper mHelper = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HttpRemoteSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool)
/*    */   {
/* 39 */     super(applicationId, sessionId, pool);
/*    */     
/* 41 */     this.mHelper = new RemoteCookieHelper(pool.getEnvironment(), pool.getConnectionStrategy());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HttpRemoteSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool, Principal userPrincipal, HttpServletRequest request)
/*    */   {
/* 52 */     super(applicationId, sessionId, pool, userPrincipal, request);
/*    */     
/* 54 */     this.mHelper = new RemoteCookieHelper(pool.getEnvironment(), pool.getConnectionStrategy());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HttpRemoteSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool, Principal userPrincipal, HttpSession session)
/*    */   {
/* 66 */     super(applicationId, sessionId, pool, userPrincipal, session);
/*    */     
/* 68 */     this.mHelper = new RemoteCookieHelper(pool.getEnvironment(), pool.getConnectionStrategy());
/*    */   }
/*    */   
/*    */ 
/*    */   public ApplicationModule createWorkerApplicationModule()
/*    */   {
/* 74 */     return this.mHelper.createWorkerApplicationModule();
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpRemoteSessionCookieImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */