package oracle.jbo.http;

import oracle.jbo.common.ampool.SessionCookie;

public abstract interface HttpSessionCookie
  extends SessionCookie
{}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpSessionCookie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */