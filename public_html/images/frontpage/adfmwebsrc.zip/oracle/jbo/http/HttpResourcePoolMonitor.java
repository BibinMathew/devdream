/*    */ package oracle.jbo.http;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.Stack;
/*    */ import javax.servlet.ServletContext;
/*    */ import oracle.adf.share.ADFContext;
/*    */ import oracle.adf.share.Environment;
/*    */ import oracle.adf.share.http.ServletADFContext;
/*    */ import oracle.jbo.pool.ResourcePoolManager;
/*    */ import oracle.jbo.pool.ResourcePoolMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpResourcePoolMonitor
/*    */   extends ResourcePoolMonitor
/*    */ {
/* 42 */   private WeakReference mServletContextRef = null;
/*    */   
/*    */ 
/*    */ 
/*    */   public HttpResourcePoolMonitor(ResourcePoolManager manager, ClassLoader loader, long interval)
/*    */   {
/* 48 */     super(manager, loader, interval);
/*    */     
/* 50 */     Environment env = ADFContext.getCurrent().getEnvironment();
/* 51 */     Object servletContext = env.getContext();
/* 52 */     if ((servletContext instanceof ServletContext))
/*    */     {
/* 54 */       this.mServletContextRef = new WeakReference(servletContext);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void initializeThreadContext(Stack holder)
/*    */   {
/* 60 */     super.initializeThreadContext(holder);
/*    */     
/* 62 */     if (this.mServletContextRef != null)
/*    */     {
/* 64 */       ServletADFContext.initThreadContext((ServletContext)this.mServletContextRef.get(), null, null);
/*    */       
/*    */ 
/* 67 */       holder.push(Boolean.TRUE);
/*    */     }
/*    */     else
/*    */     {
/* 71 */       holder.push(Boolean.FALSE);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void resetThreadContext(Stack holder)
/*    */   {
/* 77 */     if (((Boolean)holder.pop()).booleanValue())
/*    */     {
/* 79 */       ServletADFContext.resetThreadContext();
/*    */     }
/*    */     
/* 82 */     super.resetThreadContext(holder);
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpResourcePoolMonitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */