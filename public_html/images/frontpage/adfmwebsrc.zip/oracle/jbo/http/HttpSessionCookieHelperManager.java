/*    */ package oracle.jbo.http;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionCookieHelperManager
/*    */ {
/* 19 */   private static HttpSessionCookieHelper mHelper = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static synchronized HttpSessionCookieHelper getHttpSessionCookieHelper()
/*    */   {
/* 27 */     if (mHelper == null)
/*    */     {
/* 29 */       mHelper = new HttpSessionCookieHelperImpl();
/*    */     }
/*    */     
/* 32 */     return mHelper;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpSessionCookieHelperManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */