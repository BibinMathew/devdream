package oracle.jbo.http;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import oracle.jbo.common.ampool.SessionCookie;

public abstract interface HttpSessionCookieHelper
{
  public abstract String readCookieValue(HttpServletRequest paramHttpServletRequest, String paramString);
  
  public abstract String readCookieValue(Cookie[] paramArrayOfCookie, String paramString);
  
  /**
   * @deprecated
   */
  public abstract void writeCookieValue(HttpServletResponse paramHttpServletResponse, String paramString1, String paramString2);
  
  public abstract void writeCookieValue(HttpServletResponse paramHttpServletResponse, SessionCookie paramSessionCookie);
  
  public abstract String generateSessionId(HttpServletRequest paramHttpServletRequest);
  
  public abstract String generateSessionId(HttpSession paramHttpSession);
  
  public abstract String encodeURL(String paramString, SessionCookie[] paramArrayOfSessionCookie);
}


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpSessionCookieHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */