/*    */ package oracle.jbo.http;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpRemoteSessionCookieFactory
/*    */   extends HttpSessionCookieFactory
/*    */ {
/*    */   public Class getSessionCookieClass()
/*    */   {
/* 23 */     return HttpRemoteSessionCookieImpl.class;
/*    */   }
/*    */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpRemoteSessionCookieFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */