/*     */ package oracle.jbo.http;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpUtil
/*     */ {
/*     */   public static String getFullServletPath(HttpServletRequest httpRequest)
/*     */   {
/*  47 */     String servletPath = httpRequest.getServletPath();
/*     */     
/*  49 */     if (!_sLookedForContextPath)
/*     */     {
/*     */       try
/*     */       {
/*  53 */         _sGetContextPath = HttpServletRequest.class.getMethod("getContextPath", null);
/*     */       }
/*     */       catch (Exception e) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */       _sLookedForContextPath = true;
/*     */     }
/*     */     
/*  64 */     Method method = _sGetContextPath;
/*     */     
/*  66 */     if (method != null)
/*     */     {
/*     */       try
/*     */       {
/*  70 */         String contextPath = (String)method.invoke(httpRequest, null);
/*     */         
/*     */ 
/*  73 */         servletPath = contextPath + servletPath;
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */     return servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setNoCacheHeaders(HttpServletResponse response)
/*     */   {
/*  92 */     response.setHeader("Cache-Control", "no-cache");
/*  93 */     response.setHeader("Pragma", "no-cache");
/*  94 */     response.setHeader("Expires", "-1");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Locale determineLocale(ServletRequest request)
/*     */   {
/* 105 */     Locale locale = null;
/*     */     
/* 107 */     if ((request instanceof HttpServletRequest))
/*     */     {
/* 109 */       HttpServletRequest httpRequest = (HttpServletRequest)request;
/*     */       
/* 111 */       locale = _getAcceptLanguagesLocale(httpRequest.getHeader("Accept-Language"));
/*     */       
/*     */ 
/* 114 */       if (locale == null)
/*     */       {
/* 116 */         locale = _getAcceptCharSetsLocale(httpRequest.getHeader("Accept-Charset"));
/*     */       }
/*     */       
/*     */ 
/* 120 */       if ((locale != null) && ("".equals(locale.getCountry())))
/*     */       {
/* 122 */         Locale defaultLocale = Locale.getDefault();
/* 123 */         if (locale.getLanguage().equals(defaultLocale.getLanguage())) {
/* 124 */           locale = defaultLocale;
/*     */         }
/*     */       }
/*     */     }
/* 128 */     return locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validateEncoding(String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 141 */     if (encoding != null)
/*     */     {
/*     */ 
/* 144 */       new String(_sTestBytes, encoding);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String decodeRequestParameter(String string, String encoding, byte[] buffer)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 165 */     if (encoding == null)
/* 166 */       return string;
/* 167 */     if (string == null) {
/* 168 */       return null;
/*     */     }
/* 170 */     int stringLength = string.length();
/*     */     
/* 172 */     if ((buffer == null) || (stringLength > buffer.length)) {
/* 173 */       buffer = new byte[stringLength];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 178 */     string.getBytes(0, stringLength, buffer, 0);
/*     */     
/* 180 */     return new String(buffer, 0, stringLength, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Locale _getAcceptLanguagesLocale(String acceptLanguages)
/*     */   {
/* 188 */     if (acceptLanguages != null)
/*     */     {
/* 190 */       float highestWeight = 0.0F;
/* 191 */       String highestLang = null;
/*     */       
/* 193 */       StringTokenizer langs = new StringTokenizer(acceptLanguages, ",");
/*     */       
/* 195 */       while ((langs.hasMoreTokens()) && (highestWeight < 1.0F))
/*     */       {
/*     */ 
/* 198 */         String currToken = langs.nextToken();
/* 199 */         float currQ = 1.0F;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 204 */         String currLang = currToken;
/*     */         
/* 206 */         int qSepIndex = currToken.indexOf(';');
/*     */         
/* 208 */         if (qSepIndex != -1)
/*     */         {
/* 210 */           currLang = currLang.substring(0, qSepIndex);
/*     */           
/* 212 */           int tokenLength = currToken.length();
/*     */           
/* 214 */           qSepIndex++;
/*     */           
/* 216 */           if (qSepIndex < tokenLength)
/*     */           {
/* 218 */             String qString = currToken.substring(qSepIndex, tokenLength);
/* 219 */             qString.trim();
/*     */             
/* 221 */             if (qString.length() > 0)
/*     */             {
/*     */               try
/*     */               {
/* 225 */                 currQ = Float.valueOf(qString).floatValue();
/*     */               }
/*     */               catch (NumberFormatException e) {}
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 235 */         if (currQ > highestWeight)
/*     */         {
/* 237 */           highestWeight = currQ;
/* 238 */           highestLang = currLang.trim();
/*     */         }
/*     */       }
/*     */       
/* 242 */       if (highestLang != null)
/*     */       {
/* 244 */         return _createLocale(highestLang);
/*     */       }
/*     */     }
/*     */     
/* 248 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Locale _createLocale(String localeString)
/*     */   {
/* 259 */     String language = localeString;
/* 260 */     String territory = "";
/* 261 */     String variant = "";
/*     */     
/* 263 */     int territoryIndex = language.indexOf('-');
/*     */     
/* 265 */     if (territoryIndex != -1)
/*     */     {
/* 267 */       language = language.substring(0, territoryIndex);
/*     */       
/* 269 */       territoryIndex++;
/*     */       
/* 271 */       territory = localeString.substring(territoryIndex);
/*     */       
/* 273 */       int variantIndex = territory.indexOf('-');
/*     */       
/* 275 */       if (variantIndex != -1)
/*     */       {
/* 277 */         variant = territory.substring(variantIndex + 1);
/* 278 */         territory = territory.substring(0, variantIndex);
/*     */       }
/*     */     }
/*     */     
/* 282 */     return new Locale(language, territory, variant);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Locale _getAcceptCharSetsLocale(String acceptCharsets)
/*     */   {
/* 294 */     Locale currLocale = null;
/*     */     
/* 296 */     if ((acceptCharsets != null) && (!"*".equals(acceptCharsets)))
/*     */     {
/* 298 */       StringTokenizer charsets = new StringTokenizer(acceptCharsets, ",");
/*     */       
/* 300 */       while ((currLocale == null) && (charsets.hasMoreTokens()))
/*     */       {
/*     */ 
/* 303 */         String currCharset = charsets.nextToken();
/*     */         
/* 305 */         currLocale = (Locale)CHARSET_TO_LOCALE_MAP.get(currCharset);
/*     */       }
/*     */     }
/*     */     
/* 309 */     return currLocale;
/*     */   }
/*     */   
/* 312 */   private static final Hashtable CHARSET_TO_LOCALE_MAP = new Hashtable();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 319 */     CHARSET_TO_LOCALE_MAP.put("ISO-8859-1", Locale.US);
/*     */   }
/*     */   
/*     */ 
/* 323 */   private static boolean _sLookedForContextPath = false;
/*     */   
/*     */   private static Method _sGetContextPath;
/* 326 */   private static final byte[] _sTestBytes = { 65 };
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */