/*     */ package oracle.jbo.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.security.Principal;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import oracle.adf.share.ADFContext;
/*     */ import oracle.adf.share.Environment;
/*     */ import oracle.jbo.ApplicationModule;
/*     */ import oracle.jbo.common.TransactionControl;
/*     */ import oracle.jbo.common.ampool.ApplicationPool;
/*     */ import oracle.jbo.common.ampool.SessionCookieImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpSessionCookieImpl
/*     */   extends SessionCookieImpl
/*     */   implements HttpSessionCookie, BindingListener, Serializable
/*     */ {
/*     */   static final long serialVersionUID = -5336195329607336406L;
/*  75 */   private boolean mInSuspend = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool)
/*     */   {
/*  85 */     this(applicationId, sessionId, pool, null, (HttpSession)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public HttpSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool, Principal userPrincipal, HttpServletRequest request)
/*     */   {
/* 104 */     this(applicationId, sessionId, pool, userPrincipal, (HttpSession)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public HttpSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool, Principal userPrincipal, HttpSession session)
/*     */   {
/* 124 */     this(applicationId, sessionId, pool, userPrincipal);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpSessionCookieImpl(String applicationId, String sessionId, ApplicationPool pool, Principal userPrincipal)
/*     */   {
/* 133 */     super(applicationId, sessionId, pool, userPrincipal);
/*     */     
/* 135 */     setSingleThreaded(false);
/*     */     
/* 137 */     ADFContext adfContext = ADFContext.getCurrent();
/* 138 */     String value = readValue(adfContext.hasEnvironment() ? adfContext.getEnvironment().getRequest() : null);
/*     */     
/*     */ 
/*     */ 
/* 142 */     if ((value != null) && (value.length() > 0))
/*     */     {
/* 144 */       setPassivationId(new Integer(value).intValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void valueBound(BindingEvent ev) {}
/*     */   
/*     */ 
/*     */   public void valueUnbound(BindingEvent ev)
/*     */   {
/* 155 */     timeout();
/*     */   }
/*     */   
/*     */   public void timeout(BindingEvent ev)
/*     */   {
/* 160 */     timeout();
/*     */   }
/*     */   
/*     */   public void writeValue(Object sink)
/*     */   {
/* 165 */     writeValue(sink, getValue());
/*     */   }
/*     */   
/*     */   public void writeValue(Object sink, String value)
/*     */   {
/* 170 */     if (((sink instanceof HttpServletResponse)) && (isWriteCookieValue()))
/*     */     {
/* 172 */       HttpServletResponse response = (HttpServletResponse)sink;
/*     */       
/* 174 */       HttpSessionCookieHelper helper = HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
/*     */       
/* 176 */       helper.writeCookieValue(response, "jbo.ApplicationCookie." + getApplicationId(), getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String readValue(Object source)
/*     */   {
/* 184 */     String value = null;
/* 185 */     if ((source != null) && ((source instanceof HttpServletRequest)))
/*     */     {
/* 187 */       synchronized (source)
/*     */       {
/* 189 */         HttpServletRequest request = (HttpServletRequest)source;
/* 190 */         HttpSessionCookieHelper helper = HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
/* 191 */         value = helper.readCookieValue(request, "jbo.ApplicationCookie." + getApplicationId());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 196 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void beforeApplicationModuleRelease(ApplicationModule am)
/*     */   {
/* 204 */     this.mInSuspend = true;
/* 205 */     if ((am instanceof TransactionControl))
/*     */     {
/* 207 */       ((TransactionControl)am).suspend();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void afterApplicationModuleRelease()
/*     */   {
/* 213 */     this.mInSuspend = false;
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationModule useApplicationModule(boolean lock, long waitTimeout)
/*     */   {
/* 219 */     synchronized (getSyncLock())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 224 */       ApplicationModule am = super.useApplicationModule(lock, waitTimeout);
/* 225 */       if ((!this.mInSuspend) && ((am instanceof TransactionControl)))
/*     */       {
/* 227 */         ((TransactionControl)am).resume();
/*     */       }
/* 229 */       return am;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Users\mrybak.ORADEV\Desktop\!WORK\CX\!decompiled_sources\adfmweb.jar!\oracle\jbo\http\HttpSessionCookieImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */